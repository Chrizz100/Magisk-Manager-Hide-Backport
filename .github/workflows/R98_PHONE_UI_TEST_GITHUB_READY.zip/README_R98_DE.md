# R9.8 – Eigenständig installierbare Magisk-Manager-UI-Test-App

**Stand:** 9. November 2026  
**GitHub-Repository:** `Chrizz100/Magisk-Manager-Hide-Backport`  
**Neuer Workflow:** `.github/workflows/R98_PHONE_UI_TEST.yml`

## Ziel

Auf dem Redmi Note 10 Pro (`sweet`, Android 13) ist Magisk Alpha mit Versionscode 31100 aktiv. Das Root-Binary funktioniert, aber andere Apps erkennen die Root-Umgebung. Der bisherige R9.7-Workflow hat auf dem offiziellen Android-13-Emulator ein komplettes Manager-Hide/Restore-Szenario erfolgreich durchlaufen. Dieses Ergebnis ist **noch kein Nachweis für die Zusammenarbeit mit Magisk Alpha** und kein Test gegen die Root-Erkennung von Banking-Apps.

R9.8 erzeugt deshalb eine **separate App ausschließlich für den ersten Installations- und Oberflächentest**. Sie kann neben einer unter anderer Paketkennung installierten Alpha-App existieren. Sie verwendet ausdrücklich die neue Android-Paketkennung:

`org.chrizz100.magiskhide.uitest`

Ihr sichtbarer Name lautet **MH R9.8 UI Test (No Root)**. Ihr voreingestellter libsu-Shell-Modus ist `Shell.FLAG_NON_ROOT_SHELL` statt des bisherigen Root-Modus.

Die App ist **kein voll funktionsfähiger Magisk-Alpha-Manager**, darf **kein Android-Boot-Image installieren** und beweist **keine Umgehung von Root-Erkennung**. Sie ist für das Öffnen, Navigieren und Schließen der Benutzeroberfläche vorgesehen. **Die Schaltflächen Install, Uninstall und Hide nicht betätigen.**

## GitHub-Vorgehen ohne PC

1. Öffne `https://github.com/Chrizz100/Magisk-Manager-Hide-Backport` im Browser.
2. Navigiere zu `.github/workflows` und lade die neue Datei `R98_PHONE_UI_TEST.yml` als **zusätzliche Workflow-Datei** hoch. Die bisherige `R6_build.yml` **nicht ersetzen**.
3. Wechsle zu **Actions → Magisk Manager-Hide R9.8 - Isolated Non-Root UI APK for Phone → Run workflow**.
4. Der Workflow führt zuerst die unveränderten R9.7-Prüfungen erneut aus. Anschließend erzeugt er die eigenständige UI-Test-APK und prüft sie in einem **zweiten Android-13-Emulator**. Nur bei erfolgreichem UI-Test wird ein APK-Artefakt veröffentlicht.
5. Nach erfolgreichem Lauf das Actions-Artefakt `R98_SEPARATE_UI_ONLY_PHONE_TEST_APK` herunterladen und entpacken. Es enthält `R98_UI_ONLY_NOT_ROOT.apk`, die Prüfsumme `SHA256.txt` und `READ_ME_FIRST.txt`.
6. Die APK **erst nach erfolgreicher GitHub-Prüfung und Beachtung der Sicherheitswarnungen** auf dem Smartphone installieren, dann nur die Start- und Einstellungsseiten öffnen.

GitHub Actions stellt nicht von selbst eine fertige APK bereit, solange der neue Workflow nicht gestartet und erfolgreich beendet wurde. Das hier gelieferte ZIP enthält **Quell-YAML und Prüfscripte**, keine APK.

## Prüf- und Sicherheitsgrenzen

- R9.7-Original-Workflow `.github/workflows/R6_build.yml` bleibt unverändert.
- Die R9.7-Quellrekonstruktion, Native-Tests, GUI und Hide/Restore-Emulatorprüfung laufen im neuen Workflow zuerst unverändert durch und müssen bestehen.
- Der isolierte UI-Build ändert nur `applicationId`, die gekoppelte BuildConfig-Paketkennung, das Anwendungslabel und den Root-Shell-Modus. Der Test-Build wird aus denselben festgelegten Magisk-Quellen generiert.
- Der neue APK-Build muss über `aapt2` die neue Paketkennung und über `apksigner` eine gültige Signatur nachweisen. Die temporäre CI-Signatur wird **nicht** als privater Schlüssel exportiert.
- Der zweite Emulator-Test prüft Installation **ohne Ersetzen**, Startbildschirm, Einstellungen und Rückkehr zum Startbildschirm. Er nutzt kein Root und führt kein Manager-Hide aus.
- Vorhandene Alpha-Module, Kernel, ZygiskNext, Magisk-Konfiguration und Root-Berechtigungen werden auf dem Smartphone durch das Erzeugen der APK **nicht verändert**.
- Sollte das Smartphone die App-Installation verweigern (z. B. der zuvor beobachtete Android-Paketdienstfehler), nicht Magisk Alpha deinstallieren oder Einstellungen auf Verdacht ändern.
- Wegen des **pro Lauf neu generierten Zertifikats** kann ein späterer Test-Build nicht einfach als Update über eine vorherige R9.8-Test-App installiert werden. Allenfalls **die separate UI-Test-App**, niemals Magisk Alpha, darf später deinstalliert werden.

## Tatsächlicher Arbeitsstand

Das neue Workflow-Artefakt wurde lokal strukturell und syntaktisch geprüft; der ursprüngliche R9.7-Workflow wurde bytegenau erhalten. Die getrennte UI-App wurde **noch nicht vollständig auf GitHub kompiliert und noch nicht auf dem echten Smartphone installiert**. Ein Root-/Hide-/Restore-Test **mit Magisk Alpha 31100** steht weiterhin aus.
