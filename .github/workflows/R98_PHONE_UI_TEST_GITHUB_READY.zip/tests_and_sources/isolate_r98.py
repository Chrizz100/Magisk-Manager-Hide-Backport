#!/usr/bin/env python3
"""R9.8: separate package, display label and non-root-only shell for UI testing.

Runs only after the original R9.7 full emulator PASS, and ONLY in the
fresh working checkout. Does not change the user's existing R6_build.yml.
"""
from __future__ import annotations
import hashlib
import json
import re
import sys
from pathlib import Path

PKG = 'org.chrizz100.magiskhide.uitest'
LABEL = 'MH R9.8 UI Test (No Root)'


def replace_exact(path: Path, old: str, new: str) -> tuple[str, str]:
    raw = path.read_text(encoding='utf-8')
    assert raw.count(old) == 1, f'{path}: expected one exact pinned anchor, found {raw.count(old)}: {old[:100]}'
    replaced = raw.replace(old, new, 1)
    path.write_text(replaced, encoding='utf-8')
    return (hashlib.sha256(raw.encode()).hexdigest(), hashlib.sha256(replaced.encode()).hexdigest())


def apply(base: Path, report: Path) -> dict:
    base = base.resolve()
    assert (base / 'app' / 'build-logic' / 'src' / 'main' / 'java' / 'Setup.kt').is_file(), 'Expected pinned Magisk source tree missing'
    assert (base / 'app' / 'core' / 'src' / 'main' / 'java' / 'com' / 'topjohnwu' / 'magisk' / 'core' / 'AppContext.kt').is_file()
    setup = base / 'app/build-logic/src/main/java/Setup.kt'
    core = base / 'app/core/build.gradle.kts'
    context = base / 'app/core/src/main/java/com/topjohnwu/magisk/core/AppContext.kt'
    manifest = base / 'app/apk/src/main/AndroidManifest.xml'
    files = {}
    files['setup'] = replace_exact(setup,
        'applicationId = "com.topjohnwu.magisk"',
        f'applicationId = "{PKG}"')
    files['core'] = replace_exact(core,
        'buildConfigField("String", "APP_PACKAGE_NAME", "\\"com.topjohnwu.magisk\\"")',
        f'buildConfigField("String", "APP_PACKAGE_NAME", "\\"{PKG}\\"")')
    files['context'] = replace_exact(context,
        '.setFlags(Shell.FLAG_MOUNT_MASTER)',
        '.setFlags(Shell.FLAG_NON_ROOT_SHELL)')
    files['manifest'] = replace_exact(manifest,
        '<application android:localeConfig="@xml/locale_config">',
        f'<application android:localeConfig="@xml/locale_config" android:label="{LABEL}" tools:replace="android:label">')
    # Verify that no original package identifier is used for app ID or exported
    # BuildConfig package, but keep the original Java namespace unchanged.
    assert f'applicationId = "{PKG}"' in setup.read_text()
    assert f'APP_PACKAGE_NAME", "\\"{PKG}\\"' in core.read_text()
    assert '.setFlags(Shell.FLAG_NON_ROOT_SHELL)' in context.read_text()
    assert '.setFlags(Shell.FLAG_MOUNT_MASTER)' not in context.read_text()
    assert LABEL in manifest.read_text()
    from xml.etree import ElementTree as ET
    ET.parse(manifest)
    out = {'purpose': 'UI-only, NO root, NO manager hide, NO root/Alpha compatibility',
           'package': PKG, 'label': LABEL, 'key_policy': 'ephemeral CI research signing key, not exported',
           'root_shell_mode': 'Shell.FLAG_NON_ROOT_SHELL',
           'baseline_pinned_magisk': '0972f67d97f9b6302b67c5171283330c74114b4a',
           'files_sha256_before_after': {k:{'before':a,'after':b} for k,(a,b) in files.items()}}
    report.parent.mkdir(parents=True,exist_ok=True)
    report.write_text(json.dumps(out, indent=2) + '\n',encoding='utf-8')
    return out


if __name__=='__main__':
    if len(sys.argv)!=3:
        sys.exit('Usage: isolate_r98.py PINNED_MAGISK_DIR REPORT_JSON')
    print('R9.8 isolated source configuration:',json.dumps(apply(Path(sys.argv[1]),Path(sys.argv[2])),sort_keys=True))
