#!/usr/bin/env bash
# Emulator only: deliberately never call `su`, `magisk --sqlite`, or `build.py emulator`.
set -Eeuo pipefail
PKG='org.chrizz100.magiskhide.uitest'
APK="$GITHUB_WORKSPACE/dist/R98_UI_ONLY_NOT_ROOT.apk"
REP="$GITHUB_WORKSPACE/reports/r98_ui"
mkdir -p "$REP"
fail() { printf '%s\n' "$*" | tee "$REP/FAILURE.txt" >&2; exit 1; }
[[ -s "$APK" ]] || fail 'R98 APK absent'
[[ "$(adb shell getprop ro.build.version.sdk | tr -d '\r')" == '33' ]] || fail 'Require Android 13 emulator'
[[ "$(adb shell getprop ro.kernel.qemu | tr -d '\r')" == '1' ]] || fail 'Refusing non-emulator target'
[[ "$(adb devices | awk 'NR>1 && $2=="device"{print $1}' | wc -l)" -eq 1 ]] || fail 'Not exactly one emulator'
[[ "$(adb devices | awk 'NR>1 && $2=="device"{print $1}')" == emulator-* ]] || fail 'Non-emulator serial'
# Install without -r; no other installed app can be replaced.
adb install "$APK" | tee "$REP/install.txt"
adb shell pm path "$PKG" | tee "$REP/package_path.txt" | grep -F 'package:' >/dev/null || fail 'Isolated package not installed'
# Notification prompt can cover UI in Android 13. Grant only on throwaway emulator.
adb shell pm grant "$PKG" android.permission.POST_NOTIFICATIONS >"$REP/notification.txt" 2>&1 || true
adb shell am start -W -n "$PKG/com.topjohnwu.magisk.ui.MainActivity" | tee "$REP/launch.txt"
sleep 6
get_ui() {
  local name="$1" found=0
  for attempt in 1 2 3 4 5; do
    adb shell uiautomator dump "/sdcard/r98_${name}.xml" >"$REP/${name}_dump_${attempt}.txt" 2>&1 || true
    if adb pull "/sdcard/r98_${name}.xml" "$REP/${name}.xml" >"$REP/${name}_pull_${attempt}.txt" 2>&1; then
      if python3 - "$REP/${name}.xml" <<'PYXML'
import sys,xml.etree.ElementTree as E
r=E.parse(sys.argv[1]).getroot()
labels=[v for el in r.iter() for field in ('text','content-desc') if (v:=el.get(field))]
assert 'Home' in labels and 'Magisk' in labels
PYXML
      then found=1; break; fi
    fi
    sleep 3
  done
  [[ "$found" -eq 1 ]] || fail "No functional Magisk UI hierarchy: ${name}"
}
get_ui home
adb shell input tap 900 2236
sleep 3
# The Settings page is present in the genuine app; no root functions called.
for attempt in 1 2 3 4 5; do
  adb shell uiautomator dump /sdcard/r98_settings.xml >"$REP/settings_dump_${attempt}.txt" 2>&1 || true
  adb pull /sdcard/r98_settings.xml "$REP/settings.xml" >"$REP/settings_pull_${attempt}.txt" 2>&1 || true
  if python3 - "$REP/settings.xml" <<'PYXML'
import sys,xml.etree.ElementTree as E
r=E.parse(sys.argv[1]).getroot()
t={v for el in r.iter() for f in ('text','content-desc') if (v:=el.get(f))}
assert {'Settings','Customization'} <= t, sorted(t)
PYXML
  then break; fi
  [[ "$attempt" -lt 5 ]] || fail 'Settings screen failed to load'
  sleep 3
done
adb shell input tap 180 2236
sleep 2
get_ui returned_home
adb logcat -d -v brief > "$REP/logcat.txt" 2>&1 || true
python3 - "$REP" <<'PYRESULT'
from pathlib import Path
from xml.etree import ElementTree as ET
import json, sys
p=Path(sys.argv[1]);home=ET.parse(p/'returned_home.xml').getroot()
labels={v for n in home.iter() for f in ('text','content-desc') if (v:=n.get(f))}
assert {'Magisk','Home'}<=labels
# Never claim root compatibility or app concealment from this smoke test.
d={'result':'ISOLATED_UI_PASS','package':'org.chrizz100.magiskhide.uitest',
   'api':33,'install_without_replace':True,'home':True,'settings':True,
   'root_access_tested':False,'manager_hide_tested':False,'alpha_31100_compatibility_tested':False,
   'physical_device_modified':False,'scope':'UI-only on throwaway x86_64 AVD'}
(p/'RESULT.json').write_text(json.dumps(d,indent=2)+'\n')
print('R9.8 separate UI-only emulator PASS; no root, no hide, no physical phone touched')
PYRESULT
