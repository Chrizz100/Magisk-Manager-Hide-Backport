#!/usr/bin/env python3
from pathlib import Path
import importlib.util
import tempfile
import unittest
from xml.etree import ElementTree

FILE=Path(__file__).resolve().parents[1]/'scripts/isolate_r98.py'
spec=importlib.util.spec_from_file_location('r98_isolate', FILE)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class R98Fixture(unittest.TestCase):
    def fixture(self,path, *, duplicate=False):
        b=Path(path)
        files={
            'app/build-logic/src/main/java/Setup.kt': 'fun setupMainApk() { applicationId = "com.topjohnwu.magisk" }',
            'app/core/build.gradle.kts': 'buildConfigField("String", "APP_PACKAGE_NAME", "\\"com.topjohnwu.magisk\\"")',
            'app/core/src/main/java/com/topjohnwu/magisk/core/AppContext.kt': 'Shell.Builder.create().setFlags(Shell.FLAG_MOUNT_MASTER).setTimeout(2)',
            'app/apk/src/main/AndroidManifest.xml': '<?xml version="1.0" encoding="UTF-8"?><manifest xmlns:android="http://schemas.android.com/apk/res/android" xmlns:tools="http://schemas.android.com/tools"><application android:localeConfig="@xml/locale_config"></application></manifest>',
        }
        for name,val in files.items():
            p=b/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(val if not duplicate else val+val)
        return b

    def test_success(self):
        with tempfile.TemporaryDirectory() as d:
            b=self.fixture(d)
            r=m.apply(b,b/'report.json')
            self.assertEqual(r['package'],'org.chrizz100.magiskhide.uitest')
            self.assertEqual(r['root_shell_mode'],'Shell.FLAG_NON_ROOT_SHELL')
            self.assertEqual(len(r['files_sha256_before_after']),4)
            self.assertIn('org.chrizz100.magiskhide.uitest',(b/'app/build-logic/src/main/java/Setup.kt').read_text())
            self.assertIn('org.chrizz100.magiskhide.uitest',(b/'app/core/build.gradle.kts').read_text())
            self.assertNotIn('Shell.FLAG_MOUNT_MASTER',(b/'app/core/src/main/java/com/topjohnwu/magisk/core/AppContext.kt').read_text())
            ElementTree.parse(b/'app/apk/src/main/AndroidManifest.xml')

    def test_no_duplicate_anchors(self):
        with tempfile.TemporaryDirectory() as d:
            b=self.fixture(d,duplicate=True)
            with self.assertRaises(AssertionError):m.apply(b,b/'report.json')

    def test_already_isolated_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            b=self.fixture(d);m.apply(b,b/'report.json')
            with self.assertRaises(AssertionError):m.apply(b,b/'report2.json')

    def test_original_baseline_not_mutated(self):
        import hashlib
        p=Path('/mnt/data/R6_build.yml')
        expected=Path('/mnt/data/r98_build/BASELINE_R97_SHA256.txt').read_text().split()[0]
        self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),expected)

    def test_ui_scripts_only_reference_emulator(self):
        s='\n'.join(line for line in (Path(__file__).resolve().parents[1]/'scripts/r98_ui_smoke.sh').read_text().splitlines() if not line.lstrip().startswith('#'))
        assert "'emulator-*'" not in s
        for fragment in ('ro.kernel.qemu','emulator-*','adb install "$APK"','getprop ro.build.version.sdk'):
            self.assertIn(fragment,s)
        for fragment in ('adb root','adb shell su','adb_pm_install','magisk --sqlite','-r "$APK"'):
            self.assertNotIn(fragment,s)

if __name__=='__main__':unittest.main(verbosity=2)
