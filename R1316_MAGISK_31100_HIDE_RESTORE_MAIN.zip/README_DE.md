# Magisk R13.16 – Anleitung

Dies ist ein **neuer Workflow-/Test-Fix** auf dem unveränderten, zuvor grünen Magisk-Build R13.15, keine fertig getestete Geräte-APK.

1. Lade nur `R1316_MAGISK_31100_ANDROID7_TO17_REAL_E2E_CORRECTED.yml` in deine Repository unter `.github/workflows/` hoch.
2. Starte den R13.16-Workflow in GitHub Actions.
3. Werte **alle** Jobs aus. Ein grüner Compile-Job allein ist kein Hide-/Restore-Erfolg. Die 15 Android-UI-Tests und der Root-E2E-Test sind verpflichtend.
4. Die ursprüngliche Magisk-App auf dem Gerät nicht deinstallieren oder überschreiben. Keine Änderungen an Boot oder Root vor vollständiger Gerätekompatibilität.

Zum Nachvollziehen befinden sich in diesem ZIP der exakte Änderungspatch gegenüber R13.15, die zwei realen roten UI-Dumps, die verwendeten Prüfskripte und die Testberichte. Der Magisk-Buildjob wurde **nicht geändert**.
