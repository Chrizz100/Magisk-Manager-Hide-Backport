# Magisk-Manager-Hide-Backport – R13.16: Fehleranalyse und gezielte Korrektur

Stand: 18.11.2026. Referenz: GitHub Actions [Run 44210667014](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44210667014), Workflow R13.15; letzter bei der Analyse gemeldeter Status: **in_progress**, obwohl Root-E2E und Android-17-GUI bereits **failure** hatten. Die Auswertung beruht auf den **heruntergeladenen Originalartefakten**, den betroffenen Joblogs und der exakten Workflow-Datei aus GitHub (Git-Blob-SHA `6974c2438f0f3b1a14072c67043d4b83ef72505c`).

## 1. Wiederholungsursache: Android-13-Root/Hide/Restore

Im Root-AVD aus demselben Build war der native Magisk-Dienst erfolgreich eingerichtet; `su -c id -u` gab `0` zurück. Das tatsächlich laufende `/debug_ramdisk/magisk` war bytegenau identisch zur erwarteten Native-Datei (`0cb325b1d56d2f8fde88970f7ad3e0033cb607e1ade3ba7ca4e3330d511045b9`). Der originale Manager öffnete sich, der Hide-Knopf wurde gefunden und der Hide-Dialog wurde geöffnet.

**Erster echter Fehler:** `HIDE_CONFIRM_NOT_FOUND` / Exit 61. In `confirm_hide.xml` steht tatsächlich ein aktiver Knoten `text="OK"`, `bounds="[842,1323][894,1368]"`. Die alte R13.15-Auswahlfunktion verknüpfte `text + " " + content-desc`, also bei leerem `content-desc` die Zeichenfolge **`"OK "`**. Dagegen kann das reguläre Suchmuster **`^OK$`** nicht passen. Ein vorhandener Knopf wurde als nicht vorhanden gemeldet. Das ist kein Magisk-Hide-Fehler; die nachfolgende echte Paketumbenennung wurde dadurch noch nicht ausgeführt.

**R13.16-Korrektur:** Die emulierte Oberfläche verwendet jetzt `R1316_UI_FIND.py`: `text` und `content-desc` werden **separat** und nach `strip()` geprüft. Nur gültige Grenzen mit positiver Fläche liefern Klickkoordinaten. Der exakt erfasste `confirm_hide.xml` ergibt **868 1345**. Fehlende oder ungültige Knoten bleiben Fehler. Der GitHub-Job führt bereits vor dem Emulatorstart Tests gegen den ursprünglich falschen Textvergleich durch; die lokale Regression verwendet zusätzlich die **Original-XML aus dem roten Lauf**.

## 2. Wiederholungsursache: Android 17 / API 37

Im API-37-Test meldete `adb install`: `Failure calling service package: Broken pipe (32)`. Der CI-Emulator brach wiederholt in **`surfaceflinger`** (`SIGABRT`, Thread `RegionSampling`) ab, konkret mit **`Assertion failed: !rcEnc->featureInfo()->hasReadColorBufferDma`** in `mapper.ranchu.so`. Android bootete teilweise und meldete `sys.boot_completed=1`; das war kein Stabilitätsnachweis.

Eine **einschlägige, separat reproduzierte Upstream-Ursache**: Die bisherige Runner-Version erstellt API-37.0-AVDs unter älteren SDK Command-line Tools teils mit dem falschen `target=android-0`; genau dieser SurfaceFlinger-Absturz ist im [Runner-Issue #482](https://github.com/ReactiveCircus/android-emulator-runner/issues/482) dokumentiert. **Das konkrete `target` aus dem fehlgeschlagenen R13.15-AVD wurde nicht archiviert**, daher ist dieser Zusammenhang eine starke, überprüfbare Hypothese, keine rückwirkend bewiesene Eigenschaft des Runs. In der Upstream-Reproduktion behebt SDK Command-line Tools **22.0** die Fehlkonfiguration; der Fix wurde als [PR #483](https://github.com/ReactiveCircus/android-emulator-runner/pull/483) gemergt.

**R13.16-Korrektur:** Der Matrixjob verwendet den **exakt gepinnten Upstream-Fix-Commit** `660ac26f5bd4cb6c1d98b2143e66ded57bee724f` mit SDK Command-line Tools **22.0**, statt des alten beweglichen `@v2` (20.0). Das vorgeschaltete `pre-emulator-launch-script` prüft bei API 37 vor dem Booten `target=android-37.0` und die SDK-Version. `android-0` wird als Fehler zurückgewiesen. Nach dem Boot werden zwei zeitlich getrennte `surfaceflinger`-PIDs verglichen, damit ein unstabiler Grafikdienst nicht als funktionierendes Android 17 gilt. Android 17 erhält die offiziell geforderten **4 GB RAM**. Die 12-GB-Datenpartition aus R13.15 bleibt erhalten.

## 3. Regressionen und Schutz vor erneuter Fehlfreigabe

- **Die vollständigen 50 Schritte des bestehenden Magisk-Buildjobs bleiben strukturell unverändert.** Keine willkürliche Änderung am Installer, am Nativedienst oder an Signaturprüfungen.
- **Alle 15 Android-7-bis-17-Testkombinationen bleiben Pflicht.** Keine übersprungenen Systemversionen und kein Erfolg ohne tatsächliche Emulatorprüfung.
- **Der Root-/Hide-/Restore-E2E-Test bleibt ein harter Gate.** Er muss echte Paketumbenennung, Root-Autorisierung der versteckten App und Restore nachweisen. Keine künstliche PASS-Ausgabe, kein `continue-on-error`.
- **Das bisherige abschließende Gate bleibt unverändert**, einschließlich DEVICE HOLD und separater Fehlerausweisung.
- **Lokale Tests:** 45/45 Shell-Abschnitte mit `bash -n`, originalgetreue Root-UI-Selbsttests, zwei echte R13.15-XML-Dateien, positive/negative SDK-Metadatentests, exakter 50-Schritte-Buildjob-Vergleich und vollständige Matrix-Validierung. Ergebnis siehe `R1316_REGRESSION_RESULTS.json` und `R1316_LOCAL_VALIDATION.json`.

## 4. Bedeutung für den nächsten Lauf

Diese YAML behebt die **konkret belegten** R13.15-Testprobleme und ermöglicht erstmals eine valide Ausführung der nächsten Hide-Transaktion und des Android-17-Tests. Wenn dort **neue reale Magisk-Fehler** sichtbar werden, bleibt der Job ausdrücklich rot, statt eine funktionsfähige App vorzutäuschen. Der neue GitHub-Lauf ist noch **nicht ausgeführt**; ein garantiertes Grün ist daher nicht belegt.

**Keine Freigabe für die Installation über den bestehenden Magisk-Manager und keine Root-/Boot-Veränderung am physischen Gerät**. Ein bestandener Emulator-E2E-Test ersetzt nicht den sicheren Geräte-Update-/Restore-Weg.
