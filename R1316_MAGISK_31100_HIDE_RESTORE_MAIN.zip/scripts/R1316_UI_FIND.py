#!/usr/bin/env python3
"""R13.16: locate exact visible UI node without merging text and content-desc.
The old selector concatenated 'OK' + ' ' + '' -> 'OK ', breaking ^OK$.
Usage: R1316_UI_FIND.py DUMP_XML REGEX; stdout: two integer coordinates.
"""
import re
import sys
import xml.etree.ElementTree as ET


def find(path, pattern):
    target = re.compile(pattern, re.I)
    root = ET.parse(path).getroot()
    for node in root.iter('node'):
        attrs = node.attrib
        if attrs.get('enabled') == 'false':
            continue
        text = attrs.get('text', '').strip()
        description = attrs.get('content-desc', '').strip()
        if not (target.search(text) or target.search(description)):
            continue
        bounds = re.fullmatch(r'\[\s*(\d+)\s*,\s*(\d+)\s*\]\[\s*(\d+)\s*,\s*(\d+)\s*\]', attrs.get('bounds',''))
        if not bounds:
            continue
        x1,y1,x2,y2 = map(int, bounds.groups())
        if x2 <= x1 or y2 <= y1:
            continue
        return (x1+x2)//2, (y1+y2)//2
    return None


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('Usage: python3 R1316_UI_FIND.py UI_XML REGEX')
    try:
        coordinates = find(sys.argv[1], sys.argv[2])
    except (OSError, ValueError, ET.ParseError, re.error) as error:
        print('R1316_UI_DUMP_OR_SELECTOR_ERROR: '+str(error),file=sys.stderr)
        sys.exit(1)
    if coordinates is None:
        sys.exit(1)
    print(*coordinates)
