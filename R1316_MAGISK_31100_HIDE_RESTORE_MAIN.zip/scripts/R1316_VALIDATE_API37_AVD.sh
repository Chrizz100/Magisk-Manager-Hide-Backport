#!/usr/bin/env bash
set -euo pipefail
api=${1:?API argument required}
if [ "$api" != 37 ]; then
  exit 0
fi
avd="${ANDROID_AVD_HOME:-$HOME/.android/avd}/test.ini"
if [ ! -s "$avd" ]; then
  echo "R1316_API37_AVD_ROOT_INI_MISSING: $avd" >&2
  exit 81
fi
if ! grep -Fxq 'target=android-37.0' "$avd"; then
  echo 'R1316_API37_WRONG_SDK_TARGET: expected android-37.0 (old SDK tools produce android-0)' >&2
  cat "$avd" >&2
  exit 82
fi
version=$(sdkmanager --version 2>/dev/null | grep -Eo '^[0-9][0-9.]*' | head -1)
case "$version" in
  2[2-9]*|[3-9][0-9]*) :;;
  *) echo "R1316_API37_SDK_TOOL_VERSION_UNSUPPORTED: $version" >&2; exit 83;;
esac
printf 'R13.16 Android 17 AVD target=android-37.0, cmdline tools=%s: PASS\n' "$version"
