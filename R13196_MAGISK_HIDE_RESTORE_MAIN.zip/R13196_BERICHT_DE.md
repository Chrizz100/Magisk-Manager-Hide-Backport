# Magisk R13.19.6 – Korrektur des fehlerhaften R13.19.5-Patches

**Stand: 18. November 2026.** Bezug: [fehlgeschlagener Lauf 44340890627](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44340890627), Commit `b878c3e97b21d6a0a63e628163fccf5f2ced04bd`.

## Der Fehler lag in der ausgelieferten YAML

R13.19.5 brach im Buildjob bereits bei der Quellaufbereitung ab. Java-Setup, APK-Kompilierung und Android-Tests wurden in diesem GitHub-Lauf nicht erreicht. Die spätere rote Gesamtprüfung war eine Folge dieses ersten Fehlers.

Der konkrete Fehler lautete:

```text
ValueError: R13195_UNEXPECTED_UI_CONFIRM_0
```

Der Patch suchte vor den beiden Kotlin-Zeilen `showRestoreDialog = false` und `viewModel.restoreManager()` jeweils **24 Leerzeichen**. Die vorhergehende R6-Stufe erzeugt tatsächlich **16 Leerzeichen**. Beim Erstellen des Suchtextes wurde die zusätzliche YAML-Einrückung mit der Einrückung des erzeugten Kotlin-Codes vermischt.

Die zuvor gemeldeten positiven Patchtests konnten das nicht entdecken: Ihre künstlichen Eingangsdateien wurden aus demselben falschen Suchtext zusammengesetzt. Eine erfolgreiche Prüfung dieser Vorlagen war kein Nachweis, dass die vollständige Workflow-Reihenfolge auf den wirklichen Quellen funktioniert. Die damalige Bezeichnung als repariert war deshalb zu weitgehend.

Beleg: [fehlgeschlagener Buildjob](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44340890627/job/134930234645). Originale Fehlermeldung und lokaler Nachvollzug liegen im ZIP unter `evidence/baseline/`.

## Was die neue Fassung ändert

### 1. Der Patch passt zum tatsächlichen Dialog

Der neue Schritt erkennt den vollständigen `if (showRestoreDialog)`-Block mit seiner wirklichen Einrückung. Er verlangt weiterhin genau einen Treffer. Ein fehlender oder doppelter Dialog führt vor dem Schreiben der Quelldateien zum Abbruch. Es gibt keine beliebig tolerante Suche, die bei unbekanntem Quellstand irgendeine ähnlich aussehende Stelle verändern würde.

Die Quellprüfung nach dem Patch kontrolliert die vollständigen neuen UI- und ViewModel-Blöcke, den Restore-Methodentext und die protokollierten Dateihashes. Sie läuft jetzt bereits vor der Kompilierung; die entsprechende Prüfung nach dem APK-Build bleibt bestehen.

### 2. Der Android-Test wartet auf das fertige Restore

R13.19.5 wartete nur darauf, dass der Callback und die Restore-Methode betreten wurden. Anschließend konnte der Test sofort versuchen, das Original selbst zu starten. Das war zu früh: Die App konnte noch mit ihren Prüfungen und dem Reaktivieren des Launchers beschäftigt sein. Auch `pm path` eignete sich nicht als Abschlussnachweis, weil das Originalpaket beim Hide absichtlich installiert bleibt.

R13.19.6 verlangt die appseitigen Meldungen für den bestätigten Originalstart, den überprüften Bindungswechsel und den vollständigen Transaktionsabschluss. Ein gemeldeter Fehler bricht die Prüfung ab. Danach wird der Originalprozess zunächst passiv mit `pidof` geprüft. Der zusätzliche Start vom Testhost erfolgt erst nach der bestätigten Entfernung des versteckten Pakets. Dadurch stellt der Test die zu prüfende Wiederherstellung nicht selbst her.

### 3. Die Bereinigung beginnt erst nach bestätigtem Bindungswechsel

Der bisherige Code startete den verzögerten Bereinigungsprozess vor dem Schreiben und Zurücklesen von `Config.suManager`. Bei einem fehlgeschlagenen Bindungswechsel konnte damit bereits ein Prozess aktiv sein, der das versteckte Paket später entfernte.

Die neue Reihenfolge lautet: Original-APK prüfen, Original-Launcher reaktivieren, Originalstart bestätigen, Manager-Zuordnung zurücksetzen und zurücklesen, anschließend die begrenzte Bereinigung des eigenen versteckten Pakets einplanen. Ein Fehler beim Bindungswechsel kann somit keinen schon gestarteten Bereinigungsjob hinterlassen.

Die zusätzlichen Änderungen betreffen die drei App-Dateien `HomeScreen.kt`, `HomeViewModel.kt` und `AppMigration.kt`. Ihr vollständiger Unterschied zum wirklichen Präpatchstand steht in `R13196_APP_CHANGES.patch`.

## Tatsächlich ausgeführte Prüfungen

Die Ausgangsquellen stammen aus dem offiziellen Magisk-Commit `0972f67d97f9b6302b67c5171283330c74114b4a`; historische Dateien aus `ea16c8141eb64dc28b56a0e7fb536689ef465429`.

| Prüfung | Tatsächliches Ergebnis | Aussagegrenze |
| --- | --- | --- |
| Vollständige alte Quellaufbereitung auf offiziellem Checkout | Schritte 1–26 erfolgreich; Schritt 27 reproduziert exakt den GitHub-Fehler | Nachweis der ursprünglichen Integrationsursache |
| Vollständige neue Quellaufbereitung auf frischem offiziellem Checkout | 27/27 Schritte erfolgreich, einschließlich `postsource`-Gate | Echter Quellaufbau; kein Android-Laufzeitnachweis |
| Regressionen auf Kopien dieser wirklichen Präpatchdateien | 4/4 erfolgreich | Alter Fehler reproduziert; neue Fassung akzeptiert; doppelter/fehlender Callback wird ohne Dateischreibvorgang abgelehnt |
| Shellsyntax | 51 Workflow-Schritte und 6 erzeugte Shellskripte erfolgreich | Syntaxprüfung |
| Python-Syntax | 62/62 eingebettete Programme erfolgreich | Einschließlich der bisher ausgelassenen Heredocs mit Argumenten |
| Negativtest des Syntaxprüfers | Absichtlich eingefügter verschachtelter Python-Fehler wird erkannt | Prüfer übersieht diesen Fehlertyp nicht |
| Restore-Warteprüfung aus der gelieferten YAML | 15/15 Fälle erfolgreich | Echter Bash-Block mit kontrollierten ADB-Ausgaben; keine Android-Simulation behauptet |
| Native Kompilierung | ARM64, ARM32, x86_64 und x86 erfolgreich | Tatsächlicher Compilerlauf |
| Tatsächlicher Release-APK- und Test-APK-Build | Beide erfolgreich | Echte Gradle-/Kotlin-/R8-Kompilierung der vollständigen Quellen |
| Fertige APK: Signatur, Quellkette, Manifest und vier ABI-Bindungen | Alle fünf nachgelagerten Workflow-Prüfschritte erfolgreich | Tatsächliche APK und Native-Dateien geprüft, keine nachgebildeten Binärdateien |
| Neue Restore-Protokollmarker in der optimierten Release-APK | Vorhanden | R8 hat die für den Ablaufnachweis benötigten Marker nicht entfernt |
| Lokaler Android-13-Softwareemulator | Boot innerhalb von 600 Sekunden nicht abgeschlossen | Kein APK installiert, kein Root-/Hide-/Restore-Test ausgeführt |
| Android-7–17-Matrix | 15 Konfigurationen im Workflow vollständig erhalten | Hier nicht ausgeführt; die Laufzeitprüfung bleibt für GitHub Actions verpflichtend |
| Physisches Smartphone | Nicht getestet und nicht verändert | Keine Aussage über Gerätekompatibilität |

Der vollständige Release-APK-Build endete mit `BUILD SUCCESSFUL` nach 16 Minuten 35 Sekunden; der Test-APK-Build anschließend ebenfalls erfolgreich nach 1 Minute 18 Sekunden. Gebaut wurde mit dem echten JDK 25, Android-Plattform 37.1, Build Tools 37.0.0, ONDK r30.1 und Gradle 9.7.1. Eine zunächst fehlerhafte lokale Proxykonfiguration wurde vor dem erfolgreichen Android-Build korrigiert; dafür wurde weder eine Abhängigkeitsversion noch die auszuliefernde YAML geändert. Die ursprüngliche lokale Fehlermeldung und der erfolgreiche Folgelauf sind beide im Paket erhalten.

Die fertige Release-APK hat **13.174.594 Bytes** und SHA-256 `b301707e0264a61d21acee53ae628a884cc4d4dcfb02ecebd3c0186ab7c0cf7a`. Ihr Signierzertifikat stimmt mit dem tatsächlich eingebauten `TRUSTED_CERT` überein. Bei allen vier Architekturen sind die gebauten Daemon-Dateien, die APK-Inhalte und die hinterlegten Vergleichshashes bytegenau gleich. Auch die bisherigen Anforderungen an das Manifest bestanden. Das ist ein lokaler Buildnachweis; es ist kein neuer GitHub-Actions-Lauf.

Der lokale Emulator wurde ohne KVM-Hardwarebeschleunigung betrieben. Im längeren Versuch antwortete die echte Android-Shell, `sys.boot_completed=1` wurde aber bis zum Abbruch nach rund 602 Sekunden nicht erreicht. Der Emulator wurde beendet. Weder eine APK-Installation noch ein Root- oder Restore-Test wurde gestartet. Dieser fehlgeschlagene Bootversuch ist keine Aussage über die Funktionsfähigkeit von Magisk; ein Android-Funktionstest bleibt offen. Die Messdaten stehen unter `evidence/local_emulator/`.

Die Root-, Signatur-, Paketinhaber-, APK- und Native-Prüfungen wurden nicht abgeschwächt. Der vollständige GUI-Matrixjob und der unabhängige Abschlussjob sind gegenüber R13.19.5 unverändert. Die statische Vergleichsprüfung weist genau fünf geänderte Schritte aus: Quellgate, neuer App-Patch, zwei Artefaktlisten und Root-Testskript.

## Einordnung des Ergebnisses

**Der konkrete R13.19.5-Patchabbruch ist auf echten Quellen reproduziert und behoben. Die neue Fassung wurde bis zu den fertigen APKs gebaut und gegen die tatsächlichen Signatur-, Manifest- und Native-Prüfungen geprüft. Ein erfolgreicher Hide/Restore-Lauf auf Android ist noch nicht nachgewiesen.** Deshalb wird hier weder ein vollständig grüner GitHub-Gesamtlauf noch eine Freigabe für die vorhandene Smartphone-Installation behauptet.

Der alte R13.19.4-Lauf hatte den Launcher bereits ausgeblendet, aber keinen nachgewiesenen Restore-Callback. Der aktuelle R13.19.5-Lauf kam wegen des beschriebenen Patchfehlers gar nicht bis Android. Diese beiden Befunde sind getrennt zu beurteilen. Die zusätzlichen Ablaufkorrekturen sind im Quelltext begründet; ihr Android-Ergebnis wird ausschließlich durch den oben ausgewiesenen tatsächlichen Laufzeitnachweis bewertet.

## Verwendung am Smartphone

Die Datei `R13196_MAGISK_31100_SOURCE_CHAIN_RESTORE_SYNC.yml` unter `.github/workflows/` hochladen und anschließend in GitHub Actions den Workflow **Magisk R13.19.6 - exact source patch + completed Restore gate | device HOLD** starten. Der alte verlinkte Lauf bleibt an die alte R13.19.5-Fassung gebunden.

Für den Workflow wird nur die YAML benötigt. Das ZIP enthält die YAML, diesen Bericht, den App-Diff, alle Prüftools sowie die zugehörigen Belege. Die detaillierten optionalen Reproduktionsbefehle stehen in `README_R13196_DE.md`; diese sind für einen Entwicklungsrechner gedacht und für das Hochladen am Smartphone nicht erforderlich.

**SHA-256 der gelieferten YAML:**

```text
71aacfc8083741f0afdbdebd107fc48241dcaf4675b1a35aab0fa2caea5cda68
```

Das Paket enthält keine privaten Signierschlüssel. Die lokalen Build- und Emulatortests ersetzen keine Prüfung der bereits vorhandenen Root-Installation des Smartphones.
