# R13.19.6 – Workflow und nachvollziehbare Prüfungen

## Am Smartphone: nur die YAML zu GitHub hochladen

1. Im Repository `Chrizz100/Magisk-Manager-Hide-Backport` auf dem Branch `main` den Ordner `.github/workflows` öffnen.
2. Über **Add file → Upload files** die Datei `R13196_MAGISK_31100_SOURCE_CHAIN_RESTORE_SYNC.yml` aus diesem Paket hochladen und den Commit speichern.
3. Unter **Actions** den Workflow **Magisk R13.19.6 - exact source patch + completed Restore gate | device HOLD** auswählen.
4. **Run workflow** für `main` ausführen.

**Das ZIP nicht in den Workflowordner hochladen.** Für den GitHub-Lauf wird nur die neue YAML benötigt; ihre Patchskripte und Prüfungen sind bereits vollständig eingebettet. Die ältere R13.19.5 unter `evidence/baseline/` dient ausschließlich dem Fehlervergleich.

Zum Starten dieses GitHub-Laufs werden auf dem Smartphone kein ADB und kein lokaler Compiler benötigt. Den abschließenden Stand zu Android-Build, Emulator und den Grenzen der Prüfung beschreibt `R13196_BERICHT_DE.md` im Paket. Ein bestandener Quelltest allein belegt keinen funktionierenden Restore auf Android.

## Was dieses Paket belegt

Der Lauf [44340890627](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44340890627) brach im R13.19.5-Patch mit `R13195_UNEXPECTED_UI_CONFIRM_0` ab. Der Patch erwartete eine andere Einrückung als der zuvor tatsächlich erzeugte Kotlin-Code.

Die Belege im Ordner `evidence/` enthalten die Wiederholung der vollständigen Quellaufbereitung aus den offiziellen Git-Quellen, den reproduzierten alten Abbruch, die korrigierte Quellaufbereitung sowie getrennte Syntax-, Quell- und Ablaufprüfungen. Die Warteprüfungen simulieren Logausgaben; sie führen keinen Android-Emulator aus.

`R13196_APP_CHANGES.patch` zeigt die drei App-Quelldateien, die der neue Schritt gegenüber dem tatsächlichen Stand unmittelbar davor ändert. Der Patch ist zur Prüfung des Unterschieds beigefügt. Die YAML wendet die Änderungen selbst an.

## Optional: Prüfungen auf einem Entwicklungsrechner wiederholen

Diese Anleitung ist nur für die unabhängige technische Nachprüfung gedacht. Für das Hochladen am Smartphone ist sie nicht nötig.

Voraussetzungen: Linux, Python 3.11 oder neuer, Git, Bash und übliche GNU-Werkzeuge wie `grep`, `seq`, `sha256sum` und `wc`. Die Quellaufbereitung braucht Internetzugriff auf das öffentliche Repository `topjohnwu/Magisk`. Alle folgenden Befehle werden **im entpackten Paketordner** ausgeführt. Die Verzeichnisse `replays/baseline` und `replays/candidate` müssen beim ersten Aufruf noch nicht existieren; der Runner überschreibt keine bestehenden Arbeitsbäume.

### 1. Python-Abhängigkeit

```bash
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
```

`requirements.txt` pinnt die bei der Prüfung verwendete Version `PyYAML==6.0.3`.

### 2. Alten Fehler mit den echten Quellen reproduzieren

```bash
python3 tools/replay_source_workflow.py \
  evidence/baseline/R13195_MAGISK_31100_RESTORE_TRANSACTION_FIXED.yml \
  --output replays/baseline
```

**Erwartet wird hier ein Abbruch mit Exitcode 1 und `R13195_UNEXPECTED_UI_CONFIRM_0`.** Das ist der nachgestellte ursprüngliche Fehler. Die ersten 26 Quellschritte müssen vorher erfolgreich sein. Die nächsten Befehle werden anschließend separat ausgeführt.

### 3. Korrigierte Reihenfolge auf einem frischen Arbeitsbaum prüfen

```bash
python3 tools/replay_source_workflow.py \
  R13196_MAGISK_31100_SOURCE_CHAIN_RESTORE_SYNC.yml \
  --output replays/candidate \
  --source-cache replays/baseline/magisk
```

Der Cache liefert ausschließlich die bereits heruntergeladenen Git-Objekte. Der Kandidat erhält einen neuen Arbeitsbaum des gepinnten offiziellen Commits und durchläuft die komplette Reihenfolge erneut. Erwartet sind 27 erfolgreiche Quellschritte einschließlich des zusätzlichen `postsource`-Gates. Der Runner stoppt vor Java-Setup, APK-Build und Emulator.

### 4. Regressionen auf den tatsächlich erzeugten Quelldateien prüfen

```bash
python3 tools/test_real_source_regressions.py \
  --baseline-replay replays/baseline \
  --candidate-replay replays/candidate \
  --report replays/real_source_regressions.json
```

Die benötigten Patchmodule werden von den beiden vorherigen YAML-Replays erzeugt. Der Test konstruiert seine Eingangsdateien nicht aus den erwarteten Patchtexten: Er kopiert die echten Präpatchdateien. Er prüft den ursprünglichen Fehler, die erfolgreiche Korrektur und den Abbruch bei einem doppelten Dialog oder fehlenden Callback. Abgelehnte Eingaben dürfen keine Quelldateien ändern.

### 5. Syntax, unveränderte Prüfregeln und Restore-Warten prüfen

```bash
python3 tools/validate_workflow.py \
  R13196_MAGISK_31100_SOURCE_CHAIN_RESTORE_SYNC.yml \
  --baseline evidence/baseline/R13195_MAGISK_31100_RESTORE_TRANSACTION_FIXED.yml \
  --report replays/static_validation.json
```

```bash
python3 tools/R13196_E2E_WAIT_TESTS.py \
  --workflow R13196_MAGISK_31100_SOURCE_CHAIN_RESTORE_SYNC.yml \
  --report replays/restore_wait_tests.json
```

Die letzte Prüfung führt den echten eingebetteten Bash-Warteblock mit kontrollierten `adb`-Logausgaben aus. Sie prüft unter anderem, dass der bloße Eintritt in die Restore-Methode nicht als Abschluss zählt und dass ein gemeldeter Fehler den Ablauf stoppt. Die eigentlichen Android- und Root-Funktionen werden dadurch nicht ausgeführt.

## Inhalt der Belege

| Datei oder Ordner | Bedeutung |
| --- | --- |
| `evidence/baseline/` | Ursprüngliche YAML, GitHub-Abbruch und Wiederholung des fehlerhaften Quellschritts |
| `evidence/candidate/` | Wiederholung der korrigierten Quellaufbereitung und `postsource`-Gate |
| `evidence/R13196_REAL_SOURCE_REGRESSIONS.json` | Vier Prüfungen auf Kopien der tatsächlichen Präpatchdateien |
| `evidence/R13196_STATIC_VALIDATION.json` | Bash-/Python-Syntax und Erhaltung der bestehenden Workflow-Prüfregeln |
| `evidence/VALIDATOR_NEGATIVE_TEST.json` | Nachweis, dass der Syntaxprüfer einen absichtlich eingefügten Python-Fehler erkennt |
| `evidence/R13196_E2E_WORKFLOW_RESULTS.json` | Prüfungen des eingebetteten Warteblocks mit simulierten Logausgaben |

Originale Fehlerprotokolle können ihre damaligen absoluten Ausführungspfade enthalten. Die Prüfbefehle und Hilfsskripte benötigen diese Pfade nicht.
