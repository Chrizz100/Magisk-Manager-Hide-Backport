#!/usr/bin/env python3
"""Execute the shipped Restore wait block against deterministic adb log streams.

These are Bash orchestration tests, not Android, root, APK, or device tests.
Only adb and sleep are doubled; Bash, seq, grep and the source block are real.

Usage:
  python3 R13196_E2E_WAIT_TESTS.py --workflow workflow.yml --report results.json
  python3 R13196_E2E_WAIT_TESTS.py --block R13196_WAIT_RESTORE.sh
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import textwrap
import unittest

BEGIN = "# R13196_WAIT_RESTORE_BEGIN"
END = "# R13196_WAIT_RESTORE_END"
SOURCE_BLOCK = ""
SOURCE_PATH: Path | None = None
WORKFLOW_PATH: Path | None = None
CASE_RECORDS: list[dict] = []


def read_block(path: Path) -> str:
    """Read the exact marked block from YAML or standalone Bash without PyYAML."""
    lines = path.read_text(encoding="utf-8").splitlines(keepends=True)
    starts = [i for i, line in enumerate(lines) if line.strip() == BEGIN]
    ends = [i for i, line in enumerate(lines) if line.strip() == END]
    if len(starts) != 1 or len(ends) != 1 or starts[0] >= ends[0]:
        raise ValueError("Expected exactly one ordered Restore BEGIN/END pair")
    return textwrap.dedent("".join(lines[starts[0]:ends[0] + 1]))


def log(tag: str, message: str, level: str = "I") -> str:
    return f"{level}/{tag}( 4321): {message}\n"


UI = log("R13196RestoreUI", "CONFIRM_CALLBACK_RECEIVED")
ENTRY = log("R13196Restore", "ENTERED")
START = log("R13196Restore", "ORIGINAL_EXPLICIT_START_OK")
BIND = log("R13196Restore", "MANAGER_BIND_RESET_VERIFIED")
COMPLETE = log("R13196Restore", "ORIGINAL_START_CONFIRMED_CLEANUP_SCHEDULED")
VM_COMPLETE = log("R13196RestoreVM", "BACKEND_RESTORE_CONFIRMED")
SUCCESS = UI + ENTRY + START + BIND + COMPLETE + VM_COMPLETE


ADB_STUB = r'''import json, os, pathlib, sys
root = pathlib.Path(os.environ["R13196_TEST_ROOT"])
args = sys.argv[1:]
with (root / "calls.jsonl").open("a") as out:
    out.write(json.dumps({"program": "adb", "args": args}) + "\n")
if args[:2] != ["shell", "logcat"]:
    print("Unexpected active adb operation in Restore wait test", file=sys.stderr)
    sys.exit(93)
scenario = json.loads((root / "scenario.json").read_text())
counter = root / "counter.txt"
index = int(counter.read_text()) if counter.exists() else 0
counter.write_text(str(index + 1))
frame = scenario[ min(index, len(scenario) - 1) ]
if isinstance(frame, dict):
    sys.stdout.write(frame.get("stdout", ""))
    sys.stderr.write(frame.get("stderr", ""))
    sys.exit(frame.get("exit", 0))
sys.stdout.write(frame)
'''

SLEEP_STUB = r'''import json, os, pathlib, sys
root = pathlib.Path(os.environ["R13196_TEST_ROOT"])
with (root / "calls.jsonl").open("a") as out:
    out.write(json.dumps({"program": "sleep", "args": sys.argv[1:]}) + "\n")
'''


class RestoreCompletionTests(unittest.TestCase):
    maxDiff = None

    def run_scenario(self, frames: list, expected_status: int,
                     expected_polls: int, expected_error: str | None = None) -> dict:
        with tempfile.TemporaryDirectory(prefix="r13196-wait-") as temp:
            root = Path(temp)
            bindir = root / "bin"
            bindir.mkdir()
            (root / "output").mkdir()
            (root / "scenario.json").write_text(json.dumps(frames), encoding="utf-8")
            # Use the interpreter running this test, independent of caller cwd.
            shebang = "#!/bin/sh\nexec " + shlex.quote(sys.executable) + " "
            for name, code in (("adb", ADB_STUB), ("sleep", SLEEP_STUB)):
                implementation = root / f"{name}_double.py"
                implementation.write_text(code, encoding="utf-8")
                wrapper = bindir / name
                wrapper.write_text(shebang + shlex.quote(str(implementation)) + ' "$@"\n',
                                   encoding="utf-8")
                wrapper.chmod(0o755)
            script = root / "execute_wait.sh"
            script.write_text("set -euo pipefail\n" + SOURCE_BLOCK +
                              "\nwait_for_restore_completion\n", encoding="utf-8")
            env = dict(os.environ)
            env["PATH"] = str(bindir) + os.pathsep + env.get("PATH", os.defpath)
            env["OUT"] = str(root / "output")
            env["R13196_TEST_ROOT"] = str(root)
            result = subprocess.run(["bash", str(script)], env=env, cwd=root,
                                    text=True, capture_output=True, timeout=35)
            callfile = root / "calls.jsonl"
            calls = [json.loads(line) for line in callfile.read_text().splitlines()] if callfile.exists() else []
            adb_calls = [call for call in calls if call["program"] == "adb"]
            tracefile = root / "output/r13196_restore_trace.txt"
            record = {
                "test": self.id().rsplit(".", 1)[-1],
                "returncode": result.returncode,
                "expected_returncode": expected_status,
                "logcat_polls": len(adb_calls),
                "expected_logcat_polls": expected_polls,
                "stderr": result.stderr.strip(),
                "calls": calls,
                "last_trace": tracefile.read_text() if tracefile.exists() else "",
            }
            CASE_RECORDS.append(record)
            self.assertEqual(result.returncode, expected_status, result.stderr)
            self.assertEqual(len(adb_calls), expected_polls)
            self.assertTrue(adb_calls)
            self.assertTrue(all(call["args"][:2] == ["shell", "logcat"] for call in adb_calls))
            self.assertFalse(any("am" in call["args"] or "start" in call["args"] for call in adb_calls),
                             "Waiting must not start or modify the original app")
            self.assertTrue(tracefile.is_file(), "The wait must retain its observed log trace")
            if expected_error is not None:
                self.assertIn(expected_error, result.stderr)
            return record

    def test_entry_and_callback_alone_do_not_pass(self):
        self.run_scenario([UI + ENTRY], 86, 45, "R13196_RESTORE_TRANSACTION_NOT_COMPLETED")

    def test_delayed_final_success_keeps_waiting(self):
        frames = [UI, UI + ENTRY, UI + ENTRY + START, UI + ENTRY + START + BIND,
                  UI + ENTRY + START + BIND + COMPLETE, SUCCESS]
        record = self.run_scenario(frames, 0, 6)
        self.assertEqual(sum(call["program"] == "sleep" for call in record["calls"]), 5)

    def test_all_success_markers_complete_immediately(self):
        self.run_scenario([SUCCESS], 0, 1)

    def test_backend_failure_stops_without_waiting_for_timeout(self):
        self.run_scenario([UI + ENTRY, UI + ENTRY + log("R13196RestoreVM", "BACKEND_RESTORE_FAILED", "E")],
                          85, 2, "R13196_RESTORE_APP_REPORTED_FAILURE")

    def test_backend_exception_stops_immediately(self):
        self.run_scenario([UI + ENTRY + log("R13196RestoreVM", "BACKEND_EXCEPTION", "E")],
                          85, 1, "R13196_RESTORE_APP_REPORTED_FAILURE")

    def test_failure_overrides_success_markers(self):
        self.run_scenario([SUCCESS + log("R1310Restore", "MANAGER_BIND_RESET_FAILED", "E")],
                          85, 1, "R13196_RESTORE_APP_REPORTED_FAILURE")

    def test_missing_callback_has_distinct_exit(self):
        self.run_scenario([SUCCESS.replace(UI, "")], 81, 45,
                          "R13196_RESTORE_CONFIRM_CALLBACK_NOT_INVOKED")

    def test_missing_backend_entry_has_distinct_exit(self):
        self.run_scenario([SUCCESS.replace(ENTRY, "")], 82, 45,
                          "R13196_RESTORE_BACKEND_NOT_ENTERED")

    def test_missing_original_start_never_passes(self):
        self.run_scenario([SUCCESS.replace(START, "")], 86, 45,
                          "R13196_RESTORE_TRANSACTION_NOT_COMPLETED")

    def test_missing_binding_confirmation_never_passes(self):
        self.run_scenario([SUCCESS.replace(BIND, "")], 86, 45,
                          "R13196_RESTORE_TRANSACTION_NOT_COMPLETED")

    def test_missing_core_completion_never_passes(self):
        self.run_scenario([SUCCESS.replace(COMPLETE, "")], 86, 45,
                          "R13196_RESTORE_TRANSACTION_NOT_COMPLETED")

    def test_missing_viewmodel_completion_never_passes(self):
        self.run_scenario([SUCCESS.replace(VM_COMPLETE, "")], 86, 45,
                          "R13196_RESTORE_TRANSACTION_NOT_COMPLETED")

    def test_entry_substring_is_not_method_entry(self):
        false_entry = log("R13196Restore", "NOT_ENTERED")
        self.run_scenario([SUCCESS.replace(ENTRY, false_entry)], 82, 45,
                          "R13196_RESTORE_BACKEND_NOT_ENTERED")

    def test_logcat_error_cannot_pass(self):
        self.run_scenario([{"exit": 1, "stderr": "adb: device offline\n"}], 81, 45,
                          "R13196_RESTORE_CONFIRM_CALLBACK_NOT_INVOKED")


class WorkflowOrderingTests(unittest.TestCase):
    def test_host_start_occurs_after_verified_hidden_removal(self):
        if WORKFLOW_PATH is None:
            self.skipTest("Pass --workflow to inspect the delivered workflow ordering")
        source = WORKFLOW_PATH.read_text(encoding="utf-8")
        restore_start = source.index("          state=RESTORE\n")
        restore_end = source.index("          state=COMPLETE\n", restore_start)
        restore_section = source[restore_start:restore_end]
        invocation = restore_section.index("wait_for_restore_completion\n")
        cleanup = restore_section.index("state=HIDDEN_PACKAGE_CLEANUP")
        verified_cleanup = restore_section.index('[[ "$cleanup_done" == true ]]')
        host_starts = [line for line in restore_section.splitlines()
                       if "adb shell am start" in line]
        self.assertTrue(host_starts, "Retain the independent original relaunch check")
        first_start = restore_section.index("adb shell am start")
        self.assertLess(invocation, cleanup)
        self.assertLess(cleanup, verified_cleanup)
        self.assertLess(verified_cleanup, first_start,
                        "Host must not supply the original process required by app cleanup")
        self.assertIn("pidof com.topjohnwu.magisk", restore_section[invocation:cleanup],
                      "Observe the app-owned original process before cleanup")


def main() -> int:
    global SOURCE_BLOCK, SOURCE_PATH, WORKFLOW_PATH
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    inputs = parser.add_mutually_exclusive_group()
    inputs.add_argument("--workflow", type=Path, help="Test the exact marked block embedded in this YAML")
    inputs.add_argument("--block", type=Path, help="Standalone marked Bash source")
    parser.add_argument("--report", type=Path, help="Write JSON including every adb/sleep invocation")
    args = parser.parse_args()
    WORKFLOW_PATH = args.workflow.resolve() if args.workflow else None
    SOURCE_PATH = WORKFLOW_PATH or (args.block or Path(__file__).with_name("R13196_WAIT_RESTORE.sh")).resolve()
    for command in ("bash", "seq", "grep"):
        if not shutil.which(command):
            parser.error(f"Required host command unavailable: {command}")
    try:
        SOURCE_BLOCK = read_block(SOURCE_PATH)
    except (OSError, ValueError) as error:
        parser.error(str(error))
    result = unittest.TextTestRunner(verbosity=2).run(
        unittest.TestSuite((unittest.defaultTestLoader.loadTestsFromTestCase(RestoreCompletionTests),
                            unittest.defaultTestLoader.loadTestsFromTestCase(WorkflowOrderingTests))))
    report = {
        "scope": "Dynamic Bash orchestration tests with scripted adb and no-delay sleep; no Android, root, APK or device execution",
        "source_filename": SOURCE_PATH.name,
        "source_sha256": hashlib.sha256(SOURCE_PATH.read_bytes()).hexdigest(),
        "extracted_wait_block_sha256": hashlib.sha256(SOURCE_BLOCK.encode()).hexdigest(),
        "tests_run": result.testsRun,
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "result": "PASS" if result.wasSuccessful() else "FAIL",
        "cases": CASE_RECORDS,
    }
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "cases"}, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
