#!/usr/bin/env python3
"""Replay the exact pre-build shell sequence against official pinned Git sources.

Requires Python 3.11+, PyYAML, git and bash. This does not build an APK or run
an Android emulator. It executes only the source steps preceding Java setup.
Use a new --output directory for each run. No existing worktree is overwritten.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

PIN = '0972f67d97f9b6302b67c5171283330c74114b4a'
LEGACY = 'ea16c8141eb64dc28b56a0e7fb536689ef465429'
JOB = 'r139-hardened-pair-build'
FILES = [
    'app/core/src/main/java/com/topjohnwu/magisk/core/tasks/AppMigration.kt',
    'app/apk/src/main/java/com/topjohnwu/magisk/ui/home/HomeScreen.kt',
    'app/apk/src/main/java/com/topjohnwu/magisk/ui/home/HomeViewModel.kt',
    'native/src/core/package.rs',
]


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], text=True).strip()


def main() -> int:
    import yaml
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('workflow', type=Path)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--source-cache', type=Path,
                    help='Existing official Magisk clone, used via a new detached worktree')
    ap.add_argument('--through', type=int, help='Last zero-based workflow step to execute')
    args = ap.parse_args()
    workflow = args.workflow.resolve()
    data = yaml.safe_load(workflow.read_text(encoding='utf-8'))
    steps = data['jobs'][JOB]['steps']
    checkout = steps[0]
    if checkout.get('with', {}).get('repository') != 'topjohnwu/Magisk' or checkout['with'].get('ref') != PIN:
        raise SystemExit('Refusing unexpected source repository or commit')
    stop = next(i for i, s in enumerate(steps) if s.get('uses', '').startswith('actions/setup-java@')) - 1
    if args.through is not None:
        if not 1 <= args.through <= stop:
            raise SystemExit('--through must be a pre-build source step')
        stop = args.through
    for i, step in enumerate(steps[1:stop + 1], 1):
        if 'run' not in step or 'uses' in step or 'if' in step or 'env' in step or '${{' in step['run']:
            raise SystemExit(f'Cannot faithfully replay step {i}: unsupported execution metadata')
    output = args.output.resolve()
    if output.exists():
        raise SystemExit(f'Output already exists: {output}')
    output.mkdir(parents=True)
    logs = output / 'logs'
    logs.mkdir()
    source = output / 'magisk'
    if args.source_cache:
        cache = args.source_cache.resolve()
        git('-C', str(cache), 'cat-file', '-e', PIN + '^{commit}')
        git('-C', str(cache), 'worktree', 'add', '--detach', str(source), PIN)
    else:
        git('clone', '--filter=blob:none', '--no-checkout', 'https://github.com/topjohnwu/Magisk.git', str(source))
        git('-C', str(source), 'checkout', '--detach', PIN)
        # Fetch the historical tree's blobs together. Otherwise each git-show
        # in the unchanged workflow can trigger a separate network request.
        tree = git('-C', str(source), 'ls-tree', '-r', LEGACY)
        blobs = sorted({line.split()[2] for line in tree.splitlines()
                        if line.split()[1] == 'blob'})
        git('-C', str(source), 'fetch', '--no-tags', '--no-write-fetch-head', 'origin', *blobs)
    actual = git('-C', str(source), 'rev-parse', 'HEAD')
    if actual != PIN:
        raise SystemExit('Unexpected checkout SHA')
    env = dict(os.environ, CI='true', GITHUB_WORKSPACE=str(output))
    summary = {
        'workflow': workflow.name,
        'workflow_sha256': hashlib.sha256(workflow.read_bytes()).hexdigest(),
        'source_commit': actual,
        'scope': 'official-source patch sequence only; no APK build or emulator',
        'steps': [],
    }
    for i, step in enumerate(steps[1:stop + 1], 1):
        if i == stop:
            checkpoint = output / 'before_last_step'
            for rel in FILES:
                dest = checkpoint / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source / rel, dest)
        script = logs / f'{i:02}.sh'
        script.write_text(step['run'], encoding='utf-8')
        print(f'[{i}/{stop}] {step["name"]}', flush=True)
        started = time.monotonic()
        log = logs / f'{i:02}.log'
        with log.open('w', encoding='utf-8') as stream:
            result = subprocess.run(['bash', '--noprofile', '--norc', '-e', '-o', 'pipefail', str(script)],
                                    cwd=output, env=env, stdout=stream, stderr=subprocess.STDOUT)
        record = {'step_index': i, 'name': step['name'], 'returncode': result.returncode,
                  'seconds': round(time.monotonic() - started, 3), 'log': str(log.relative_to(output))}
        summary['steps'].append(record)
        summary['status'] = 'FAILED' if result.returncode else ('PASS' if i == stop else 'RUNNING')
        (output / 'SOURCE_REPLAY.json').write_text(json.dumps(summary, indent=2) + '\n', encoding='utf-8')
        if result.returncode:
            print(log.read_text(encoding='utf-8')[-5000:], flush=True)
            return result.returncode
    print('Official-source pre-build patch sequence PASS; APK/emulator not tested.', flush=True)
    return 0


if __name__ == '__main__':
    sys.exit(main())
