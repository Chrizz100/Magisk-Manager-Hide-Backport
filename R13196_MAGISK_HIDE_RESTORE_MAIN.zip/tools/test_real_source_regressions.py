#!/usr/bin/env python3
"""Regression tests using captured, fully replayed official source files.

No fixture is constructed from a patch module's expected strings. The source
fixture must be the before_last_step directory emitted by replay_source_workflow.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

MIGRATION = 'app/core/src/main/java/com/topjohnwu/magisk/core/tasks/AppMigration.kt'
UI = 'app/apk/src/main/java/com/topjohnwu/magisk/ui/home/HomeScreen.kt'
VM = 'app/apk/src/main/java/com/topjohnwu/magisk/ui/home/HomeViewModel.kt'
NATIVE = 'native/src/core/package.rs'
FILES = (MIGRATION, UI, VM, NATIVE)


def hashes(root: Path) -> dict:
    return {rel: hashlib.sha256((root / rel).read_bytes()).hexdigest() for rel in FILES}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline-replay', required=True, type=Path)
    ap.add_argument('--candidate-replay', required=True, type=Path)
    ap.add_argument('--report', required=True, type=Path)
    args = ap.parse_args()
    baseline = args.baseline_replay.resolve()
    candidate = args.candidate_replay.resolve()
    fixture = candidate / 'before_last_step'
    if hashes(fixture) != hashes(baseline / 'before_last_step'):
        raise AssertionError('Candidate and baseline prepatch source fixtures differ')
    old_patch = baseline / 'R13195_RESTORE_TXN_PATCH.py'
    new_patch = candidate / 'R13196_RESTORE_TXN_PATCH.py'
    original_ui = (fixture / UI).read_text(encoding='utf-8')
    # Capture the actual complete block by its source boundaries, without
    # importing either patch or reading its UI_OLD/UI_NEW constants.
    start = original_ui.index('    if (showRestoreDialog) {\n')
    end = original_ui.index('\n    }', start) + len('\n    }')
    actual_dialog = original_ui[start:end]
    assert original_ui.count(actual_dialog) == 1
    assert actual_dialog.count('viewModel.restoreManager()') == 1
    results = []
    cases = [
        ('original_r13195_reproduces_real_failure', old_patch, None, 'R13195_UNEXPECTED_UI_CONFIRM_0'),
        ('corrected_r13196_accepts_real_source', new_patch, None, None),
        ('duplicate_actual_dialog_rejected_before_writes', new_patch,
         lambda u: u.replace(actual_dialog, actual_dialog + '\n' + actual_dialog, 1),
         'R13196_UNEXPECTED_UI_CONFIRM_2'),
        ('missing_actual_callback_rejected_before_writes', new_patch,
         lambda u: u.replace('                viewModel.restoreManager()\n',
                             '                // Callback accidentally removed\n', 1),
         'R13196_UNEXPECTED_UI_CONFIRM_0'),
    ]
    for name, patch, mutation, expected_error in cases:
        with tempfile.TemporaryDirectory(prefix='magisk-real-source-') as temporary:
            root = Path(temporary) / 'source'
            shutil.copytree(fixture, root)
            if mutation:
                (root / UI).write_text(mutation(original_ui), encoding='utf-8')
            before = hashes(root)
            report = Path(temporary) / 'patch_report.json'
            result = subprocess.run([sys.executable, str(patch), str(root), str(report)],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            if expected_error:
                assert result.returncode != 0, (name, result.stdout)
                assert expected_error in result.stdout, (name, result.stdout)
                assert hashes(root) == before, f'{name}: rejected input nevertheless changed source files'
                assert not report.exists(), f'{name}: rejected input created a success report'
            else:
                assert result.returncode == 0, (name, result.stdout)
                assert report.is_file(), name
                attestation = json.loads(report.read_text(encoding='utf-8'))
                actual = hashes(root)
                for rel, digest in zip(attestation['patched_files'], attestation['after']):
                    assert actual[rel] == digest, (name, rel)
                assert actual[NATIVE] == before[NATIVE], 'Unexpected native-code mutation'
            results.append({'case': name, 'status': 'PASS', 'process_returncode': result.returncode,
                            'expected_error': expected_error,
                            'rejected_input_has_no_source_writes': True if expected_error else None})
    output = {'fixture_origin': 'complete workflow source replay from official pinned Git checkout',
              'fixture_sha256': hashes(fixture),
              'baseline_workflow': json.loads((baseline / 'SOURCE_REPLAY.json').read_text())['workflow_sha256'],
              'candidate_workflow': json.loads((candidate / 'SOURCE_REPLAY.json').read_text())['workflow_sha256'],
              'status': 'PASS', 'tests': results,
              'apk_build': 'NOT_TESTED_BY_THIS_SCRIPT', 'emulator': 'NOT_TESTED_BY_THIS_SCRIPT'}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(output, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(output, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
