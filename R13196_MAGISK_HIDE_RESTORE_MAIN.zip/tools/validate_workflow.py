#!/usr/bin/env python3
"""Portable syntax and preservation checks for the R13.19.6 workflow.

Usage: python3 validate_workflow.py NEW.yml --baseline OLD.yml --report report.json
Requires Python 3, PyYAML and bash. Does not execute workflow code or contact devices.
"""
from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

import yaml


class WorkflowLoader(yaml.SafeLoader):
    """YAML-safe loader with YAML 1.2 booleans and duplicate-key rejection."""


WorkflowLoader.yaml_implicit_resolvers = copy.deepcopy(yaml.SafeLoader.yaml_implicit_resolvers)
for initial, rules in WorkflowLoader.yaml_implicit_resolvers.items():
    WorkflowLoader.yaml_implicit_resolvers[initial] = [
        pair for pair in rules if pair[0] != 'tag:yaml.org,2002:bool'
    ]
WorkflowLoader.add_implicit_resolver(
    'tag:yaml.org,2002:bool', re.compile(r'^(?:true|false)$', re.I), list('tTfF')
)


def unique_mapping(loader, node, deep=False):
    result = {}
    loader.flatten_mapping(node)
    for key_node, value_node in node.value:
        key = loader.construct_object(key_node, deep=deep)
        if key in result:
            raise ValueError(f'Duplicate YAML key {key!r} at line {key_node.start_mark.line+1}')
        result[key] = loader.construct_object(value_node, deep=deep)
    return result


WorkflowLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)
HERE = re.compile(r'''(?<!<)<<(?P<tabs>-?)[ \t]*(?P<quote>['"]?)(?P<marker>[A-Za-z_][A-Za-z_0-9]*)(?P=quote)''')
PYTHON = re.compile(r'\bpython(?:3(?:\.\d+)?)?\b')
CAT_TARGET = re.compile(r'''\bcat\b[^\n]*?(?<!<)>{1,2}\s*['"]?(?P<target>[^\s'"<>]+)''')


def sha(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def heredocs(shell):
    """Parse quoted/unquoted shell heredocs, preserving Python indentation.

    Arguments, redirections and if/assignment prefixes before << are supported.
    A parent .sh heredoc is parsed recursively by the caller, avoiding false
    recognition of heredoc-like text inside Kotlin, Python or patch literals.
    """
    lines = shell.splitlines(keepends=True)
    i = 0
    while i < len(lines):
        header = lines[i]
        matches = list(HERE.finditer(header))
        if not matches or header.lstrip().startswith('#'):
            i += 1
            continue
        command_line = i + 1
        i += 1
        for match in matches:
            marker = match.group('marker')
            body = []
            while i < len(lines):
                line = lines[i]
                if match.group('tabs'):
                    line = line.lstrip('\t')
                if line.rstrip('\r\n') == marker:
                    break
                body.append(line)
                i += 1
            if i == len(lines):
                raise ValueError(f'Unterminated heredoc {marker} at shell line {command_line}')
            yield command_line, header.rstrip(), marker, ''.join(body)
            i += 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('workflow', type=Path)
    parser.add_argument('--baseline', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    parser.add_argument('--extract-dir', type=Path)
    args = parser.parse_args()
    text = args.workflow.read_text(encoding='utf-8')
    before_text = args.baseline.read_text(encoding='utf-8')
    after = yaml.load(text, Loader=WorkflowLoader)
    before = yaml.load(before_text, Loader=WorkflowLoader)
    report = {
        'scope':'STATIC_SYNTAX_AND_BASELINE_PRESERVATION_ONLY',
        'workflow_filename':args.workflow.name, 'workflow_sha256':sha(text),
        'baseline_filename':args.baseline.name, 'baseline_sha256':sha(before_text),
        'python_version':sys.version.split()[0], 'bash_checks':[], 'python_checks':[],
        'heredocs':[], 'preservation_checks':[], 'changed_steps':[], 'errors':[],
        'android_build':'NOT_PERFORMED_BY_THIS_VALIDATOR',
        'android_runtime':'NOT_PERFORMED_BY_THIS_VALIDATOR',
        'physical_device':'NOT_TESTED',
    }
    extracted = {}

    def check(name, value, detail=None):
        item = {'name':name, 'result':'PASS' if value else 'FAIL'}
        if detail is not None:
            item['detail'] = detail
        report['preservation_checks'].append(item)
        if not value:
            report['errors'].append(name)

    def check_python(code, origin, target=None, kind='heredoc'):
        result = {'origin':origin, 'kind':kind, 'sha256':sha(code), 'result':'PASS'}
        if target:
            result['target'] = target
            extracted.setdefault(target, []).append(code)
        try:
            compile(code, origin, 'exec')
            tree = ast.parse(code, filename=origin)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                if isinstance(node.func, ast.Name) and node.func.id in ('compile','exec') and node.args:
                    first = node.args[0]
                    if isinstance(first, ast.Constant) and isinstance(first.value, str):
                        check_python(first.value, origin+':literal_'+node.func.id+':'+str(node.lineno), kind='embedded_literal')
        except (SyntaxError, ValueError) as exc:
            result['result'] = 'FAIL'
            result['error'] = str(exc)
            report['errors'].append(origin+': '+str(exc))
        report['python_checks'].append(result)

    def check_bash(code, origin, kind='run'):
        proc = subprocess.run(['bash','-n'], input=code, text=True, capture_output=True)
        result = {'origin':origin, 'kind':kind, 'sha256':sha(code), 'result':'PASS' if proc.returncode==0 else 'FAIL'}
        if proc.returncode:
            result['error'] = proc.stderr
            report['errors'].append(origin+': '+proc.stderr)
        report['bash_checks'].append(result)
        try:
            for line, header, marker, body in heredocs(code):
                target_match = CAT_TARGET.search(header)
                target = target_match.group('target') if target_match else None
                language = 'other'
                entry_origin = f'{origin}:{line}:{marker}'
                if PYTHON.search(header) and re.search(r'\bpython(?:3(?:\.\d+)?)?\s+-\s', header):
                    language = 'python'
                    check_python(body, entry_origin)
                elif target and target.endswith('.py'):
                    language = 'python_file'
                    check_python(body, entry_origin, target)
                elif target and target.endswith('.sh'):
                    language = 'bash_file'
                    check_bash(body, entry_origin, 'generated_script')
                report['heredocs'].append({'origin':entry_origin,'header':header,'marker':marker,'language':language,'target':target})
        except ValueError as exc:
            report['errors'].append(origin+': '+str(exc))

    jobs = after['jobs']
    old_jobs = before['jobs']
    expected_jobs = ['r139-hardened-pair-build','r1313-gui-matrix','r1314-root-hide-restore-avd','r1313-api-coverage-gate']
    check('four_jobs_preserved', list(jobs)==list(old_jobs)==expected_jobs)
    check('workflow_permissions_preserved', after.get('permissions')==before.get('permissions'))
    check('workflow_triggers_preserved', after.get('on')==before.get('on'))
    check('workflow_concurrency_preserved', after.get('concurrency')==before.get('concurrency'))
    for job_name, job in jobs.items():
        old = old_jobs[job_name]
        check(job_name+':needs_preserved', job.get('needs')==old.get('needs'))
        check(job_name+':job_if_preserved', job.get('if')==old.get('if'))
        check(job_name+':runner_preserved', job.get('runs-on')==old.get('runs-on'))
        check(job_name+':strategy_preserved', job.get('strategy')==old.get('strategy'))
        check(job_name+':continue_on_error_absent', not job.get('continue-on-error',False))
        check(job_name+':step_count_preserved', len(job['steps'])==len(old['steps']))
        for index, step in enumerate(job['steps'], 1):
            old_step = old['steps'][index-1]
            origin = f'{job_name}/step{index:02d}'
            check(origin+':failure_policy_preserved', step.get('if')==old_step.get('if') and not step.get('continue-on-error',False))
            check(origin+':action_reference_preserved', step.get('uses')==old_step.get('uses'))
            if step != old_step:
                report['changed_steps'].append({'job':job_name,'step':index,'name':step.get('name'),'changed_keys':sorted(k for k in set(step)|set(old_step) if step.get(k)!=old_step.get(k))})
            if 'run' in step:
                shell = step.get('shell', job.get('defaults',{}).get('run',{}).get('shell','bash'))
                check(origin+':shell_is_bash', shell=='bash')
                check_bash(step['run'], origin)
    matrix = jobs['r1313-gui-matrix']['strategy']['matrix']['include']
    check('all_15_android_matrix_cases_preserved', len(matrix)==15 and matrix==old_jobs['r1313-gui-matrix']['strategy']['matrix']['include'])
    report['matrix_cases'] = matrix
    check('independent_final_gate_unchanged', jobs['r1313-api-coverage-gate']==old_jobs['r1313-api-coverage-gate'])
    check('gui_matrix_job_unchanged', jobs['r1313-gui-matrix']==old_jobs['r1313-gui-matrix'])
    allowed_changes = {('r139-hardened-pair-build',27),('r139-hardened-pair-build',28),('r139-hardened-pair-build',53),('r139-hardened-pair-build',56),('r1314-root-hide-restore-avd',3)}
    actual_changes = {(r['job'],r['step']) for r in report['changed_steps']}
    check('change_scope_matches_reviewed_steps', actual_changes==allowed_changes)
    # All compilation, signing, native digest, older source audits and platform
    # checks outside the two deliberately updated source steps are byte-identical.
    build = jobs['r139-hardened-pair-build']['steps']
    old_build = old_jobs['r139-hardened-pair-build']['steps']
    for index,(new_step,old_step) in enumerate(zip(build,old_build),1):
        if index in (27,28,53,56):
            continue
        check(f'build_step{index:02d}_byte_identical', new_step==old_step)
    gate, = extracted.get('R13191_STRICT_GATE.py', [])
    for marker in (
        'NATIVE_SIGNER_OR_OWNER_GUARD','UNTRUSTED_ADDITIONAL_UNINSTALL',
        'ORIGINAL_PACKAGE_OR_BOOT_DESTRUCTIVE','NATIVE_APK_HASH_MISMATCH',
        'ASSET_NATIVE_HASH_MISMATCH','SIGNER_PAIR_NOT_CONFIRMED',
        'R1312_PREPATCH_NOT_PASSED','R1312_UNDECLARED_MUTATION_',
        'NEW_FINALIZER_NOT_EXACT','NEW_RESTORE_NOT_EXACT',
        'RESTORE_UI_NOT_EXACT','RESTORE_VM_NOT_EXACT',
    ):
        check('strict_gate:'+marker, marker in gate)
    patch_run = build[27]['run']
    check('postsource_audit_invoked_before_compilation', 'python3 R13191_STRICT_GATE.py magisk reports postsource' in patch_run)
    root_run = jobs['r1314-root-hide-restore-avd']['steps'][2]['run']
    for marker in (
        'HIDDEN_APP_ROOT_UID0_VISIBLE_PROOF.txt','R1319_ORIGINAL_PACKAGE_DISAPPEARED_DURING_HIDE',
        'R1319_ORIGINAL_LAUNCHER_STILL_STARTABLE','R1319_HIDDEN_STUB_REMAINS_INSTALLED_AFTER_RESTORE',
        'R1319_ORIGINAL_LAUNCHER_NOT_REENABLED','ORIGINAL_START_CONFIRMED_CLEANUP_SCHEDULED',
        'MANAGER_BIND_RESET_VERIFIED','Status: ok',
    ):
        check('root_e2e:'+marker, marker in root_run)
    # Parser self-check: arguments/redirections and nested heredocs must remain visible.
    sample = 'if python3 - "$input" > "$output" <<\'PY\'\nprint(1)\nPY\nthen :; fi\n'
    parsed = list(heredocs(sample))
    check('parser_handles_python_args_and_redirection', len(parsed)==1 and parsed[0][3]=='print(1)\n')
    python_args = [r for r in report['heredocs'] if r['language']=='python' and re.search(r'python3\s+-\s+[^<\s]',r['header'])]
    check('python_heredocs_with_arguments_were_checked', len(python_args)>=8)
    report['python_heredocs_with_arguments'] = len(python_args)
    if args.extract_dir:
        args.extract_dir.mkdir(parents=True,exist_ok=True)
        for target, variants in extracted.items():
            for index, code in enumerate(variants,1):
                filename = Path(target).name
                if len(variants)>1:
                    filename = f'{index}_{filename}'
                (args.extract_dir/filename).write_text(code,encoding='utf-8')
    report['summary'] = {
        'result':'PASS' if not report['errors'] else 'FAIL',
        'jobs':len(jobs), 'steps':sum(len(j['steps']) for j in jobs.values()),
        'bash_run_steps':sum(r['kind']=='run' for r in report['bash_checks']),
        'bash_generated_scripts':sum(r['kind']=='generated_script' for r in report['bash_checks']),
        'python_blocks':len(report['python_checks']),
        'python_file_outputs':sum(len(v) for v in extracted.values()),
        'preservation_checks':len(report['preservation_checks']),
        'errors':len(report['errors']),
    }
    args.report.parent.mkdir(parents=True,exist_ok=True)
    args.report.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps(report['summary'],indent=2))
    for error in report['errors']:
        print(error,file=sys.stderr)
    return int(bool(report['errors']))


if __name__ == '__main__':
    raise SystemExit(main())
