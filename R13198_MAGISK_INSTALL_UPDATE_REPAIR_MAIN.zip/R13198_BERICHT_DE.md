# R13.19.8 – dauerhafte Signatur, Neuinstallation und Update

## Ergebnis und aktueller Stand

Das Thema war bereits in früheren Fassungen behandelt. R13.9 enthielt einen dauerhaften Signierweg und ein Termux-Skript. Der dauerhafte Schlüssel war jedoch **optional**. Wenn im Buildjob keine der vier Secret-Variablen gefüllt war, erzeugte der Workflow einen neuen temporären Schlüssel. Genau dieser Modus ist für den grünen Lauf [44436521996](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44436521996) belegt. Daraus folgt nicht, dass auf dem Telefon kein früher erzeugter Schlüssel existiert.

Die vorliegende R13.19.8 korrigiert den vollständigen Workflow. Sie verlangt den erhaltenen Signierschlüssel und einen öffentlichen Zertifikatsfingerabdruck, ergänzt einen tatsächlichen Android-Neuinstallations-/Updatevertrag und veröffentlicht die abschließende APK erst nach allen Pflichtprüfungen. Die Produktquellen aus dem grünen R13.19.7-Lauf bleiben unverändert.

**Die neue Workflowfassung wurde lokal integriert und geprüft, aber noch nicht in einem neuen GitHub-Lauf ausgeführt. Eine neue R13.19.8-APK und ein erfolgreicher Update-/Neuinstallationsnachweis auf dem Redmi liegen deshalb noch nicht vor.** Die bereits ausgegebene R13.19.7-APK wurde weder verändert noch nachsigniert.

## 1. Nachgewiesene Ursachen

### Optionaler statt verbindlicher Dauerschlüssel

Der alte Signierschritt hatte drei Fälle: alle vier Werte vorhanden → `STABLE_SECRET`; nur ein Teil vorhanden → Fehler; kein Wert vorhanden → `EPHEMERAL_RESEARCH_ONLY` mit einem neu erzeugten Schlüssel. Die APK des grünen Laufs wurde im dritten Fall gebaut. Ein weiteres grünes Build mit einem anderen temporären Schlüssel wäre deshalb noch kein Android-Update derselben Installation.

Android verlangt für ein reguläres Update eine passende Signieridentität. Eine neue Signatur kann einen fehlenden alten privaten Schlüssel nicht ersetzen. Das bloße erneute Signieren der bereits gebauten APK würde zudem die Bindung an den im Magisk-Core eingebetteten `TRUSTED_CERT` nicht nachträglich reparieren. Quellen: [Android App Signing](https://developer.android.com/studio/publish/app-signing), `evidence/PERSISTENT_SIGNING_AUDIT.json`, `evidence/PHONE_COMPATIBILITY_AUDIT.json`.

### Erzwungener Berichtswert

Der bisherige R13.19.2-Preflight gab unabhängig vom Prüfergebnis stets `phone_in_place_update: BLOCKED` aus und verlangte diesen Wert anschließend per Assertion. Selbst eine korrekt erhaltene Signieridentität konnte diese Ausgabe nicht ändern. Der neue Bericht trennt jetzt Build-Identität, tatsächlichen Android-Installationstest und unbekannte Telefonkompatibilität.

### Kein nachgewiesener Updatevorgang

Die 15 GUI-Fälle des grünen Laufs prüfen APK-Installation und Start. Der zusätzliche gerootete Android-13-Fall prüft Root, Hide, Abbrechen, Bestätigen und Restore. Ein Update zwischen zwei verschiedenen, gleich signierten APK-Dateien mit nachgewiesen erhaltenem App-UID und App-Daten war darin bisher nicht enthalten.

## 2. Änderungen in R13.19.8

### Erhaltene Signieridentität

Die gleichen vier Repository-Secrets bleiben in Verwendung:

| Typ | Name |
|---|---|
| Secret | `MAGISK_HIDE_P12_BASE64` |
| Secret | `MAGISK_HIDE_P12_PASSWORD` |
| Secret | `MAGISK_HIDE_P12_KEY_PASSWORD` |
| Secret | `MAGISK_HIDE_P12_ALIAS` |
| Öffentliche Repository-Variable | `MAGISK_HIDE_SIGNER_SHA256` |

Ein früher Check erkennt fehlende Konfiguration vor dem langen Build. Der vollständige Import prüft den PKCS12-Container, beide Passwörter, den privaten Schlüssel zum Alias, Zertifikatsgültigkeit, den öffentlichen Fingerabdruck und eine echte Signatur mit anschließender Verifikation. Erst dann wird `STABLE_SECRET` geschrieben. Es gibt keine automatische Erzeugung eines Ersatzschlüssels im Workflow.

Der native Core und die APK werden gemeinsam mit diesem Schlüssel gebaut. Die bestehenden Prüfungen `TRUSTED_CERT = APK-Signer = Build-Schlüssel` sowie alle vier nativen APK-/Daemon-Bindungen bleiben verbindlich. Private Schlüsseldateien und Passwortdateien werden nicht als Artefakt veröffentlicht.

### Tatsächlicher Neuinstallations-/Updatevertrag im CI-Emulator

Der Workflow erstellt eine ausdrücklich synthetische Fixture: dieselbe vollständige APK mit einem zusätzlichen gekennzeichneten Test-Asset. Beide Dateien müssen verschiedene Gesamt-Hashes, aber die gleiche Signatur, das gleiche Manifest und identische native Programme enthalten. Diese Fixture ist keine frühere Produktveröffentlichung.

Der gerootete API33-Test prüft anschließend:

1. Vor der Installation fehlt der Original-Manager im isolierten, frischen Emulator.
2. Der unveränderte offizielle Magisk-AVD-Helper installiert die Fixture.
3. Die tatsächlich installierten APK-Bytes und der zugehörige App-UID werden gelesen; der laufende Core muss weiterhin den erwarteten nativen Bytes entsprechen.
4. Ein dem App-UID zugehöriger Datenmarker wird in dessen App-Datenverzeichnis angelegt.
5. `adb install -r` installiert die echte finale APK. Der Test verlangt exakt deren Hash, denselben UID und erhaltene Daten. Ein Deinstallationsschritt ist nicht implementiert.
6. Danach folgen die bisherigen Benachrichtigungsfreigaben und der vollständige Root-/Hide-/Abbrechen-/Bestätigen-/Restore-Test.

Diese ADB-Schritte laufen ausschließlich auf dem GitHub-Emulator. Für den Benutzer ist weder ein PC noch ADB auf dem Telefon erforderlich.

### Abschluss und APK-Download

Alle 15 GUI-Fälle bleiben unverändert. Das abschließende Aggregat verlangt zusätzlich den erfolgreichen Buildjob, erfolgreichen Rootjob, vollständigen Root-Abschlussbericht und den an die konkrete APK, Fixture und Signatur gebundenen Installationsvertrag. Fehlende oder unvollständige Belege führen nicht zu PASS.

Erst nach diesem Gesamterfolg entsteht das Artefakt:

`R13198_APK_STABLE_SIGNER_INSTALL_UPDATE_VERIFIED`

Es enthält `Magisk_R13198.apk`, deren SHA-256 und die vollständige Abschlussauswertung. Der Telefonstatus bleibt dabei ausdrücklich `UNKNOWN` / `NOT_ATTESTED`, weil ein CI-Emulator keine Installation auf dem Redmi beobachtet.

## 3. Was A und B für das vorhandene Telefon bedeuten

| Weg | Erforderlicher Nachweis | Stand |
|---|---|---|
| **A: bestehende App aktualisieren** | Installierte App und neue APK besitzen eine kompatible Signatur; der tatsächlich laufende Magisk-Core passt zu den unveränderten Authentifizierungs- und Native-Prüfungen. | Aktuelle Telefonwerte fehlen. Ein erhaltener R13.9-Schlüssel soll zuerst geprüft und weiterverwendet werden. |
| **B: neue Installation mit dauerhafter Identität** | Eine neue Paketinstallation ist möglich; ein eventuell bestehender Original-/Hidden-Manager und die Bindung des vorhandenen Root-Cores müssen geordnet berücksichtigt werden. | Der neue CI-Vertrag prüft die frische Installation. Eine konkrete Migration des vorhandenen Telefons ist damit noch nicht bestätigt. |

Die zuletzt gemessene Telefon-Core-SHA `2022c38a…` unterscheidet sich von der ARM64-Payload der grünen R13.19.7-APK `a653748b…`. Diese historische Messung ist kein aktueller Telefonbefund. Die App verlangt derzeit jedoch absichtlich exakt passende laufende Daemon-Bytes. Zusätzlich prüft der Core die Manager-Signatur. Deshalb lässt sich volle Root-/Hide-/Restore-Funktion mit einem neuen Schlüssel nicht allein durch Entfernen und erneutes Installieren der Manager-APK garantieren.

Die vorhandenen Original-/Hidden-Pakete, Root-Bindungen und Authentifizierungsprüfungen werden durch dieses Paket nicht verändert. Eine Core-Migration benötigt einen eigenen, konkret geprüften Ablauf. Aus dem Fehlen einer alten Schlüsseldatei entsteht kein Anlass, ungeprüft den vorhandenen Manager zu deinstallieren.

**Vorgesehene manuelle Updatefolge:** versteckte App zunächst zum Original-Manager wiederherstellen → neue Projekt-APK aktualisieren → anschließend bei Bedarf erneut verstecken. Ein Update während des versteckten Zustands ist nicht abgenommen. Der vorhandene In-App-Updater bleibt auf seinem Upstream-Verhalten; R13.19.8 richtet keinen eigenen automatischen Projekt-Updatekanal ein.

## 4. Einmalige Einrichtung auf dem Smartphone

### Vorhandenen R13.9-Schlüssel prüfen

`R13198_SIGNING_SETUP_TERMUX.sh` übernimmt den früheren Standardpfad:

```text
$HOME/.config/magisk-hide-r139-signer
```

Nach dem Herunterladen des Skripts wird es in Termux zunächst nur geprüft:

```bash
bash ~/storage/downloads/R13198_SIGNING_SETUP_TERMUX.sh --inspect
```

Falls die Programme fehlen, nennt das Skript `pkg install python openssl-tool`. Falls Termux noch keinen Zugriff auf den Downloadordner hat, muss dieser Zugriff einmal mit `termux-setup-storage` freigegeben werden. Der Prüfmodus erzeugt keinen neuen Schlüssel und gibt weder private Schlüssel noch Passwörter aus.

`--prepare` verwendet einen vorhandenen gültigen R13.9-Schlüssel unverändert und erzeugt die passenden vier Secret-Dateien sowie den öffentlichen Fingerprint. Nur wenn das gewählte private Verzeichnis tatsächlich noch keinen Schlüsselbestand enthält, erzeugt dieser ausdrücklich gewählte Vorbereitungsmodus einmalig eine neue Identität. Vor einer solchen Neuerzeugung sollte geklärt sein, ob ein bisher genutzter Schlüssel an einem anderen Ort erhalten ist. Ein neuer Schlüssel ist kein Ersatz für die Signatur der derzeit installierten App.

Ein vorhandener falscher oder unvollständiger Schlüsselbestand, abweichender gespeicherter Fingerprint oder falsches Passwort wird nicht stillschweigend ersetzt. Der Helper bewahrt die PKCS12-Datei beim Wiederverwenden bytegleich. Dateien mit privaten Werten bleiben im privaten Termux-Verzeichnis.

### GitHub-Werte hinterlegen

Unter [Repository Settings → Secrets and variables → Actions](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/settings/secrets/actions) werden die vier gleichnamigen Secret-Dateien als Repository-Secrets hinterlegt. `MAGISK_HIDE_SIGNER_SHA256.txt` wird als Wert der öffentlichen Repository-Variable `MAGISK_HIDE_SIGNER_SHA256` eingetragen. Beim alten R13.9-Container sind Store- und Key-Passwort gleich; der neue Helper exportiert beide Dateien ausdrücklich.

Die privaten Dateien gehören ausschließlich in die vorgesehenen GitHub-Secrets und in eine private Sicherung. Für die weitere Prüfung im Chat genügt der öffentliche Prüfbericht. Quelle zur Einrichtung: [GitHub Actions Secrets](https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-secrets).

### Aktuelle Telefonidentität rein lesend erfassen

Der zusätzliche Helper `R13198_PHONE_PREFLIGHT_READONLY.sh` liest die Signatur der tatsächlich installierten Original-Manager-APK, die Signatur der angegebenen Kandidaten-APK und die SHA-256 der laufenden `magiskd`-Programme. Er prüft außerdem die nativen Kandidatenbytes gegen deren eingebetteten Erwartungshash. Die private temporäre APK-Lesekopie wird danach entfernt; Root, Apps, Datenbank und Boot-Partition werden nicht verändert.

Für die bereits heruntergeladene grüne APK lautet der Aufruf:

```bash
bash ~/storage/downloads/R13198_PHONE_PREFLIGHT_READONLY.sh \
  ~/storage/downloads/Magisk_R13197_Run44436521996.apk
```

Falls die APK anders benannt oder abgelegt wurde, wird nur das zweite Argument auf ihren tatsächlichen Pfad geändert. Der Helper benötigt eine lesende Root-Abfrage über das vorhandene Magisk. Fehlen Termux-Werkzeuge, nennt er ausdrücklich `pkg install python apksigner`; er installiert nichts automatisch. Diese Pakete betreffen nur die Termux-Werkzeuge, nicht den Magisk-Manager.

Die öffentliche Datei `R13198_PHONE_PREFLIGHT_PUBLIC_….json` wird im erreichbaren Downloadordner, sonst im Termux-Home gespeichert. `MATCH` oder `DIFFERENT` beziehen sich jeweils auf Zertifikat und Core. Auch ein vollständiger Identitätsbericht ist noch kein auf dem Telefon ausgeführter Installationstest. Zusammen mit der öffentlichen Ausgabe des Schlüsselhelfers reicht er, um die derzeit fehlende Zuordnung zwischen erhaltenem Schlüssel, installierter App und laufendem Core zu prüfen. Private Schlüssel und Passwortdateien sind hierfür nicht erforderlich.

### Neuen Workflow starten

Die mitgelieferte vollständige YAML gehört nach `.github/workflows/R13198_MAGISK_31100_PERSISTENT_SIGNING_INSTALL_UPDATE.yml` auf den Standardbranch. Anschließend den neuen Workflow **Magisk R13.19.8** unter Actions mit **Run workflow** starten. Der neue Build setzt die fünf zuvor genannten Werte voraus; er erzeugt bei fehlender Einrichtung keine neue Wegwerf-Identität.

Ein erneutes **Re-run** des alten R13.19.7-Laufs testet nicht automatisch die neu hinzugefügte Workflowdatei. Quellen: [manueller Workflowstart](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow), [Wiederholen von Workflows](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs).

Die verfügbare GitHub-Verbindung hatte das Schreiben von Workflowdateien mit HTTP 403 `Resource not accessible by integration` abgewiesen; in dieser Sitzung ist kein neu verfügbarer Schreib- oder Secret-Verwaltungszugriff belegt. Die Änderung liegt deshalb als vollständige Datei vor und wird hier nicht als bereits auf GitHub veröffentlicht ausgegeben.

## 5. Verifikation und Nachweisgrenzen

Die beigefügten JSON-Berichte unterscheiden echte Werkzeugprüfungen und simulierte Testeingaben ausdrücklich:

- Echte PKCS12-/Java-/`apksigner`-Prüfungen für den Schlüsselimport.
- Echte APK-Signatur-, Manifest-, Alignment- und Payload-Prüfungen für die Fixture.
- Echte OpenSSL-Prüfungen des Termux-Schlüsselhelfers einschließlich Wiederverwendung und Fehlerfällen.
- Kontrollierte Fake-ADB-Eingaben für die Ablauf- und Fehlerfalllogik; diese sind kein Android-Laufzeitnachweis.
- Berichtstests und simulierte Nachweise für das abschließende Aggregat.
- Bash-/Python-/YAML-Prüfung und bytegenauer Vergleich der erhaltenen Produktquellschritte und GUI-Tests.

Die lokale Labor-APK `f04dcbdb…` und ihre Fixture dienen ausschließlich der Werkzeugprüfung. Die grüne Nutzer-APK `d9b78b40…` wurde nicht geändert. Die lokalen Labor-APKs und temporären privaten Testschlüssel sind nicht Teil des Lieferpakets.

Die endgültigen Testzahlen, Implementierungs-Hashes und Nachweisarten stehen in `evidence/R13198_VERIFICATION_SUMMARY.json`. Ein neuer GitHub-Lauf und die konkreten aktuellen Telefonwerte bleiben für die nächste Freigabe erforderlich.
