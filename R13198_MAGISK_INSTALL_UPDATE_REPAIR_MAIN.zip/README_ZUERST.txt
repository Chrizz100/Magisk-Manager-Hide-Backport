R13.19.8 – vollständiger Workflow auf der grünen R13.19.7-Produktbasis.

Zuerst R13198_BERICHT_DE.md lesen. Die YAML ist vollständig eigenständig;
ihre eingebetteten Prüfprogramme benötigen keinen zusätzlichen Repository-Upload.
Vier erhaltene Signier-Secrets + MAGISK_HIDE_SIGNER_SHA256 sind vor dem Start nötig.
Vorhandenen R13.9-Schlüssel mit dem Termux-Helper zunächst --inspect prüfen.
Aktuelle Telefonwerte liefert das separate rein lesende Phone-Preflight.
Das Paket enthält keinen privaten Schlüssel und keine neu freigegebene APK.
Nach vollständigem GitHub-Erfolg: Artifact
R13198_APK_STABLE_SIGNER_INSTALL_UPDATE_VERIFIED herunterladen.
