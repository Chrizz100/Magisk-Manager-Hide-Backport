#!/usr/bin/env python3
"""Actual installation/update contract for one disposable GitHub API33 AVD.

prepare runs before official avd_setup installs the synthetic fixture. complete
runs after the existing daemon-byte verification and before the existing
notification-permission/UI stages. No APK uninstallation or phone operation is
implemented. The exact release APK is installed at the end.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import zipfile

PACKAGE = "com.topjohnwu.magisk"
FIXTURE_ASSET = "assets/r13198_install_update_fixture.json"
RESULT_NAME = "R13198_INSTALL_UPDATE_RESULT.json"
SCHEMA = "r13198.install-update-v1"
APP_DATA_DIR = "/data/user/0/" + PACKAGE
DATA_DIR = APP_DATA_DIR + "/files"
SENTINEL = DATA_DIR + "/r13198_update_contract.txt"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def load_inputs(release: Path, fixture: Path, manifest: Path) -> dict:
    document = json.loads(manifest.read_text())
    require(document.get("schema") == "r13198.install-update-fixture.v1" and document.get("status") == "PASS", "Invalid fixture verification report")
    require(document.get("package") == PACKAGE and document.get("version_code") == 31100, "Wrong package/version contract")
    require(document.get("fixture_role") == "SYNTHETIC_INSTALL_UPDATE_FIXTURE_NOT_A_RELEASE", "Fixture role is not explicit")
    require(document.get("fixture_asset") == FIXTURE_ASSET, "Wrong fixture marker path")
    require(document.get("payload_same_except_fixture_asset") is True, "Fixture payload identity was not established")
    for key, path in (("release_apk_sha256", release), ("fixture_apk_sha256", fixture)):
        require(digest(path.read_bytes()) == document.get(key), "APK hash differs from fixture report: " + key)
    require(document["release_apk_sha256"] != document["fixture_apk_sha256"], "Update must use two byte-different APKs")
    require(re.fullmatch(r"[0-9a-f]{64}", document.get("certificate_sha256", "")) is not None, "Missing verified certificate fingerprint")
    with zipfile.ZipFile(release) as original, zipfile.ZipFile(fixture) as modified:
        require(original.testzip() is None and modified.testzip() is None, "APK CRC check failed")
        require(FIXTURE_ASSET not in original.namelist() and FIXTURE_ASSET in modified.namelist(), "Release/fixture role mismatch")
        require(original.read("AndroidManifest.xml") == modified.read("AndroidManifest.xml"), "Fixture manifest differs")
        require(digest(original.read("AndroidManifest.xml")) == document.get("manifest_sha256"), "Manifest hash differs")
        native = document.get("native_sha256", {})
        require(set(native) == {"arm64-v8a", "armeabi-v7a", "x86", "x86_64"}, "Missing native architectures")
        for abi, expected in native.items():
            name = "lib/" + abi + "/libmagisk.so"
            require(original.read(name) == modified.read(name), "Fixture changed native bytes: " + abi)
            require(digest(original.read(name)) == expected, "Native hash differs: " + abi)
        marker = json.loads(modified.read(FIXTURE_ASSET))
        require(marker.get("release_apk_sha256") == document["release_apk_sha256"], "Fixture references a different release")
    return document


class Contract:
    def __init__(self, release: Path, fixture: Path, manifest: Path, out: Path):
        self.release, self.fixture, self.manifest, self.out = release, fixture, manifest, out
        self.out.mkdir(parents=True, exist_ok=True)
        self.path = out / RESULT_NAME
        self.inputs = load_inputs(release, fixture, manifest)
        self.serial: str | None = None
        self.report: dict = {}

    def save(self) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.report, indent=2) + "\n")
        temp.replace(self.path)

    def command(self, args: list[str], timeout: int = 60) -> str:
        command = ["adb"] + (["-s", self.serial] if self.serial else []) + args
        result = subprocess.run(command, text=True, capture_output=True, timeout=timeout)
        record = {"argv": command, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
        self.report.setdefault("commands", []).append(record)
        self.save()
        require(result.returncode == 0, "ADB command failed: " + " ".join(args))
        return result.stdout.replace("\r", "").strip()

    def shell(self, *args: str) -> str:
        return self.command(["shell", *args])

    def guard(self) -> None:
        require(os.environ.get("GITHUB_ACTIONS") == "true", "GitHub Actions only; no phone/local bypass")
        run_id = os.environ.get("GITHUB_RUN_ID", "")
        require(run_id.isdigit(), "Missing GitHub run provenance")
        raw = self.command(["devices"])
        devices = [line.split() for line in raw.splitlines() if line and not line.startswith("List of devices attached")]
        require(len(devices) == 1 and len(devices[0]) == 2, "Exactly one isolated ADB device is required")
        serial, state = devices[0]
        require(re.fullmatch(r"emulator-\d+", serial) is not None and state == "device", "Physical, offline or ambiguous target rejected")
        require(not os.environ.get("ANDROID_SERIAL") or os.environ["ANDROID_SERIAL"] == serial, "ANDROID_SERIAL conflicts with isolated emulator")
        self.serial = serial
        require(self.shell("getprop", "ro.kernel.qemu") == "1", "QEMU property required")
        require(self.shell("getprop", "ro.build.version.sdk") == "33", "Only API33 is authorized")
        require(self.shell("getprop", "ro.product.cpu.abi") == "x86_64", "Only x86_64 AVD is authorized")
        require(self.shell("id", "-u") == "0", "Rooted ADB shell is required for app-data proof")
        self.report["emulator"] = {"serial": serial, "api": 33, "abi": "x86_64", "qemu": True}
        self.report["github_run_id"] = run_id
        self.save()

    def third_party_packages(self) -> list[str]:
        text = self.shell("pm", "list", "packages", "-3", "--user", "0")
        lines = text.splitlines() if text else []
        require(all(re.fullmatch(r"package:[A-Za-z0-9_.]+", line) for line in lines), "Unexpected package-list output")
        return sorted(line.removeprefix("package:") for line in lines)

    def selinux_context(self, path: str) -> str:
        context = self.shell("stat", "-c", "%C", path)
        require(re.fullmatch(r"u:object_r:[A-Za-z0-9_]+:s0(?::c\d+(?:[,.]c\d+)*)?", context) is not None,
                "Cannot verify application-data SELinux context: " + path)
        return context

    def installed(self) -> dict:
        uid_text = self.shell("pm", "list", "packages", "-U", "--user", "0", PACKAGE)
        match = re.fullmatch(r"package:com\.topjohnwu\.magisk uid:(\d+)", uid_text)
        require(match is not None, "Original package UID is missing or ambiguous")
        uid = int(match.group(1))
        require(uid >= 10000, "Unexpected application UID")
        path_text = self.shell("pm", "path", "--user", "0", PACKAGE)
        match = re.fullmatch(r"package:(/data/app/[^\r\n]+/base\.apk)", path_text)
        require(match is not None, "Expected exactly one installed base APK")
        path = match.group(1)
        sha_text = self.shell("sha256sum", path)
        match = re.fullmatch(r"([0-9a-f]{64})\s+" + re.escape(path), sha_text)
        require(match is not None, "Cannot verify installed APK bytes")
        require(self.third_party_packages() == [PACKAGE], "Contract requires the normal original package without a hidden manager")
        return {"uid": uid, "apk_path": path, "apk_sha256": match.group(1)}

    def prepare(self) -> None:
        require(not self.path.exists(), "Refusing stale installation-contract result")
        self.report = {
            "schema": SCHEMA, "status": "RUNNING", "phase": "prepare",
            "release_apk_sha256": self.inputs["release_apk_sha256"],
            "apk_sha256": self.inputs["release_apk_sha256"],
            "fixture_apk_sha256": self.inputs["fixture_apk_sha256"],
            "fixture_manifest_sha256": digest(self.manifest.read_bytes()),
            "certificate_sha256": self.inputs["certificate_sha256"],
            "signer_sha256": self.inputs["certificate_sha256"],
            "package": PACKAGE, "version_code": 31100,
            "fixture_is_historical_release": False,
            "update_scope": "NORMAL_ORIGINAL_PACKAGE_ONLY",
            "normal_manager_only": True,
            "hidden_state_update_tested": False,
            "physical_device_tested": False,
            "fresh_install_verified": False, "update_verified": False,
            "uid_preserved": False, "app_data_preserved": False,
            "final_release_exact": False,
            "fresh_install": {"passed": False, "was_absent": False},
            "update_in_place": {"passed": False, "same_uid": False, "data_preserved": False, "without_uninstall": False},
        }
        self.save()
        self.guard()
        packages = self.third_party_packages()
        require(packages == [], "Fresh fixture installation requires an empty third-party package state")
        require(self.shell("pm", "list", "packages", "--user", "0", PACKAGE) == "", "The original package already exists")
        self.report.update(status="PREPARED", phase="awaiting_official_fixture_install", empty_package_state_verified=True, packages_before=packages)
        self.report["fresh_install"]["was_absent"] = True
        self.save()

    def complete(self) -> None:
        prior = json.loads(self.path.read_text())
        require(prior.get("schema") == SCHEMA and prior.get("status") == "PREPARED", "Missing completed pre-install precondition")
        require(prior.get("empty_package_state_verified") is True, "Fresh-install baseline was not verified")
        require(prior.get("github_run_id") == os.environ.get("GITHUB_RUN_ID"), "Result belongs to a different GitHub run")
        require(prior.get("release_apk_sha256") == self.inputs["release_apk_sha256"] and prior.get("fixture_apk_sha256") == self.inputs["fixture_apk_sha256"], "Prepared APK identity changed")
        require(prior.get("fixture_manifest_sha256") == digest(self.manifest.read_bytes()), "Fixture report changed after preparation")
        self.report = prior
        self.report.update(status="RUNNING", phase="verify_fresh_fixture_install")
        expected_serial = prior.get("emulator", {}).get("serial")
        self.guard()
        require(self.serial == expected_serial, "Emulator changed between contract phases")
        fresh = self.installed()
        require(fresh["apk_sha256"] == self.inputs["fixture_apk_sha256"], "Official helper did not install the exact fixture")
        native = self.shell("sha256sum", "/debug_ramdisk/magisk").split()
        require(len(native) == 2 and native[0] == self.inputs["native_sha256"]["x86_64"] and native[1] == "/debug_ramdisk/magisk", "Live daemon differs from both APKs")
        self.report.update(fresh_install_verified=True, fresh_install={
            "passed": True, "was_absent": True,
            "installed_apk_sha256": fresh["apk_sha256"], "uid": fresh["uid"],
            "apk_path": fresh["apk_path"],
        }, phase="prepare_app_data_marker")
        self.save()
        uid = str(fresh["uid"])
        marker = "r13198-update-data-" + secrets.token_hex(16)
        marker_file = self.out / "r13198_update_marker_input.txt"
        marker_file.write_text(marker)
        app_context = self.selinux_context(APP_DATA_DIR)
        self.shell("mkdir", "-p", DATA_DIR)
        self.shell("chown", uid + ":" + uid, DATA_DIR)
        self.shell("chmod", "700", DATA_DIR)
        self.command(["push", str(marker_file), SENTINEL])
        self.shell("chown", uid + ":" + uid, SENTINEL)
        self.shell("chmod", "600", SENTINEL)
        # Android 13 skips app-data descendants during recursive restorecon
        # unless -D is supplied. Do not infer a correct label from exit status.
        self.shell("restorecon", "-D", "-R", DATA_DIR)
        require(self.shell("cat", SENTINEL) == marker, "App-data marker was not written")
        require(self.shell("stat", "-c", "%u:%g", SENTINEL) == uid + ":" + uid, "Marker must be owned by the application UID")
        require(self.selinux_context(DATA_DIR) == app_context, "Files directory does not have the installed application's SELinux context")
        require(self.selinux_context(SENTINEL) == app_context, "Marker does not have the installed application's SELinux context")
        self.report.update(phase="replace_with_exact_release", marker_sha256=digest(marker.encode()), marker_app_owned_before=True,
                           marker_selinux_context=app_context, marker_context_verified_before=True)
        self.save()
        install_output = self.command(["install", "--no-streaming", "-r", str(self.release)], timeout=240)
        require("Success" in install_output.splitlines(), "Android did not confirm the replacement install")
        updated = self.installed()
        require(updated["apk_sha256"] == self.inputs["release_apk_sha256"], "Final installed APK is not the exact release")
        require(updated["uid"] == fresh["uid"], "Update changed the app UID")
        require(self.shell("cat", SENTINEL) == marker, "Update lost the application data marker")
        require(self.shell("stat", "-c", "%u:%g", SENTINEL) == uid + ":" + uid, "Update changed marker ownership")
        require(self.selinux_context(APP_DATA_DIR) == app_context, "Update changed the application's SELinux context")
        require(self.selinux_context(DATA_DIR) == app_context, "Update changed the files directory's SELinux context")
        require(self.selinux_context(SENTINEL) == app_context, "Update changed marker SELinux context")
        self.shell("rm", SENTINEL)
        self.report.update(
            status="PASS", phase="COMPLETE", update_verified=True,
            uid_preserved=True, app_data_preserved=True, final_release_exact=True,
            marker_removed=True, marker_context_preserved=True, final_install=updated,
            install_method="fresh fixture via official AVD helper, then byte-different release via adb install -r",
            expected_user_sequence="restore original manager before update; hide again only after a successful normal-state update",
            root_hide_restore_result="SEPARATE_FOLLOWING_REQUIRED_TEST",
            update_in_place={
                "passed": True, "installed_apk_sha256": updated["apk_sha256"],
                "same_uid": True, "uid_before": fresh["uid"], "uid_after": updated["uid"],
                "data_preserved": True, "data_context_preserved": True, "without_uninstall": True,
            },
        )
        self.save()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "complete"))
    for name in ("release-apk", "fixture-apk", "manifest", "out"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    contract = None
    try:
        contract = Contract(args.release_apk.resolve(), args.fixture_apk.resolve(), args.manifest.resolve(), args.out.resolve())
        getattr(contract, args.phase)()
        print(json.dumps({"status": contract.report["status"], "phase": contract.report["phase"]}))
    except Exception as exc:
        # Never convert missing evidence, an ADB failure or a partial update into PASS.
        if contract is not None:
            if not contract.report and contract.path.exists():
                try:
                    contract.report = json.loads(contract.path.read_text())
                except (OSError, ValueError):
                    contract.report = {"schema": SCHEMA}
            contract.report.update(status="FAIL", error=str(exc), physical_device_tested=False)
            contract.save()
        raise SystemExit("R13198_INSTALL_UPDATE_CONTRACT_FAILED: " + str(exc))


if __name__ == "__main__":
    main()
