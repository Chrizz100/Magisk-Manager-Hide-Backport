# R13.19.8 – echter Neuinstallations- und Updatevertrag

Dieser Zusatz prüft den Android-Paketmanager mit zwei byteverschiedenen, gleich
signierten APKs des vollständigen Magisk-Pakets `com.topjohnwu.magisk`,
Versionscode `31100`. Er verändert keine Magisk-App- oder Native-Quelldatei.
Die bestehenden GUI- und Root-/Hide-/Restore-Prüfungen bleiben verpflichtend.

## Dateien und Integration

- `R13198_BUILD_UPDATE_FIXTURE.py` erzeugt im Buildjob nach den vorhandenen
  Signatur-/Native-/APK-Gates die beiden öffentlichen Dateien
  `R13198_INSTALL_UPDATE_FIXTURE.apk` und
  `R13198_INSTALL_UPDATE_FIXTURE.json`.
- `R13198_INSTALL_UPDATE.py` enthält den zweiphasigen tatsächlichen AVD-Test.
- `workflow_install_update_snippets.py` erzeugt exakte Ergänzungen für den
  geprüften R13.19.7-Workflow. Es überschreibt die Eingabe-YAML nicht.
- `generated_snippets/` enthält die erzeugten Build-, Upload- und Download-
  Schritte sowie den ergänzten Root-Scriptgenerator und Emulatoraufruf.

Der Fixture-Build benötigt die bereits importierte PKCS12-Datei und die
bestehenden vier Secret-Namen. Die Passwörter werden von `apksigner` über
Umgebungsvariablen gelesen. Der erwartete öffentliche Zertifikatsfingerabdruck
steht in `R13198_EXPECTED_SIGNER_SHA256`. Private Schlüssel und Passwörter werden
nicht in das Fixture-Artefakt aufgenommen. Das Artefakt heißt
`R13198_INSTALL_UPDATE_FIXTURE` und wird nur zusätzlich in den Root-AVD-Job
heruntergeladen; die 15 GUI-Jobs brauchen es nicht.

## Was die Fixture bedeutet

Die Fixture ist ausdrücklich **keine historische Veröffentlichung**. Sie ist
eine Kopie der echten Release-APK mit genau einem zusätzlichen gekennzeichneten
Test-Asset. Der Builder prüft tatsächlich beide Signaturen, unterschiedliche
APK-Hashes, ein identisches Manifest und bytegleiche Payloads einschließlich
aller vier nativen Magisk-Programme. Damit lässt sich ein echter
Paketmanager-Updatevorgang ausführen, ohne Produktcode nur für den Test zu ändern.

## Ablauf im vorhandenen Root-AVD

1. `prepare` verlangt GitHub Actions, genau einen erreichbaren Emulator,
   QEMU, API 33, x86_64 und eine ADB-Shell mit UID 0. Das normale Magisk-Paket und
   alle anderen Drittanbieterpakete müssen noch fehlen. Der Bericht bleibt
   anschließend `PREPARED`; das ist kein PASS.
2. Der gepinnte offizielle `avd_setup`-Helper installiert diese Fixture frisch.
   Seine nativen Programme sind nachweislich dieselben wie in der Release-APK.
3. Die vorhandene Root- und Live-Daemon-Hashprüfung läuft unverändert gegen die
   Release-APK weiter.
4. `complete` prüft die tatsächlich installierten Fixture-Bytes und ihren UID.
   Im App-Datenverzeichnis wird ein Marker mit dem App-UID als Eigentümer
   geschrieben. `restorecon -D -R` stellt auch die Datei innerhalb des
   App-Datenverzeichnisses wieder her; ohne `-D` überspringt Android 13 diese
   Untereinträge. Der tatsächliche SELinux-Kontext von `files` und Marker muss
   dem von Android vergebenen Kontext des App-Verzeichnisses entsprechen.
   Der Paketbestand muss ausschließlich den normalen Original-Manager enthalten.
5. `adb install -r` installiert die echte, byteverschiedene Release-APK.
   Installierte APK-SHA, unveränderter UID, erhaltener Marker und dessen
   unveränderter Eigentümer und SELinux-Kontext werden überprüft.
   Der Marker wird danach entfernt.
   Ein Paket-Uninstall ist im Zusatz nicht implementiert.
6. Erst danach folgen die bestehenden Benachrichtigungsfreigaben und der
   vollständige unveränderte Root-/Hide-/Abbrechen-/Bestätigen-/Restore-Test.

Der Ergebnisbericht `R13198_INSTALL_UPDATE_RESULT.json` verwendet das Schema
`r13198.install-update-v1`. Die unabhängige Abschlussprüfung muss `status=PASS`
und alle `fresh_install`-/`update_in_place`-Nachweise sowie die gebundenen APK-
und Signatur-Hashes verlangen. Ein vorbereiteter oder teilweise ausgeführter
Vertrag reicht nicht.

## Nachweisgrenzen

Dieser Zusatz prüft ein Update **im normalen Original-Managerzustand**.
Ein Update während die App versteckt ist wird ausdrücklich nicht behauptet.
Der vorgesehene Ablauf lautet: zum Original-Manager zurückkehren, aktualisieren,
danach bei Bedarf erneut verstecken. Der nachfolgende Root-Test prüft dieses
Verstecken und Wiederherstellen nach dem Update.

Ein gleichsigniertes Installer-Update der synthetischen Fixture beweist weder
eine Migration von R13.4 noch die Annahme einer anderen Signatur durch eine
bereits installierte Telefon-App. Die Smartphone-/Daemon-Kompatibilität wird
dadurch ebenfalls nicht automatisch bestätigt.

Die lokal ausgeführten Prüfungen sind getrennt dokumentiert:

- `FIXTURE_CRYPTO_REGRESSIONS.json`: tatsächliche APK-Signatur-, ZIP-Alignment-
  und Payload-Prüfung einschließlich falschem Zertifikat/Schlüssel und
  öffentlichem Fingerprint mit äußerem Leerraum. Die zusätzliche Prüfung des
  Leerraums ist in `FIXTURE_SIGNER_WHITESPACE_REGRESSION.json` einzeln belegt;
  die vier unveränderten vorherigen Kryptofälle wurden dafür nicht wiederholt.
- `INSTALL_UPDATE_ORCHESTRATION_REGRESSIONS.json`: klar gekennzeichnete
  Fake-ADB-Eingaben für Erfolgs- und Fehlerpfade; kein Android-Laufzeitnachweis.
- `WORKFLOW_SNIPPET_VALIDATION.json`: Bash-Syntax und bytegenaue Rekonstruktion
  des ursprünglichen Root-Testgenerators nach Rücknahme der exakten Ergänzungen.
- `ANDROID13_ENVIRONMENT_REVIEW.json`: Abgleich mit den echten grünen
  Paket-/Datenpfadbelegen und den Android-13-Implementierungen von Paketmanager,
  `stat` und `restorecon`; ausdrücklich kein neuer Emulatorlauf.

Die tatsächliche neue Android-Ausführung steht bis zum nächsten GitHub-Lauf aus.
Die lokalen `crypto_proof*`-APKs sind Prüfmaterial und gehören nicht als
Telefon-Download in das öffentliche Lieferpaket. Die ausführbaren Programme,
Integrationsdateien und JSON-Prüfberichte reichen für dessen Reproduktion.
