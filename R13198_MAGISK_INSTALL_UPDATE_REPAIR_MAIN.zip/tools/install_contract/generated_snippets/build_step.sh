set -euo pipefail
cat > R13198_BUILD_UPDATE_FIXTURE.py <<'R13198_FIXTURE_BUILDER_PY'
#!/usr/bin/env python3
"""Build a public, same-signer APK installation probe from the real release APK.

The probe is a synthetic fixture, not a previously published version. Only one
clearly labelled asset differs; application code, manifest and native payloads
are byte-identical. The private keystore and credentials are never copied out.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import tempfile
import zipfile

ASSET = "assets/r13198_install_update_fixture.json"
PACKAGE = "com.topjohnwu.magisk"
VERSION_CODE = 31100
SCHEMA = "r13198.install-update-fixture.v1"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def signature_entry(name: str) -> bool:
    name = name.upper()
    return name.startswith("META-INF/") and (
        name == "META-INF/MANIFEST.MF" or name.endswith((".SF", ".RSA", ".DSA", ".EC"))
    )


def payload(apk: Path) -> dict[str, bytes]:
    with zipfile.ZipFile(apk) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("Duplicate ZIP entry in APK")
        if archive.testzip() is not None:
            raise ValueError("APK ZIP CRC failed")
        return {
            name: archive.read(name) for name in names
            if not name.endswith("/") and not signature_entry(name)
        }


def checked(args: list[str], env: dict[str, str] | None = None) -> str:
    proc = subprocess.run(args, env=env, text=True, capture_output=True, timeout=180)
    text = proc.stdout + proc.stderr
    for name in ("R139_STOREPASS", "R139_KEYPASS", "R139_P12_B64"):
        secret = (env or os.environ).get(name, "")
        if secret:
            text = text.replace(secret, "[REDACTED]")
    if proc.returncode:
        raise RuntimeError(f"{Path(args[0]).name} failed ({proc.returncode}): {text[:6000]}")
    return text


def signer(apksigner: str, apk: Path) -> str:
    text = checked([apksigner, "verify", "--verbose", "--print-certs", str(apk)])
    if not re.search(r"^Number of signers: 1$", text, re.M):
        raise ValueError("Exactly one APK signer is required")
    certificates = re.findall(
        r"^(?:V[1-4](?:\.\d+)? Signer:|Signer #1) certificate SHA-256 digest: ([0-9a-fA-F]{64})$",
        text, re.M,
    )
    distinct = {value.lower() for value in certificates}
    if len(distinct) != 1:
        raise ValueError("APK certificate SHA-256 was missing or ambiguous")
    return distinct.pop()


def manifest_identity(aapt2: str, apk: Path) -> tuple[str, int]:
    text = checked([aapt2, "dump", "badging", str(apk)])
    matches = re.findall(r"^package: name='([^']+)' versionCode='(\d+)'", text, re.M)
    if len(matches) != 1:
        raise ValueError("Missing or ambiguous Android package identity")
    return matches[0][0], int(matches[0][1])


def build(args: argparse.Namespace) -> dict:
    release = Path(args.release_apk).resolve()
    out = Path(args.out_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)
    expected = args.expected_signer_sha256.strip().lower()
    if not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Expected certificate must be a SHA-256 fingerprint")
    if not re.fullmatch(r"[A-Za-z0-9_.-]+", args.alias):
        raise ValueError("Invalid keystore alias")
    for name in ("R139_STOREPASS", "R139_KEYPASS"):
        if not os.environ.get(name):
            raise ValueError(f"Missing credential environment variable {name}")
    if manifest_identity(args.aapt2, release) != (PACKAGE, VERSION_CODE):
        raise ValueError("Release is not the required complete Magisk 31100 package")
    if signer(args.apksigner, release) != expected:
        raise ValueError("Release signer differs from the explicitly pinned identity")
    original = payload(release)
    if ASSET in original:
        raise ValueError("A synthetic fixture cannot be supplied as the release APK")
    release_sha = sha256(release.read_bytes())
    marker = {
        "schema": SCHEMA,
        "role": "SYNTHETIC_INSTALL_UPDATE_FIXTURE_NOT_A_RELEASE",
        "release_apk_sha256": release_sha,
        "payload_change": "This test-only asset; not application code or previous-release history",
    }
    final_fixture = out / "R13198_INSTALL_UPDATE_FIXTURE.apk"
    final_report = out / "R13198_INSTALL_UPDATE_FIXTURE.json"
    if final_fixture.exists() or final_report.exists():
        raise ValueError("Refusing to overwrite existing fixture evidence")
    fixture = out / ".r13198-fixture-pending.apk"
    with tempfile.TemporaryDirectory(prefix="r13198-fixture-", dir=out) as directory:
        temp = Path(directory)
        unsigned = temp / "unsigned.apk"
        aligned = temp / "aligned.apk"
        with zipfile.ZipFile(release) as source, zipfile.ZipFile(unsigned, "w") as target:
            for info in source.infolist():
                if not signature_entry(info.filename):
                    target.writestr(info, source.read(info))
            info = zipfile.ZipInfo(ASSET, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            target.writestr(info, json.dumps(marker, sort_keys=True).encode() + b"\n")
        checked([args.zipalign, "-P", "16", "-f", "4", str(unsigned), str(aligned)])
        checked([
            args.apksigner, "sign", "--ks", str(Path(args.keystore).resolve()),
            "--ks-key-alias", args.alias,
            "--ks-pass", "env:R139_STOREPASS", "--key-pass", "env:R139_KEYPASS",
            "--v1-signing-enabled", "false", "--v2-signing-enabled", "true",
            "--v3-signing-enabled", "false", "--v4-signing-enabled", "false",
            "--out", str(fixture), str(aligned),
        ])
    checked([args.zipalign, "-c", "-P", "16", "4", str(fixture)])
    if signer(args.apksigner, fixture) != expected:
        raise ValueError("Fixture signer differs from the release signer")
    modified = payload(fixture)
    if set(modified) != set(original) | {ASSET}:
        raise ValueError("Fixture APK has unexpected payload paths")
    if any(modified[name] != value for name, value in original.items()):
        raise ValueError("Fixture changed release payload bytes")
    if manifest_identity(args.aapt2, fixture) != (PACKAGE, VERSION_CODE):
        raise ValueError("Fixture package/version changed")
    fixture_sha = sha256(fixture.read_bytes())
    if fixture_sha == release_sha:
        raise ValueError("The update probe must be byte-different from the release")
    native = {
        name.split("/")[1]: sha256(data)
        for name, data in original.items()
        if re.fullmatch(r"lib/[^/]+/libmagisk\.so", name)
    }
    if set(native) != {"arm64-v8a", "armeabi-v7a", "x86", "x86_64"}:
        raise ValueError("All four Magisk native architectures are required")
    report = {
        "schema": SCHEMA, "status": "PASS",
        "fixture_role": marker["role"],
        "release_apk_sha256": release_sha, "fixture_apk_sha256": fixture_sha,
        "certificate_sha256": expected, "signer_sha256": expected,
        "package": PACKAGE, "version_code": VERSION_CODE,
        "manifest_sha256": sha256(original["AndroidManifest.xml"]),
        "native_sha256": native, "fixture_asset": ASSET,
        "payload_same_except_fixture_asset": True,
        "android_runtime_execution": "NOT_PERFORMED_BY_FIXTURE_BUILDER",
        "historical_version_update_tested": False,
        "hidden_state_update_tested": False,
        "keystore_or_credentials_in_output": False,
    }
    fixture.replace(final_fixture)
    final_report.write_text(json.dumps(report, indent=2) + "\n")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("release-apk", "keystore", "alias", "apksigner", "aapt2", "zipalign", "expected-signer-sha256", "out-dir"):
        parser.add_argument("--" + option, required=True)
    args = parser.parse_args()
    try:
        print(json.dumps(build(args), indent=2))
    except Exception as exc:
        # Tool output is scrubbed by checked(); no credentials enter this message.
        raise SystemExit("R13198_FIXTURE_BUILD_FAILED: " + str(exc))


if __name__ == "__main__":
    main()
R13198_FIXTURE_BUILDER_PY
sdk_tools="$(python3 - <<'R13198_SDK_TOOLS'
from pathlib import Path
import os,re
root=Path(os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT') or '/opt/android-sdk')
choices=[p for p in (root/'build-tools').glob('*') if all((p/name).is_file() for name in ('apksigner','aapt2','zipalign'))]
assert choices,'Required Android signing/alignment tools are missing'
choices.sort(key=lambda p:tuple(int(x) for x in re.findall(r'\d+',p.name)))
print(choices[-1])
R13198_SDK_TOOLS
)"
python3 R13198_BUILD_UPDATE_FIXTURE.py \
  --release-apk "$GITHUB_WORKSPACE/magisk/out/app-release.apk" \
  --keystore "$GITHUB_WORKSPACE/magisk/r6-ci-only.p12" \
  --alias "$R139_ALIAS" \
  --apksigner "$sdk_tools/apksigner" --aapt2 "$sdk_tools/aapt2" --zipalign "$sdk_tools/zipalign" \
  --expected-signer-sha256 "$R13198_EXPECTED_SIGNER_SHA256" \
  --out-dir "$GITHUB_WORKSPACE/r13198-install-fixture"
