cat > R13198_INSTALL_UPDATE.py <<'R13198_INSTALL_UPDATE_PY'
#!/usr/bin/env python3
"""Actual installation/update contract for one disposable GitHub API33 AVD.

prepare runs before official avd_setup installs the synthetic fixture. complete
runs after the existing daemon-byte verification and before the existing
notification-permission/UI stages. No APK uninstallation or phone operation is
implemented. The exact release APK is installed at the end.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import subprocess
import sys
import zipfile

PACKAGE = "com.topjohnwu.magisk"
FIXTURE_ASSET = "assets/r13198_install_update_fixture.json"
RESULT_NAME = "R13198_INSTALL_UPDATE_RESULT.json"
SCHEMA = "r13198.install-update-v1"
APP_DATA_DIR = "/data/user/0/" + PACKAGE
DATA_DIR = APP_DATA_DIR + "/files"
SENTINEL = DATA_DIR + "/r13198_update_contract.txt"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def load_inputs(release: Path, fixture: Path, manifest: Path) -> dict:
    document = json.loads(manifest.read_text())
    require(document.get("schema") == "r13198.install-update-fixture.v1" and document.get("status") == "PASS", "Invalid fixture verification report")
    require(document.get("package") == PACKAGE and document.get("version_code") == 31100, "Wrong package/version contract")
    require(document.get("fixture_role") == "SYNTHETIC_INSTALL_UPDATE_FIXTURE_NOT_A_RELEASE", "Fixture role is not explicit")
    require(document.get("fixture_asset") == FIXTURE_ASSET, "Wrong fixture marker path")
    require(document.get("payload_same_except_fixture_asset") is True, "Fixture payload identity was not established")
    for key, path in (("release_apk_sha256", release), ("fixture_apk_sha256", fixture)):
        require(digest(path.read_bytes()) == document.get(key), "APK hash differs from fixture report: " + key)
    require(document["release_apk_sha256"] != document["fixture_apk_sha256"], "Update must use two byte-different APKs")
    require(re.fullmatch(r"[0-9a-f]{64}", document.get("certificate_sha256", "")) is not None, "Missing verified certificate fingerprint")
    with zipfile.ZipFile(release) as original, zipfile.ZipFile(fixture) as modified:
        require(original.testzip() is None and modified.testzip() is None, "APK CRC check failed")
        require(FIXTURE_ASSET not in original.namelist() and FIXTURE_ASSET in modified.namelist(), "Release/fixture role mismatch")
        require(original.read("AndroidManifest.xml") == modified.read("AndroidManifest.xml"), "Fixture manifest differs")
        require(digest(original.read("AndroidManifest.xml")) == document.get("manifest_sha256"), "Manifest hash differs")
        native = document.get("native_sha256", {})
        require(set(native) == {"arm64-v8a", "armeabi-v7a", "x86", "x86_64"}, "Missing native architectures")
        for abi, expected in native.items():
            name = "lib/" + abi + "/libmagisk.so"
            require(original.read(name) == modified.read(name), "Fixture changed native bytes: " + abi)
            require(digest(original.read(name)) == expected, "Native hash differs: " + abi)
        marker = json.loads(modified.read(FIXTURE_ASSET))
        require(marker.get("release_apk_sha256") == document["release_apk_sha256"], "Fixture references a different release")
    return document


class Contract:
    def __init__(self, release: Path, fixture: Path, manifest: Path, out: Path):
        self.release, self.fixture, self.manifest, self.out = release, fixture, manifest, out
        self.out.mkdir(parents=True, exist_ok=True)
        self.path = out / RESULT_NAME
        self.inputs = load_inputs(release, fixture, manifest)
        self.serial: str | None = None
        self.report: dict = {}

    def save(self) -> None:
        temp = self.path.with_suffix(".tmp")
        temp.write_text(json.dumps(self.report, indent=2) + "\n")
        temp.replace(self.path)

    def command(self, args: list[str], timeout: int = 60) -> str:
        command = ["adb"] + (["-s", self.serial] if self.serial else []) + args
        result = subprocess.run(command, text=True, capture_output=True, timeout=timeout)
        record = {"argv": command, "returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
        self.report.setdefault("commands", []).append(record)
        self.save()
        require(result.returncode == 0, "ADB command failed: " + " ".join(args))
        return result.stdout.replace("\r", "").strip()

    def shell(self, *args: str) -> str:
        return self.command(["shell", *args])

    def guard(self) -> None:
        require(os.environ.get("GITHUB_ACTIONS") == "true", "GitHub Actions only; no phone/local bypass")
        run_id = os.environ.get("GITHUB_RUN_ID", "")
        require(run_id.isdigit(), "Missing GitHub run provenance")
        raw = self.command(["devices"])
        devices = [line.split() for line in raw.splitlines() if line and not line.startswith("List of devices attached")]
        require(len(devices) == 1 and len(devices[0]) == 2, "Exactly one isolated ADB device is required")
        serial, state = devices[0]
        require(re.fullmatch(r"emulator-\d+", serial) is not None and state == "device", "Physical, offline or ambiguous target rejected")
        require(not os.environ.get("ANDROID_SERIAL") or os.environ["ANDROID_SERIAL"] == serial, "ANDROID_SERIAL conflicts with isolated emulator")
        self.serial = serial
        require(self.shell("getprop", "ro.kernel.qemu") == "1", "QEMU property required")
        require(self.shell("getprop", "ro.build.version.sdk") == "33", "Only API33 is authorized")
        require(self.shell("getprop", "ro.product.cpu.abi") == "x86_64", "Only x86_64 AVD is authorized")
        require(self.shell("id", "-u") == "0", "Rooted ADB shell is required for app-data proof")
        self.report["emulator"] = {"serial": serial, "api": 33, "abi": "x86_64", "qemu": True}
        self.report["github_run_id"] = run_id
        self.save()

    def third_party_packages(self) -> list[str]:
        text = self.shell("pm", "list", "packages", "-3", "--user", "0")
        lines = text.splitlines() if text else []
        require(all(re.fullmatch(r"package:[A-Za-z0-9_.]+", line) for line in lines), "Unexpected package-list output")
        return sorted(line.removeprefix("package:") for line in lines)

    def selinux_context(self, path: str) -> str:
        context = self.shell("stat", "-c", "%C", path)
        require(re.fullmatch(r"u:object_r:[A-Za-z0-9_]+:s0(?::c\d+(?:[,.]c\d+)*)?", context) is not None,
                "Cannot verify application-data SELinux context: " + path)
        return context

    def installed(self) -> dict:
        uid_text = self.shell("pm", "list", "packages", "-U", "--user", "0", PACKAGE)
        match = re.fullmatch(r"package:com\.topjohnwu\.magisk uid:(\d+)", uid_text)
        require(match is not None, "Original package UID is missing or ambiguous")
        uid = int(match.group(1))
        require(uid >= 10000, "Unexpected application UID")
        path_text = self.shell("pm", "path", "--user", "0", PACKAGE)
        match = re.fullmatch(r"package:(/data/app/[^\r\n]+/base\.apk)", path_text)
        require(match is not None, "Expected exactly one installed base APK")
        path = match.group(1)
        sha_text = self.shell("sha256sum", path)
        match = re.fullmatch(r"([0-9a-f]{64})\s+" + re.escape(path), sha_text)
        require(match is not None, "Cannot verify installed APK bytes")
        require(self.third_party_packages() == [PACKAGE], "Contract requires the normal original package without a hidden manager")
        return {"uid": uid, "apk_path": path, "apk_sha256": match.group(1)}

    def prepare(self) -> None:
        require(not self.path.exists(), "Refusing stale installation-contract result")
        self.report = {
            "schema": SCHEMA, "status": "RUNNING", "phase": "prepare",
            "release_apk_sha256": self.inputs["release_apk_sha256"],
            "apk_sha256": self.inputs["release_apk_sha256"],
            "fixture_apk_sha256": self.inputs["fixture_apk_sha256"],
            "fixture_manifest_sha256": digest(self.manifest.read_bytes()),
            "certificate_sha256": self.inputs["certificate_sha256"],
            "signer_sha256": self.inputs["certificate_sha256"],
            "package": PACKAGE, "version_code": 31100,
            "fixture_is_historical_release": False,
            "update_scope": "NORMAL_ORIGINAL_PACKAGE_ONLY",
            "normal_manager_only": True,
            "hidden_state_update_tested": False,
            "physical_device_tested": False,
            "fresh_install_verified": False, "update_verified": False,
            "uid_preserved": False, "app_data_preserved": False,
            "final_release_exact": False,
            "fresh_install": {"passed": False, "was_absent": False},
            "update_in_place": {"passed": False, "same_uid": False, "data_preserved": False, "without_uninstall": False},
        }
        self.save()
        self.guard()
        packages = self.third_party_packages()
        require(packages == [], "Fresh fixture installation requires an empty third-party package state")
        require(self.shell("pm", "list", "packages", "--user", "0", PACKAGE) == "", "The original package already exists")
        self.report.update(status="PREPARED", phase="awaiting_official_fixture_install", empty_package_state_verified=True, packages_before=packages)
        self.report["fresh_install"]["was_absent"] = True
        self.save()

    def complete(self) -> None:
        prior = json.loads(self.path.read_text())
        require(prior.get("schema") == SCHEMA and prior.get("status") == "PREPARED", "Missing completed pre-install precondition")
        require(prior.get("empty_package_state_verified") is True, "Fresh-install baseline was not verified")
        require(prior.get("github_run_id") == os.environ.get("GITHUB_RUN_ID"), "Result belongs to a different GitHub run")
        require(prior.get("release_apk_sha256") == self.inputs["release_apk_sha256"] and prior.get("fixture_apk_sha256") == self.inputs["fixture_apk_sha256"], "Prepared APK identity changed")
        require(prior.get("fixture_manifest_sha256") == digest(self.manifest.read_bytes()), "Fixture report changed after preparation")
        self.report = prior
        self.report.update(status="RUNNING", phase="verify_fresh_fixture_install")
        expected_serial = prior.get("emulator", {}).get("serial")
        self.guard()
        require(self.serial == expected_serial, "Emulator changed between contract phases")
        fresh = self.installed()
        require(fresh["apk_sha256"] == self.inputs["fixture_apk_sha256"], "Official helper did not install the exact fixture")
        native = self.shell("sha256sum", "/debug_ramdisk/magisk").split()
        require(len(native) == 2 and native[0] == self.inputs["native_sha256"]["x86_64"] and native[1] == "/debug_ramdisk/magisk", "Live daemon differs from both APKs")
        self.report.update(fresh_install_verified=True, fresh_install={
            "passed": True, "was_absent": True,
            "installed_apk_sha256": fresh["apk_sha256"], "uid": fresh["uid"],
            "apk_path": fresh["apk_path"],
        }, phase="prepare_app_data_marker")
        self.save()
        uid = str(fresh["uid"])
        marker = "r13198-update-data-" + secrets.token_hex(16)
        marker_file = self.out / "r13198_update_marker_input.txt"
        marker_file.write_text(marker)
        app_context = self.selinux_context(APP_DATA_DIR)
        self.shell("mkdir", "-p", DATA_DIR)
        self.shell("chown", uid + ":" + uid, DATA_DIR)
        self.shell("chmod", "700", DATA_DIR)
        self.command(["push", str(marker_file), SENTINEL])
        self.shell("chown", uid + ":" + uid, SENTINEL)
        self.shell("chmod", "600", SENTINEL)
        # Android 13 skips app-data descendants during recursive restorecon
        # unless -D is supplied. Do not infer a correct label from exit status.
        self.shell("restorecon", "-D", "-R", DATA_DIR)
        require(self.shell("cat", SENTINEL) == marker, "App-data marker was not written")
        require(self.shell("stat", "-c", "%u:%g", SENTINEL) == uid + ":" + uid, "Marker must be owned by the application UID")
        require(self.selinux_context(DATA_DIR) == app_context, "Files directory does not have the installed application's SELinux context")
        require(self.selinux_context(SENTINEL) == app_context, "Marker does not have the installed application's SELinux context")
        self.report.update(phase="replace_with_exact_release", marker_sha256=digest(marker.encode()), marker_app_owned_before=True,
                           marker_selinux_context=app_context, marker_context_verified_before=True)
        self.save()
        install_output = self.command(["install", "--no-streaming", "-r", str(self.release)], timeout=240)
        require("Success" in install_output.splitlines(), "Android did not confirm the replacement install")
        updated = self.installed()
        require(updated["apk_sha256"] == self.inputs["release_apk_sha256"], "Final installed APK is not the exact release")
        require(updated["uid"] == fresh["uid"], "Update changed the app UID")
        require(self.shell("cat", SENTINEL) == marker, "Update lost the application data marker")
        require(self.shell("stat", "-c", "%u:%g", SENTINEL) == uid + ":" + uid, "Update changed marker ownership")
        require(self.selinux_context(APP_DATA_DIR) == app_context, "Update changed the application's SELinux context")
        require(self.selinux_context(DATA_DIR) == app_context, "Update changed the files directory's SELinux context")
        require(self.selinux_context(SENTINEL) == app_context, "Update changed marker SELinux context")
        self.shell("rm", SENTINEL)
        self.report.update(
            status="PASS", phase="COMPLETE", update_verified=True,
            uid_preserved=True, app_data_preserved=True, final_release_exact=True,
            marker_removed=True, marker_context_preserved=True, final_install=updated,
            install_method="fresh fixture via official AVD helper, then byte-different release via adb install -r",
            expected_user_sequence="restore original manager before update; hide again only after a successful normal-state update",
            root_hide_restore_result="SEPARATE_FOLLOWING_REQUIRED_TEST",
            update_in_place={
                "passed": True, "installed_apk_sha256": updated["apk_sha256"],
                "same_uid": True, "uid_before": fresh["uid"], "uid_after": updated["uid"],
                "data_preserved": True, "data_context_preserved": True, "without_uninstall": True,
            },
        )
        self.save()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("prepare", "complete"))
    for name in ("release-apk", "fixture-apk", "manifest", "out"):
        parser.add_argument("--" + name, required=True, type=Path)
    args = parser.parse_args()
    contract = None
    try:
        contract = Contract(args.release_apk.resolve(), args.fixture_apk.resolve(), args.manifest.resolve(), args.out.resolve())
        getattr(contract, args.phase)()
        print(json.dumps({"status": contract.report["status"], "phase": contract.report["phase"]}))
    except Exception as exc:
        # Never convert missing evidence, an ADB failure or a partial update into PASS.
        if contract is not None:
            if not contract.report and contract.path.exists():
                try:
                    contract.report = json.loads(contract.path.read_text())
                except (OSError, ValueError):
                    contract.report = {"schema": SCHEMA}
            contract.report.update(status="FAIL", error=str(exc), physical_device_tested=False)
            contract.save()
        raise SystemExit("R13198_INSTALL_UPDATE_CONTRACT_FAILED: " + str(exc))


if __name__ == "__main__":
    main()
R13198_INSTALL_UPDATE_PY
cat > R13193_AVD_FOREIGN_DIALOG.py <<'R13193_DIALOG_PY'
#!/usr/bin/env python3
"""Recognize only the confirmed Android AVD KeyChain process-crash dialog.

This selector never dismisses Magisk crashes, security prompts, SU dialogs,
or an arbitrary system popup. The bash caller enforces a one-time recovery.
"""
from __future__ import annotations
import re
import sys
import xml.etree.ElementTree as ET

RECT = re.compile(r"^\[(\d+),(\d+)\]\[(\d+),(\d+)\]$")

def coordinates(xml: str) -> tuple[int, int] | None:
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return None
    nodes = list(root.iter("node"))
    titles = [n for n in nodes if n.get("package") == "android"
              and n.get("resource-id") == "android:id/alertTitle"
              and n.get("text", "").strip() == "Key Chain keeps stopping"]
    closes = [n for n in nodes if n.get("package") == "android"
              and n.get("resource-id") == "android:id/aerr_close"
              and n.get("text", "").strip() == "Close app"
              and n.get("clickable") == "true"
              and n.get("enabled") == "true"]
    if len(titles) != 1 or len(closes) != 1:
        return None
    hit = RECT.fullmatch(closes[0].get("bounds", ""))
    if not hit:
        return None
    x1, y1, x2, y2 = map(int, hit.groups())
    if not (0 <= x1 < x2 <= 4000 and 0 <= y1 < y2 <= 4000):
        return None
    return ((x1+x2)//2, (y1+y2)//2)

def selftest() -> None:
    sample = '<hierarchy><node package="android" resource-id="android:id/alertTitle" text="Key Chain keeps stopping"/><node package="android" resource-id="android:id/aerr_close" text="Close app" clickable="true" enabled="true" bounds="[71,1241][1009,1373]"/></hierarchy>'
    assert coordinates(sample) == (540,1307)
    assert coordinates(sample.replace('Key Chain keeps stopping','Magisk keeps stopping')) is None
    assert coordinates(sample.replace('package="android"','package="com.topjohnwu.magisk"')) is None
    assert coordinates(sample.replace('clickable="true"','clickable="false"')) is None
    assert coordinates(sample.replace('enabled="true"','enabled="false"')) is None
    assert coordinates(sample.replace('[71,1241][1009,1373]','invalid')) is None
    assert coordinates(sample.replace('Close app','Grant')) is None
    assert coordinates(sample+sample) is None
    assert coordinates('<node invalid') is None
    print('R13193_FOREIGN_SYSTEM_DIALOG_SELECTOR_SELFTEST_PASS')

if __name__ == '__main__':
    if len(sys.argv) == 2 and sys.argv[1] == '--self-test':
        selftest();sys.exit(0)
    if len(sys.argv) != 2:
        sys.exit(2)
    try:
        result = coordinates(open(sys.argv[1], encoding='utf-8').read())
    except OSError:
        sys.exit(2)
    if result is None:
        sys.exit(1)
    print(result[0], result[1])
R13193_DIALOG_PY
python3 R13193_AVD_FOREIGN_DIALOG.py --self-test
cat > R1315_ROOT_HIDE_RESTORE_AVD.sh <<'R1315_END_SCRIPT'
#!/usr/bin/env bash
# Root/Hide/Restore acceptance test ONLY on an isolated API 33 x86_64 QEMU emulator.
# Never run against a physical phone. Exit nonzero on any missing functional proof.
set -Eeuo pipefail
: "${GITHUB_ACTIONS:?GitHub Actions only}"
APK=${1:?APK required}
MAGISK_SRC=${2:?Magisk source directory required}
OUT=${3:-"$PWD/r1314-e2e"}
FIXTURE=${4:?Verified update fixture APK required}
FIXTURE_REPORT=${5:?Verified fixture identity required}
mkdir -p "$OUT"
rc=1; state=BLOCKED
finish() {
  rc=$?
  trap - EXIT
  adb logcat -d -v time > "$OUT/logcat.txt" 2>&1 || true
  adb shell dumpsys activity activities > "$OUT/activity.txt" 2>&1 || true
  adb shell pm list packages -3 > "$OUT/packages_final.txt" 2>&1 || true
  adb shell df -Pk /data > "$OUT/data_free_final.txt" 2>&1 || true
  local final_status=FAIL
  [[ $rc -eq 0 ]] && final_status=ROOT_HIDE_RESTORE_PASS
  R1314_STATUS="$final_status" R1314_STATE="$state" R1314_RC="$rc" \
    python3 - "$OUT/R1314_E2E_RESULT.json" <<'PYJSON'
import json,os,sys
v={'schema':'r1314.root-hide-restore-avd-v1','status':os.environ['R1314_STATUS'],
   'last_stage':os.environ['R1314_STATE'],'exit_code':int(os.environ['R1314_RC']),
   'physical_device_tested':False,'physical_device_release':'HOLD',
   'note':'Root & Hide verified only if app-owned SU and package-transition evidence exists; no physical flash.'}
with open(sys.argv[1],'w') as f: json.dump(v,f,indent=2);f.write('\n')
PYJSON
  exit "$rc"
}
trap finish EXIT
[[ -s "$APK" && -s "$FIXTURE" && -s "$FIXTURE_REPORT" && -f "$MAGISK_SRC/build.py" ]] || exit 51
sdk="$(adb shell getprop ro.build.version.sdk | tr -d '\r\n')"
arch="$(adb shell getprop ro.product.cpu.abi | tr -d '\r\n')"
qemu="$(adb shell getprop ro.kernel.qemu | tr -d '\r\n')"
[[ "$sdk" == 33 && "$arch" == x86_64 && "$qemu" == 1 ]] || { echo 'NO_EMULATOR_SAFE_GATE' >&2; exit 52; }
# Android emulator's shell is rootable; no physical boot image is changed.
adb root > "$OUT/adb_root.txt" 2>&1
adb wait-for-device
[[ "$(adb shell id -u | tr -d '\r\n')" == 0 ]] || { echo 'ADB_ROOT_UNAVAILABLE' >&2;exit 53; }
state=VERIFY_EMPTY_AVD_BEFORE_FRESH_INSTALL
python3 R13198_INSTALL_UPDATE.py prepare --release-apk "$APK" --fixture-apk "$FIXTURE" --manifest "$FIXTURE_REPORT" --out "$OUT"
state=INSTALL_NATIVE_MATCHING_DAEMON
# Reuse official Magisk AVD setup. It installs binaries exactly from this build APK.
python3 "$MAGISK_SRC/build.py" -r emulator "$FIXTURE" > "$OUT/avd_setup.txt" 2>&1 || { tail -80 "$OUT/avd_setup.txt" >&2;exit 54; }
adb wait-for-device
for i in $(seq 1 60); do
 if [[ "$(adb shell getprop sys.boot_completed | tr -d '\r\n')" == 1 ]];then break;fi
 sleep 3
done
[[ "$(adb shell getprop sys.boot_completed | tr -d '\r\n')" == 1 ]] || exit 55
adb shell /debug_ramdisk/magisk -v > "$OUT/magisk_version.txt" 2>&1 || exit 56
adb shell su -c 'id -u' > "$OUT/su_daemon.txt" 2>&1 || exit 57
grep -Fxq 0 "$OUT/su_daemon.txt" || { echo 'MAGISK_SU_NOT_UID0' >&2;exit 58; }
# Verify the live daemon bytes match the packaged x86_64 native executable.
python3 - "$APK" "$OUT/expected_native.sha256" <<'PYNATIVE'
import zipfile,hashlib,sys
with zipfile.ZipFile(sys.argv[1]) as z:
 data=z.read('lib/x86_64/libmagisk.so')
open(sys.argv[2],'w').write(hashlib.sha256(data).hexdigest()+'\n')
PYNATIVE
adb shell sha256sum /debug_ramdisk/magisk > "$OUT/live_daemon.sha256" 2>&1
expected=$(cat "$OUT/expected_native.sha256")
grep -q "$expected" "$OUT/live_daemon.sha256" || { echo 'NATIVE_DAEMON_APK_HASH_MISMATCH' >&2;exit 59; }
# Permission dialog blocked the *previous* R13.14 root AVD test before Magisk UI.
# This changes only the disposable Android 13 x86_64 emulator, never a phone.
state=VERIFY_FRESH_INSTALL_AND_NORMAL_UPDATE
python3 R13198_INSTALL_UPDATE.py complete --release-apk "$APK" --fixture-apk "$FIXTURE" --manifest "$FIXTURE_REPORT" --out "$OUT"
state=ANDROID13_NOTIFICATION_PERMISSION
adb shell pm grant com.topjohnwu.magisk android.permission.POST_NOTIFICATIONS \
  > "$OUT/notification_permission.txt" 2>&1 || {
    echo 'R1315_ANDROID13_NOTIFICATION_GRANT_FAILED' >&2
    cat "$OUT/notification_permission.txt" >&2
    exit 71
  }
# Validate the notification permission rather than assuming the command worked.
adb shell dumpsys package com.topjohnwu.magisk > "$OUT/notification_permission_state.txt"
python3 - "$OUT/notification_permission_state.txt" <<'R1315_PERM_CHECK'
import sys,re
s=open(sys.argv[1],encoding='utf-8',errors='replace').read()
assert re.search(r'android\.permission\.POST_NOTIFICATIONS:[^\n]*granted=true',s), 'R1315_POST_NOTIFICATIONS_NOT_GRANTED'
R1315_PERM_CHECK
state=APP_LAUNCH
adb shell am force-stop com.topjohnwu.magisk >/dev/null 2>&1 || true
adb shell am start -W -n com.topjohnwu.magisk/.ui.MainActivity > "$OUT/original_start.txt" 2>&1
sleep 5
adb shell uiautomator dump /sdcard/r1314_home.xml >/dev/null 2>&1 || true
adb pull /sdcard/r1314_home.xml "$OUT/home.xml" >/dev/null 2>&1 || true
# Require the Hide control supplied by the current build (source-only checks do not count).
click_node() {
  local regex="$1"; local filename="$2"; local remote="/sdcard/r1314_${filename}.xml"
  adb shell uiautomator dump "$remote" > "$OUT/${filename}_dump.log" 2>&1 || return 1
  adb pull "$remote" "$OUT/${filename}.xml" >/dev/null 2>&1 || return 1
  # Under `if click_node ...`, Bash suppresses errexit: test the Python exit explicitly.
  if ! python3 R1316_UI_FIND.py "$OUT/${filename}.xml" "$regex" > "$OUT/${filename}_xy.txt"; then
    echo "R1315_UI_NODE_NOT_FOUND: $filename ($regex)" >&2
    return 1
  fi
  local x y
  read -r x y < "$OUT/${filename}_xy.txt" || return 1
  [[ "$x" =~ ^[0-9]+$ && "$y" =~ ^[0-9]+$ ]] || {
    echo "R1315_INVALID_TAP_COORDINATES: $filename" >&2
    return 1
  }
  adb shell input tap "$x" "$y"
}
# Android UI composition can take several seconds after the emulator restarted zygote.
# A notification permission screen is NOT proof of a working Magisk home.
state=WAIT_MAGISK_HOME
home_ready=false
foreign_dialog_recoveries=0
for attempt in $(seq 1 18); do
  if click_node 'Hide the Magisk app|Magisk.*verstecken|Magisk.*verbergen' before_hide; then
    home_ready=true; break
  fi
  # R13.19.2 real AVD failure: a KeyChain SYSTEM crash window covered
  # the Magisk activity. Do NOT confuse its overlay with a Hide bug.
  # Never dismiss a Magisk crash or arbitrary security/permission dialog.
  if [[ -s "$OUT/before_hide.xml" ]] &&
     python3 R13193_AVD_FOREIGN_DIALOG.py "$OUT/before_hide.xml" > "$OUT/r13193_foreign_dialog_xy.txt"; then
    if (( foreign_dialog_recoveries >= 1 )); then
      cp "$OUT/before_hide.xml" "$OUT/r13193_repeated_system_crash.xml"
      echo 'R13193_AVD_KEYCHAIN_SYSTEM_CRASH_REPEATED_NOT_A_MAGISK_HIDE_FAILURE' >&2
      exit 82
    fi
    read -r fx fy < "$OUT/r13193_foreign_dialog_xy.txt"
    [[ "$fx" =~ ^[0-9]+$ && "$fy" =~ ^[0-9]+$ ]] || exit 83
    cp "$OUT/before_hide.xml" "$OUT/r13193_original_system_crash.xml"
    echo "R13193_AVD_KEYCHAIN_CRASH_DIALOG_DISMISSED_ONCE: $fx $fy" > "$OUT/r13193_recovery_evidence.txt"
    adb shell input tap "$fx" "$fy" || exit 84
    ((++foreign_dialog_recoveries))
    # Relaunch only the original Magisk ACTIVITY, not the Magisk daemon.
    adb shell am start -W -n com.topjohnwu.magisk/.ui.MainActivity \
      > "$OUT/r13193_reopen_magisk_after_system_dialog.txt" 2>&1 || exit 85
    sleep 2
    continue
  fi
  sleep 2
done
[[ "$home_ready" == true ]] || {
  echo 'R1315_MAGISK_HOME_HIDE_CONTROL_NOT_FOUND_AFTER_PERMISSION_GRANT' >&2
  exit 60
}
state=HIDE_DIALOG
sleep 2
# Dialog must be present. Fill the label when an editable field is shown.
adb shell uiautomator dump /sdcard/r1314_dialog.xml >/dev/null 2>&1 || true
adb pull /sdcard/r1314_dialog.xml "$OUT/dialog.xml" >/dev/null 2>&1 || true
python3 - "$OUT/dialog.xml" > "$OUT/edit_xy.txt" <<'PYEDIT'
import sys,re,xml.etree.ElementTree as E
for n in E.parse(sys.argv[1]).getroot().iter('node'):
 if n.attrib.get('class','').endswith('EditText'):
  a=list(map(int,re.findall(r'\d+',n.attrib.get('bounds',''))))
  if len(a)==4:print((a[0]+a[2])//2,(a[1]+a[3])//2);sys.exit(0)
sys.exit(1)
PYEDIT
if [[ -s "$OUT/edit_xy.txt" ]];then read -r ex ey < "$OUT/edit_xy.txt";adb shell input tap "$ex" "$ey";adb shell input text ToolManager;adb shell input keyevent 4;fi
# Record initial packages before action; package changes, not UI labels, are decisive.
adb shell pm list packages -3 > "$OUT/packages_before.txt"
click_node '^OK$|^Hide$|^Verbergen$|^Bestätigen$' confirm_hide || { echo 'HIDE_CONFIRM_NOT_FOUND' >&2;exit 61; }
state=HIDDEN_MANAGER_PACKAGE
# Only accept newly installed random package distinct from the original.
found=''
for i in $(seq 1 30);do
 adb shell pm list packages -3 > "$OUT/packages_after.txt"
 found=$(python3 - "$OUT/packages_before.txt" "$OUT/packages_after.txt" <<'PYDIFF'
import sys
read=lambda p:{x.strip().removeprefix('package:') for x in open(p) if x.strip().startswith('package:')}
diff=read(sys.argv[2])-read(sys.argv[1]);diff.discard('com.topjohnwu.magisk')
if len(diff)==1:print(next(iter(diff)))
PYDIFF
 )
 [[ -n "$found" ]] && break
 sleep 3
done
[[ -n "$found" ]] || { echo 'HIDE_DID_NOT_CHANGE_PACKAGE_NAME' >&2;exit 62; }
printf '%s\n' "$found" > "$OUT/hidden_package.txt"
adb shell monkey -p "$found" -c android.intent.category.LAUNCHER 1 > "$OUT/hidden_launch.txt" 2>&1 || exit 63
sleep 6
# Evidence of a live hidden manager; app-owned SU grant still must be verified separately.
adb shell pidof "$found" > "$OUT/hidden_process.txt" 2>&1 || { echo 'HIDDEN_MANAGER_PROCESS_MISSING' >&2;exit 64; }
# A host-side SU call does not prove the hidden app is authorized. Test its own UI.
state=HIDDEN_APP_OWNED_SU
root_button_found=false
for scan in 1 2 3 4 5; do
  if click_node 'Magisk und Root abfragen' hidden_root_click; then root_button_found=true;break;fi
  adb shell input swipe 520 1400 520 350 440 || true
  sleep 2
done
[[ "$root_button_found" == true ]] || { echo 'HIDDEN_APP_ROOT_BUTTON_MISSING' >&2;exit 70; }
# R13.18: app-owned root proof. The earlier R13.17 assertion repeatedly
# inspected the same visible viewport while Text(output) sat BELOW 10+
# actions; this is not proof of a denied SU request.
# Never infer app-owned privileges from adb-shell's own UID 0.
root_ui_verified=false
state=HIDDEN_APP_OWNED_SU_RESULT
for attempt in $(seq 1 20); do
  remote="/sdcard/r1318_root_${attempt}.xml"
  adb shell uiautomator dump "$remote" > "$OUT/r1318_root_${attempt}.dump" 2>&1 || true
  adb pull "$remote" "$OUT/r1318_root_${attempt}.xml" >/dev/null 2>&1 || true
  if [[ -s "$OUT/r1318_root_${attempt}.xml" ]]; then
    python3 - "$OUT/r1318_root_${attempt}.xml" "$OUT/r1318_root_${attempt}.visible.txt" <<'PYROOTVIS'
import sys,xml.etree.ElementTree as ET
doc=ET.parse(sys.argv[1]);lines=[]
for node in doc.getroot().iter('node'):
    for attr in ('text','content-desc'):
        value=node.get(attr,'').strip()
        if value: lines.append(value)
open(sys.argv[2],'w').write('\n'.join(lines)+'\n')
PYROOTVIS
    # This must be BOTH the actual app's root UID and its Magisk version
    # result; a shell-side `su -c id` is insufficient evidence.
    if grep -Fq 'UID=0' "$OUT/r1318_root_${attempt}.visible.txt" && \
       grep -Fq 'MAGISK=' "$OUT/r1318_root_${attempt}.visible.txt" && \
       grep -Fq 'CODE=' "$OUT/r1318_root_${attempt}.visible.txt"; then
        cp "$OUT/r1318_root_${attempt}.visible.txt" "$OUT/HIDDEN_APP_ROOT_UID0_VISIBLE_PROOF.txt"
        root_ui_verified=true
        break
    fi
  fi
  # The native SU manager may request user approval. Accept only
  # an actual visible grant dialog, not an adb shell surrogate.
  if click_node '^Grant$|^Allow$|^Zulassen$|^Gewähren$' "r1318_grant_su_${attempt}"; then
    echo "SU_USER_GRANT_CLICKED attempt=$attempt" >> "$OUT/r1318_su_consent.txt"
  else
    # R13.17 repeatedly dumped the same screen without scrolling.
    # Root output is rendered after many controls in historical builds.
    # Scroll within the isolated AVD and preserve each diagnostic dump.
    adb shell input swipe 555 1880 550 635 430 >/dev/null 2>&1 || true
  fi
  sleep 2
done
[[ "$root_ui_verified" == true ]] || {
  echo 'R1318_HIDDEN_APP_ROOT_UNPROVEN_CHECK_R1318_ROOT_VISIBLE_LOGS' >&2
  exit 72
}
# R13.19.4: verified from the failing R13.19.3 AVD artifact:
# r1318_root_1.xml contains the second-stage button; r1318_root_2.xml
# has UID=0 but is scrolled BELOW it. Repeating an UPWARD finger swipe
# (1600 -> 350) cannot reveal a button ABOVE the viewport.
# Restore the TOP viewport with DOWNWARD finger swipes BEFORE searching.
# Only the test's UI viewport is modified; never skip the actual Hide.
state=ORIGINAL_LAUNCHER_HIDE
adb shell uiautomator dump /sdcard/r13194_before_viewport_reset.xml \
  > "$OUT/r13194_before_viewport_reset_dump.log" 2>&1 || true
adb pull /sdcard/r13194_before_viewport_reset.xml \
  "$OUT/r13194_before_viewport_reset.xml" >/dev/null 2>&1 || true
for reset in 1 2; do
  adb shell input swipe 530 380 530 1820 470 >/dev/null 2>&1 || true
  sleep 1
done
hide_button_found=false
for trial in 1 2 3 4 5 6; do
  if click_node 'Original-Launcher verbergen' r1319_original_launcher_hide; then
    hide_button_found=true; break
  fi
  # The button is ABOVE, so scroll UP in content (finger DOWN).
  adb shell input swipe 530 420 530 1700 450 >/dev/null 2>&1 || true
  sleep 2
done
[[ "$hide_button_found" == true ]] || { echo 'R13194_SECOND_STAGE_BUTTON_NOT_VISIBLE_AFTER_SCROLL_UP' >&2; exit 73; }
sleep 5
adb shell pm path com.topjohnwu.magisk > "$OUT/r1319_original_package_present.txt" 2>&1
grep -q '^package:' "$OUT/r1319_original_package_present.txt" || {
  echo 'R1319_ORIGINAL_PACKAGE_DISAPPEARED_DURING_HIDE' >&2; exit 74;
}
adb shell am start -W -n com.topjohnwu.magisk/.ui.MainActivity > "$OUT/r1319_original_launcher_hidden_test.txt" 2>&1 || true
# Explicit launch of a disabled component must NOT report a good start.
if grep -q 'Status: ok' "$OUT/r1319_original_launcher_hidden_test.txt"; then
  echo 'R1319_ORIGINAL_LAUNCHER_STILL_STARTABLE' >&2; exit 75;
fi
# A false-positive generated by am returning nothing must be excluded.
grep -Eiq 'does not exist|not found|Unable to resolve|Error|disabled|not exported' \
  "$OUT/r1319_original_launcher_hidden_test.txt" || {
  echo 'R1319_LAUNCHER_HIDE_NOT_INDEPENDENTLY_CONFIRMED' >&2; exit 76;
}
adb shell pm path "$found" > "$OUT/r1319_hidden_still_installed.txt" 2>&1
grep -q '^package:' "$OUT/r1319_hidden_still_installed.txt" || exit 77
state=RESTORE
adb shell input swipe 520 350 520 1500 600 || true
sleep 3
click_node 'Restore the Magisk app|Magisk.*wiederherstellen' before_restore || { echo 'RESTORE_CONTROL_NOT_FOUND' >&2;exit 65; }
sleep 2
# R13197_CANCEL_CHECK_BEGIN
# Cancel must dismiss the actual fitted dialog without entering Restore.
state=RESTORE_CANCEL
click_node '^Cancel$|^Abbrechen$' cancel_restore || { echo 'R13197_RESTORE_CANCEL_MISSING' >&2; exit 89; }
sleep 1
adb shell uiautomator dump /sdcard/r13197_after_cancel.xml > "$OUT/after_restore_cancel_dump.log" 2>&1
adb pull /sdcard/r13197_after_cancel.xml "$OUT/after_restore_cancel.xml" >/dev/null
python3 - "$OUT/after_restore_cancel.xml" "$found" <<'R13197_CANCEL_XML'
import sys
import xml.etree.ElementTree as ET
nodes=[n for n in ET.parse(sys.argv[1]).getroot().iter('node') if n.get('package')==sys.argv[2]]
assert any(n.get('content-desc')=='Restore the Magisk app' for n in nodes), 'R13197_CANCEL_DID_NOT_RETURN_TO_HOME'
assert not any(n.get('text') in ('OK','Cancel','Abbrechen') for n in nodes), 'R13197_CANCEL_DIALOG_STILL_VISIBLE'
R13197_CANCEL_XML
adb shell logcat -d -v brief -s R13196RestoreUI:I R13196RestoreVM:I R13196Restore:I '*:S' > "$OUT/r13197_cancel_trace.txt"
if grep -Eq 'CONFIRM_CALLBACK_RECEIVED|REQUEST_RECEIVED|[[:space:]]ENTERED$' "$OUT/r13197_cancel_trace.txt"; then
  echo 'R13197_CANCEL_INCORRECTLY_STARTED_RESTORE' >&2; exit 90
fi
adb shell pm path "$found" > "$OUT/r13197_hidden_after_cancel.txt"
grep -q '^package:' "$OUT/r13197_hidden_after_cancel.txt" || { echo 'R13197_CANCEL_REMOVED_HIDDEN_APP' >&2; exit 91; }
click_node 'Restore the Magisk app|Magisk.*wiederherstellen' before_restore_confirm || { echo 'R13197_RESTORE_CONTROL_MISSING_AFTER_CANCEL' >&2; exit 92; }
sleep 2
state=RESTORE_CONFIRM
# R13197_CANCEL_CHECK_END
click_node '^OK$|^Restore$|^Wiederherstellen$|^Bestätigen$' confirm_restore || { echo 'RESTORE_CONFIRM_MISSING' >&2;exit 66; }
state=RESTORE_TRANSACTION_COMPLETION
# R13196_WAIT_RESTORE_BEGIN
# Wait for completion reported by the app itself. Merely entering restoreApp
# does not mean its hash checks, launcher activation or binding reset finished.
wait_for_restore_completion() {
  local restore_ui_seen=false
  local restore_backend_seen=false
  local restore_complete=false
  local n
  for n in $(seq 1 45); do
    adb shell logcat -d -v brief -s R13196RestoreUI:I R13196RestoreVM:I R13196Restore:I R1310Restore:E R1319Restore:E '*:S' \
      > "$OUT/r13196_restore_trace.txt" 2>&1 || true
    grep -Fq 'CONFIRM_CALLBACK_RECEIVED' "$OUT/r13196_restore_trace.txt" && restore_ui_seen=true || true
    grep -Eq '[[:space:]]ENTERED$' "$OUT/r13196_restore_trace.txt" && restore_backend_seen=true || true
    if grep -Eq 'BACKEND_RESTORE_FAILED|BACKEND_EXCEPTION|BUSY_PREVIOUS_TRANSACTION_NOT_FINISHED|RESTORE_TRANSACTION_REJECTED_HIDDEN_RETAINED|RESTORE_TRANSACTION_EXCEPTION|MANAGER_BIND_RESET_FAILED|CLEANUP_SCHEDULING_FAILED_KEEP_HIDDEN' \
        "$OUT/r13196_restore_trace.txt"; then
      echo 'R13196_RESTORE_APP_REPORTED_FAILURE' >&2
      return 85
    fi
    if [[ "$restore_ui_seen" == true && "$restore_backend_seen" == true ]] && \
       grep -Fq 'ORIGINAL_EXPLICIT_START_OK' "$OUT/r13196_restore_trace.txt" && \
       grep -Fq 'MANAGER_BIND_RESET_VERIFIED' "$OUT/r13196_restore_trace.txt" && \
       grep -Fq 'ORIGINAL_START_CONFIRMED_CLEANUP_SCHEDULED' "$OUT/r13196_restore_trace.txt" && \
       grep -Fq 'BACKEND_RESTORE_CONFIRMED' "$OUT/r13196_restore_trace.txt"; then
      restore_complete=true
      break
    fi
    sleep 1
  done
  [[ "$restore_ui_seen" == true ]] || { echo 'R13196_RESTORE_CONFIRM_CALLBACK_NOT_INVOKED' >&2; return 81; }
  [[ "$restore_backend_seen" == true ]] || { echo 'R13196_RESTORE_BACKEND_NOT_ENTERED' >&2; return 82; }
  [[ "$restore_complete" == true ]] || { echo 'R13196_RESTORE_TRANSACTION_NOT_COMPLETED' >&2; return 86; }
  [[ $(grep -Fc 'CONFIRM_CALLBACK_RECEIVED' "$OUT/r13196_restore_trace.txt") == 1 &&
     $(grep -Ec '[[:space:]]ENTERED$' "$OUT/r13196_restore_trace.txt") == 1 ]] || {
    echo 'R13197_RESTORE_CONFIRM_OR_BACKEND_REPEATED' >&2; return 93;
  }
}
# R13196_WAIT_RESTORE_END
wait_for_restore_completion
# The retained package was installed throughout Hide. Its presence alone is
# never a Restore completion signal. Verify it after the app-side barrier.
adb shell pm path com.topjohnwu.magisk > "$OUT/original_restored.txt" 2>&1
grep -q '^package:' "$OUT/original_restored.txt" || { echo 'RESTORE_ORIGINAL_MISSING' >&2; exit 67; }
# Passive evidence: the app must have started the original itself. Do not
# supply its process from adb before checking the app-owned cleanup.
adb shell pidof com.topjohnwu.magisk > "$OUT/r13196_original_pid_after_app_restore.txt" 2>&1 || {
  echo 'R13196_ORIGINAL_PROCESS_MISSING_AFTER_APP_RESTORE' >&2; exit 87;
}
grep -Eq '^[[:space:]]*[0-9]+([[:space:]]+[0-9]+)*[[:space:]]*$' "$OUT/r13196_original_pid_after_app_restore.txt" || {
  echo 'R13196_ORIGINAL_PROCESS_NOT_CONFIRMED' >&2; exit 88;
}
# Restore must remove the random package, never the original.
state=HIDDEN_PACKAGE_CLEANUP
cleanup_done=false
for attempt in $(seq 1 25); do
  adb shell pm list packages -3 > "$OUT/r1319_packages_cleanup_${attempt}.txt" 2>&1
  if ! grep -Fxq "package:$found" "$OUT/r1319_packages_cleanup_${attempt}.txt"; then
    cleanup_done=true; break
  fi
  sleep 2
done
[[ "$cleanup_done" == true ]] || {
  echo 'R1319_HIDDEN_STUB_REMAINS_INSTALLED_AFTER_RESTORE' >&2; exit 78;
}
adb shell pm path com.topjohnwu.magisk > "$OUT/r1319_original_after_cleanup.txt" 2>&1
grep -q '^package:' "$OUT/r1319_original_after_cleanup.txt" || exit 79
adb shell am start -W -n com.topjohnwu.magisk/.ui.MainActivity > "$OUT/r1319_original_launcher_restored.txt" 2>&1
grep -q 'Status: ok' "$OUT/r1319_original_launcher_restored.txt" || {
  echo 'R1319_ORIGINAL_LAUNCHER_NOT_REENABLED' >&2; exit 80;
}
adb shell su -c id -u > "$OUT/su_after_restore.txt" 2>&1
grep -Fxq 0 "$OUT/su_after_restore.txt" || exit 69
state=COMPLETE
echo 'R13.19.6 root, random Hide, original launcher hide, app-owned Restore and hidden cleanup PASS; phone HOLD'
R1315_END_SCRIPT
cat > R1316_UI_FIND.py <<'R1316_UI_SELECTOR_EOF'
#!/usr/bin/env python3
"""R13.16: locate exact visible UI node without merging text and content-desc.
The old selector concatenated 'OK' + ' ' + '' -> 'OK ', breaking ^OK$.
Usage: R1316_UI_FIND.py DUMP_XML REGEX; stdout: two integer coordinates.
"""
import re
import sys
import xml.etree.ElementTree as ET


def find(path, pattern):
    target = re.compile(pattern, re.I)
    root = ET.parse(path).getroot()
    for node in root.iter('node'):
        attrs = node.attrib
        if attrs.get('enabled') == 'false':
            continue
        text = attrs.get('text', '').strip()
        description = attrs.get('content-desc', '').strip()
        if not (target.search(text) or target.search(description)):
            continue
        bounds = re.fullmatch(r'\[\s*(\d+)\s*,\s*(\d+)\s*\]\[\s*(\d+)\s*,\s*(\d+)\s*\]', attrs.get('bounds',''))
        if not bounds:
            continue
        x1,y1,x2,y2 = map(int, bounds.groups())
        if x2 <= x1 or y2 <= y1:
            continue
        return (x1+x2)//2, (y1+y2)//2
    return None


if __name__ == '__main__':
    if len(sys.argv) != 3:
        sys.exit('Usage: python3 R1316_UI_FIND.py UI_XML REGEX')
    try:
        coordinates = find(sys.argv[1], sys.argv[2])
    except (OSError, ValueError, ET.ParseError, re.error) as error:
        print('R1316_UI_DUMP_OR_SELECTOR_ERROR: '+str(error),file=sys.stderr)
        sys.exit(1)
    if coordinates is None:
        sys.exit(1)
    print(*coordinates)
R1316_UI_SELECTOR_EOF
python3 -m py_compile R1316_UI_FIND.py
python3 - <<'R1316_UI_SELECTOR_TESTS'
import subprocess,tempfile,pathlib,xml.etree.ElementTree as ET
# Captured R13.15 UI dialogue: text=OK, desc empty, bounds=[842,1323][894,1368].
with tempfile.TemporaryDirectory() as td:
    path=pathlib.Path(td)/'actual-dialog.xml'
    path.write_text('<hierarchy><node text="OK" content-desc="" enabled="true" bounds="[842,1323][894,1368]"/></hierarchy>')
    def probe(pattern):
        return subprocess.run(['python3','R1316_UI_FIND.py',str(path),pattern],capture_output=True,text=True)
    p=probe('^OK$|^Hide$|^Verbergen$|^Bestätigen$')
    assert p.returncode==0 and p.stdout.strip()=='868 1345',p
    assert probe('^Grant$').returncode==1
    # Prove the exact historical root cause (the old algorithm cannot match).
    import re
    assert not re.search('^OK$', 'OK ')
    # Reject a malformed clickable target without valid bounds.
    path.write_text('<hierarchy><node text="OK" enabled="true" bounds="[0,0][0,0]"/></hierarchy>')
    assert probe('^OK$').returncode==1
print('R13.16 UI selector confirmed: original OK+trailing-space regression fixed, fail-closed checks PASS')
R1316_UI_SELECTOR_TESTS
chmod 755 R1315_ROOT_HIDE_RESTORE_AVD.sh
bash -n R1315_ROOT_HIDE_RESTORE_AVD.sh
