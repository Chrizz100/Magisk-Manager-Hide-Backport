#!/usr/bin/env python3
"""Run actual APK/keystore fixture regressions; no Android device is contacted."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess
import tempfile


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    for name in ("release-apk", "keystore", "alias", "sdk-tools", "expected-signer-sha256", "report"):
        p.add_argument("--" + name, required=True)
    p.add_argument("--case", choices=("signer_whitespace",), help="Run only this new regression; otherwise run all cases")
    args = p.parse_args()
    base = Path(__file__).resolve().parent
    sdk = Path(args.sdk_tools).resolve()
    release = Path(args.release_apk).resolve()
    env = os.environ.copy()
    for name in ("R139_STOREPASS", "R139_KEYPASS"):
        if not env.get(name):
            raise SystemExit("Missing credential environment variable " + name)
    results = []

    def invoke(command, expected, environment, label):
        run = subprocess.run(command, env=environment, text=True, capture_output=True, timeout=180)
        output = run.stdout + run.stderr
        for name in ("R139_STOREPASS", "R139_KEYPASS"):
            if environment[name] in output:
                raise RuntimeError("A subprocess exposed a signing password")
        if (run.returncode == 0) != expected:
            raise RuntimeError("Unexpected result for " + label + ": " + str(run.returncode))
        results.append({"case": label, "passed": True, "exit_code": run.returncode})

    with tempfile.TemporaryDirectory(prefix="r13198-fixture-regressions-") as directory:
        temp = Path(directory)
        normal = temp / "normal"
        command = [
            "python3", str(base / "R13198_BUILD_UPDATE_FIXTURE.py"),
            "--release-apk", str(release), "--keystore", str(Path(args.keystore).resolve()),
            "--alias", args.alias, "--apksigner", str(sdk / "apksigner"),
            "--aapt2", str(sdk / "aapt2"), "--zipalign", str(sdk / "zipalign"),
            "--expected-signer-sha256", args.expected_signer_sha256,
            "--out-dir", str(normal),
        ]
        if args.case is None:
            invoke(command, True, env, "real_release_to_verified_fixture")
            invoke(command, False, env, "refuse_stale_fixture_overwrite")
            wrong_pin = command.copy()
            wrong_pin[wrong_pin.index("--expected-signer-sha256") + 1] = "0" * 64
            wrong_pin[-1] = str(temp / "wrong-pin")
            invoke(wrong_pin, False, env, "reject_wrong_pinned_certificate")
            foreign_key = temp / "foreign.p12"
            foreign_env = env.copy()
            password = secrets.token_urlsafe(32)
            foreign_env.update(R139_STOREPASS=password, R139_KEYPASS=password, R13198_TEST_PASSWORD=password)
            keygen = subprocess.run([
                "keytool", "-genkeypair", "-noprompt", "-storetype", "PKCS12", "-keystore", str(foreign_key),
                "-storepass:env", "R13198_TEST_PASSWORD", "-keypass:env", "R13198_TEST_PASSWORD",
                "-alias", "fixture-negative", "-keyalg", "RSA", "-keysize", "2048", "-validity", "2",
                "-dname", "CN=Fixture Negative Test",
            ], env=foreign_env, text=True, capture_output=True, timeout=120)
            if keygen.returncode:
                raise RuntimeError("Cannot create temporary negative-test keystore")
            wrong_key = command.copy()
            wrong_key[wrong_key.index("--keystore") + 1] = str(foreign_key)
            wrong_key[wrong_key.index("--alias") + 1] = "fixture-negative"
            wrong_key[-1] = str(temp / "wrong-key")
            invoke(wrong_key, False, foreign_env, "reject_different_actual_signing_key")
            if (Path(wrong_key[-1]) / "R13198_INSTALL_UPDATE_FIXTURE.apk").exists() or (Path(wrong_key[-1]) / "R13198_INSTALL_UPDATE_FIXTURE.json").exists():
                raise RuntimeError("Rejected signer produced a published fixture result")
        whitespace_pin = command.copy()
        whitespace_pin[whitespace_pin.index("--expected-signer-sha256") + 1] = " \t\n" + args.expected_signer_sha256.strip().upper() + "\r\n "
        whitespace_pin[-1] = str(temp / "whitespace-pin")
        invoke(whitespace_pin, True, env, "accept_public_signer_pin_with_outer_whitespace")
        verified_fixture = json.loads((Path(whitespace_pin[-1]) / "R13198_INSTALL_UPDATE_FIXTURE.json").read_text())
        if verified_fixture["certificate_sha256"] != args.expected_signer_sha256.strip().lower():
            raise RuntimeError("Whitespace normalization changed the expected signer identity")
    report = {
        "status": "PASS", "tests": len(results), "checks": results,
        "scope": "Actual apksigner/zipalign/aapt2 and APK payload/signature checks; no Android execution",
        "android_runtime_executed": False,
        "source_apk_sha256": hashlib.sha256(release.read_bytes()).hexdigest(),
        "verified_fixture": verified_fixture,
        "private_negative_test_key_removed": True,
        "private_negative_test_key_created": args.case is None,
        "selected_case": args.case or "all",
    }
    Path(args.report).write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "tests": len(results), "android_runtime_executed": False}))


if __name__ == "__main__":
    main()
