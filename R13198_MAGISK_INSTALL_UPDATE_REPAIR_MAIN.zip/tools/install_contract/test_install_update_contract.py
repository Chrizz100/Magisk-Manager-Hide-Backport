#!/usr/bin/env python3
"""Negative orchestration checks with explicit fake ADB; never Android PASS."""
from __future__ import annotations

import argparse
import contextlib
import importlib.util
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("r13198_contract", HERE / "R13198_INSTALL_UPDATE.py")
contract = importlib.util.module_from_spec(spec)
spec.loader.exec_module(contract)


class FakeAndroid:
    """Each response is a supplied test input, not a device measurement."""
    def __init__(self, inputs: dict):
        self.inputs = inputs
        self.packages = []
        self.uid = 10123
        self.sha = None
        self.marker = None
        self.owner = None
        self.contexts = {contract.APP_DATA_DIR: "u:object_r:app_data_file:s0:c123,c256,c512,c768"}
        self.fault = None
        self.devices = "List of devices attached\nemulator-5554\tdevice\n"
        self.props = {"ro.kernel.qemu": "1", "ro.build.version.sdk": "33", "ro.product.cpu.abi": "x86_64"}

    def helper_install_fixture(self):
        self.packages = [contract.PACKAGE]
        self.sha = self.inputs["fixture_apk_sha256"]

    def command(self, instance, args, timeout=60):
        result = self.answer(args)
        instance.report.setdefault("commands", []).append({"argv": ["FAKE_ADB", *args], "returncode": 0, "stdout": result, "stderr": ""})
        instance.save()
        return result.strip()

    def answer(self, args):
        if args == ["devices"]:return self.devices
        if args[:2] == ["shell", "getprop"]:return self.props[args[2]]
        if args == ["shell", "id", "-u"]:return "0"
        if args == ["shell", "pm", "list", "packages", "-3", "--user", "0"]:
            return "\n".join("package:" + p for p in self.packages)
        if args == ["shell", "pm", "list", "packages", "--user", "0", contract.PACKAGE]:
            return "package:" + contract.PACKAGE if contract.PACKAGE in self.packages else ""
        if args == ["shell", "pm", "list", "packages", "-U", "--user", "0", contract.PACKAGE]:
            return f"package:{contract.PACKAGE} uid:{self.uid}"
        if args == ["shell", "pm", "path", "--user", "0", contract.PACKAGE]:
            return "package:/data/app/test/com.topjohnwu.magisk/base.apk"
        if args == ["shell", "sha256sum", "/data/app/test/com.topjohnwu.magisk/base.apk"]:
            return self.sha + "  /data/app/test/com.topjohnwu.magisk/base.apk"
        if args == ["shell", "sha256sum", "/debug_ramdisk/magisk"]:
            value = "0" * 64 if self.fault == "wrong_daemon" else self.inputs["native_sha256"]["x86_64"]
            return value + "  /debug_ramdisk/magisk"
        if args[:2] in (["shell", "mkdir"], ["shell", "chmod"]):return ""
        if args[:2] == ["shell", "restorecon"]:
            self.contexts[contract.DATA_DIR] = self.contexts[contract.APP_DATA_DIR]
            if "-D" in args:
                self.contexts[contract.SENTINEL] = self.contexts[contract.APP_DATA_DIR]
            if self.fault == "bad_marker_context":self.contexts[contract.SENTINEL] = "u:object_r:shell_data_file:s0"
            if self.fault == "bad_directory_context":self.contexts[contract.DATA_DIR] = "u:object_r:shell_data_file:s0"
            return ""
        if args[:2] == ["shell", "chown"]:
            if args[-1] == contract.SENTINEL:self.owner = args[2]
            return ""
        if args[:1] == ["push"]:
            self.marker = Path(args[1]).read_text();return "1 file pushed"
        if args == ["shell", "cat", contract.SENTINEL]:return self.marker or ""
        if args == ["shell", "stat", "-c", "%u:%g", contract.SENTINEL]:return self.owner or ""
        if args[:4] == ["shell", "stat", "-c", "%C"]:return self.contexts.get(args[4], "u:object_r:shell_data_file:s0")
        if args[:3] == ["install", "--no-streaming", "-r"]:
            if self.fault == "install_rejected":return "Failure [INSTALL_FAILED_UPDATE_INCOMPATIBLE]"
            self.sha = self.inputs["release_apk_sha256"]
            if self.fault == "wrong_final_apk":self.sha = "0" * 64
            if self.fault == "uid_changed":self.uid += 1
            if self.fault == "data_lost":self.marker = None
            if self.fault == "owner_changed":self.owner = "0:0"
            if self.fault == "context_changed":self.contexts[contract.SENTINEL] = "u:object_r:shell_data_file:s0"
            return "Performing Non-Streaming Install\nSuccess"
        if args == ["shell", "rm", contract.SENTINEL]:self.marker = None;return ""
        raise AssertionError("Unexpected fake ADB command: " + repr(args))


class Cases(unittest.TestCase):
    release: Path
    fixture: Path
    manifest: Path

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="r13198-contract-test-")
        self.out = Path(self.temp.name) / "out"
        self.inputs = json.loads(self.manifest.read_text())
        self.fake = FakeAndroid(self.inputs)
        self.env = patch.dict(os.environ, {"GITHUB_ACTIONS": "true", "GITHUB_RUN_ID": "123456789", "ANDROID_SERIAL": "emulator-5554"})
        self.env.start()
        fake = self.fake
        self.adb = patch.object(contract.Contract, "command", lambda instance, args, timeout=60: fake.command(instance, args, timeout))
        self.adb.start()

    def tearDown(self):
        self.adb.stop();self.env.stop();self.temp.cleanup()

    def invoke(self, phase, expected_success=True, manifest=None):
        argv = ["contract", phase, "--release-apk", str(self.release), "--fixture-apk", str(self.fixture), "--manifest", str(manifest or self.manifest), "--out", str(self.out)]
        with patch("sys.argv", argv), contextlib.redirect_stdout(io.StringIO()):
            if expected_success:contract.main()
            else:
                with self.assertRaises(SystemExit):contract.main()
        path = self.out / contract.RESULT_NAME
        report = json.loads(path.read_text()) if path.exists() else {}
        if not expected_success:self.assertNotEqual(report.get("status"), "PASS")
        return report

    def prepared(self):
        self.assertEqual(self.invoke("prepare")["status"], "PREPARED")
        self.fake.helper_install_fixture()

    def test_positive_contract_with_fake_adb(self):
        self.prepared()
        report = self.invoke("complete")
        self.assertEqual(report["status"], "PASS")
        self.assertTrue(report["fresh_install"]["passed"])
        self.assertTrue(report["fresh_install"]["was_absent"])
        self.assertEqual(report["fresh_install"]["installed_apk_sha256"], self.inputs["fixture_apk_sha256"])
        self.assertEqual(report["update_in_place"]["installed_apk_sha256"], self.inputs["release_apk_sha256"])
        self.assertTrue(all(report["update_in_place"][key] for key in ("passed", "same_uid", "data_preserved", "without_uninstall")))
        self.assertTrue(report["normal_manager_only"])
        self.assertFalse(report["hidden_state_update_tested"])
        self.assertFalse(report["physical_device_tested"])
        self.assertTrue(report["marker_context_preserved"])
        self.assertFalse(any("uninstall" in event["argv"] for event in report["commands"]))

    def test_requires_github_guard(self):
        os.environ["GITHUB_ACTIONS"] = "false";self.invoke("prepare", False)

    def test_rejects_physical_serial(self):
        self.fake.devices = "List of devices attached\nPHYSICAL123\tdevice\n";self.invoke("prepare", False)

    def test_rejects_two_targets(self):
        self.fake.devices += "emulator-5556\tdevice\n";self.invoke("prepare", False)

    def test_rejects_wrong_api(self):
        self.fake.props["ro.build.version.sdk"] = "34";self.invoke("prepare", False)

    def test_rejects_non_qemu(self):
        self.fake.props["ro.kernel.qemu"] = "0";self.invoke("prepare", False)

    def test_rejects_wrong_abi(self):
        self.fake.props["ro.product.cpu.abi"] = "arm64-v8a";self.invoke("prepare", False)

    def test_rejects_serial_mismatch(self):
        os.environ["ANDROID_SERIAL"] = "emulator-5556";self.invoke("prepare", False)

    def test_rejects_existing_manager_before_fresh_install(self):
        self.fake.packages = [contract.PACKAGE];self.invoke("prepare", False)

    def test_rejects_hidden_manager_state(self):
        self.prepared();self.fake.packages.append("random.hidden");self.invoke("complete", False)

    def test_rejects_missing_prepare(self):self.invoke("complete", False)

    def test_rejects_stale_run(self):
        self.prepared();os.environ["GITHUB_RUN_ID"] = "999";self.invoke("complete", False)

    def test_rejects_wrong_fresh_installed_bytes(self):
        self.prepared();self.fake.sha = self.inputs["release_apk_sha256"];self.invoke("complete", False)

    def test_rejects_wrong_daemon(self):
        self.prepared();self.fake.fault = "wrong_daemon";self.invoke("complete", False)

    def test_rejects_installer_failure(self):
        self.prepared();self.fake.fault = "install_rejected";self.invoke("complete", False)

    def test_rejects_wrong_updated_bytes(self):
        self.prepared();self.fake.fault = "wrong_final_apk";self.invoke("complete", False)

    def test_rejects_uid_change(self):
        self.prepared();self.fake.fault = "uid_changed";self.invoke("complete", False)

    def test_rejects_data_loss(self):
        self.prepared();self.fake.fault = "data_lost";self.invoke("complete", False)

    def test_rejects_changed_data_owner(self):
        self.prepared();self.fake.fault = "owner_changed";self.invoke("complete", False)

    def test_rejects_bad_initial_marker_context(self):
        self.prepared();self.fake.fault = "bad_marker_context";self.invoke("complete", False)

    def test_rejects_bad_initial_directory_context(self):
        self.prepared();self.fake.fault = "bad_directory_context";self.invoke("complete", False)

    def test_rejects_changed_data_context(self):
        self.prepared();self.fake.fault = "context_changed";self.invoke("complete", False)

    def test_rejects_fixture_report_change_after_prepare(self):
        self.prepared()
        other = Path(self.temp.name) / "changed.json"
        changed = dict(self.inputs);changed["extra_unexpected_annotation"] = True
        other.write_text(json.dumps(changed))
        self.invoke("complete", False, manifest=other)

    def test_rejects_missing_native_abi(self):
        other = Path(self.temp.name) / "changed.json"
        changed = json.loads(self.manifest.read_text());del changed["native_sha256"]["arm64-v8a"]
        other.write_text(json.dumps(changed));self.invoke("prepare", False, manifest=other)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release-apk", type=Path, required=True)
    parser.add_argument("--fixture-apk", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    Cases.release, Cases.fixture, Cases.manifest = args.release_apk.resolve(), args.fixture_apk.resolve(), args.manifest.resolve()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(Cases)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    record = {"status": "PASS" if result.wasSuccessful() else "FAIL", "tests": result.testsRun,
              "scope": "Python orchestration with supplied FAKE_ADB responses; real APK inputs and hashes; NOT Android runtime execution",
              "android_runtime_executed": False, "failures": len(result.failures), "errors": len(result.errors)}
    args.report.write_text(json.dumps(record, indent=2) + "\n")
    if not result.wasSuccessful():raise SystemExit(1)


if __name__ == "__main__":main()
