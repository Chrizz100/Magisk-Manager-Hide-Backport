#!/usr/bin/env python3
"""Exact additions to the proven R13.19.7 workflow; does not write that workflow."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FIXTURE = "R13198_INSTALL_UPDATE_FIXTURE.apk"
REPORT = "R13198_INSTALL_UPDATE_FIXTURE.json"


def heredoc(script: Path, delimiter: str) -> str:
    text = script.read_text()
    if delimiter in text.splitlines():
        raise ValueError("Heredoc delimiter occurs in script")
    return f"cat > {script.name} <<'{delimiter}'\n{text}" + ("" if text.endswith("\n") else "\n") + delimiter + "\n"


def replace_once(text: str, old: str, new: str) -> str:
    if text.count(old) != 1:
        raise ValueError("Expected one exact root-script integration anchor: " + old[:100])
    return text.replace(old, new, 1)


def build_step() -> dict:
    body = "set -euo pipefail\n" + heredoc(HERE / "R13198_BUILD_UPDATE_FIXTURE.py", "R13198_FIXTURE_BUILDER_PY")
    body += '''sdk_tools="$(python3 - <<'R13198_SDK_TOOLS'
from pathlib import Path
import os,re
root=Path(os.environ.get('ANDROID_HOME') or os.environ.get('ANDROID_SDK_ROOT') or '/opt/android-sdk')
choices=[p for p in (root/'build-tools').glob('*') if all((p/name).is_file() for name in ('apksigner','aapt2','zipalign'))]
assert choices,'Required Android signing/alignment tools are missing'
choices.sort(key=lambda p:tuple(int(x) for x in re.findall(r'\\d+',p.name)))
print(choices[-1])
R13198_SDK_TOOLS
)"
python3 R13198_BUILD_UPDATE_FIXTURE.py \\
  --release-apk "$GITHUB_WORKSPACE/magisk/out/app-release.apk" \\
  --keystore "$GITHUB_WORKSPACE/magisk/r6-ci-only.p12" \\
  --alias "$R139_ALIAS" \\
  --apksigner "$sdk_tools/apksigner" --aapt2 "$sdk_tools/aapt2" --zipalign "$sdk_tools/zipalign" \\
  --expected-signer-sha256 "$R13198_EXPECTED_SIGNER_SHA256" \\
  --out-dir "$GITHUB_WORKSPACE/r13198-install-fixture"
'''
    return {
        "name": "R13.19.8 - Build verified same-signer synthetic update fixture (public APK only)",
        "shell": "bash", "run": body,
        "env": {
            "R139_STOREPASS": "${{ secrets.MAGISK_HIDE_P12_PASSWORD }}",
            "R139_KEYPASS": "${{ secrets.MAGISK_HIDE_P12_KEY_PASSWORD }}",
            "R139_ALIAS": "${{ secrets.MAGISK_HIDE_P12_ALIAS }}",
        },
    }


def fixture_upload_step() -> dict:
    return {"name": "R13.19.8 - Keep verified public update fixture and identity",
            "uses": "actions/upload-artifact@v4",
            "with": {"name": "R13198_INSTALL_UPDATE_FIXTURE", "if-no-files-found": "error", "retention-days": 14,
                     "path": f"r13198-install-fixture/{FIXTURE}\nr13198-install-fixture/{REPORT}"}}


def fixture_download_step() -> dict:
    return {"name": "Download this run's same-signer update fixture",
            "uses": "actions/download-artifact@v4",
            "with": {"name": "R13198_INSTALL_UPDATE_FIXTURE", "path": "r13198-install-fixture"}}


def patch_root_generator(original: str) -> str:
    text = original
    text = replace_once(text, 'OUT=${3:-"$PWD/r1314-e2e"}\n',
        'OUT=${3:-"$PWD/r1314-e2e"}\nFIXTURE=${4:?Verified update fixture APK required}\nFIXTURE_REPORT=${5:?Verified fixture identity required}\n')
    text = replace_once(text, '[[ -s "$APK" && -f "$MAGISK_SRC/build.py" ]] || exit 51',
        '[[ -s "$APK" && -s "$FIXTURE" && -s "$FIXTURE_REPORT" && -f "$MAGISK_SRC/build.py" ]] || exit 51')
    text = replace_once(text, 'state=INSTALL_NATIVE_MATCHING_DAEMON\n',
        'state=VERIFY_EMPTY_AVD_BEFORE_FRESH_INSTALL\n'
        'python3 R13198_INSTALL_UPDATE.py prepare --release-apk "$APK" --fixture-apk "$FIXTURE" --manifest "$FIXTURE_REPORT" --out "$OUT"\n'
        'state=INSTALL_NATIVE_MATCHING_DAEMON\n')
    text = replace_once(text, 'python3 "$MAGISK_SRC/build.py" -r emulator "$APK" > "$OUT/avd_setup.txt"',
        'python3 "$MAGISK_SRC/build.py" -r emulator "$FIXTURE" > "$OUT/avd_setup.txt"')
    text = replace_once(text, 'state=ANDROID13_NOTIFICATION_PERMISSION\n',
        'state=VERIFY_FRESH_INSTALL_AND_NORMAL_UPDATE\n'
        'python3 R13198_INSTALL_UPDATE.py complete --release-apk "$APK" --fixture-apk "$FIXTURE" --manifest "$FIXTURE_REPORT" --out "$OUT"\n'
        'state=ANDROID13_NOTIFICATION_PERMISSION\n')
    return heredoc(HERE / "R13198_INSTALL_UPDATE.py", "R13198_INSTALL_UPDATE_PY") + text


def patch_action_script(original: str) -> str:
    old = 'bash R1315_ROOT_HIDE_RESTORE_AVD.sh "$GITHUB_WORKSPACE/r1314-apk/magisk/out/app-release.apk" "$GITHUB_WORKSPACE/magisk-source" "$GITHUB_WORKSPACE/r1314-e2e"'
    new = old + f' "$GITHUB_WORKSPACE/r13198-install-fixture/{FIXTURE}" "$GITHUB_WORKSPACE/r13198-install-fixture/{REPORT}"'
    return replace_once(original, old, new)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workflow", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    import yaml
    workflow = yaml.safe_load(args.workflow.read_text())
    job = workflow["jobs"]["r1314-root-hide-restore-avd"]
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / "root_generator.sh").write_text(patch_root_generator(job["steps"][2]["run"]))
    (args.output / "root_action_script.sh").write_text(patch_action_script(job["steps"][4]["with"]["script"]))
    for name, value in [("build_step.json", build_step()), ("fixture_upload_step.json", fixture_upload_step()), ("fixture_download_step.json", fixture_download_step())]:
        (args.output / name).write_text(json.dumps(value, indent=2) + "\n")


if __name__ == "__main__":main()
