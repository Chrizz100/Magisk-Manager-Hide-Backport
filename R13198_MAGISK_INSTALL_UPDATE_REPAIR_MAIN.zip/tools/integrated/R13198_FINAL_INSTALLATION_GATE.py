#!/usr/bin/env python3
"""Require the same-run build, 15 GUI cases, rooted test and install/update proof.

This combines existing evidence. It never performs a device operation or promotes
emulator evidence to a physical-phone approval.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil


def one_file(root: Path, filename: str) -> Path:
    matches = list(root.rglob(filename)) if root.is_dir() else []
    if len(matches) != 1:
        raise ValueError(f"Expected exactly one {filename}; found {len(matches)}")
    return matches[0]


def read_json(path: Path) -> dict:
    data = json.loads(path.read_text())
    if not isinstance(data, dict):
        raise ValueError(f"JSON object required: {path.name}")
    return data


def evaluate(workspace: Path) -> dict:
    report = {
        "schema": "r13198.complete-ci-installation-verdict-v1",
        "revision": "R13.19.8",
        "status": "FAIL",
        "github_run_id": os.environ.get("GITHUB_RUN_ID"),
        "physical_device_tested": False,
        "phone_in_place_update": "UNKNOWN",
        "phone_device_release": "NOT_ATTESTED",
        "hidden_state_update_tested": False,
        "supported_update_flow": "RESTORE_TO_ORIGINAL_MANAGER_THEN_MANUAL_PROJECT_APK_UPDATE_THEN_REHIDE",
        "failures": [],
    }
    failures = report["failures"]
    for name in ("BUILD_JOB", "GUI_JOB", "ROOT_JOB"):
        value = os.environ.get(name, "MISSING")
        report[name.lower()] = value
        if value != "success":
            failures.append(name + "_NOT_SUCCESS: " + value)
    try:
        coverage = read_json(workspace / "R1313_ANDROID7_TO17_FINAL_REPORT.json")
        report["coverage"] = coverage
        if (coverage.get("number_expected") != 15
                or coverage.get("number_recorded") != 15
                or coverage.get("gui_install_launch_matrix") != "PASS"
                or coverage.get("isolated_rooted_avd_hide_restore") != "PASS"
                or coverage.get("failures") != []):
            failures.append("ORIGINAL_GUI_AND_ROOT_COVERAGE_GATE_NOT_PASSED")
    except (OSError, ValueError) as exc:
        failures.append("COVERAGE_EVIDENCE_INVALID: " + str(exc))
    root_dir = workspace / "r13198-root-evidence"
    try:
        rooted = read_json(one_file(root_dir, "R1314_E2E_RESULT.json"))
        report["root_hide_restore"] = rooted
        if (rooted.get("schema") != "r1314.root-hide-restore-avd-v1"
                or rooted.get("status") != "ROOT_HIDE_RESTORE_PASS"
                or rooted.get("last_stage") != "COMPLETE"
                or type(rooted.get("exit_code")) is not int
                or rooted.get("exit_code") != 0
                or rooted.get("physical_device_tested") is not False):
            failures.append("ROOT_HIDE_RESTORE_RUNTIME_NOT_PASSED")
    except (OSError, ValueError) as exc:
        failures.append("ROOT_EVIDENCE_INVALID: " + str(exc))
    try:
        identity_dir = workspace / "r13198-build-identity"
        module_path = one_file(identity_dir, "R13198_RELEASE_INSTALLATION_AUDIT.py")
        spec = importlib.util.spec_from_file_location("r13198_release_identity", module_path)
        if spec is None or spec.loader is None:
            raise ValueError("Installation validator cannot be loaded")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        identity = read_json(one_file(identity_dir, "R13198_INSTALLATION_IDENTITY.json"))
        runtime = read_json(one_file(root_dir, "R13198_INSTALL_UPDATE_RESULT.json"))
        merged = module.merge_runtime(identity, runtime, require_runtime=True)
        module.write_report(workspace / "R13198_INSTALLATION_VERIFICATION.json", merged)
        report["installation"] = merged
        if merged.get("runtime_contract_valid") is not True:
            failures.append("INSTALL_UPDATE_CONTRACT_NOT_PASSED")
        if runtime.get("github_run_id") != os.environ.get("GITHUB_RUN_ID"):
            failures.append("INSTALL_UPDATE_CONTRACT_RUN_ID_MISMATCH")
        if runtime.get("hidden_state_update_tested") is not False:
            failures.append("INSTALL_UPDATE_HIDDEN_SCOPE_NOT_SUPPORTED")
        candidate = one_file(workspace / "r13198-final-apk", "app-release.apk")
        candidate_sha = hashlib.sha256(candidate.read_bytes()).hexdigest()
        report["apk_sha256"] = candidate_sha
        if candidate_sha != merged.get("apk_sha256"):
            failures.append("FINAL_APK_DIFFERS_FROM_VERIFIED_RELEASE")
    except (OSError, ValueError, KeyError, TypeError, ImportError) as exc:
        failures.append("INSTALLATION_EVIDENCE_INVALID: " + str(exc))
    if not failures:
        report["status"] = "CI_INSTALL_UPDATE_GUI_ROOT_HIDE_RESTORE_PASS"
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    report = evaluate(workspace)
    (workspace / "R13198_FINAL_INSTALLATION_VERDICT.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "failures": report["failures"]}))
    if report["status"] != "CI_INSTALL_UPDATE_GUI_ROOT_HIDE_RESTORE_PASS":
        return 2
    ready = workspace / "r13198-ready-apk"
    ready.mkdir(exist_ok=False)
    shutil.copyfile(one_file(workspace / "r13198-final-apk", "app-release.apk"), ready / "Magisk_R13198.apk")
    for name in ("R13198_FINAL_INSTALLATION_VERDICT.json", "R13198_INSTALLATION_VERIFICATION.json"):
        shutil.copyfile(workspace / name, ready / name)
    (ready / "Magisk_R13198.apk.sha256").write_text(report["apk_sha256"] + "  Magisk_R13198.apk\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
