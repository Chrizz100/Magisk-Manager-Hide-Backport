#!/data/data/com.termux/files/usr/bin/bash
# Reads public APK/core identities only. Writes a report and a private temporary
# APK read-copy; it never installs, removes, disables, patches or flashes anything.
set -uo pipefail
if [ "$#" -ne 1 ]; then
  printf 'Usage: bash R13198_PHONE_PREFLIGHT_READONLY.sh /path/to/candidate.apk\n' >&2
  exit 2
fi
if ! command -v python3 >/dev/null 2>&1; then
  printf '{"status":"MISSING_DEPENDENCY_PYTHON3","dependency_setup_hint":"pkg install python apksigner","automatic_installation":false,"phone_installation_approval":"NOT_ESTABLISHED"}\n'
  exit 2
fi
python3 - "$1" <<'R13198_PHONE_PREFLIGHT_PY'
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import tempfile
import zipfile

ASSETS = {
    "arm64-v8a": "r139_expected_arm64_magisk.sha256",
    "armeabi-v7a": "r139_expected_armeabi_v7a_magisk.sha256",
    "x86_64": "r139_expected_x86_64_magisk.sha256",
    "x86": "r139_expected_x86_magisk.sha256",
}


def call(argv, timeout=45):
    try:
        result = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return result.returncode, result.stdout.strip()
    except (OSError, subprocess.SubprocessError):
        return -1, ""


def sha256_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def apk_signature(path, apksigner):
    if apksigner is None:
        return {"status": "MISSING_DEPENDENCY_APKSIGNER"}
    code, output = call([apksigner, "verify", "--verbose", "--print-certs", str(path)], 120)
    if code != 0:
        return {"status": "APKSIGNER_VERIFY_FAILED_OR_RUNTIME_UNAVAILABLE"}
    certs = set(re.findall(
        r"(?im)^\s*(?:(?:V[1-4](?:\.\d+)?\s+)?Signer:\s+certificate|Signer\s*#\s*\d+\s+certificate)"
        r"\s+SHA-256\s+digest:\s*([0-9a-fA-F]{64})\s*$", output))
    certs = {value.lower() for value in certs}
    if len(certs) != 1 or re.findall(r"(?m)^Number of signers:\s*(\d+)\s*$", output) != ["1"]:
        return {"status": "APKSIGNER_IDENTITY_MISSING_OR_AMBIGUOUS"}
    return {"status": "APK_SIGNATURE_VERIFIED", "signer_sha256": certs.pop(), "apk_sha256": sha256_file(path)}


def root_shell(su, *argv):
    return [su, "-c", " ".join(shlex.quote(str(argument)) for argument in argv)]


def original_path(su):
    code, output = call(root_shell(su, "/system/bin/pm", "path", "com.topjohnwu.magisk"))
    lines = output.splitlines()
    if code == 0 and not lines:
        return None, "ORIGINAL_PACKAGE_NOT_PRESENT"
    if code != 0 or len(lines) != 1 or not lines[0].startswith("package:/data/app/") or not lines[0].endswith("/base.apk"):
        return None, "ORIGINAL_PACKAGE_PATH_UNAVAILABLE_OR_AMBIGUOUS"
    path = lines[0][len("package:"):]
    if any(ord(ch) < 32 for ch in path):
        return None, "ORIGINAL_PACKAGE_PATH_INVALID"
    return path, "ORIGINAL_PACKAGE_PRESENT"


def installed_identity(su, apksigner):
    path, status = original_path(su)
    if path is None:
        return {"status": status}
    if apksigner is None:
        return {"status": "ORIGINAL_PACKAGE_PRESENT_APKSIGNER_MISSING"}
    try:
        with tempfile.TemporaryDirectory(prefix="r13198-apk-read-") as private:
            copy = Path(private) / "installed-base.apk"
            fd = os.open(copy, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, "wb") as output:
                result = subprocess.run(root_shell(su, "/system/bin/cat", path), stdout=output,
                                        stderr=subprocess.DEVNULL, timeout=120)
            after, _ = original_path(su)
            if result.returncode != 0 or after != path or copy.stat().st_size < 1000000:
                return {"status": "INSTALLED_APK_READ_FAILED_OR_PACKAGE_CHANGED"}
            return apk_signature(copy, apksigner)
    except (OSError, subprocess.SubprocessError):
        return {"status": "PRIVATE_APK_READ_COPY_FAILED"}


def daemon_identity(su):
    command = root_shell(su, "/system/bin/pidof", "magiskd")
    code, text = call(command)
    pids = text.split()
    if code != 0 or not 1 <= len(pids) <= 20 or not all(re.fullmatch(r"[1-9][0-9]*", pid) for pid in pids):
        return {"status": "LIVE_MAGISKD_PID_UNAVAILABLE"}
    values = []
    for pid in sorted(set(pids)):
        code, text = call(root_shell(su, "/system/bin/sha256sum", "/proc/" + pid + "/exe"))
        match = re.fullmatch(r"([0-9a-f]{64})\s+/proc/" + pid + r"/exe", text)
        if code != 0 or match is None:
            return {"status": "LIVE_MAGISKD_HASH_UNAVAILABLE"}
        values.append(match.group(1))
    code, after = call(command)
    if code != 0 or set(after.split()) != set(pids):
        return {"status": "LIVE_MAGISKD_CHANGED_DURING_READ"}
    return {"status": "LIVE_MAGISKD_HASHES_READ", "process_count": len(values), "sha256": values}


def main(candidate):
    apksigner = shutil.which("apksigner")
    model = call(["/system/bin/getprop", "ro.product.device"])[1]
    sdk = call(["/system/bin/getprop", "ro.build.version.sdk"])[1]
    abi = call(["/system/bin/getprop", "ro.product.cpu.abi"])[1]
    report = {"schema": "r13198.public-phone-identity-v1", "status": "PARTIAL_READ_ONLY_EVIDENCE",
              "device_model": model or "UNKNOWN", "android_sdk": sdk or "UNKNOWN", "abi": abi or "UNKNOWN",
              "installed_original": {"status": "ROOT_UNAVAILABLE"}, "running_core": {"status": "ROOT_UNAVAILABLE"},
              "candidate": {"status": "CANDIDATE_APK_UNREADABLE"},
              "certificate_comparison": "UNKNOWN", "native_comparison": "UNKNOWN",
              "phone_installation_approval": "NOT_ESTABLISHED", "physical_installation_tested": False,
              "app_root_boot_modified": False, "automatic_dependency_installation": False}
    if not apksigner:
        report["dependency_status"] = "MISSING_DEPENDENCY_APKSIGNER"
        report["dependency_setup_hint"] = "pkg install python apksigner"
    try:
        if candidate.is_file():
            report["candidate"] = apk_signature(candidate, apksigner)
            report["candidate"]["apk_sha256"] = sha256_file(candidate)
            if abi in ASSETS:
                with zipfile.ZipFile(candidate) as archive:
                    native = archive.read("lib/" + abi + "/libmagisk.so")
                    expected = archive.read("assets/" + ASSETS[abi]).decode("ascii").strip()
                    actual = hashlib.sha256(native).hexdigest()
                    if re.fullmatch(r"[0-9a-f]{64}", expected):
                        report["candidate"].update(native_sha256=actual, native_expected_asset_sha256=expected)
                        report["candidate"]["native_binding_status"] = "MATCH" if actual == expected else "DIFFERENT"
                    else:
                        report["candidate"].update(native_sha256=actual, native_binding_status="INVALID_EXPECTED_ASSET")
    except (OSError, ValueError, KeyError, zipfile.BadZipFile):
        report["candidate"]["native_binding_status"] = "UNAVAILABLE"
    su = shutil.which("su")
    if su and call(root_shell(su, "/system/bin/id", "-u")) == (0, "0"):
        report["installed_original"] = installed_identity(su, apksigner)
        report["running_core"] = daemon_identity(su)
    installed_cert = report["installed_original"].get("signer_sha256")
    candidate_cert = report["candidate"].get("signer_sha256")
    if installed_cert and candidate_cert:
        report["certificate_comparison"] = "MATCH" if installed_cert == candidate_cert else "DIFFERENT"
    cores = report["running_core"].get("sha256")
    if cores and report["candidate"].get("native_binding_status") == "MATCH" and candidate_cert:
        report["native_comparison"] = "MATCH" if all(value == report["candidate"]["native_sha256"] for value in cores) else "DIFFERENT"
    complete = report["certificate_comparison"] != "UNKNOWN" and report["native_comparison"] != "UNKNOWN"
    if complete:
        report["status"] = "COMPLETE_READ_ONLY_IDENTITY_SNAPSHOT"
    directory = Path.home() / "storage/downloads"
    if not directory.is_dir() or not os.access(directory, os.W_OK):
        directory = Path.home()
    output = directory / ("R13198_PHONE_PREFLIGHT_PUBLIC_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f") + ".json")
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    print("PUBLIC_REPORT=" + str(output))
    return 0 if complete else 2


if __name__ == "__main__":
    import sys
    raise SystemExit(main(Path(sys.argv[1]).expanduser()))
R13198_PHONE_PREFLIGHT_PY
