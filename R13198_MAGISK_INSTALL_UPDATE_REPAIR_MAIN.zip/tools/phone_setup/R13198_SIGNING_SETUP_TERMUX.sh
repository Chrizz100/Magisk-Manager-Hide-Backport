#!/data/data/com.termux/files/usr/bin/bash
# R13.19.8 phone-only persistent APK signing identity setup.
# Run in Termux (no root, ADB, computer or Android installation needed).
# Prerequisites: pkg install python openssl-tool
# Read-only default: bash R13198_SIGNING_SETUP_TERMUX.sh
# Read-only explicit: bash R13198_SIGNING_SETUP_TERMUX.sh --inspect
# Reuse existing key or create once only if truly absent:
#   bash R13198_SIGNING_SETUP_TERMUX.sh --prepare
# Existing R13.9 directory is reused: $HOME/.config/magisk-hide-r139-signer
# Private export files must stay private; only the certificate pin is public.
# --directory PATH is available for a deliberately selected private directory.
set -euo pipefail
for dependency in python3 openssl; do
  if ! command -v "$dependency" >/dev/null 2>&1; then
    printf '%s\n' 'Prerequisite missing. In Termux run: pkg install python openssl-tool' >&2
    exit 2
  fi
done
python3 - "$@" <<'R13198_PHONE_SETUP_PY'
#!/usr/bin/env python3
"""Keep/reuse the R13.9 signing identity; prepare private GitHub-secret files.

No Android installation, su, daemon change or network request is performed.
The default --inspect mode only reads existing credentials and prints public data.
"""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import stat
import subprocess
import tempfile

HISTORICAL_CERT = "972781bce7cb9de02651d121e89acd6e3ac6e6f2c9cf519462ff8c586192de69"
FILES = {
    "keystore": "magisk-hide.p12",
    "password": "MAGISK_HIDE_P12_PASSWORD.txt",
    "key_password": "MAGISK_HIDE_P12_KEY_PASSWORD.txt",
    "alias": "MAGISK_HIDE_P12_ALIAS.txt",
    "base64": "MAGISK_HIDE_P12_BASE64.txt",
    "pin": "MAGISK_HIDE_SIGNER_SHA256.txt",
}
LEGACY_MATERIAL = ("magisk-hide-private.pem", "magisk-hide-cert.pem")
SHARED_ROOTS = tuple(Path(value) for value in ("/sdcard", "/storage", "/mnt", "/data/media"))


class SetupError(Exception):
    pass


def private_directory(directory: Path) -> Path:
    """Validate before reading secrets or creating anything; never follow links."""
    directory = directory.expanduser().absolute()
    for component in (directory, *directory.parents):
        if component.is_symlink():
            raise SetupError("SIGNER_PATH_MUST_NOT_CONTAIN_SYMLINKS")
    directory = directory.resolve(strict=False)
    if any(directory == root or root in directory.parents for root in SHARED_ROOTS):
        raise SetupError("KEEP_PRIVATE_KEY_IN_TERMUX_PRIVATE_STORAGE")
    if directory.exists() and not directory.is_dir():
        raise SetupError("SIGNER_DIRECTORY_IS_NOT_A_DIRECTORY")
    for name in (*FILES.values(), *LEGACY_MATERIAL):
        path = directory / name
        if path.is_symlink():
            raise SetupError("SIGNER_FILE_MUST_NOT_BE_A_SYMLINK")
        if path.exists():
            info = path.stat(follow_symlinks=False)
            if not stat.S_ISREG(info.st_mode):
                raise SetupError("SIGNER_FILE_MUST_BE_A_REGULAR_FILE")
            if info.st_nlink != 1:
                raise SetupError("SIGNER_FILE_MUST_NOT_HAVE_EXTERNAL_HARDLINKS")
    return directory


def checked(args: list[str], data: bytes | None = None) -> bytes:
    try:
        result = subprocess.run(args, input=data, capture_output=True, timeout=90)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise SetupError("OPENSSL_EXECUTION_FAILED") from exc
    if result.returncode:
        # Raw child output may contain private material. Never print it.
        raise SetupError("KEYSTORE_OR_PASSWORD_VALIDATION_FAILED")
    return result.stdout


def read_password(path: Path) -> str:
    if not path.is_file():
        raise SetupError("EXISTING_PASSWORD_FILE_MISSING_KEEP_ORIGINAL_KEY")
    password = path.read_text(encoding="utf-8").rstrip("\r\n")
    if not password or password != password.strip() or any(
        ord(c) < 32 or ord(c) > 126 or c == "\\" for c in password
    ):
        raise SetupError("PASSWORD_NOT_COMPATIBLE_WITH_BOTH_BUILD_PROPERTY_READERS")
    return password


def inspect_identity(directory: Path) -> tuple[dict, str | None]:
    directory = private_directory(directory)
    keystore = directory / FILES["keystore"]
    if not keystore.is_file():
        partial = directory.exists() and any(directory.iterdir())
        return ({"status": "PARTIAL_EXISTING_SIGNING_DIRECTORY" if partial else "KEY_NOT_PRESENT",
                 "directory": str(directory), "new_key_can_be_created": not partial,
                 "phone_installation_checked": False, "private_values_printed": False}, None)
    password_path = directory / FILES["password"]
    password = read_password(password_path)
    key_password_path = directory / FILES["key_password"]
    if key_password_path.exists() and read_password(key_password_path) != password:
        # The legacy OpenSSL setup uses one PKCS12 password. Do not replace a
        # separately configured key merely because this phone helper cannot load it.
        raise SetupError("SEPARATE_KEY_PASSWORD_KEEP_EXISTING_KEY_USE_CI_VALIDATOR")
    common = ["openssl", "pkcs12", "-in", str(keystore),
              "-passin", "file:" + str(password_path)]
    cert_output = checked(common + ["-clcerts", "-nokeys"])
    key_output = checked(common + ["-nocerts", "-nodes"])
    certs = re.findall(b"-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----",
                       cert_output, re.S)
    keys = re.findall(b"-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----", key_output)
    if len(certs) != 1 or len(keys) != 1:
        raise SetupError("REQUIRE_ONE_CERTIFICATE_AND_PRIVATE_KEY")
    cert = certs[0] + b"\n"
    der = checked(["openssl", "x509", "-outform", "DER"], cert)
    public_from_cert = checked(["openssl", "x509", "-pubkey", "-noout"], cert)
    public_from_key = checked(["openssl", "pkey", "-pubout"], key_output)
    if public_from_cert != public_from_key:
        raise SetupError("PRIVATE_KEY_DOES_NOT_MATCH_CERTIFICATE")
    dates = checked(["openssl", "x509", "-startdate", "-enddate", "-noout"], cert)
    try:
        bounds = dict(line.split("=", 1) for line in dates.decode("ascii").splitlines())
        not_before = datetime.strptime(bounds["notBefore"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
        not_after = datetime.strptime(bounds["notAfter"], "%b %d %H:%M:%S %Y %Z").replace(tzinfo=timezone.utc)
    except (ValueError, KeyError, UnicodeError):
        raise SetupError("CERTIFICATE_VALIDITY_RANGE_UNREADABLE") from None
    if not not_before <= datetime.now(timezone.utc) < not_after:
        raise SetupError("CERTIFICATE_NOT_CURRENTLY_VALID")
    aliases = re.findall(rb"^\s*friendlyName:\s*([^\r\n]+)", cert_output, re.M)
    key_aliases = re.findall(rb"^\s*friendlyName:\s*([^\r\n]+)", key_output, re.M)
    if len(aliases) != 1 or key_aliases != aliases:
        raise SetupError("PKCS12_ALIAS_AMBIGUOUS")
    alias = aliases[0].decode("ascii", errors="strict")
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", alias):
        raise SetupError("PKCS12_ALIAS_NOT_COMPATIBLE_WITH_WORKFLOW")
    alias_file = directory / FILES["alias"]
    if alias_file.exists() and alias_file.read_text().strip() != alias:
        raise SetupError("SAVED_ALIAS_DIFFERS_FROM_EXISTING_KEYSTORE")
    fingerprint = hashlib.sha256(der).hexdigest()
    pin_file = directory / FILES["pin"]
    if pin_file.exists():
        saved_pin = pin_file.read_text(encoding="ascii").strip()
        if not re.fullmatch(r"[0-9a-fA-F]{64}", saved_pin):
            raise SetupError("SAVED_CERTIFICATE_PIN_INVALID_KEEP_EXISTING_KEY")
        if saved_pin.lower() != fingerprint:
            raise SetupError("SAVED_CERTIFICATE_PIN_DIFFERS_NO_KEY_ROTATION")
    private_paths = [directory / name for name in (*FILES.values(), *LEGACY_MATERIAL)]
    permissions_ok = stat.S_IMODE(directory.stat().st_mode) == 0o700 and all(
        stat.S_IMODE(path.stat().st_mode) == 0o600 for path in private_paths if path.exists()
    )
    return ({"status": "EXISTING_KEY_VALID", "directory": str(directory),
            "signer_sha256": fingerprint, "alias_verified": True,
            "keystore_sha256": hashlib.sha256(keystore.read_bytes()).hexdigest(),
            "historical_r134_certificate_matches": fingerprint == HISTORICAL_CERT,
            "historical_comparison_is_not_current_phone_measurement": True,
            "private_storage_permissions_ok": permissions_ok,
            "phone_installation_checked": False, "private_values_printed": False}, alias)


def inspect(directory: Path) -> dict:
    # The alias is needed internally for export but is itself stored as a GitHub
    # secret. Keep it out of public output along with every password/key value.
    return inspect_identity(directory)[0]


def private_write(path: Path, data: bytes) -> None:
    descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, "wb") as stream:
        stream.write(data)


def replace_export(path: Path, data: bytes) -> None:
    descriptor, temporary = tempfile.mkstemp(prefix=".r13198-export-", dir=path.parent)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
        os.chmod(temporary, 0o600)
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def prepare(directory: Path) -> dict:
    os.umask(0o077)
    directory = private_directory(directory)
    created = False
    if not (directory / FILES["keystore"]).is_file():
        if directory.exists() and any(directory.iterdir()):
            raise SetupError("PARTIAL_EXISTING_SIGNING_DIRECTORY_PRESERVED_NO_NEW_KEY")
        directory.parent.mkdir(parents=True, exist_ok=True)
        temporary = Path(tempfile.mkdtemp(prefix=".magisk-signer-stage-", dir=directory.parent))
        try:
            password = secrets.token_hex(32)
            alias = "magisk-hide-r139"
            private_write(temporary / FILES["password"], (password + "\n").encode())
            private_write(temporary / FILES["alias"], (alias + "\n").encode())
            checked(["openssl", "req", "-x509", "-newkey", "rsa:3072", "-nodes",
                     "-days", "10000", "-keyout", str(temporary / "magisk-hide-private.pem"),
                     "-out", str(temporary / "magisk-hide-cert.pem"),
                     "-subj", "/CN=Magisk Hide persistent project signing/O=Personal project/C=DE"])
            checked(["openssl", "pkcs12", "-export", "-inkey",
                     str(temporary / "magisk-hide-private.pem"), "-in",
                     str(temporary / "magisk-hide-cert.pem"), "-name", alias,
                     "-out", str(temporary / FILES["keystore"]),
                     "-passout", "file:" + str(temporary / FILES["password"])])
            inspect(temporary)
            # The encrypted PKCS12 is sufficient. Do not retain a newly created
            # unencrypted private PEM. Existing legacy PEM backups are preserved.
            (temporary / "magisk-hide-private.pem").unlink()
            for item in temporary.iterdir():
                item.chmod(0o600)
            # An empty pre-existing directory is not a key; remove only if empty.
            if directory.exists():
                directory.rmdir()
            temporary.rename(directory)
            created = True
        finally:
            if temporary.exists():
                shutil.rmtree(temporary)
    result, alias = inspect_identity(directory)
    if result["status"] != "EXISTING_KEY_VALID":
        raise SetupError("NO_VALID_EXISTING_KEY")
    directory.chmod(0o700)
    for name in (*FILES.values(), *LEGACY_MATERIAL):
        path = directory / name
        if path.exists():
            path.chmod(0o600)
    before = (directory / FILES["keystore"]).read_bytes()
    password = read_password(directory / FILES["password"])
    exports = {
        FILES["base64"]: base64.b64encode(before) + b"\n",
        FILES["key_password"]: (password + "\n").encode(),
        FILES["alias"]: (alias + "\n").encode(),
        FILES["pin"]: (result["signer_sha256"] + "\n").encode(),
    }
    for name, data in exports.items():
        replace_export(directory / name, data)
    if (directory / FILES["keystore"]).read_bytes() != before:
        raise SetupError("EXISTING_KEYSTORE_BYTES_CHANGED")
    result["status"] = "NEW_DURABLE_KEY_CREATED" if created else "EXISTING_KEY_REUSED_UNCHANGED"
    result["github_repository_secrets"] = ["MAGISK_HIDE_P12_BASE64", "MAGISK_HIDE_P12_PASSWORD",
                                            "MAGISK_HIDE_P12_KEY_PASSWORD", "MAGISK_HIDE_P12_ALIAS"]
    result["github_repository_variable"] = "MAGISK_HIDE_SIGNER_SHA256"
    result["private_files_directory"] = str(directory)
    result["private_storage_permissions_ok"] = True
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path,
                        default=Path.home() / ".config/magisk-hide-r139-signer")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--inspect", action="store_true", help="Read only; default")
    mode.add_argument("--prepare", action="store_true", help="Reuse existing key or create once if truly absent")
    options = parser.parse_args()
    if not shutil.which("openssl"):
        print("OPENSSL_MISSING: In Termux: pkg install python openssl-tool")
        return 2
    try:
        result = prepare(options.directory) if options.prepare else inspect(options.directory)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (SetupError, OSError, UnicodeError) as exc:
        code = str(exc) if isinstance(exc, SetupError) else "LOCAL_FILE_OR_ENCODING_ERROR"
        print(json.dumps({"status": "STOPPED", "reason": code,
                          "existing_key_preserved": True, "private_values_printed": False}))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
R13198_PHONE_SETUP_PY
