# R13.19.8: Telefon-Signierschlüssel weiterverwenden

Der überprüfte Helper liegt eine Ebene über diesem Verzeichnis:

- `R13198_SIGNING_SETUP.py`
- `R13198_SIGNING_SETUP_TERMUX.sh` — eigenständiger Bash-Wrapper mit bytegenau eingebettetem Python-Quelltext.

Die Standardablage bleibt exakt `$HOME/.config/magisk-hide-r139-signer`. Das ist die Ablage des früheren R13.9-Setups. Der Helper verändert keine Android-App, keine Root-Installation und keinen Magisk-Daemon. Er benötigt weder `su` noch ADB und sendet nichts ins Netz.

## Verwendung in Termux

Benötigt werden `python3` und `openssl`. Falls eines davon fehlt, nennt der Wrapper diesen manuellen Installationsbefehl:

```sh
pkg install python openssl-tool
```

Prüfen ohne Schreibzugriffe auf die Schlüsselablage:

```sh
bash R13198_SIGNING_SETUP_TERMUX.sh --inspect
```

Ohne Argument ist ebenfalls ausschließlich `--inspect` aktiv. Der Status `KEY_NOT_PRESENT` bedeutet nur, dass am geprüften Pfad kein Schlüssel liegt. `PARTIAL_EXISTING_SIGNING_DIRECTORY` bedeutet, dass dort bereits andere Dateien liegen und deshalb kein Ersatzschlüssel erzeugt werden darf. Beide Status sind Inspektionsbefunde, keine Signaturfreigabe.

Vorhandenen gültigen Schlüssel verwenden und die Exportdateien vorbereiten:

```sh
bash R13198_SIGNING_SETUP_TERMUX.sh --prepare
```

`--prepare` erzeugt nur dann eine neue Identität, wenn der gewählte Ordner fehlt oder tatsächlich leer ist. Bei einer vorhandenen gültigen `magisk-hide.p12` bleiben deren Bytes unverändert. Fehlende oder widersprüchliche Zugangsdaten, ein abweichender gespeicherter Zertifikats-Pin oder eine unvollständige Ablage führen zum Stopp; es gibt keine automatische Schlüsselrotation.

Das alte R13.9-Setup hatte keine eigene `MAGISK_HIDE_P12_KEY_PASSWORD.txt`. Für diesen OpenSSL-PKCS12-Fall ergänzt `--prepare` die Datei aus dem erfolgreich geprüften vorhandenen Passwort. Ein bereits vorhandenes abweichendes Key-Passwort wird nicht überschrieben; der Helper stoppt und verweist auf die CI-Validierung, die getrennte Passwörter unterstützt.

## Export und Vertraulichkeit

| Datei in der privaten Ablage | Ziel in GitHub |
| --- | --- |
| `MAGISK_HIDE_P12_BASE64.txt` | Repository Secret `MAGISK_HIDE_P12_BASE64` |
| `MAGISK_HIDE_P12_PASSWORD.txt` | Repository Secret `MAGISK_HIDE_P12_PASSWORD` |
| `MAGISK_HIDE_P12_KEY_PASSWORD.txt` | Repository Secret `MAGISK_HIDE_P12_KEY_PASSWORD` |
| `MAGISK_HIDE_P12_ALIAS.txt` | Repository Secret `MAGISK_HIDE_P12_ALIAS` |
| `MAGISK_HIDE_SIGNER_SHA256.txt` | Öffentliche Repository Variable `MAGISK_HIDE_SIGNER_SHA256` |

Der Wrapper zeigt keine dieser privaten Werte an. Die JSON-Ausgabe enthält den öffentlichen Zertifikats-Fingerabdruck, den Dateihash des Keystores und Statuswerte. Der Alias wird nicht als eigenes Ausgabefeld gedruckt. Passwörter werden OpenSSL über private Dateien übergeben, nicht als Passwortwerte auf der Kommandozeile. Die Ausgabe bestätigt ausdrücklich keine Update-Kompatibilität mit einem realen Telefon.

Vor jedem Lesen oder Schreiben werden Symlinks in den Pfadkomponenten und den bekannten Dateien, externe Hardlinks und nicht reguläre Dateien abgewiesen. `/sdcard`, `/storage`, `/mnt` und `/data/media` sind als Schlüsselablage gesperrt. Das ist eine lokale Schutzprüfung gegen versehentliche Umleitung; sie behauptet keinen Schutz vor einem gleichberechtigten Prozess, der gleichzeitig Dateien austauscht.

`--inspect` verändert weder Rechte noch Exportdateien. Nach erfolgreicher Prüfung setzt `--prepare` den Ablageordner auf `0700` und die bekannten privaten Dateien auf `0600`. Ein neu erzeugter unverschlüsselter privater PEM-Schlüssel wird vor Veröffentlichung der Ablage entfernt; vorhandene alte PEM-Backups bleiben byteidentisch erhalten und bekommen ebenfalls `0600`. Der verschlüsselte PKCS12-Keystore bleibt das dauerhaft verwendete Original.

Passwörter müssen wegen der zwei unterschiedlichen Property-Parser im Magisk-Build aus druckbarem ASCII ohne Backslash sowie ohne führende oder abschließende Leerzeichen bestehen. Nicht kompatible Passwörter werden nicht stillschweigend verändert. Eine gegebenenfalls notwendige Passwortänderung muss denselben bestehenden privaten Schlüssel erhalten.

## Regressionsnachweis

Ausgeführt wurde:

```sh
python3 work_r13198/phone_setup/tests/test_signing_setup.py \
  --ci-importer work_r13198/signing_impl/R13198_IMPORT_SIGNING.py
```

Ergebnis: **34 Tests bestanden, 0 fehlgeschlagen.** Details, Werkzeugversionen und Quelltexthashes stehen in `R13198_PHONE_SETUP_TEST_RESULTS.json`.

Die Prüfungen verwenden echte OpenSSL-PKCS12-Dateien, Zertifikate und private RSA-Schlüssel in einem automatisch entfernten temporären Verzeichnis. Es werden keine kryptografischen Funktionen simuliert. Ein privater Schlüssel signiert tatsächlich eine Nachricht, deren Signatur mit dem Zertifikatsschlüssel verifiziert wird. Die beiden abschließenden Tests übergeben die alten beziehungsweise neu erzeugten Telefon-Exportdateien an den echten Java-basierten CI-Importer; dessen Signaturprüfung, PrivateKeyEntry-Prüfung, beide Passwörter, Zertifikats-Pin und beide Property-Parser bestehen ebenfalls. Der Import übernimmt die P12-Bytes unverändert und meldet `STABLE_SECRET`.

Abgedeckt sind insbesondere:

- Standardpfad, fehlende und vorhandene Ablage: Inspektion ohne Datei-, Rechte-, Inode- oder Änderungszeitänderung.
- Neuerstellung in fehlendem beziehungsweise leerem Ordner und wiederholte Vorbereitung ohne Wechsel der P12-Bytes oder Zertifikatsidentität.
- Altes R13.9-Format mit nur drei Exportdateien; Ergänzung des vierten Secrets und des öffentlichen Pins.
- Falsches oder fehlendes Passwort, falscher Alias, abweichender oder ungültiger Pin, abweichendes Key-Passwort und ungültiger PKCS12-Inhalt: Stopp ohne Veränderung des vorhandenen Materials.
- Zertifikat ohne privaten Schlüssel, fehlender PKCS12-Alias sowie künftig gültige oder abgelaufene Zertifikate: Ablehnung.
- Verzeichnissymlinks, Symlinks in Vorfahren oder bekannten Dateien, externe Hardlinks, FIFO-Dateien und gemeinsam zugängliche Android-Speicherpfade: Ablehnung vor privatem Export.
- Alte offene Dateirechte: Inspektion meldet sie unverändert, erfolgreiche Vorbereitung korrigiert sie.
- Wrapper-Syntax, eingebetteter Quelltext, Standardmodus, Argumentweitergabe und fehlende Voraussetzungen.

Es wurde kein dauerhafter Projektschlüssel auf diesem Host angelegt. Sämtliche privaten Test-Fixtures wurden entfernt. Diese Prüfungen ersetzen keinen Lauf auf dem echten Telefon und keine Messung dessen aktuell installierter APK-Signatur.
