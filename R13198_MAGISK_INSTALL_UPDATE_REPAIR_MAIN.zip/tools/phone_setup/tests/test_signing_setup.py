#!/usr/bin/env python3
"""Real OpenSSL regressions for the phone-only persistent signing helper.

Every private key is disposable test material in TemporaryDirectory. This test
does not inspect the real HOME signer directory and never creates a project key.
The report contains names, results and tool versions, never fixture secrets.
"""
from __future__ import annotations

import argparse
import base64
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile
import time


ROOT = Path(__file__).resolve().parents[1]
SCRIPT = ROOT / "R13198_SIGNING_SETUP.py"
WRAPPER = ROOT / "R13198_SIGNING_SETUP_TERMUX.sh"
NAMES = {
    "p12": "magisk-hide.p12",
    "password": "MAGISK_HIDE_P12_PASSWORD.txt",
    "key_password": "MAGISK_HIDE_P12_KEY_PASSWORD.txt",
    "alias": "MAGISK_HIDE_P12_ALIAS.txt",
    "base64": "MAGISK_HIDE_P12_BASE64.txt",
    "pin": "MAGISK_HIDE_SIGNER_SHA256.txt",
}


class CheckFailed(Exception):
    pass


def require(condition: bool, label: str) -> None:
    if not condition:
        raise CheckFailed(label)


def tool(args: list[str], *, data: bytes | None = None, env: dict | None = None) -> bytes:
    result = subprocess.run(args, input=data, capture_output=True, timeout=120, env=env)
    if result.returncode:
        # OpenSSL may return private material; do not include raw output.
        raise CheckFailed("TEST_FIXTURE_TOOL_FAILED:" + Path(args[0]).name)
    return result.stdout


def file_snapshot(directory: Path) -> dict:
    """Compare bytes, paths, modes, inodes and modification times; ignore atime."""
    if not directory.exists() and not directory.is_symlink():
        return {}
    paths = [directory]
    if directory.is_dir() and not directory.is_symlink():
        paths += sorted(directory.rglob("*"))
    result = {}
    for path in paths:
        info = path.lstat()
        relative = "." if path == directory else str(path.relative_to(directory))
        entry = {
            "mode": stat.S_IMODE(info.st_mode),
            "mtime_ns": info.st_mtime_ns,
            "inode": info.st_ino,
            "links": info.st_nlink,
        }
        if stat.S_ISLNK(info.st_mode):
            entry["target"] = os.readlink(path)
        elif stat.S_ISREG(info.st_mode):
            entry["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
        result[relative] = entry
    return result


class Suite:
    def __init__(self, temporary: Path, ci_importer: Path | None = None):
        self.temporary = temporary
        self.home = temporary / "home"
        self.home.mkdir(mode=0o700)
        self.environment = dict(os.environ, HOME=str(self.home))
        self.password = "Temporary-passphrase.4819-DO-NOT-USE"
        self.alias = "temporary-regression-fixture-alias"
        self.private_values = [self.password.encode(), self.alias.encode()]
        self.results = []
        self.ci_importer = ci_importer
        self.fixture = self.make_fixture()

    def make_fixture(self) -> Path:
        directory = self.temporary / "fixture"
        directory.mkdir(mode=0o700)
        (directory / NAMES["password"]).write_text(self.password + "\n")
        (directory / NAMES["alias"]).write_text(self.alias + "\n")
        tool(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-days", "5",
              "-keyout", str(directory / "magisk-hide-private.pem"),
              "-out", str(directory / "magisk-hide-cert.pem"),
              "-subj", "/CN=Disposable signing regression fixture"])
        self.export_p12(directory)
        (directory / NAMES["base64"]).write_bytes(base64.b64encode((directory / NAMES["p12"]).read_bytes()) + b"\n")
        for path in directory.iterdir():
            path.chmod(0o600)
        return directory

    def export_p12(self, directory: Path, *, certificate: Path | None = None,
                   omit_alias: bool = False, cert_only: bool = False) -> None:
        certificate = certificate or directory / "magisk-hide-cert.pem"
        command = ["openssl", "pkcs12", "-export", "-in", str(certificate)]
        if cert_only:
            command += ["-nokeys"]
        else:
            command += ["-inkey", str(directory / "magisk-hide-private.pem")]
        if not omit_alias:
            command += ["-name", self.alias]
        command += ["-out", str(directory / NAMES["p12"]), "-passout",
                    "file:" + str(directory / NAMES["password"])]
        tool(command)

    def clone(self, name: str) -> Path:
        path = self.temporary / name
        shutil.copytree(self.fixture, path)
        return path

    def cli(self, directory: Path | None = None, *arguments: str,
            expected_code: int = 0, wrapper: bool = False,
            environment: dict | None = None) -> dict:
        command = ["bash", str(WRAPPER)] if wrapper else [sys.executable, str(SCRIPT)]
        if directory is not None:
            command += ["--directory", str(directory)]
        command += arguments
        result = subprocess.run(command, capture_output=True, timeout=120,
                                env=environment or self.environment)
        require(result.returncode == expected_code,
                "CLI_EXIT_CODE:" + str(result.returncode) + "_EXPECTED:" + str(expected_code))
        combined = result.stdout + result.stderr
        for value in self.private_values:
            require(value not in combined, "PRIVATE_FIXTURE_VALUE_IN_OUTPUT")
        require(b"BEGIN PRIVATE KEY" not in combined and b"BEGIN RSA PRIVATE KEY" not in combined,
                "PRIVATE_PEM_IN_OUTPUT")
        require(not result.stderr, "UNEXPECTED_CLI_STDERR")
        try:
            report = json.loads(result.stdout)
        except (ValueError, UnicodeError):
            raise CheckFailed("CLI_DID_NOT_RETURN_JSON") from None
        require(report.get("private_values_printed") is False, "PRIVACY_REPORT_MISSING")
        require("alias" not in report, "ALIAS_MUST_NOT_BE_PRINTED")
        return report

    def stopped_unchanged(self, directory: Path, reason: str) -> None:
        before = file_snapshot(directory)
        report = self.cli(directory, "--prepare", expected_code=2)
        require(report["status"] == "STOPPED" and report["reason"] == reason,
                "WRONG_FAILURE_CLASSIFICATION")
        require(file_snapshot(directory) == before, "FAILED_PREPARE_MODIFIED_EXISTING_MATERIAL")

    def valid_exports(self, directory: Path) -> None:
        p12 = (directory / NAMES["p12"]).read_bytes()
        password = (directory / NAMES["password"]).read_bytes().rstrip(b"\r\n")
        alias = (directory / NAMES["alias"]).read_bytes().rstrip(b"\r\n")
        self.private_values += [password, base64.b64encode(p12)]
        # The helper's fixed, public new-key alias also appears in its legacy
        # directory name. It is not a leaked secret when printing that path.
        # Arbitrary existing aliases are checked, and no alias field is emitted.
        if alias != b"magisk-hide-r139":
            self.private_values += [alias]
        require(base64.b64decode((directory / NAMES["base64"]).read_bytes()) == p12,
                "BASE64_EXPORT_NOT_EXACT_KEYSTORE")
        require((directory / NAMES["key_password"]).read_bytes().rstrip(b"\r\n") == password,
                "KEY_PASSWORD_EXPORT_NOT_LEGACY_PASSWORD")
        common = ["openssl", "pkcs12", "-in", str(directory / NAMES["p12"]), "-passin",
                  "file:" + str(directory / NAMES["password"])]
        cert = tool(common + ["-clcerts", "-nokeys"])
        private = tool(common + ["-nocerts", "-nodes"])
        der = tool(["openssl", "x509", "-outform", "DER"], data=cert)
        require((directory / NAMES["pin"]).read_text().strip() == hashlib.sha256(der).hexdigest(),
                "PUBLIC_PIN_DOES_NOT_MATCH_P12_CERTIFICATE")
        cert_pub = tool(["openssl", "x509", "-pubkey", "-noout"], data=cert)
        key_pub = tool(["openssl", "pkey", "-pubout"], data=private)
        require(cert_pub == key_pub, "CERTIFICATE_AND_PRIVATE_KEY_DO_NOT_MATCH")
        # Perform an actual signature using the extracted key, not just metadata.
        with tempfile.TemporaryDirectory(prefix="sign-proof-", dir=self.temporary) as temporary:
            proof = Path(temporary)
            (proof / "private.pem").write_bytes(private)
            (proof / "public.pem").write_bytes(cert_pub)
            message = b"R13198 disposable test: private key really signs"
            signature = tool(["openssl", "dgst", "-sha256", "-sign", str(proof / "private.pem")], data=message)
            (proof / "signature.bin").write_bytes(signature)
            verified = tool(["openssl", "dgst", "-sha256", "-verify", str(proof / "public.pem"),
                             "-signature", str(proof / "signature.bin")], data=message)
            require(b"Verified OK" in verified, "REAL_SIGNATURE_PROOF_FAILED")

    def record(self, name: str, check) -> None:
        start = time.monotonic()
        try:
            check()
            result = {"name": name, "status": "PASS"}
        except CheckFailed as exc:
            result = {"name": name, "status": "FAIL", "reason": str(exc)}
        except Exception as exc:
            # Never serialize an exception that might contain passwords/PEM.
            result = {"name": name, "status": "FAIL", "reason": type(exc).__name__}
        result["seconds"] = round(time.monotonic() - start, 3)
        self.results.append(result)
        print(name + ": " + result["status"])

    def missing_inspect(self):
        before = file_snapshot(self.home)
        report = self.cli()
        expected = self.home / ".config/magisk-hide-r139-signer"
        require(report["status"] == "KEY_NOT_PRESENT", "MISSING_NOT_IDENTIFIED")
        require(report["directory"] == str(expected), "LEGACY_DEFAULT_PATH_CHANGED")
        require(report["new_key_can_be_created"] is True, "EMPTY_DIRECTORY_NOT_RECOGNIZED")
        require(file_snapshot(self.home) == before, "DEFAULT_INSPECT_WROTE_FILES")

    def existing_inspect(self):
        directory = self.clone("inspect-existing")
        before = file_snapshot(directory)
        report = self.cli(directory)
        require(report["status"] == "EXISTING_KEY_VALID", "LEGACY_KEY_NOT_RECOGNIZED")
        require(file_snapshot(directory) == before, "INSPECT_CHANGED_EXISTING_FILES")
        require(not (directory / NAMES["key_password"]).exists(), "INSPECT_EXPORTED_KEY_PASSWORD")
        require(not (directory / NAMES["pin"]).exists(), "INSPECT_EXPORTED_PUBLIC_PIN")

    def new_repeat(self, empty_existing: bool = False):
        directory = self.temporary / ("new-empty" if empty_existing else "new-missing")
        if empty_existing:
            directory.mkdir(mode=0o755)
        report = self.cli(directory, "--prepare")
        require(report["status"] == "NEW_DURABLE_KEY_CREATED", "NEW_IDENTITY_NOT_CREATED")
        first_p12 = (directory / NAMES["p12"]).read_bytes()
        first_key_hash = hashlib.sha256(first_p12).hexdigest()
        require(report["keystore_sha256"] == first_key_hash, "WRONG_REPORTED_KEYSTORE_HASH")
        self.valid_exports(directory)
        require(not (directory / "magisk-hide-private.pem").exists(), "UNENCRYPTED_NEW_PRIVATE_KEY_RETAINED")
        again = self.cli(directory, "--prepare")
        require(again["status"] == "EXISTING_KEY_REUSED_UNCHANGED", "REPEAT_DID_NOT_REUSE_KEY")
        require((directory / NAMES["p12"]).read_bytes() == first_p12, "REPEAT_ROTATED_KEYSTORE")
        require(again["signer_sha256"] == report["signer_sha256"], "REPEAT_CHANGED_SIGNER")
        require(again["keystore_sha256"] == first_key_hash, "REPEAT_CHANGED_KEYSTORE_HASH")
        self.assert_permissions(directory)

    def legacy_prepare(self):
        directory = self.clone("legacy-three-secrets")
        require(not (directory / NAMES["key_password"]).exists(), "LEGACY_FIXTURE_NOT_LEGACY")
        p12_before = (directory / NAMES["p12"]).read_bytes()
        pem_before = (directory / "magisk-hide-private.pem").read_bytes()
        report = self.cli(directory, "--prepare")
        require(report["status"] == "EXISTING_KEY_REUSED_UNCHANGED", "LEGACY_KEY_NOT_REUSED")
        require((directory / NAMES["p12"]).read_bytes() == p12_before, "LEGACY_P12_REWRITTEN")
        require((directory / "magisk-hide-private.pem").read_bytes() == pem_before,
                "EXISTING_LEGACY_PRIVATE_BACKUP_CHANGED")
        require(set(report["github_repository_secrets"]) == {NAMES[key][:-4] for key in
                ("base64", "password", "key_password", "alias")}, "FOUR_SECRET_NAMES_CHANGED")
        require(report["github_repository_variable"] == "MAGISK_HIDE_SIGNER_SHA256", "PIN_VARIABLE_CHANGED")
        self.valid_exports(directory)

    def wrong_password(self):
        directory = self.clone("wrong-password")
        (directory / NAMES["password"]).write_text("Intentionally-wrong.6789\n")
        self.private_values += [b"Intentionally-wrong.6789"]
        self.stopped_unchanged(directory, "KEYSTORE_OR_PASSWORD_VALIDATION_FAILED")

    def partial_directory(self):
        directory = self.temporary / "partial-directory"
        directory.mkdir()
        (directory / NAMES["password"]).write_text(self.password + "\n")
        before = file_snapshot(directory)
        report = self.cli(directory, "--inspect")
        require(report["status"] == "PARTIAL_EXISTING_SIGNING_DIRECTORY", "PARTIAL_INSPECT_MISCLASSIFIED")
        require(report["new_key_can_be_created"] is False, "PARTIAL_MAY_CREATE_NEW_KEY")
        require(file_snapshot(directory) == before, "PARTIAL_INSPECT_WROTE_FILES")
        self.stopped_unchanged(directory, "PARTIAL_EXISTING_SIGNING_DIRECTORY_PRESERVED_NO_NEW_KEY")

    def missing_password(self):
        directory = self.clone("missing-password")
        (directory / NAMES["password"]).unlink()
        self.stopped_unchanged(directory, "EXISTING_PASSWORD_FILE_MISSING_KEEP_ORIGINAL_KEY")

    def wrong_alias(self):
        directory = self.clone("wrong-alias")
        (directory / NAMES["alias"]).write_text("different-fixture-alias\n")
        self.private_values += [b"different-fixture-alias"]
        self.stopped_unchanged(directory, "SAVED_ALIAS_DIFFERS_FROM_EXISTING_KEYSTORE")

    def wrong_pin(self, malformed: bool = False):
        directory = self.clone("malformed-pin" if malformed else "wrong-pin")
        (directory / NAMES["pin"]).write_text(("not-a-pin" if malformed else "00" * 32) + "\n")
        self.stopped_unchanged(directory, "SAVED_CERTIFICATE_PIN_INVALID_KEEP_EXISTING_KEY" if malformed
                               else "SAVED_CERTIFICATE_PIN_DIFFERS_NO_KEY_ROTATION")

    def distinct_key_password(self):
        directory = self.clone("different-key-password")
        (directory / NAMES["key_password"]).write_text("Separate-key-password.2288\n")
        self.private_values += [b"Separate-key-password.2288"]
        self.stopped_unchanged(directory, "SEPARATE_KEY_PASSWORD_KEEP_EXISTING_KEY_USE_CI_VALIDATOR")

    def invalid_p12(self):
        directory = self.clone("invalid-p12")
        (directory / NAMES["p12"]).write_bytes(b"this is not PKCS12\x00\x01")
        self.stopped_unchanged(directory, "KEYSTORE_OR_PASSWORD_VALIDATION_FAILED")

    def no_private_key(self):
        directory = self.clone("certificate-only")
        self.export_p12(directory, cert_only=True)
        self.stopped_unchanged(directory, "REQUIRE_ONE_CERTIFICATE_AND_PRIVATE_KEY")

    def missing_alias_in_p12(self):
        directory = self.clone("p12-no-alias")
        self.export_p12(directory, omit_alias=True)
        self.stopped_unchanged(directory, "PKCS12_ALIAS_AMBIGUOUS")

    def bad_password_representation(self, value: str, name: str):
        directory = self.clone("password-representation-" + name)
        (directory / NAMES["password"]).write_text(value + "\n")
        self.private_values += [value.encode()]
        self.stopped_unchanged(directory, "PASSWORD_NOT_COMPATIBLE_WITH_BOTH_BUILD_PROPERTY_READERS")

    def symlink_directory(self, ancestor: bool = False):
        outside = self.temporary / ("outside-ancestor" if ancestor else "outside-leaf")
        outside.mkdir()
        link = self.temporary / ("ancestor-link" if ancestor else "leaf-link")
        link.symlink_to(outside, target_is_directory=True)
        directory = link / "new-private-key" if ancestor else link
        before = file_snapshot(outside)
        report = self.cli(directory, "--prepare", expected_code=2)
        require(report["reason"] == "SIGNER_PATH_MUST_NOT_CONTAIN_SYMLINKS", "SYMLINK_PATH_NOT_BLOCKED")
        require(file_snapshot(outside) == before, "PRIVATE_FILES_LEAKED_THROUGH_DIRECTORY_SYMLINK")
        self.cli(directory, "--inspect", expected_code=2)
        require(file_snapshot(outside) == before, "INSPECT_CHANGED_SYMLINK_TARGET")

    def symlink_file(self, kind: str):
        directory = self.clone("symlink-file-" + kind)
        outside = self.temporary / ("outside-file-" + kind)
        source = directory / NAMES[kind]
        if source.exists():
            outside.write_bytes(source.read_bytes())
            source.unlink()
        else:
            outside.write_bytes(b"outside file must not change\n")
        source.symlink_to(outside)
        before = outside.read_bytes()
        self.stopped_unchanged(directory, "SIGNER_FILE_MUST_NOT_BE_A_SYMLINK")
        require(outside.read_bytes() == before, "SYMLINK_TARGET_MODIFIED")
        report = self.cli(directory, "--inspect", expected_code=2)
        require(report["reason"] == "SIGNER_FILE_MUST_NOT_BE_A_SYMLINK", "INSPECT_FOLLOWED_SECRET_SYMLINK")

    def hardlink_file(self):
        directory = self.clone("hardlink-password")
        outside = self.temporary / "outside-password-hardlink"
        os.link(directory / NAMES["password"], outside)
        before = outside.read_bytes()
        self.stopped_unchanged(directory, "SIGNER_FILE_MUST_NOT_HAVE_EXTERNAL_HARDLINKS")
        require(outside.read_bytes() == before, "HARDLINK_TARGET_MODIFIED")

    def shared_storage(self):
        for value in ("/sdcard/r13198-test-never-write", "/storage/emulated/0/r13198-test-never-write",
                      "/mnt/r13198-test-never-write", "/data/media/0/r13198-test-never-write",
                      "/storage/../storage/emulated/0/r13198-test-never-write"):
            directory = Path(value)
            report = self.cli(directory, "--prepare", expected_code=2)
            require(report["reason"] in {"KEEP_PRIVATE_KEY_IN_TERMUX_PRIVATE_STORAGE",
                                           "SIGNER_PATH_MUST_NOT_CONTAIN_SYMLINKS"},
                    "SHARED_STORAGE_NOT_BLOCKED")
            require(not directory.exists(), "CREATED_SIGNER_IN_SHARED_STORAGE")

    def non_regular_file(self):
        directory = self.clone("non-regular-password")
        (directory / NAMES["password"]).unlink()
        os.mkfifo(directory / NAMES["password"])
        self.stopped_unchanged(directory, "SIGNER_FILE_MUST_BE_A_REGULAR_FILE")

    def assert_permissions(self, directory: Path):
        require(stat.S_IMODE(directory.stat().st_mode) == 0o700, "SIGNER_DIRECTORY_PERMISSIONS")
        for name in (*NAMES.values(), "magisk-hide-private.pem", "magisk-hide-cert.pem"):
            path = directory / name
            if path.exists():
                require(stat.S_IMODE(path.stat().st_mode) == 0o600, "SIGNER_FILE_PERMISSIONS")

    def permissions(self):
        directory = self.clone("legacy-open-permissions")
        directory.chmod(0o755)
        for path in directory.iterdir():
            path.chmod(0o644)
        before = file_snapshot(directory)
        inspect_report = self.cli(directory, "--inspect")
        require(inspect_report["private_storage_permissions_ok"] is False, "INSPECT_MISREPORTS_PERMISSIONS")
        require(file_snapshot(directory) == before, "INSPECT_FIXED_PERMISSIONS_WITHOUT_PREPARE")
        p12 = (directory / NAMES["p12"]).read_bytes()
        report = self.cli(directory, "--prepare")
        require(report["private_storage_permissions_ok"] is True, "PREPARE_DID_NOT_REPORT_PRIVATE_PERMISSIONS")
        self.assert_permissions(directory)
        require((directory / NAMES["p12"]).read_bytes() == p12, "PERMISSION_FIX_CHANGED_KEY")

    def certificate_time(self, future: bool):
        directory = self.clone("future-cert" if future else "expired-cert")
        ca = directory / "ca"
        ca.mkdir()
        (ca / "index").write_text("")
        (ca / "serial").write_text("01\n")
        config = ca / "openssl.cnf"
        config.write_text("[ca]\ndefault_ca=local\n[local]\ndatabase=" + str(ca / "index")
                          + "\nserial=" + str(ca / "serial") + "\nnew_certs_dir=" + str(ca)
                          + "\ndefault_md=sha256\npolicy=policy\n[policy]\ncommonName=supplied\n")
        csr = ca / "request.pem"
        tool(["openssl", "req", "-new", "-key", str(directory / "magisk-hide-private.pem"),
              "-subj", "/CN=Disposable time-bound fixture", "-out", str(csr)])
        now = datetime.now(timezone.utc)
        start = now + timedelta(days=2) if future else now - timedelta(days=5)
        end = now + timedelta(days=5) if future else now - timedelta(days=2)
        certificate = ca / "certificate.pem"
        tool(["openssl", "ca", "-config", str(config), "-batch", "-selfsign", "-notext",
              "-in", str(csr), "-out", str(certificate), "-keyfile", str(directory / "magisk-hide-private.pem"),
              "-cert", str(directory / "magisk-hide-cert.pem"),
              "-startdate", start.strftime("%Y%m%d%H%M%SZ"), "-enddate", end.strftime("%Y%m%d%H%M%SZ")])
        self.export_p12(directory, certificate=certificate)
        self.stopped_unchanged(directory, "CERTIFICATE_NOT_CURRENTLY_VALID")

    def wrapper(self):
        wrapper = WRAPPER.read_bytes()
        marker = b"python3 - \"$@\" <<'R13198_PHONE_SETUP_PY'\n"
        require(wrapper.count(marker) == 1, "WRAPPER_EMBED_BEGIN_MARKER")
        embedded = wrapper.split(marker, 1)[1].rsplit(b"\nR13198_PHONE_SETUP_PY\n", 1)[0] + b"\n"
        require(embedded == SCRIPT.read_bytes(), "WRAPPER_PYTHON_NOT_EXACT_SOURCE")
        tool(["bash", "-n", str(WRAPPER)])
        home = self.temporary / "wrapper-home"
        home.mkdir()
        environment = dict(self.environment, HOME=str(home))
        before = file_snapshot(home)
        report = self.cli(wrapper=True, environment=environment)
        require(report["status"] == "KEY_NOT_PRESENT", "WRAPPER_DEFAULT_NOT_INSPECT")
        require(file_snapshot(home) == before, "WRAPPER_DEFAULT_CHANGED_FILES")
        directory = self.clone("wrapper-existing")
        before_p12 = (directory / NAMES["p12"]).read_bytes()
        result = self.cli(directory, "--prepare", wrapper=True, environment=environment)
        require(result["status"] == "EXISTING_KEY_REUSED_UNCHANGED", "WRAPPER_ARGUMENTS_NOT_FORWARDED")
        require((directory / NAMES["p12"]).read_bytes() == before_p12, "WRAPPER_CHANGED_KEY")

    def wrapper_prerequisites(self):
        for missing in ("python3", "openssl"):
            executable_directory = self.temporary / ("wrapper-bin-missing-" + missing)
            executable_directory.mkdir()
            for command in ("python3", "openssl"):
                if command != missing:
                    (executable_directory / command).symlink_to(shutil.which(command))
            environment = dict(self.environment, PATH=str(executable_directory))
            before = file_snapshot(self.home)
            result = subprocess.run([shutil.which("bash"), str(WRAPPER)], env=environment,
                                    capture_output=True, timeout=30)
            require(result.returncode == 2, "WRAPPER_MISSING_DEPENDENCY_NOT_STOPPED")
            require(b"pkg install python openssl-tool" in result.stderr, "TERMUX_INSTALL_HELP_MISSING")
            require(not result.stdout, "MISSING_DEPENDENCY_WRAPPER_OUTPUT")
            require(file_snapshot(self.home) == before, "WRAPPER_PREREQUISITE_CHECK_WROTE_FILES")

    def ci_import(self, existing: bool):
        directory = self.temporary / ("legacy-three-secrets" if existing else "new-missing")
        require((directory / NAMES["pin"]).is_file(), "PREPARED_PHONE_FIXTURE_MISSING")
        workspace = self.temporary / ("ci-import-legacy" if existing else "ci-import-new")
        workspace.mkdir()
        environment = dict(self.environment)
        for environment_name, file_key in (("R139_P12_B64", "base64"), ("R139_STOREPASS", "password"),
                                          ("R139_KEYPASS", "key_password"), ("R139_ALIAS", "alias"),
                                          ("R13198_EXPECTED_SIGNER_SHA256", "pin")):
            environment[environment_name] = (directory / NAMES[file_key]).read_text().rstrip("\r\n")
        result = subprocess.run([sys.executable, str(self.ci_importer), "--workspace", str(workspace)],
                                env=environment, capture_output=True, timeout=120)
        for value in self.private_values:
            require(value not in result.stdout + result.stderr, "CI_IMPORT_LEAKED_PRIVATE_VALUE")
        require(result.returncode == 0, "CI_IMPORT_DID_NOT_ACCEPT_PHONE_EXPORTS")
        require(not result.stderr, "CI_IMPORT_UNEXPECTED_STDERR")
        proof = json.loads(result.stdout)
        require(proof["status"] == "PASS" and proof["signing_mode"] == "STABLE_SECRET", "CI_IMPORT_NOT_STABLE")
        for flag in ("private_key_verified", "store_password_verified", "key_password_verified",
                     "alias_is_private_key_entry", "python_properties_roundtrip", "java_properties_roundtrip"):
            require(proof[flag] is True, "CI_IMPORT_PROOF_MISSING:" + flag)
        require((workspace / "magisk/r6-ci-only.p12").read_bytes() == (directory / NAMES["p12"]).read_bytes(),
                "CI_IMPORT_CHANGED_PHONE_KEYSTORE")
        require((workspace / "reports/R139_SIGNING_MODE.txt").read_text().strip() == "STABLE_SECRET",
                "CI_IMPORT_DID_NOT_EXPORT_STABLE_MODE")
        require(proof["signer_sha256"] == environment["R13198_EXPECTED_SIGNER_SHA256"],
                "CI_IMPORT_CHANGED_SIGNING_IDENTITY")

    def run(self):
        cases = [
            ("default_inspect_missing_read_only_exact_legacy_path", self.missing_inspect),
            ("inspect_existing_legacy_read_only", self.existing_inspect),
            ("new_key_then_repeat_exact_bytes_valid_signature", self.new_repeat),
            ("existing_empty_directory_new_key_then_repeat_exact_bytes", lambda: self.new_repeat(True)),
            ("legacy_three_exports_add_fourth_and_pin_without_rotation", self.legacy_prepare),
            ("wrong_password_preserves_all_material", self.wrong_password),
            ("partial_directory_never_generates_replacement", self.partial_directory),
            ("missing_password_preserves_p12", self.missing_password),
            ("wrong_alias_file_no_overwrite", self.wrong_alias),
            ("wrong_saved_certificate_pin_no_repin", self.wrong_pin),
            ("malformed_saved_pin_no_repin", lambda: self.wrong_pin(True)),
            ("separate_key_password_preserved_for_ci_validation", self.distinct_key_password),
            ("malformed_pkcs12_preserved", self.invalid_p12),
            ("certificate_only_pkcs12_rejected", self.no_private_key),
            ("missing_pkcs12_alias_rejected", self.missing_alias_in_p12),
            ("backslash_password_not_silently_reencoded", lambda: self.bad_password_representation("bad\\pass.1287", "slash")),
            ("unicode_password_not_silently_reencoded", lambda: self.bad_password_representation("bädpass.1287", "unicode")),
            ("boundary_whitespace_password_not_trimmed", lambda: self.bad_password_representation(" badpass.1287", "space")),
            ("directory_symlink_no_private_output", self.symlink_directory),
            ("ancestor_symlink_no_private_output", lambda: self.symlink_directory(True)),
            ("keystore_symlink_rejected", lambda: self.symlink_file("p12")),
            ("password_symlink_rejected", lambda: self.symlink_file("password")),
            ("export_destination_symlink_rejected", lambda: self.symlink_file("base64")),
            ("public_pin_destination_symlink_rejected", lambda: self.symlink_file("pin")),
            ("external_hardlink_rejected", self.hardlink_file),
            ("shared_storage_paths_blocked_before_writes", self.shared_storage),
            ("non_regular_secret_file_rejected_without_blocking", self.non_regular_file),
            ("inspect_keeps_permissions_prepare_sets_private_modes", self.permissions),
            ("future_certificate_rejected_without_rotation", lambda: self.certificate_time(True)),
            ("expired_certificate_rejected_without_rotation", lambda: self.certificate_time(False)),
            ("standalone_wrapper_exact_source_read_only_default_and_forwarding", self.wrapper),
            ("wrapper_missing_dependencies_stop_with_termux_install_help", self.wrapper_prerequisites),
        ]
        if self.ci_importer is not None:
            cases += [
                ("legacy_phone_exports_real_java_ci_import_same_identity", lambda: self.ci_import(True)),
                ("new_phone_exports_real_java_ci_import_same_identity", lambda: self.ci_import(False)),
            ]
        for name, check in cases:
            self.record(name, check)
        return self.results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, default=Path(__file__).with_name("R13198_PHONE_SETUP_TEST_RESULTS.json"))
    parser.add_argument("--ci-importer", type=Path,
                        help="Also validate phone exports with this real R13198 CI importer (requires Java)")
    options = parser.parse_args()
    original_umask = os.umask(0o077)
    try:
        with tempfile.TemporaryDirectory(prefix="r13198-phone-tests-") as temporary:
            fixture_root = Path(temporary)
            results = Suite(fixture_root, options.ci_importer.resolve() if options.ci_importer else None).run()
        require(not fixture_root.exists(), "TEMPORARY_PRIVATE_FIXTURES_NOT_CLEANED")
    finally:
        os.umask(original_umask)
    report = {
        "schema": "r13198.phone-signing-setup.tests.v1",
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version.split()[0],
        "openssl_version": tool(["openssl", "version"]).decode().strip(),
        "helper_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
        "wrapper_sha256": hashlib.sha256(WRAPPER.read_bytes()).hexdigest(),
        "ci_importer_sha256": hashlib.sha256(options.ci_importer.read_bytes()).hexdigest() if options.ci_importer else None,
        "tests_total": len(results),
        "tests_passed": sum(item["status"] == "PASS" for item in results),
        "tests_failed": sum(item["status"] != "PASS" for item in results),
        "test_method": "Real OpenSSL PKCS12 import/export, key/certificate checks and RSA sign/verify; real subprocess CLI and Bash wrapper; no cryptographic mocks.",
        "temporary_private_fixtures_removed": True,
        "project_signing_key_created": False,
        "real_phone_installation_performed": False,
        "results": results,
    }
    options.report.parent.mkdir(parents=True, exist_ok=True)
    options.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("tests_total", "tests_passed", "tests_failed", "temporary_private_fixtures_removed")}))
    return 1 if report["tests_failed"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
