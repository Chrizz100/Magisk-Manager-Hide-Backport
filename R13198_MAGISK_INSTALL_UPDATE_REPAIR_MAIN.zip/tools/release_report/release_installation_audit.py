#!/usr/bin/env python3
"""Bind release identity to an independently executed Android install/update test.

This report never turns a historical certificate/native comparison or an
emulator result into a physical-phone result. APK inspection uses SDK tools;
merge_runtime() is a pure JSON operation for the final workflow aggregate.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import zipfile


IDENTITY_SCHEMA = "r13198.installation-identity-v1"
RUNTIME_SCHEMA = "r13198.install-update-v1"
PACKAGE_NAME = "com.topjohnwu.magisk"
VERSION_CODE = 31100
STABLE_MODE = "STABLE_SECRET"
ABI_ASSETS = {
    "arm64-v8a": ("r139_expected_arm64_magisk.sha256", 183),
    "armeabi-v7a": ("r139_expected_armeabi_v7a_magisk.sha256", 40),
    "x86_64": ("r139_expected_x86_64_magisk.sha256", 62),
    "x86": ("r139_expected_x86_magisk.sha256", 3),
}
HISTORICAL_REFERENCE = {
    "name": "Historical R13.4 certificate and last recorded phone daemon",
    "certificate_sha256": "972781bce7cb9de02651d121e89acd6e3ac6e6f2c9cf519462ff8c586192de69",
    "arm64_daemon_sha256": "2022c38a4e4afd88bd2517782a8694d5dacf0691d721459af369fa796b17153e",
    "current_device_measurement": False,
}


def _object(value):
    return value if isinstance(value, dict) else {}


def fingerprint(value):
    if not isinstance(value, str):
        return None
    value = value.strip()
    if re.fullmatch(r"(?:[0-9a-fA-F]{2}:){31}[0-9a-fA-F]{2}", value):
        value = value.replace(":", "")
    return value.lower() if re.fullmatch(r"[0-9a-fA-F]{64}", value) else None


def parse_signer_output(text, returncode=0):
    certs = re.findall(
        r"(?im)^\s*(?:(?:V2\s+)?Signer:\s+certificate|Signer\s*#\s*\d+\s+certificate)"
        r"\s+SHA-256\s+digest:\s*([0-9a-fA-F]{64})\s*$", text
    )
    counts = re.findall(r"(?im)^\s*Number of signers:\s*(\d+)\s*$", text)
    return {
        "verified": returncode == 0,
        "v2_verified": "Verified using v2 scheme (APK Signature Scheme v2): true" in text,
        "certificate_sha256s": sorted({c.lower() for c in certs}),
        "signer_count": int(counts[0]) if len(counts) == 1 else None,
    }


def parse_badging(text):
    packages = re.findall(r"(?m)^package:\s*(.*)$", text)
    if len(packages) != 1:
        raise ValueError("APK_PACKAGE_LINE_MISSING_OR_AMBIGUOUS")
    attrs = dict(re.findall(r"([A-Za-z][A-Za-z0-9_]*)='([^']*)'", packages[0]))
    version = attrs.get("versionCode", "")
    mins = re.findall(r"(?m)^(?:minSdkVersion|sdkVersion):'([0-9]+)'\s*$", text)
    targets = re.findall(r"(?m)^targetSdkVersion:'([0-9]+)'\s*$", text)
    return {
        "package_name": attrs.get("name"),
        "version_code": int(version) if version.isdigit() else None,
        "version_name": attrs.get("versionName"),
        "min_sdk": int(mins[0]) if len(mins) == 1 else None,
        "target_sdk": int(targets[0]) if len(targets) == 1 else None,
    }


def sdk_tool(name, explicit=None):
    if explicit:
        path = Path(explicit)
        if not path.is_file():
            raise ValueError("SDK_TOOL_NOT_FOUND_" + name.upper())
        return str(path)
    candidates = []
    for key in ("ANDROID_HOME", "ANDROID_SDK_ROOT"):
        if os.environ.get(key):
            candidates.extend(Path(os.environ[key]).glob("build-tools/*/" + name))
    if candidates:
        def version(path):
            return tuple(int(x) for x in re.findall(r"\d+", path.parent.name))
        return str(max(candidates, key=version))
    found = shutil.which(name)
    if found:
        return found
    raise ValueError("SDK_TOOL_NOT_FOUND_" + name.upper())


def inspect_apk(path, apksigner, aapt2):
    path = Path(path)
    if not path.is_file():
        raise ValueError("APK_NOT_FOUND")
    data = path.read_bytes()
    signer = subprocess.run(
        [apksigner, "verify", "--verbose", "--print-certs", str(path)],
        text=True, capture_output=True, timeout=120, check=False,
    )
    badging = subprocess.run(
        [aapt2, "dump", "badging", str(path)],
        text=True, capture_output=True, timeout=120, check=False,
    )
    facts = {
        "sha256": hashlib.sha256(data).hexdigest(),
        "bytes": len(data),
        "signature": parse_signer_output(signer.stdout, signer.returncode),
        "manifest": parse_badging(badging.stdout) if badging.returncode == 0 else {},
        "tool_exit_codes": {"apksigner": signer.returncode, "aapt2": badging.returncode},
        "native": {},
        "archive_errors": [],
    }
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        facts["zip_crc_valid"] = archive.testzip() is None
        if names.count("AndroidManifest.xml") == 1:
            facts["manifest_sha256"] = hashlib.sha256(archive.read("AndroidManifest.xml")).hexdigest()
        else:
            facts["archive_errors"].append("ANDROID_MANIFEST_MISSING_OR_DUPLICATED")
        for abi, (asset, machine) in ABI_ASSETS.items():
            native_name = "lib/" + abi + "/libmagisk.so"
            asset_name = "assets/" + asset
            if names.count(native_name) != 1 or names.count(asset_name) != 1:
                facts["archive_errors"].append("NATIVE_OR_BINDING_ASSET_MISSING_OR_DUPLICATED_" + abi)
                continue
            binary = archive.read(native_name)
            expected = fingerprint(archive.read(asset_name).decode("ascii").strip())
            elf = len(binary) >= 20 and binary[:4] == b"\x7fELF" and binary[5] == 1
            actual_machine = struct.unpack_from("<H", binary, 18)[0] if elf else None
            facts["native"][abi] = {
                "sha256": hashlib.sha256(binary).hexdigest(),
                "expected_asset_sha256": expected,
                "elf_machine": actual_machine,
                "expected_elf_machine": machine,
            }
    return facts


def _apk_errors(facts, label, pin):
    errors = []
    prefix = label.upper() + "_"
    if not isinstance(facts, dict):
        errors.append(prefix + "APK_FACTS_NOT_OBJECT")
    facts = _object(facts)
    if fingerprint(facts.get("sha256")) is None or type(facts.get("bytes")) is not int or facts["bytes"] < 1000000:
        errors.append(prefix + "APK_IDENTITY_INVALID")
    signature = _object(facts.get("signature"))
    if signature.get("verified") is not True or signature.get("v2_verified") is not True:
        errors.append(prefix + "APK_SIGNATURE_INVALID")
    certs = signature.get("certificate_sha256s")
    if (type(signature.get("signer_count")) is not int or signature["signer_count"] != 1
            or not isinstance(certs, list) or len(certs) != 1 or fingerprint(certs[0]) is None):
        errors.append(prefix + "SIGNER_MISSING_OR_AMBIGUOUS")
    elif fingerprint(certs[0]) != pin:
        errors.append(prefix + "SIGNER_PIN_MISMATCH")
    manifest = _object(facts.get("manifest"))
    if fingerprint(facts.get("manifest_sha256")) is None:
        errors.append(prefix + "MANIFEST_DIGEST_MISSING")
    if manifest.get("package_name") != PACKAGE_NAME:
        errors.append(prefix + "PACKAGE_NAME_MISMATCH")
    if type(manifest.get("version_code")) is not int or manifest["version_code"] != VERSION_CODE:
        errors.append(prefix + "VERSION_CODE_MISMATCH")
    if manifest.get("min_sdk") != 24 or manifest.get("target_sdk") != 37:
        errors.append(prefix + "SDK_CONTRACT_MISMATCH")
    exits = _object(facts.get("tool_exit_codes"))
    if set(exits) != {"apksigner", "aapt2"} or any(type(code) is not int or code != 0 for code in exits.values()):
        errors.append(prefix + "SDK_INSPECTION_FAILED")
    if facts.get("zip_crc_valid") is not True:
        errors.append(prefix + "APK_ARCHIVE_INVALID")
    archive_errors = facts.get("archive_errors")
    if not isinstance(archive_errors, list):
        errors.append(prefix + "ARCHIVE_ERROR_LIST_INVALID")
    else:
        for error in archive_errors:
            errors.append(prefix + str(error))
    native = _object(facts.get("native"))
    if set(native) != set(ABI_ASSETS):
        errors.append(prefix + "FOUR_ABI_BINDING_MISSING")
    for abi, (_, machine) in ABI_ASSETS.items():
        value = _object(native.get(abi))
        actual = fingerprint(value.get("sha256"))
        if actual is None or actual != fingerprint(value.get("expected_asset_sha256")):
            errors.append(prefix + "NATIVE_ASSET_BINDING_MISMATCH_" + abi)
        if value.get("elf_machine") != machine:
            errors.append(prefix + "NATIVE_ARCHITECTURE_MISMATCH_" + abi)
    return errors


def build_report(release, fixture, signing_mode, expected_signer_sha256, historical_reference=None):
    """Create identity evidence; no Android execution or phone attestation is inferred."""
    pin = fingerprint(expected_signer_sha256)
    history = copy.deepcopy(_object(historical_reference) or HISTORICAL_REFERENCE)
    history["current_device_measurement"] = False
    errors = []
    if signing_mode != STABLE_MODE:
        errors.append("PERSISTENT_SIGNING_REQUIRED_NO_EPHEMERAL_RELEASE")
    if pin is None:
        errors.append("EXPECTED_SIGNER_PIN_INVALID_OR_MISSING")
    errors.extend(_apk_errors(release, "release", pin))
    errors.extend(_apk_errors(fixture, "fixture", pin))
    release = _object(release)
    fixture = _object(fixture)
    if release.get("sha256") == fixture.get("sha256"):
        errors.append("UPDATE_FIXTURE_MUST_DIFFER_FROM_RELEASE")
    if (release.get("manifest") != fixture.get("manifest")
            or release.get("manifest_sha256") != fixture.get("manifest_sha256")):
        errors.append("UPDATE_FIXTURE_MANIFEST_MUST_MATCH_RELEASE")
    if release.get("native") != fixture.get("native"):
        errors.append("UPDATE_FIXTURE_NATIVE_BINDING_MUST_MATCH_RELEASE")
    certs = _object(release.get("signature")).get("certificate_sha256s")
    cert = fingerprint(certs[0]) if isinstance(certs, list) and len(certs) == 1 else None
    native_hashes = {abi: fingerprint(_object(value).get("sha256"))
                     for abi, value in _object(release.get("native")).items()}
    arm64 = native_hashes.get("arm64-v8a")
    valid = not errors
    return {
        "schema": IDENTITY_SCHEMA,
        "revision": "R13.19.8",
        "status": "IDENTITY_VERIFIED_RUNTIME_PENDING" if valid else "IDENTITY_REJECTED",
        "identity_valid": valid,
        "apk_sha256": release.get("sha256"),
        "fixture_apk_sha256": fixture.get("sha256"),
        "signer_sha256": cert,
        "native_arm64_sha256": arm64,
        "abi_count": len(native_hashes),
        "signing_mode": signing_mode if signing_mode in (STABLE_MODE, "EPHEMERAL_RESEARCH_ONLY") else "UNRECOGNIZED",
        "expected_signer_sha256": pin,
        "apks": {"release": copy.deepcopy(release), "fixture": copy.deepcopy(fixture)},
        "signing_continuity": {
            "status": "PINNED_IDENTITY_VERIFIED" if valid else "REJECTED",
            "future_builds_require_same_private_key_and_pin": True,
            "current_phone_signing_identity": "UNKNOWN",
            "previous_historical_key_recovered": "NOT_ESTABLISHED_BY_THIS_CHECK",
        },
        "android_installation": {
            "runtime_status": "PENDING",
            "fresh_install": {"status": "PENDING"},
            "update_in_place": {"status": "PENDING"},
            "normal_manager_only": True,
            "synthetic_fixture_not_a_historical_release": True,
        },
        "backend_compatibility": {
            "app_requirement": "EXACT_RUNNING_NATIVE_SHA256_FOR_CURRENT_ABI",
            "expected_native_sha256": native_hashes,
            "native_manager_certificate_and_owner_checks": "UNCHANGED",
            "physical_phone_backend": "UNKNOWN",
            "root_hide_restore_gate": "SEPARATE_REQUIRED_JOB",
        },
        "historical_reference": history,
        "r134_signer_sha256": history.get("certificate_sha256"),
        "last_measured_phone_magiskd_sha256": history.get("arm64_daemon_sha256"),
        "signer_matches_historical_r134": cert is not None and cert == fingerprint(history.get("certificate_sha256")),
        "native_matches_last_phone_measurement": arm64 is not None and arm64 == fingerprint(history.get("arm64_daemon_sha256")),
        "phone_in_place_update": "UNKNOWN",
        "phone_device_release": "NOT_ATTESTED",
        "physical_device_tested": False,
        "blocking_reasons": errors,
        "unverified_conditions": ["CURRENT_PHONE_CERTIFICATE_AND_RUNNING_CORE", "PHYSICAL_PHONE_INSTALLATION_AND_HIDE_RESTORE"],
        "supported_update_flow": "RESTORE_TO_ORIGINAL_MANAGER_THEN_MANUAL_PROJECT_APK_UPDATE_THEN_REHIDE",
        "update_while_hidden": "NOT_COVERED_RESTORE_FIRST_REQUIRED",
        "in_app_upstream_updater": "UNCHANGED_NOT_VERIFIED_FOR_PROJECT_RELEASES",
        "complete_ci_pass": "NOT_DECIDED_BY_THIS_REPORT",
    }


def merge_runtime(identity_report, runtime_contract, require_runtime=True):
    """Revalidate identity structure and bind a runtime contract without SDK/ADB calls."""
    identity_report = _object(identity_report)
    facts = _object(identity_report.get("apks"))
    merged = build_report(
        facts.get("release", {}), facts.get("fixture", {}),
        identity_report.get("signing_mode"), identity_report.get("expected_signer_sha256"),
        identity_report.get("historical_reference"),
    )
    identity_errors = merged["blocking_reasons"]
    if identity_report.get("schema") != IDENTITY_SCHEMA:
        identity_errors.append("IDENTITY_SCHEMA_MISMATCH")
    if identity_report.get("identity_valid") is not True:
        identity_errors.append("IDENTITY_REPORT_NOT_VERIFIED")
    for field in ("apk_sha256", "fixture_apk_sha256", "signer_sha256"):
        if identity_report.get(field) != merged[field]:
            identity_errors.append("IDENTITY_TOP_LEVEL_BINDING_MISMATCH_" + field.upper())
    merged["identity_valid"] = not identity_errors
    if identity_errors:
        merged["signing_continuity"]["status"] = "REJECTED"
    runtime_errors = []
    if runtime_contract is None:
        if require_runtime:
            runtime_errors.append("INSTALL_UPDATE_RUNTIME_CONTRACT_MISSING")
    elif not isinstance(runtime_contract, dict):
        runtime_errors.append("INSTALL_UPDATE_RUNTIME_CONTRACT_NOT_OBJECT")
    else:
        if runtime_contract.get("schema") != RUNTIME_SCHEMA:
            runtime_errors.append("INSTALL_UPDATE_RUNTIME_SCHEMA_MISMATCH")
        if runtime_contract.get("status") != "PASS":
            runtime_errors.append("INSTALL_UPDATE_RUNTIME_NOT_PASS")
        if runtime_contract.get("physical_device_tested") is not False:
            runtime_errors.append("INSTALL_UPDATE_SCOPE_MUST_BE_EMULATOR")
        if runtime_contract.get("normal_manager_only") is not True:
            runtime_errors.append("INSTALL_UPDATE_NORMAL_MANAGER_SCOPE_REQUIRED")
        for field in ("apk_sha256", "fixture_apk_sha256", "signer_sha256"):
            if runtime_contract.get(field) != merged[field]:
                runtime_errors.append("INSTALL_UPDATE_BINDING_MISMATCH_" + field.upper())
        fresh = runtime_contract.get("fresh_install")
        update = runtime_contract.get("update_in_place")
        fresh = fresh if isinstance(fresh, dict) else {}
        update = update if isinstance(update, dict) else {}
        for key in ("passed", "was_absent"):
            if fresh.get(key) is not True:
                runtime_errors.append("FRESH_INSTALL_" + key.upper() + "_REQUIRED")
        if fresh.get("installed_apk_sha256") != merged["fixture_apk_sha256"]:
            runtime_errors.append("FRESH_INSTALL_APK_HASH_MISMATCH")
        for key in ("passed", "same_uid", "data_preserved", "without_uninstall"):
            if update.get(key) is not True:
                runtime_errors.append("UPDATE_IN_PLACE_" + key.upper() + "_REQUIRED")
        if update.get("installed_apk_sha256") != merged["apk_sha256"]:
            runtime_errors.append("UPDATE_IN_PLACE_APK_HASH_MISMATCH")
        uids = [fresh.get("uid"), update.get("uid_before"), update.get("uid_after")]
        if not all(type(uid) is int and uid >= 10000 for uid in uids) or len(set(map(str, uids))) != 1:
            runtime_errors.append("UPDATE_IN_PLACE_ACTUAL_UIDS_MISSING_OR_CHANGED")
        merged["android_installation"]["fresh_install"] = copy.deepcopy(fresh)
        merged["android_installation"]["update_in_place"] = copy.deepcopy(update)
    passed = merged["identity_valid"] and runtime_contract is not None and not runtime_errors
    pending = merged["identity_valid"] and runtime_contract is None and not require_runtime
    merged["android_installation"]["runtime_status"] = "PASS" if passed else "PENDING" if pending else "FAIL"
    merged["runtime_contract_valid"] = passed
    merged["runtime_errors"] = runtime_errors
    merged["blocking_reasons"] = identity_errors + runtime_errors
    merged["status"] = (
        "INSTALLATION_CONTRACT_VERIFIED_PHONE_UNATTESTED" if passed
        else "IDENTITY_VERIFIED_RUNTIME_PENDING" if pending
        else "INSTALLATION_CONTRACT_REJECTED"
    )
    return merged


def write_report(path, report):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", dir=path.parent, delete=False) as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
        temporary = Path(stream.name)
    temporary.replace(path)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    inspect = commands.add_parser("inspect", help="Inspect release and synthetic update fixture APKs")
    inspect.add_argument("--apk", required=True)
    inspect.add_argument("--fixture-apk", required=True)
    inspect.add_argument("--signing-mode-file", required=True)
    inspect.add_argument("--expected-signer-sha256", required=True)
    inspect.add_argument("--apksigner")
    inspect.add_argument("--aapt2")
    inspect.add_argument("--output", required=True)
    inspect.add_argument("--identity-output", required=True)
    merge = commands.add_parser("merge", help="Validate a runtime JSON against the build identity; no SDK/ADB")
    merge.add_argument("--identity-input", required=True)
    merge.add_argument("--runtime-contract", required=True)
    merge.add_argument("--output", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "inspect":
            signer = sdk_tool("apksigner", args.apksigner)
            aapt = sdk_tool("aapt2", args.aapt2)
            release = inspect_apk(args.apk, signer, aapt)
            fixture = inspect_apk(args.fixture_apk, signer, aapt)
            mode = Path(args.signing_mode_file).read_text().strip()
            report = build_report(release, fixture, mode, args.expected_signer_sha256)
            write_report(args.output, report)
            write_report(args.identity_output, report)
            ok = report["identity_valid"]
        else:
            identity = json.loads(Path(args.identity_input).read_text())
            runtime_path = Path(args.runtime_contract)
            runtime = json.loads(runtime_path.read_text()) if runtime_path.is_file() else None
            report = merge_runtime(identity, runtime, require_runtime=True)
            write_report(args.output, report)
            ok = report["runtime_contract_valid"]
    except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile, subprocess.SubprocessError) as exc:
        report = {
            "schema": IDENTITY_SCHEMA, "revision": "R13.19.8", "status": "INSPECTION_FAILED",
            "identity_valid": False, "runtime_contract_valid": False,
            "phone_in_place_update": "UNKNOWN", "phone_device_release": "NOT_ATTESTED",
            "physical_device_tested": False, "blocking_reasons": [type(exc).__name__ + ": " + str(exc)],
        }
        write_report(args.output, report)
        if args.command == "inspect":
            write_report(args.identity_output, report)
        ok = False
    print(json.dumps({"status": report["status"], "blocking_reasons": report["blocking_reasons"]}))
    return 0 if ok else 2


if __name__ == "__main__":
    raise SystemExit(main())
