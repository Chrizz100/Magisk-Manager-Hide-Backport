"""Focused tests for release decisions, not a replacement for Android execution."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import release_installation_audit as audit


CERT = "c" * 64
RELEASE = "a" * 64
FIXTURE = "b" * 64


def apk_facts(apk_hash, cert=CERT):
    return {
        "sha256": apk_hash, "bytes": 12345678,
        "signature": {"verified": True, "v2_verified": True,
                      "certificate_sha256s": [cert], "signer_count": 1},
        "manifest": {"package_name": "com.topjohnwu.magisk", "version_code": 31100,
                     "version_name": "R13.19.8", "min_sdk": 24, "target_sdk": 37},
        "manifest_sha256": "5" * 64,
        "tool_exit_codes": {"apksigner": 0, "aapt2": 0},
        "native": {abi: {"sha256": f"{i}" * 64, "expected_asset_sha256": f"{i}" * 64,
                         "elf_machine": machine, "expected_elf_machine": machine}
                   for i, (abi, (_, machine)) in enumerate(audit.ABI_ASSETS.items(), 1)},
        "archive_errors": [], "zip_crc_valid": True,
    }


def identity():
    return audit.build_report(apk_facts(RELEASE), apk_facts(FIXTURE), "STABLE_SECRET", CERT)


def contract():
    return {
        "schema": audit.RUNTIME_SCHEMA, "status": "PASS",
        "apk_sha256": RELEASE, "fixture_apk_sha256": FIXTURE, "signer_sha256": CERT,
        "physical_device_tested": False, "normal_manager_only": True,
        "fresh_install": {"passed": True, "was_absent": True,
                          "installed_apk_sha256": FIXTURE, "uid": 10123},
        "update_in_place": {"passed": True, "installed_apk_sha256": RELEASE,
                            "same_uid": True, "data_preserved": True, "without_uninstall": True,
                            "uid_before": 10123, "uid_after": 10123},
    }


class ReleaseIdentityTests(unittest.TestCase):
    def test_stable_pinned_identity_is_pending_not_phone_pass(self):
        result = identity()
        self.assertTrue(result["identity_valid"])
        self.assertEqual(result["status"], "IDENTITY_VERIFIED_RUNTIME_PENDING")
        self.assertEqual(result["android_installation"]["runtime_status"], "PENDING")
        self.assertEqual(result["phone_in_place_update"], "UNKNOWN")
        self.assertEqual(result["phone_device_release"], "NOT_ATTESTED")
        self.assertFalse(result["physical_device_tested"])
        self.assertEqual(result["backend_compatibility"]["app_requirement"],
                         "EXACT_RUNNING_NATIVE_SHA256_FOR_CURRENT_ABI")

    def test_ephemeral_key_is_rejected_even_when_pin_matches(self):
        result = audit.build_report(apk_facts(RELEASE), apk_facts(FIXTURE), "EPHEMERAL_RESEARCH_ONLY", CERT)
        self.assertFalse(result["identity_valid"])
        self.assertIn("PERSISTENT_SIGNING_REQUIRED_NO_EPHEMERAL_RELEASE", result["blocking_reasons"])

    def test_pin_is_required_and_must_match(self):
        for pin in (None, "", "bad", "d" * 64):
            with self.subTest(pin=pin):
                self.assertFalse(audit.build_report(apk_facts(RELEASE), apk_facts(FIXTURE),
                                                    "STABLE_SECRET", pin)["identity_valid"])

    def test_real_apk_identity_requirements_are_fail_closed(self):
        changes = [
            ("signature", "verified", False), ("signature", "v2_verified", False),
            ("signature", "signer_count", 2), ("signature", "signer_count", True),
            ("signature", "certificate_sha256s", []),
            ("signature", "certificate_sha256s", ["d" * 64]),
            ("manifest", "package_name", "different.package"),
            ("manifest", "version_code", 31101), ("manifest", "min_sdk", 23),
            ("manifest", "target_sdk", 36), ("tool_exit_codes", "aapt2", 1),
            ("tool_exit_codes", "apksigner", False),
        ]
        for parent, key, value in changes:
            with self.subTest(parent=parent, key=key, value=value):
                release = apk_facts(RELEASE)
                release[parent][key] = value
                self.assertFalse(audit.build_report(release, apk_facts(FIXTURE), "STABLE_SECRET", CERT)["identity_valid"])

    def test_native_binding_and_architecture_are_required(self):
        for field, value in (("sha256", "e" * 64), ("expected_asset_sha256", None), ("elf_machine", 40)):
            with self.subTest(field=field):
                release = apk_facts(RELEASE)
                release["native"]["arm64-v8a"][field] = value
                self.assertFalse(audit.build_report(release, apk_facts(FIXTURE), "STABLE_SECRET", CERT)["identity_valid"])

    def test_fixture_must_be_distinct_with_same_manifest_and_native_payload(self):
        cases = [apk_facts(RELEASE), apk_facts(FIXTURE), apk_facts(FIXTURE), apk_facts(FIXTURE)]
        cases[1]["manifest"]["version_name"] = "different-version"
        cases[2]["native"]["arm64-v8a"]["sha256"] = "e" * 64
        cases[2]["native"]["arm64-v8a"]["expected_asset_sha256"] = "e" * 64
        cases[3]["manifest_sha256"] = "6" * 64
        for fixture in cases:
            with self.subTest(fixture=fixture["sha256"]):
                self.assertFalse(audit.build_report(apk_facts(RELEASE), fixture, "STABLE_SECRET", CERT)["identity_valid"])

    def test_historical_matches_alone_never_pass_the_phone(self):
        cert = audit.HISTORICAL_REFERENCE["certificate_sha256"]
        native = audit.HISTORICAL_REFERENCE["arm64_daemon_sha256"]
        release, fixture = apk_facts(RELEASE, cert), apk_facts(FIXTURE, cert)
        for facts in (release, fixture):
            facts["native"]["arm64-v8a"].update(sha256=native, expected_asset_sha256=native)
        result = audit.build_report(release, fixture, "STABLE_SECRET", cert)
        self.assertTrue(result["signer_matches_historical_r134"])
        self.assertTrue(result["native_matches_last_phone_measurement"])
        self.assertEqual(result["phone_in_place_update"], "UNKNOWN")
        self.assertEqual(result["phone_device_release"], "NOT_ATTESTED")
        self.assertEqual(result["android_installation"]["runtime_status"], "PENDING")
        self.assertNotEqual(result["status"], "PASS")

    def test_malformed_json_facts_reject_without_crashing(self):
        cases = [None, [], "bad", {}]
        for field in ("signature", "manifest", "native", "archive_errors", "tool_exit_codes"):
            for value in (None, 5, "bad"):
                facts = apk_facts(RELEASE)
                facts[field] = value
                cases.append(facts)
        for value in (None, True, "c" * 64, [None], {"0": CERT}):
            facts = apk_facts(RELEASE)
            facts["signature"]["certificate_sha256s"] = value
            cases.append(facts)
        for facts in cases:
            with self.subTest(facts=facts):
                self.assertFalse(audit.build_report(facts, apk_facts(FIXTURE), "STABLE_SECRET", CERT)["identity_valid"])


class RuntimeMergeTests(unittest.TestCase):
    def test_real_contract_pass_is_only_emulator_installation(self):
        with patch.object(audit.subprocess, "run", side_effect=AssertionError("SDK/ADB forbidden in merge")):
            result = audit.merge_runtime(identity(), contract())
        self.assertTrue(result["runtime_contract_valid"])
        self.assertEqual(result["status"], "INSTALLATION_CONTRACT_VERIFIED_PHONE_UNATTESTED")
        self.assertEqual(result["android_installation"]["runtime_status"], "PASS")
        self.assertEqual(result["phone_in_place_update"], "UNKNOWN")
        self.assertFalse(result["physical_device_tested"])
        self.assertEqual(result["complete_ci_pass"], "NOT_DECIDED_BY_THIS_REPORT")

    def test_missing_contract_is_pending_only_before_runtime_gate(self):
        self.assertEqual(audit.merge_runtime(identity(), None, require_runtime=False)
                         ["android_installation"]["runtime_status"], "PENDING")
        result = audit.merge_runtime(identity(), None)
        self.assertFalse(result["runtime_contract_valid"])
        self.assertIn("INSTALL_UPDATE_RUNTIME_CONTRACT_MISSING", result["blocking_reasons"])
        self.assertEqual(result["android_installation"]["runtime_status"], "FAIL")

    def test_runtime_top_level_bindings_scope_and_schema_are_required(self):
        for field, value in (
            ("schema", "old"), ("status", "PENDING"), ("apk_sha256", FIXTURE),
            ("fixture_apk_sha256", RELEASE), ("signer_sha256", "d" * 64),
            ("physical_device_tested", True), ("physical_device_tested", "false"),
            ("normal_manager_only", False), ("normal_manager_only", "true"),
        ):
            with self.subTest(field=field, value=value):
                runtime = contract()
                runtime[field] = value
                self.assertFalse(audit.merge_runtime(identity(), runtime)["runtime_contract_valid"])

    def test_fresh_install_requires_absence_fixture_hash_and_actual_uid(self):
        for field, value in (("passed", False), ("passed", "true"), ("was_absent", False),
                             ("was_absent", 1), ("installed_apk_sha256", RELEASE),
                             ("uid", 10124), ("uid", None), ("uid", True)):
            with self.subTest(field=field, value=value):
                runtime = contract()
                runtime["fresh_install"][field] = value
                self.assertFalse(audit.merge_runtime(identity(), runtime)["runtime_contract_valid"])

    def test_update_requires_no_uninstall_same_uid_data_and_exact_final_apk(self):
        for field, value in (("passed", False), ("same_uid", "true"), ("data_preserved", False),
                             ("without_uninstall", False), ("installed_apk_sha256", FIXTURE),
                             ("uid_before", 1000), ("uid_after", 10124), ("uid_after", "10123")):
            with self.subTest(field=field, value=value):
                runtime = contract()
                runtime["update_in_place"][field] = value
                self.assertFalse(audit.merge_runtime(identity(), runtime)["runtime_contract_valid"])

    def test_report_tampering_is_rejected_and_phone_claim_is_reset(self):
        for field, value in (("schema", "old"), ("identity_valid", "true"),
                             ("apk_sha256", FIXTURE), ("fixture_apk_sha256", RELEASE),
                             ("signer_sha256", "d" * 64)):
            with self.subTest(field=field):
                report = identity()
                report[field] = value
                result = audit.merge_runtime(report, contract())
                self.assertFalse(result["runtime_contract_valid"])
                self.assertEqual(result["signing_continuity"]["status"], "REJECTED")
        report = identity()
        report.update(phone_in_place_update="PASS", phone_device_release="PASS", physical_device_tested=True)
        result = audit.merge_runtime(report, contract())
        self.assertEqual(result["phone_in_place_update"], "UNKNOWN")
        self.assertEqual(result["phone_device_release"], "NOT_ATTESTED")
        self.assertFalse(result["physical_device_tested"])

    def test_malformed_contract_and_identity_fail_closed(self):
        for runtime in ([], "PASS", 1, {}, {"fresh_install": [], "update_in_place": 1}):
            with self.subTest(runtime=runtime):
                self.assertFalse(audit.merge_runtime(identity(), runtime)["runtime_contract_valid"])
        for report in (None, [], "PASS", {}, {"apks": None}):
            with self.subTest(report=report):
                self.assertFalse(audit.merge_runtime(report, contract())["runtime_contract_valid"])

    def test_cli_missing_runtime_exits_nonzero_and_writes_explanation(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "identity.json").write_text(json.dumps(identity()))
            code = audit.main(["merge", "--identity-input", str(root / "identity.json"),
                               "--runtime-contract", str(root / "absent.json"),
                               "--output", str(root / "merged.json")])
            self.assertEqual(code, 2)
            self.assertIn("INSTALL_UPDATE_RUNTIME_CONTRACT_MISSING",
                          json.loads((root / "merged.json").read_text())["blocking_reasons"])


class SdkParserTests(unittest.TestCase):
    def test_supported_apksigner_formats_parse_one_verified_identity(self):
        for prefix in ("V2 Signer: certificate", "Signer: certificate", "Signer #1 certificate"):
            with self.subTest(prefix=prefix):
                output = ("Verified using v2 scheme (APK Signature Scheme v2): true\n"
                          "Number of signers: 1\n" + prefix + " SHA-256 digest: " + CERT + "\n")
                result = audit.parse_signer_output(output)
                self.assertTrue(result["v2_verified"])
                self.assertEqual(result["certificate_sha256s"], [CERT])
                self.assertEqual(result["signer_count"], 1)

    def test_badging_supports_both_minimum_sdk_names(self):
        for sdk_name in ("sdkVersion", "minSdkVersion"):
            result = audit.parse_badging("package: name='com.topjohnwu.magisk' versionCode='31100' versionName='R13.19.8'\n"
                                         + sdk_name + ":'24'\ntargetSdkVersion:'37'\n")
            self.assertEqual(result["min_sdk"], 24)
            self.assertEqual(result["target_sdk"], 37)
            self.assertEqual(result["version_code"], 31100)

    def test_fingerprint_normalization_requires_exact_digest(self):
        self.assertEqual(audit.fingerprint(":".join(["AB"] * 32)), "ab" * 32)
        for value in (None, "c" * 63, "c" * 65, "sha256:" + CERT, " "):
            self.assertIsNone(audit.fingerprint(value))


if __name__ == "__main__":
    unittest.main(verbosity=2)
