#!/usr/bin/env python3
"""Import one pinned, persistent signing identity. Never generate a release key.

Secrets are read only from the four established R139_* environment variables.
The project signer pin is public configuration in R13198_EXPECTED_SIGNER_SHA256.
No passwords, aliases, keystore bytes or child-tool diagnostics are printed.
"""
from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile


SECRET_NAMES = ("R139_P12_B64", "R139_STOREPASS", "R139_KEYPASS", "R139_ALIAS")
PIN_NAME = "R13198_EXPECTED_SIGNER_SHA256"
ABI_LIST = "arm64-v8a,armeabi-v7a,x86_64,x86"
PREFIX = "R13198_SIGNING_"


class SigningError(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(PREFIX + code)


JAVA_VALIDATOR = r'''import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.Key;
import java.security.KeyStore;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.HexFormat;
import java.util.Properties;

class R13198KeyStoreCheck {
    static final class Rejected extends Exception {
        final String code;
        Rejected(String value) { code = value; }
    }
    static String env(String name) throws Rejected {
        String value = System.getenv(name);
        if (value == null || value.isEmpty()) throw new Rejected("CONFIGURATION_MISSING");
        return value;
    }
    static void require(boolean value, String code) throws Rejected {
        if (!value) throw new Rejected(code);
    }
    static void run(String[] args) throws Exception {
        require(args.length == 3, "VALIDATOR_ARGUMENTS_INVALID");
        String alias = env("R139_ALIAS");
        char[] storePassword = env("R139_STOREPASS").toCharArray();
        char[] keyPassword = env("R139_KEYPASS").toCharArray();
        try {
            // This is the same InputStream parser used by Magisk's Gradle plugin.
            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(Path.of(args[1]))) { props.load(in); }
            require(env("R139_STOREPASS").equals(props.getProperty("keyStorePass")), "JAVA_PROPERTIES_MISMATCH");
            require(env("R139_KEYPASS").equals(props.getProperty("keyPass")), "JAVA_PROPERTIES_MISMATCH");
            require(alias.equals(props.getProperty("keyAlias")), "JAVA_PROPERTIES_MISMATCH");
            require(env("R13198_VALIDATION_KEYSTORE_PATH").equals(props.getProperty("keyStore")), "JAVA_PROPERTIES_MISMATCH");
            require("arm64-v8a,armeabi-v7a,x86_64,x86".equals(props.getProperty("abiList")), "JAVA_PROPERTIES_MISMATCH");

            KeyStore store = KeyStore.getInstance("PKCS12");
            try (InputStream in = Files.newInputStream(Path.of(args[0]))) {
                try { store.load(in, storePassword); }
                catch (Exception ignored) { throw new Rejected("STORE_PASSWORD_OR_CONTAINER_INVALID"); }
            }
            require(store.containsAlias(alias) && store.isKeyEntry(alias), "ALIAS_NOT_PRIVATE_KEY");
            Key key;
            try { key = store.getKey(alias, keyPassword); }
            catch (Exception ignored) { throw new Rejected("KEY_PASSWORD_INVALID"); }
            require(key instanceof PrivateKey, "ALIAS_NOT_PRIVATE_KEY");
            require(store.getCertificate(alias) instanceof X509Certificate, "CERTIFICATE_INVALID");
            X509Certificate cert = (X509Certificate) store.getCertificate(alias);
            try { cert.checkValidity(); }
            catch (Exception ignored) { throw new Rejected("CERTIFICATE_NOT_CURRENTLY_VALID"); }
            byte[] der = cert.getEncoded();
            String digest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(der));
            require(digest.equals(env("R13198_EXPECTED_SIGNER_SHA256")), "SIGNER_PIN_MISMATCH");

            String algorithm;
            String keyKind;
            switch (key.getAlgorithm()) {
                case "RSA": algorithm = "SHA256withRSA"; keyKind = "RSA"; break;
                case "EC": algorithm = "SHA256withECDSA"; keyKind = "EC"; break;
                case "DSA": algorithm = "SHA256withDSA"; keyKind = "DSA"; break;
                default: throw new Rejected("KEY_ALGORITHM_UNSUPPORTED");
            }
            // Prove the private key is usable and corresponds to the pinned public cert.
            byte[] challenge = new byte[32];
            new SecureRandom().nextBytes(challenge);
            Signature proof = Signature.getInstance(algorithm);
            proof.initSign((PrivateKey) key);
            proof.update(challenge);
            byte[] signature = proof.sign();
            proof.initVerify(cert.getPublicKey());
            proof.update(challenge);
            require(proof.verify(signature), "PRIVATE_KEY_CERTIFICATE_MISMATCH");
            Files.write(Path.of(args[2]), der);
            System.out.println("{\"status\":\"PASS\",\"signer_sha256\":\"" + digest
                + "\",\"key_algorithm\":\"" + keyKind
                + "\",\"private_key_verified\":true,\"certificate_valid\":true,"
                + "\"java_properties_roundtrip\":true}");
        } finally {
            Arrays.fill(storePassword, '\0');
            Arrays.fill(keyPassword, '\0');
        }
    }
    public static void main(String[] args) {
        try { run(args); }
        catch (Rejected failure) { System.err.println("R13198_SIGNING_" + failure.code); System.exit(2); }
        catch (Exception ignored) { System.err.println("R13198_SIGNING_VALIDATOR_FAILED"); System.exit(2); }
    }
}
'''


def literal_property_value(value: str, code: str) -> str:
    # build.py keeps literal backslashes and UTF-8; Java Properties unescapes
    # backslashes and decodes ISO-8859-1. There is no lossless common encoding
    # for such values without changing an upstream parser. Reject, never alter.
    if (not value or value != value.strip(" \t\r\n") or "\\" in value
            or any(ord(ch) < 32 or ord(ch) > 126 for ch in value)):
        raise SigningError(code)
    return value


def configuration(env: dict[str, str]) -> tuple[dict[str, str], bytes]:
    present = sum(bool(env.get(name)) for name in SECRET_NAMES)
    if present == 0:
        raise SigningError("CONFIGURATION_MISSING")
    if present != len(SECRET_NAMES):
        raise SigningError("CONFIGURATION_INCOMPLETE")
    pin = env.get(PIN_NAME, "").strip()
    if not pin:
        raise SigningError("SIGNER_PIN_MISSING")
    if not re.fullmatch(r"[0-9A-Fa-f]{64}", pin):
        raise SigningError("SIGNER_PIN_INVALID")
    alias = env["R139_ALIAS"]
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", alias):
        raise SigningError("ALIAS_INVALID")
    store_pass = literal_property_value(env["R139_STOREPASS"], "STORE_PASSWORD_NOT_REPRESENTABLE")
    key_pass = literal_property_value(env["R139_KEYPASS"], "KEY_PASSWORD_NOT_REPRESENTABLE")
    try:
        encoded = env["R139_P12_B64"]
        # GitHub's secret text may contain ordinary Base64 line wrapping.
        encoded = re.sub(r"[ \t\r\n]", "", encoded)
        if len(encoded) > 2 * 1024 * 1024:
            raise SigningError("PKCS12_TOO_LARGE")
        data = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        raise SigningError("BASE64_INVALID") from None
    if not 128 <= len(data) <= 1024 * 1024:
        raise SigningError("PKCS12_SIZE_INVALID")
    return {"pin": pin.lower(), "alias": alias, "store_pass": store_pass, "key_pass": key_pass}, data


def atomic_write(path: Path, data: bytes, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".r13198-", dir=path.parent, delete=False) as handle:
            temporary = Path(handle.name)
            os.chmod(temporary, mode)
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None and temporary.exists():
            temporary.unlink()


def import_signing(workspace: Path, env: dict[str, str]) -> dict:
    values, keystore_bytes = configuration(env)
    workspace = workspace.resolve()
    if not workspace.is_dir():
        raise SigningError("WORKSPACE_MISSING")
    key_path = workspace / "magisk/r6-ci-only.p12"
    props_path = workspace / "r6-build.prop"
    report_path = workspace / "reports/R13198_SIGNING_IDENTITY.json"
    cert_path = workspace / "reports/R13198_SIGNER_CERT.der"
    key_path_value = literal_property_value(str(key_path), "KEYSTORE_PATH_NOT_REPRESENTABLE")
    java = shutil.which("java")
    if not java:
        raise SigningError("JAVA_UNAVAILABLE")
    props = {
        "abiList": ABI_LIST,
        "keyStore": key_path_value,
        "keyStorePass": values["store_pass"],
        "keyPass": values["key_pass"],
        "keyAlias": values["alias"],
    }
    properties_bytes = "".join(f"{key}={value}\n" for key, value in props.items()).encode("ascii")
    # Check the literal parser contract used by pinned Magisk build.py.
    decoded = {}
    for line in properties_bytes.decode("ascii").splitlines():
        key, sep, value = line.strip(" \t\r\n").partition("=")
        if sep and key.strip(" \t\r\n") and value.strip(" \t\r\n"):
            decoded[key.strip(" \t\r\n")] = value.strip(" \t\r\n")
    if decoded != props:
        raise SigningError("PYTHON_PROPERTIES_MISMATCH")
    with tempfile.TemporaryDirectory(prefix=".r13198-signing-", dir=workspace) as temporary:
        stage = Path(temporary)
        stage_key = stage / "signer.p12"
        stage_props = stage / "build.prop"
        stage_cert = stage / "signer.der"
        source = stage / "R13198KeyStoreCheck.java"
        atomic_write(stage_key, keystore_bytes, 0o600)
        atomic_write(stage_props, properties_bytes, 0o600)
        source.write_text(JAVA_VALIDATOR, encoding="utf-8")
        child_env = dict(env)
        child_env[PIN_NAME] = values["pin"]
        child_env["R13198_VALIDATION_KEYSTORE_PATH"] = key_path_value
        try:
            result = subprocess.run(
                [java, str(source), str(stage_key), str(stage_props), str(stage_cert)],
                env=child_env, text=True, capture_output=True, timeout=90, check=False,
            )
        except (OSError, subprocess.SubprocessError):
            raise SigningError("VALIDATOR_EXECUTION_FAILED") from None
        if result.returncode:
            known = {
                "CONFIGURATION_MISSING", "VALIDATOR_ARGUMENTS_INVALID", "JAVA_PROPERTIES_MISMATCH",
                "STORE_PASSWORD_OR_CONTAINER_INVALID", "ALIAS_NOT_PRIVATE_KEY", "KEY_PASSWORD_INVALID",
                "CERTIFICATE_INVALID", "CERTIFICATE_NOT_CURRENTLY_VALID", "SIGNER_PIN_MISMATCH",
                "KEY_ALGORITHM_UNSUPPORTED", "PRIVATE_KEY_CERTIFICATE_MISMATCH", "VALIDATOR_FAILED",
            }
            codes = re.findall(r"(?m)^R13198_SIGNING_([A-Z0-9_]+)$", result.stderr)
            code = codes[-1] if codes and codes[-1] in known else "VALIDATOR_EXECUTION_FAILED"
            raise SigningError(code)
        try:
            proof = json.loads(result.stdout)
            der = stage_cert.read_bytes()
        except (OSError, ValueError):
            raise SigningError("VALIDATOR_PROTOCOL_INVALID") from None
        if (proof.get("status") != "PASS" or proof.get("private_key_verified") is not True
                or proof.get("java_properties_roundtrip") is not True
                or proof.get("signer_sha256") != values["pin"]
                or hashlib.sha256(der).hexdigest() != values["pin"]):
            raise SigningError("VALIDATOR_PROOF_INVALID")
        # Nothing is published to the build until every credential/certificate check passes.
        atomic_write(key_path, keystore_bytes, 0o600)
        atomic_write(props_path, properties_bytes, 0o600)
        atomic_write(cert_path, der, 0o644)
        report = {
            "schema": "r13198.persistent-signing-v1",
            "status": "PASS",
            "signing_mode": "STABLE_SECRET",
            "expected_signer_sha256": values["pin"],
            "signer_sha256": proof["signer_sha256"],
            "key_algorithm": proof["key_algorithm"],
            "private_key_verified": True,
            "store_password_verified": True,
            "key_password_verified": True,
            "alias_is_private_key_entry": True,
            "python_properties_roundtrip": True,
            "java_properties_roundtrip": True,
            "public_certificate": "reports/R13198_SIGNER_CERT.der",
            "private_key_published": False,
            "new_signing_key_generated": False,
            "phone_update_compatibility": "NOT_ASSERTED_BY_SIGNING_IMPORT",
        }
        atomic_write(report_path, (json.dumps(report, indent=2) + "\n").encode(), 0o644)
        # Write the compatibility mode last; a successful process exit is still mandatory.
        atomic_write(workspace / "reports/R139_SIGNING_MODE.txt", b"STABLE_SECRET\n", 0o644)
        return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=Path, default=Path.cwd())
    parser.add_argument("--check-config", action="store_true", help="Early presence/format check only; does not validate a private key or create outputs")
    args = parser.parse_args()
    try:
        if args.check_config:
            values, _ = configuration(dict(os.environ))
            print(json.dumps({"status": "CONFIG_PRESENT", "private_key_validated": False,
                              "expected_signer_sha256": values["pin"]}))
        else:
            print(json.dumps(import_signing(args.workspace, dict(os.environ)), sort_keys=True))
        return 0
    except SigningError as failure:
        if not args.check_config and args.workspace.is_dir():
            # Do not erase an existing private key on failure. Invalidate only generated verdicts.
            mode = args.workspace / "reports/R139_SIGNING_MODE.txt"
            mode.unlink(missing_ok=True)
            report = {"schema": "r13198.persistent-signing-v1", "status": "FAIL", "error": PREFIX + failure.code}
            atomic_write(args.workspace / "reports/R13198_SIGNING_IDENTITY.json",
                         (json.dumps(report, indent=2) + "\n").encode(), 0o644)
        print(PREFIX + failure.code)
        return 2
    except (OSError, ValueError):
        # Never print a subprocess exception or raw input; these can contain credentials.
        mode = args.workspace / "reports/R139_SIGNING_MODE.txt"
        try:
            mode.unlink(missing_ok=True)
        except OSError:
            pass
        print(PREFIX + "IO_OR_CONFIGURATION_FAILURE")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
