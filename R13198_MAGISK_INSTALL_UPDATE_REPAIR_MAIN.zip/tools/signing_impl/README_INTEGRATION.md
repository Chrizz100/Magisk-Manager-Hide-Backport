# R13.19.8 – Persistent signing import

This module imports an existing PKCS12 signing identity. It never creates a project signing key, rotates a key, modifies runtime Hide/Restore signing, or changes an APK package name/version.

## Inputs

Keep the existing repository secrets and expose them as the established environment variables:

| GitHub secret or variable | Environment variable |
|---|---|
| Secret `MAGISK_HIDE_P12_BASE64` | `R139_P12_B64` |
| Secret `MAGISK_HIDE_P12_PASSWORD` | `R139_STOREPASS` |
| Secret `MAGISK_HIDE_P12_KEY_PASSWORD` | `R139_KEYPASS` |
| Secret `MAGISK_HIDE_P12_ALIAS` | `R139_ALIAS` |
| Public repository variable `MAGISK_HIDE_SIGNER_SHA256` | `R13198_EXPECTED_SIGNER_SHA256` |

The public pin must identify the existing intended signing certificate. Prefer the user's preserved R13.9 key when available. Do not generate a replacement merely because its secrets are missing from a job.

## Workflow integration

Choose one of the supplied snippets:

- `R13198_SIGNING_SETUP_STEPS.yml` contains two steps. Place the first at the beginning of the build job; it creates the module and performs the early configuration presence/format check. Place the second where the old signing step ran, or after Java setup and source preparation. The full import needs JDK 17 or newer with the Java compiler/source launcher; the existing workflow uses Java 25.
- `R13198_SIGNING_REPLACEMENT_STEP.yml` is a self-contained replacement for the old signing step if the optional earlier check is not added. It embeds the same module and performs the full import.

Both snippets use the exact same implementation. The early result is `CONFIG_PRESENT`, explicitly **not** private-key verification. Only the full import can write `STABLE_SECRET`.

Do not retain the old zero-secret `keytool -genkeypair` fallback. There is no research fallback in these steps. Keep the existing native `TRUSTED_CERT`, APK signer and compiled-native pairing gates.

## Outputs and compatibility

The existing build integration remains unchanged:

- `magisk/r6-ci-only.p12` — imported original bytes, mode `0600`.
- `r6-build.prop` — existing `abiList`, `keyStore`, `keyStorePass`, `keyPass`, `keyAlias` format, mode `0600`.
- `reports/R139_SIGNING_MODE.txt` — exactly `STABLE_SECRET` after successful import.
- `reports/R13198_SIGNING_IDENTITY.json` — public verdict and certificate fingerprint.
- `reports/R13198_SIGNER_CERT.der` — public DER certificate; its SHA-256 is the pinned fingerprint.

The native build still exports the certificate from this same PKCS12 file and embeds it as `TRUSTED_CERT`. This importer does not re-sign an already-built APK.

The private key and properties file must remain excluded from artifacts and caches. Only the public report, certificate and mode file may be published. A failed retry invalidates an old `STABLE_SECRET` verdict while retaining any existing private-file bytes as a backup; the workflow must also require the import command's zero exit status.

## What is validated

The full import validates Base64, PKCS12 decoding, the store password, a private-key alias, the private-key password, current certificate validity, the exact public pin, and a real sign/verify challenge proving that the usable private key matches the pinned certificate. Merely listing or exporting a certificate is insufficient.

Passwords are passed to the Java validator only through the environment; its command arguments contain file paths. Error output uses fixed codes and does not print passwords, aliases, keystore contents or raw child-tool diagnostics. The validator checks the properties with the same `java.util.Properties.load(InputStream)` API used by Magisk's Gradle plugin.

### The two build-property parsers

The pinned Magisk `build.py` keeps property values literal and strips leading/trailing whitespace. Its Gradle plugin instead uses Java Properties, which treats backslashes as escapes and input bytes as ISO-8859-1. Therefore this module rejects backslashes, non-ASCII characters, control characters and leading/trailing whitespace in passwords, rather than silently changing their meaning. Interior ASCII spaces and punctuation such as `$`, quotes, `=`, `:`, `#` and backticks are retained literally and tested.

If a preserved keystore has a password outside this representable subset, the identity must not be replaced. A separate, deliberate re-encryption of the same key under a representable password is possible; it is outside this importer's scope.

The imported keystore path is subject to the same property representation check. The current Linux GitHub workspace path is compatible.

### Existing upstream command-line behavior

The importer does not put passwords in subprocess arguments. The current upstream `build.py.dump_flags_native()` separately invokes `keytool -exportcert -storepass <value>`. If the complete pipeline must avoid password arguments, that existing call must be changed by the workflow integrator to the supported environment form. This module does not silently modify upstream `build.py`.

## Reproduction

Run the portable tests with the actual SDK tool, a valid APK fixture, and the pinned Magisk checkout:

```bash
python3 test_import_signing.py \
  --apksigner /path/to/android-sdk/build-tools/37.0.0/apksigner \
  --apk /path/to/a-valid-fixture.apk \
  --magisk-root /path/to/magisk \
  --report /path/to/signing-test-results.json
```

Tests use real `keytool`, Java PKCS12 handling and `apksigner`. They invoke the actual `parse_props` function extracted from the supplied `build.py`, not a replacement test parser. Disposable keys and re-signed APKs are confined to a private temporary directory and deleted at completion. The signing fixtures are never installed and are not candidates: re-signing them does not establish native signer pairing or phone compatibility.

This module proves a stable usable signing identity. Android install/update testing and compatibility with an already-running phone daemon remain separate requirements.
