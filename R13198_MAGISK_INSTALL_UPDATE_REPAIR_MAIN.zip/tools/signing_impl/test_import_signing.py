#!/usr/bin/env python3
"""Real PKCS12/keytool/apksigner regressions. All private fixtures are temporary.

The re-signed fixture APK is used only to verify signing-tool integration. It is
never installed or delivered and makes no claim about native signer pairing.
"""
from __future__ import annotations

import argparse
import ast
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile


HERE = Path(__file__).resolve().parent
MODULE = HERE / "R13198_IMPORT_SIGNING.py"
SECRETS = ("R139_P12_B64", "R139_STOREPASS", "R139_KEYPASS", "R139_ALIAS")
PIN = "R13198_EXPECTED_SIGNER_SHA256"
STORE_PASS = "Fixture store $`\"'=:# 9"
KEY_PASS = "Fixture private $`\"'=:# 8"
ALIAS = "r13198-disposable-fixture"

REPROTECT = r'''import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.security.cert.*;
class ReprotectFixture {
    public static void main(String[] args) throws Exception {
        char[] sourcePass = System.getenv("R13198_FIXTURE_SOURCE_PASSWORD").toCharArray();
        char[] storePass = System.getenv("R139_STOREPASS").toCharArray();
        char[] keyPass = System.getenv("R139_KEYPASS").toCharArray();
        String alias = System.getenv("R139_ALIAS");
        KeyStore source = KeyStore.getInstance("PKCS12");
        try (InputStream in = Files.newInputStream(Path.of(args[0]))) { source.load(in, sourcePass); }
        Key key = source.getKey(alias, sourcePass);
        java.security.cert.Certificate[] chain = source.getCertificateChain(alias);
        if (args.length == 3) {
            try (InputStream in = Files.newInputStream(Path.of(args[2]))) {
                chain = new java.security.cert.Certificate[]{CertificateFactory.getInstance("X.509").generateCertificate(in)};
            }
        }
        KeyStore dest = KeyStore.getInstance("PKCS12");
        dest.load(null, storePass);
        dest.setKeyEntry(alias, key, keyPass, chain);
        try (OutputStream out = Files.newOutputStream(Path.of(args[1]))) { dest.store(out, storePass); }
    }
}
'''


def external(argv, env, *, limit=90):
    result = subprocess.run([str(x) for x in argv], env=env, capture_output=True, text=True, timeout=limit)
    if result.returncode:
        # Fixture-creation diagnostics are useful, but never expose input credentials.
        diagnostic = result.stderr + result.stdout
        hidden = [v for k, v in env.items() if v and re.search(r"PASS|PASSWORD|ALIAS|B64|TOKEN|SECRET", k, re.I)]
        for value in sorted(hidden, key=len, reverse=True):
            diagnostic = diagnostic.replace(value, "<redacted>")
        raise AssertionError("EXTERNAL_FIXTURE_TOOL_FAILED: " + diagnostic[:3500])
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apksigner", type=Path, required=True)
    parser.add_argument("--apk", type=Path, required=True)
    parser.add_argument("--magisk-root", type=Path, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args()
    assert args.apksigner.is_file() and args.apk.is_file()
    assert shutil.which("java") and shutil.which("keytool")
    actual_build = args.magisk_root / "build.py"
    build_source = actual_build.read_text()
    parse_node = next(n for n in ast.parse(build_source).body if isinstance(n, ast.FunctionDef) and n.name == "parse_props")
    actual_namespace = {"Path": Path}
    exec(compile(ast.Module(body=[parse_node], type_ignores=[]), str(actual_build), "exec"), actual_namespace)
    actual_parse_props = actual_namespace["parse_props"]
    base_env = dict(os.environ)
    for name in (*SECRETS, PIN):
        base_env.pop(name, None)
    records = []
    with tempfile.TemporaryDirectory(prefix="r13198-private-signing-tests-") as temp:
        private = Path(temp)
        private.chmod(0o700)
        fixture_env = dict(base_env, R13198_FIXTURE_PASSWORD=STORE_PASS)
        keytool = shutil.which("keytool")
        def make_key(name):
            p12 = private / (name + ".p12")
            cert = private / (name + ".der")
            external([keytool, "-genkeypair", "-noprompt", "-keystore", p12, "-storetype", "PKCS12",
                      "-storepass:env", "R13198_FIXTURE_PASSWORD", "-keypass:env", "R13198_FIXTURE_PASSWORD",
                      "-alias", ALIAS, "-keyalg", "RSA", "-keysize", "2048", "-validity", "2",
                      "-dname", "CN=R13198 disposable automated test fixture"], fixture_env)
            external([keytool, "-exportcert", "-keystore", p12, "-storetype", "PKCS12",
                      "-storepass:env", "R13198_FIXTURE_PASSWORD", "-alias", ALIAS, "-file", cert], fixture_env)
            return p12, cert
        original, cert = make_key("original")
        other, other_cert = make_key("other")
        expected_pin = hashlib.sha256(cert.read_bytes()).hexdigest()
        normal = {"R139_P12_B64": base64.b64encode(original.read_bytes()).decode(),
                  "R139_STOREPASS": STORE_PASS, "R139_KEYPASS": STORE_PASS, "R139_ALIAS": ALIAS,
                  PIN: expected_pin}
        java_source = private / "ReprotectFixture.java"
        java_source.write_text(REPROTECT)
        distinct_path = private / "distinct-passwords.p12"
        reprotect_env = dict(base_env, **normal, R13198_FIXTURE_SOURCE_PASSWORD=STORE_PASS)
        reprotect_env["R139_KEYPASS"] = KEY_PASS
        external(["java", java_source, original, distinct_path], reprotect_env)
        distinct = dict(normal, R139_P12_B64=base64.b64encode(distinct_path.read_bytes()).decode(), R139_KEYPASS=KEY_PASS)
        mismatch_path = private / "mismatched-private-cert.p12"
        external(["java", java_source, original, mismatch_path, other_cert], reprotect_env)
        mismatch = dict(distinct, R139_P12_B64=base64.b64encode(mismatch_path.read_bytes()).decode())
        mismatch[PIN] = hashlib.sha256(other_cert.read_bytes()).hexdigest()
        cert_only = private / "certificate-only.p12"
        external([keytool, "-importcert", "-noprompt", "-storetype", "PKCS12", "-keystore", cert_only,
                  "-storepass:env", "R13198_FIXTURE_PASSWORD", "-alias", ALIAS, "-file", cert], fixture_env)
        def execute(name, values, expected_error=None, early=False):
            workspace = private / name
            workspace.mkdir()
            env = dict(base_env, **values)
            argv = [sys.executable, str(MODULE), "--workspace", str(workspace)]
            if early:
                argv.append("--check-config")
            # Inputs are only in environment; arguments contain no credentials.
            result = subprocess.run(argv, env=env, text=True, capture_output=True, timeout=120)
            output = result.stdout + result.stderr
            private_values = [value for key, value in values.items() if key in SECRETS and value]
            if any(value in output for value in private_values):
                raise AssertionError("SECRET_LEAK_DETECTED_IN_" + name)
            mode = workspace / "reports/R139_SIGNING_MODE.txt"
            if expected_error:
                assert result.returncode != 0, "UNEXPECTED_ACCEPTANCE_" + name
                assert "R13198_SIGNING_" + expected_error in output, "WRONG_REJECTION_" + name
                assert not mode.exists(), "FAILURE_LEFT_STABLE_MODE_" + name
                assert not (workspace / "magisk/r6-ci-only.p12").exists(), "FAILURE_PUBLISHED_KEY_" + name
                records.append({"test": name, "status": "PASS", "expected_rejection": expected_error})
            elif early:
                assert result.returncode == 0
                data = json.loads(result.stdout)
                assert data["status"] == "CONFIG_PRESENT" and data["private_key_validated"] is False
                assert not (workspace / "magisk").exists() and not mode.exists()
                records.append({"test": name, "status": "PASS", "scope": "CONFIG_PRESENCE_ONLY"})
            else:
                assert result.returncode == 0, "VALID_FIXTURE_REJECTED_" + name
                data = json.loads(result.stdout)
                assert data["status"] == "PASS" and data["private_key_verified"] is True
                assert data["new_signing_key_generated"] is False
                assert mode.read_text() == "STABLE_SECRET\n"
                key_path = workspace / "magisk/r6-ci-only.p12"
                props_path = workspace / "r6-build.prop"
                assert stat.S_IMODE(key_path.stat().st_mode) == 0o600
                assert stat.S_IMODE(props_path.stat().st_mode) == 0o600
                assert key_path.read_bytes() == base64.b64decode(re.sub(r"[ \t\r\n]", "", values["R139_P12_B64"]))
                assert hashlib.sha256((workspace / "reports/R13198_SIGNER_CERT.der").read_bytes()).hexdigest() == expected_pin
                # Run the actual pinned build.py parser rather than a second test implementation.
                props = actual_parse_props(props_path)
                assert props["keyStorePass"] == values["R139_STOREPASS"]
                assert props["keyPass"] == values["R139_KEYPASS"]
                assert props["keyAlias"] == values["R139_ALIAS"]
                assert props["keyStore"] == str(key_path.resolve())
                records.append({"test": name, "status": "PASS", "actual_build_py_parser_pass": True,
                                "java_properties_parser_pass": True, "private_files_mode": "0600"})
            return workspace

        execute("missing_all", {}, "CONFIGURATION_MISSING")
        execute("partial", {"R139_P12_B64": normal["R139_P12_B64"]}, "CONFIGURATION_INCOMPLETE")
        execute("missing_pin", {k: v for k, v in normal.items() if k != PIN}, "SIGNER_PIN_MISSING")
        execute("invalid_pin", dict(normal, **{PIN: "not-a-certificate-pin"}), "SIGNER_PIN_INVALID")
        execute("invalid_base64", dict(normal, R139_P12_B64="invalid-base64-secret-value!"), "BASE64_INVALID")
        execute("invalid_pkcs12", dict(normal, R139_P12_B64=base64.b64encode(b"not a PKCS12 container" * 20).decode()), "STORE_PASSWORD_OR_CONTAINER_INVALID")
        execute("wrong_store_password", dict(normal, R139_STOREPASS="IncorrectStorePassword123"), "STORE_PASSWORD_OR_CONTAINER_INVALID")
        execute("wrong_key_password", dict(distinct, R139_KEYPASS="IncorrectPrivateKeyPassword123"), "KEY_PASSWORD_INVALID")
        execute("missing_alias", dict(normal, R139_ALIAS="missing-alias"), "ALIAS_NOT_PRIVATE_KEY")
        execute("certificate_only", dict(normal, R139_P12_B64=base64.b64encode(cert_only.read_bytes()).decode()), "ALIAS_NOT_PRIVATE_KEY")
        execute("wrong_pin", dict(normal, **{PIN: "0" * 64}), "SIGNER_PIN_MISMATCH")
        execute("mismatched_private_key_and_certificate", mismatch, "PRIVATE_KEY_CERTIFICATE_MISMATCH")
        execute("newline_store_password", dict(normal, R139_STOREPASS=STORE_PASS + "\nkeyAlias=injected"), "STORE_PASSWORD_NOT_REPRESENTABLE")
        execute("leading_whitespace", dict(normal, R139_STOREPASS=" " + STORE_PASS), "STORE_PASSWORD_NOT_REPRESENTABLE")
        execute("trailing_whitespace", dict(normal, R139_KEYPASS=STORE_PASS + " "), "KEY_PASSWORD_NOT_REPRESENTABLE")
        execute("backslash_password", dict(normal, R139_KEYPASS=STORE_PASS + "\\x"), "KEY_PASSWORD_NOT_REPRESENTABLE")
        execute("unicode_password", dict(normal, R139_KEYPASS=STORE_PASS + "ä"), "KEY_PASSWORD_NOT_REPRESENTABLE")
        execute("alias_injection", dict(normal, R139_ALIAS="bad\nkeyStore=wrong"), "ALIAS_INVALID")
        good_same = execute("valid_ascii_metacharacters", normal)
        good_distinct = execute("valid_distinct_key_password", distinct)
        wrapped = dict(distinct)
        wrapped["R139_P12_B64"] = "\n".join(wrapped["R139_P12_B64"][n:n+64] for n in range(0, len(wrapped["R139_P12_B64"]), 64))
        execute("wrapped_base64", wrapped)
        execute("early_configuration_check", normal, early=True)
        for label, workspace, values in [("apksigner_same_password", good_same, normal), ("apksigner_distinct_password", good_distinct, distinct)]:
            signed = private / (label + ".apk")
            env = dict(base_env, **values)
            command = [args.apksigner, "sign", "--ks", workspace / "magisk/r6-ci-only.p12",
                       "--ks-key-alias", ALIAS, "--ks-pass", "env:R139_STOREPASS", "--key-pass", "env:R139_KEYPASS",
                       "--v1-signing-enabled", "false", "--v2-signing-enabled", "true", "--v3-signing-enabled", "false",
                       "--v4-signing-enabled", "false", "--out", signed, args.apk]
            external(command, env)
            verify = external([args.apksigner, "verify", "--verbose", "--print-certs", signed], env)
            assert "Verified using v2 scheme (APK Signature Scheme v2): true" in verify.stdout
            digests = set(re.findall(r"(?im)^\s*(?:(?:V2\s+)?Signer:\s+certificate|Signer\s*#\s*\d+\s+certificate)\s+SHA-256\s+digest:\s*([0-9a-fA-F]{64})\s*$", verify.stdout))
            assert digests == {expected_pin}
            records.append({"test": label, "status": "PASS", "real_apksigner_v2_verified": True,
                            "scope": "DISPOSABLE_SIGNATURE_FIXTURE_ONLY_NOT_A_NATIVE_PAIR_OR_DEVICE_CANDIDATE"})
        # Failure after success must not leave a stale STABLE_SECRET verdict; retain the backup bytes.
        before_key = (good_same / "magisk/r6-ci-only.p12").read_bytes()
        before_props = (good_same / "r6-build.prop").read_bytes()
        result = subprocess.run([sys.executable, str(MODULE), "--workspace", str(good_same)], env=base_env,
                                text=True, capture_output=True, timeout=120)
        assert result.returncode != 0
        assert not (good_same / "reports/R139_SIGNING_MODE.txt").exists()
        assert json.loads((good_same / "reports/R13198_SIGNING_IDENTITY.json").read_text())["status"] == "FAIL"
        assert (good_same / "magisk/r6-ci-only.p12").read_bytes() == before_key
        assert (good_same / "r6-build.prop").read_bytes() == before_props
        records.append({"test": "failed_retry_invalidates_mode_preserves_private_backup", "status": "PASS"})
    assert not private.exists(), "PRIVATE_FIXTURES_NOT_REMOVED"
    report = {"scope": "Real disposable PKCS12/keytool/Java/apksigner signing tests; no project signing key generated, no app installed, no native-pair or phone pass claimed",
              "status": "PASS", "tests": records, "test_count": len(records),
              "implementation_sha256": hashlib.sha256(MODULE.read_bytes()).hexdigest(),
              "actual_build_py_parse_props_sha256": hashlib.sha256(ast.get_source_segment(build_source, parse_node).encode()).hexdigest(),
              "all_private_fixtures_removed": True}
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "test_count": len(records), "report": str(args.report), "all_private_fixtures_removed": True}))


if __name__ == "__main__":
    main()
