# R13.19.9 – Sofortabbruch und Folgefehler aus Lauf 44448376001

## Ergebnis

Die Ursache ist nachgewiesen und die Ablaufsteuerung ist korrigiert. Der neue Workflow unterscheidet ausdrücklich zwischen **Einrichtung prüfen** und **signierte APK bauen und vollständig testen**. Eine erfolgreiche Einrichtungsprüfung behauptet weder einen Build noch einen bestandenen Android-Test.

Die vollständige YAML ist eigenständig; ihre Hilfsprogramme sind eingebettet. Die Produktquellen und sämtliche bisherigen Signatur-, Native-, GUI-, Installations-, Update-, Root-, Hide- und Restore-Prüfungen sind unverändert. Es wurde kein neuer Schlüssel und keine neue APK erzeugt. Ein neuer GitHub-Durchlauf wurde hier nicht ausgeführt.

## Nachgewiesener Abbruch

- Lauf: [44448376001](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44448376001).
- Commit: `5dd28252418b5bae5ea399c3c157ce26dac477b5`.
- Erster Fehler: [Buildjob 135305989374, Schritt 2](https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/44448376001/job/135305989374).
- Meldung: `R13198_SIGNING_CONFIGURATION_MISSING`, Exitcode 2.
- Alle vier Signier-Secrets und die öffentliche Fingerprint-Variable waren im Job leer.
- Checkout, Kompilierung, APK-Erzeugung und Android-Tests wurden nicht begonnen.

Die gestartete YAML ist bytegenau die zuvor gelieferte R13.19.8, SHA-256:

```text
98e62ace4a989ab2311dc5f7186cf433cc63de69cfe0a6fd279e9b94ee5b4571
```

Der anschließende Abschlussjob lief wegen seines bisherigen `always()` trotz des nicht gestarteten Builds. Er versuchte drei nicht vorhandene Artefakte herunterzuladen und führte Prüfungen ohne Belege aus. Diese Folgefehler waren keine neu beobachteten Magisk-Laufzeitfehler.

Die benötigten GitHub-Werte sind:

| Art | Name |
|---|---|
| Repository-Secret | `MAGISK_HIDE_P12_BASE64` |
| Repository-Secret | `MAGISK_HIDE_P12_PASSWORD` |
| Repository-Secret | `MAGISK_HIDE_P12_KEY_PASSWORD` |
| Repository-Secret | `MAGISK_HIDE_P12_ALIAS` |
| Öffentliche Repository-Variable | `MAGISK_HIDE_SIGNER_SHA256` |

Die leeren Jobwerte beweisen nicht, dass ein früherer Schlüssel auf dem Telefon fehlt. Es wird deshalb kein Ersatzschlüssel erzeugt und die bestehende Signieridentität nicht ausgetauscht.

## Korrigierte Bedienung

Der neue Workflow heißt:

**Magisk R13.19.9 – Einrichtung prüfen oder signierten APK-Build ausführen**

Beim manuellen Start gibt es das Auswahlfeld `operation`:

| Auswahl | Verhalten |
|---|---|
| **`check_signing_setup` – Standard** | Prüft ausschließlich vorhandene Einstellungen und deren Format. Meldet fehlende oder ungültige Angaben verständlich im öffentlichen Bericht. Erzeugt keine APK und führt keine Android-Tests aus. |
| **`build_release`** | Verlangt vollständige, formal gültige Angaben. Danach laufen der unveränderte echte Schlüsselimport, Build und alle bisherigen Pflichtprüfungen. Fehlende oder ungültige Schlüsselangaben bleiben ein Fehler. |

Der sichtbare Laufname nennt im ersten Fall ausdrücklich **„Einrichtung prüfen (keine APK)“**. Ein grünes Ergebnis in diesem Modus bedeutet ausschließlich, dass die angeforderte Einrichtungsprüfung abgeschlossen wurde.

Für den jetzt bekannten Fall mit fünf fehlenden Werten ergibt der Vorbereitungsmodus:

```text
Signiereinrichtung: SETUP_REQUIRED
Abschluss: SETUP_CHECK_COMPLETED_NO_APK
APK gebaut: nein
Android-Tests ausgeführt: nein
Vollständiger CI-Pass: nein
```

Wird stattdessen `build_release` ohne die Werte angefordert, bleibt der Vorgang fehlgeschlagen und nennt die Ursache zusammengefasst:

```text
SIGNED_BUILD_NOT_STARTED_SETUP_REJECTED
SIGNING_SETUP_NOT_READY
```

Das ist bewusst keine Freigabe einer unsignierten oder mit einem neuen Wegwerf-Schlüssel gebauten APK.

## Technische Änderungen

1. Ein eigener Einrichtungsjob verwendet die Konfigurationsregeln des unveränderten `R13198_IMPORT_SIGNING.py`. Er veröffentlicht ausschließlich öffentliche Einstellungsnamen und feste Statuswerte, keine Secretwerte oder privaten Dateien.
2. Der Produkt-Build benötigt einen erfolgreichen Einrichtungsjob, die ausdrückliche Auswahl `build_release` und `build_permitted=true`. Die eigentliche private Schlüsselprüfung bleibt zusätzlich verbindlich.
3. Der bisherige Gesamtprüfjob läuft nur nach einem erfolgreichen Build. Fehlende Konfiguration führt dadurch nicht mehr zu Downloadversuchen für nicht erzeugte APK-/Android-Artefakte.
4. Nach einem erfolgreichen Build bleibt der Gesamtprüfjob auch bei fehlgeschlagenen, abgebrochenen oder übersprungenen GUI-/Root-Jobs aktiv. Diese Fehler werden weiterhin erkannt.
5. Ein eigener abschließender Statusjob verhindert, dass ein unerwartet übersprungener Build oder ein fehlender Output als vollständiger CI-Erfolg erscheint.

Die Jobsteuerung entspricht der [GitHub-Dokumentation zu Abhängigkeiten](https://docs.github.com/en/actions/how-tos/write-workflows/choose-what-workflows-do/use-jobs) und [Jobbedingungen](https://docs.github.com/en/actions/how-tos/write-workflows/choose-when-workflows-run/control-jobs-with-conditions). Da übersprungene Checks GitHub-seitig erfolgreich angezeigt werden können, ist die explizite Gesamtprüfung weiterhin notwendig.

## Durchgeführte Prüfungen

| Prüfung | Ergebnis und Aussage |
|---|---|
| 32 Konfigurationsfälle | Bestanden; darunter die exakte Wiederholung des ursprünglichen Fehlers mit dem unveränderten Importer, Teilkonfigurationen, ungültige Eingaben und vertrauliche Ausgabe. |
| Exakte neue Workflow-Skripte mit den fünf leeren Werten | Vorbereitung endet mit einem ehrlichen Setupbericht; angeforderter Build bleibt abgelehnt. Keine APK oder Schlüsseldatei erzeugt. |
| 36 Build- und 192 Aggregat-Bedingungsfälle | Bestanden; sinnvolle Jobausführung und notwendige Fehlererkennung bleiben erhalten. |
| 83 Abschlussfälle | Bestanden; fehlende Outputs, falsche Boolwerte, unerwartete Skips sowie fehlerhafte/abgebrochene Pflichtjobs ergeben keinen CI-Pass. |
| 57 Bash-Blöcke, Python und YAML | Syntax-/Einbettungsprüfung bestanden. |
| Vorherige Workflow-Schritte | Alle 61 Build-, 8 GUI-, 7 Root- und 9 Aggregat-Schritte unverändert; 28 Produktquellschritte und 15 GUI-Fälle erhalten. |

Die Bedingungs- und Abschlussprüfungen verwenden ausdrücklich simulierte GitHub-Jobzustände. Sie sind keine neue Android-Ausführung. Die öffentlichen JSON-Berichte und ausführbaren Prüfprogramme sind im Paket enthalten.

## Verwendung

1. Die YAML unter `.github/workflows/R13199_MAGISK_31100_SIGNING_SETUP_AND_VERIFIED_BUILD.yml` auf den Standardbranch hochladen.
2. Unter Actions den neuen R13.19.9-Workflow wählen und **Run workflow** öffnen.
3. Solange die Einrichtung noch offen ist, den Standard **`check_signing_setup`** verwenden. Der Bericht liegt in `R13199_SIGNING_SETUP_REPORT_NO_APK`; der Abschluss in `R13199_WORKFLOW_STATUS`.
4. Nach Hinterlegung des erhaltenen Schlüssels und Fingerprints **`build_release`** wählen.

Die fachlichen R13.19.8-Prüfungen und deren Artefaktnamen bleiben unverändert. Nach einem vollständigen erfolgreichen Build-/Testlauf ist die verifizierte APK im Artefakt `R13198_APK_STABLE_SIGNER_INSTALL_UPDATE_VERIFIED` enthalten. Im Vorbereitungsmodus wird dieses Artefakt nicht erstellt.

Ein „Re-run“ des alten R13.19.8-Laufs startet dessen ursprünglichen Workflow. Für die Änderung ist ein neuer Start der R13.19.9-Datei erforderlich.

Die vorhandenen Termux-Helfer bleiben gültig und liegen unverändert unter `phone/`. Die späteren öffentlichen Termux-Berichte betreffen die vorhandene Signieridentität und Telefonkompatibilität. Sie ersetzen nicht die in GitHub benötigten privaten Signier-Secrets; private Schlüssel und Passwörter gehören nicht in den Chat.

Die verfügbare GitHub-Verbindung besitzt weiterhin keinen nachgewiesenen Workflow-Schreibzugriff; die aktuelle Installationsabfrage lieferte keine Installation. Nach dem früheren HTTP-403-Fehler wurde kein gleichartiger Schreibversuch wiederholt. Die korrigierte Datei wird deshalb zum Hochladen bereitgestellt und nicht als bereits veröffentlichte Änderung ausgegeben.
