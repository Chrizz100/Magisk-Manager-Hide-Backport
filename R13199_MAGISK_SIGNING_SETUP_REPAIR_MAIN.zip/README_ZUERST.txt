R13.19.9 – Korrektur des Sofortabbruchs aus Lauf 44448376001

Die YAML unter .github/workflows/ ist vollständig und eigenständig.
Default check_signing_setup: nur Einrichtung prüfen, keine APK.
build_release: signierte APK plus alle bisherigen Pflichtprüfungen;
dafür sind vier erhaltene Signier-Secrets und der öffentliche Pin nötig.

Der Bericht erklärt die nachgewiesene Ursache und den Start. Die Ordner
work_r13199 und work_r13198 enthalten reproduzierbaren Code und Belege.
phone/ enthält die bisherigen unveränderten Termux-Helfer.
Keine APK und keine privaten Schlüssel befinden sich im Paket.
