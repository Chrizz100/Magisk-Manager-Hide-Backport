#!/usr/bin/env python3
"""Check signing setup without creating a key, building an APK or claiming PASS.

check_signing_setup completes a diagnostic request even if setup is incomplete.
build_release requires valid configuration before the unchanged private-key
validator and build job may start. Presence/format never proves key ownership.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile


SCHEMA = "r13199.signing-setup-preflight-v1"
OPERATIONS = ("check_signing_setup", "build_release")
SETTINGS = (
    ("R139_P12_B64", "MAGISK_HIDE_P12_BASE64", "secret"),
    ("R139_STOREPASS", "MAGISK_HIDE_P12_PASSWORD", "secret"),
    ("R139_KEYPASS", "MAGISK_HIDE_P12_KEY_PASSWORD", "secret"),
    ("R139_ALIAS", "MAGISK_HIDE_P12_ALIAS", "secret"),
    ("R13198_EXPECTED_SIGNER_SHA256", "MAGISK_HIDE_SIGNER_SHA256", "variable"),
)
KNOWN_ERRORS = frozenset({
    "CONFIGURATION_MISSING", "CONFIGURATION_INCOMPLETE", "SIGNER_PIN_MISSING",
    "SIGNER_PIN_INVALID", "ALIAS_INVALID", "STORE_PASSWORD_NOT_REPRESENTABLE",
    "KEY_PASSWORD_NOT_REPRESENTABLE", "PKCS12_TOO_LARGE", "BASE64_INVALID",
    "PKCS12_SIZE_INVALID",
})
MISSING_ERRORS = frozenset({"CONFIGURATION_MISSING", "CONFIGURATION_INCOMPLETE", "SIGNER_PIN_MISSING"})


class QuietParser(argparse.ArgumentParser):
    def error(self, message):
        # argparse's normal error can echo an unknown user argument verbatim.
        print('{"status":"REQUEST_INVALID","error_code":"CLI_ARGUMENTS_INVALID","build_permitted":false}')
        raise SystemExit(2)


def load_importer(path: Path):
    spec = importlib.util.spec_from_file_location("r13198_signing_import", path)
    if spec is None or spec.loader is None:
        raise ImportError("IMPORTER_UNAVAILABLE")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if not callable(getattr(module, "configuration", None)):
        raise ImportError("IMPORTER_CONFIGURATION_FUNCTION_MISSING")
    return module


def inspect_setup(operation: str, env: dict[str, str], importer) -> tuple[dict, int]:
    """Return public names/statuses only. Never return any supplied value."""
    public_operation = operation if operation in OPERATIONS else "INVALID"
    present, missing = [], []
    for variable, public_name, kind in SETTINGS:
        value = env.get(variable, "")
        # The pin's surrounding whitespace is accepted by the unchanged importer.
        exists = bool(value.strip()) if kind == "variable" else bool(value)
        (present if exists else missing).append(public_name)
    report = {
        "schema": SCHEMA,
        "revision": "R13.19.9",
        "operation": public_operation,
        "status": "REQUEST_INVALID",
        "error_code": None,
        "provided_settings": present,
        "missing_settings": missing,
        "settings_types": {name: kind for _, name, kind in SETTINGS},
        "configuration_format_valid": False,
        "private_key_validated": False,
        "build_permitted": False,
        "apk_build": "NOT_REQUESTED" if public_operation == "check_signing_setup" else "NOT_STARTED",
        "signed_apk_produced": False,
        "android_runtime": "NOT_RUN",
        "release_status": "NOT_BUILT",
        "new_signing_key_generated": False,
        "secret_values_disclosed": False,
        "phone_installation_approval": "NOT_ESTABLISHED",
    }
    if public_operation == "INVALID":
        report["error_code"] = "OPERATION_INVALID"
        return report, 2
    try:
        # Reuse the exact release importer's configuration rules. Its returned
        # password/alias/key bytes stay local and are never added to the report.
        importer.configuration(dict(env))
    except importer.SigningError as failure:
        code = failure.code if failure.code in KNOWN_ERRORS else "CONFIGURATION_VALIDATION_FAILED"
        report["error_code"] = code
        report["status"] = "SETUP_REQUIRED" if code in MISSING_ERRORS else "CONFIGURATION_INVALID"
        return report, 0 if operation == "check_signing_setup" else 2
    except (ValueError, TypeError, UnicodeError):
        # Exceptions can contain invalid input bytes or secret values. Emit only
        # a fixed public code, never str(exception) or a traceback.
        report["error_code"] = "CONFIGURATION_VALIDATION_FAILED"
        report["status"] = "CONFIGURATION_INVALID"
        return report, 0 if operation == "check_signing_setup" else 2
    report["status"] = "CONFIG_PRESENT_NOT_KEY_VALIDATED"
    report["configuration_format_valid"] = True
    report["build_permitted"] = operation == "build_release"
    return report, 0


def atomic_json(path: Path, report: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix=".r13199-public-", dir=path.parent, delete=False) as stream:
            temporary = Path(stream.name)
            os.chmod(temporary, 0o644)
            stream.write((json.dumps(report, indent=2, ensure_ascii=True) + "\n").encode("utf-8"))
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def publish_github(report: dict, env: dict[str, str]) -> None:
    output = env.get("GITHUB_OUTPUT")
    if output:
        with Path(output).open("a", encoding="utf-8") as stream:
            stream.write("build_permitted=" + ("true" if report["build_permitted"] else "false") + "\n")
            stream.write("status=" + report["status"] + "\n")
            stream.write("operation=" + report["operation"] + "\n")
    summary = env.get("GITHUB_STEP_SUMMARY")
    if summary:
        lines = [
            "## R13.19.9 – Signiereinrichtung", "",
            "**Status:** `" + report["status"] + "`", "",
            "**Auftrag:** `" + report["operation"] + "`", "",
            "Dieser Schritt prüft ausschließlich Vorhandensein und Format der Konfiguration.",
            "Es wurden keine APK gebaut, keine Android-Tests ausgeführt und kein privater Schlüssel validiert.",
            "Eine erfolgreiche Einrichtungsprüfung ist keine Build- oder Installationsfreigabe.", "",
        ]
        if report["operation"] == "check_signing_setup":
            lines += ["Der ausdrücklich gewählte Vorbereitungsmodus endet nach diesem Bericht. Alle Build- und Testjobs bleiben ausgelassen.", ""]
        elif report["build_permitted"]:
            lines += ["Die formale Konfiguration ist vorhanden. Der nachfolgende Build muss den privaten Schlüssel unverändert vollständig prüfen.", ""]
        else:
            lines += ["Der angeforderte signierte Build kann mit dieser Konfiguration nicht starten.", ""]
        if report["error_code"]:
            lines += ["**Prüfcode:** `" + report["error_code"] + "`", ""]
        lines += ["| Einstellung | Typ | Im Job verfügbar |", "|---|---|---|"]
        for _, name, kind in SETTINGS:
            state = "ja" if name in report["provided_settings"] else "fehlt"
            lines.append("| `" + name + "` | " + kind + " | " + state + " |")
        lines += ["", "Die vorhandene Signieridentität erhalten und diese Werte unter Repository Settings → Secrets and variables → Actions hinterlegen.",
                  "Keine privaten Schlüssel oder Passwörter in den Bericht oder in den Chat übernehmen.", ""]
        with Path(summary).open("a", encoding="utf-8") as stream:
            stream.write("\n".join(lines))


def main(argv=None) -> int:
    parser = QuietParser(description=__doc__)
    parser.add_argument("--operation", required=True)
    parser.add_argument("--importer", type=Path, default=Path("R13198_IMPORT_SIGNING.py"))
    parser.add_argument("--report", type=Path, default=Path("reports/R13199_SIGNING_SETUP.json"))
    args = parser.parse_args(argv)
    try:
        importer = load_importer(args.importer)
        report, result = inspect_setup(args.operation, dict(os.environ), importer)
        atomic_json(args.report, report)
        publish_github(report, dict(os.environ))
        print(json.dumps(report, ensure_ascii=True, sort_keys=True))
        return result
    except (OSError, ImportError, SyntaxError, AttributeError, ValueError, TypeError, UnicodeError):
        # A broken script/read/write is an actual failure even in diagnostic mode.
        print('{"status":"PREFLIGHT_EXECUTION_FAILED","error_code":"PREFLIGHT_IO_OR_IMPORT_FAILURE","build_permitted":false}')
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
