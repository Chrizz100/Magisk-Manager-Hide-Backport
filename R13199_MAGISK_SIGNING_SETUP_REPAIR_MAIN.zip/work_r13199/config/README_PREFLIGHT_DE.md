# R13.19.9 – ausdrücklich getrennte Einrichtungsprüfung

`R13199_SIGNING_SETUP_PREFLIGHT.py` verwendet die unveränderte Funktion
`configuration()` aus `R13198_IMPORT_SIGNING.py`. Es erzeugt keinen Schlüssel,
importiert keinen privaten Schlüssel und baut keine APK.

## Aufruf

```bash
python3 R13199_SIGNING_SETUP_PREFLIGHT.py \
  --operation check_signing_setup \
  --importer R13198_IMPORT_SIGNING.py \
  --report reports/R13199_SIGNING_SETUP.json
```

`--operation build_release` fordert zusätzlich, dass die formalen
Konfigurationsvoraussetzungen für den nachfolgenden signierten Build vorliegen.
Die tatsächliche PKCS12-/PrivateKey-/Passwort-/Zertifikatsprüfung bleibt im
bestehenden vollständigen Signing-Import des Buildjobs erforderlich.

| Auftrag und Befund | Status | Exitcode | `build_permitted` |
|---|---|---:|---|
| Einrichtung prüfen; Werte fehlen | `SETUP_REQUIRED` | 0 | `false` |
| Einrichtung prüfen; Format ungültig | `CONFIGURATION_INVALID` | 0 | `false` |
| Einrichtung prüfen; Format gültig | `CONFIG_PRESENT_NOT_KEY_VALIDATED` | 0 | `false` |
| Release anfordern; Werte fehlen | `SETUP_REQUIRED` | 2 | `false` |
| Release anfordern; Format ungültig | `CONFIGURATION_INVALID` | 2 | `false` |
| Release anfordern; Format gültig | `CONFIG_PRESENT_NOT_KEY_VALIDATED` | 0 | `true` |
| Unbekannter Auftrag oder tatsächlicher Ausführungsfehler | fester Fehlerstatus | 2 | `false` |

Ein erfolgreicher **Diagnoseauftrag** bei fehlender Einrichtung ist kein
Build-PASS. Der Bericht enthält immer `private_key_validated: false`,
`signed_apk_produced: false`, `android_runtime: NOT_RUN` und
`release_status: NOT_BUILT`. Im Diagnosemodus steht `apk_build: NOT_REQUESTED`.

## GitHub-Schnittstelle

Die vier vorhandenen `R139_*`-Secret-Umgebungsvariablen und
`R13198_EXPECTED_SIGNER_SHA256` werden wie bisher verwendet. Der öffentliche
Bericht und die Job-Zusammenfassung zeigen ausschließlich deren GitHub-Namen,
Vorhandensein, festen Fehlercode und Status; keine Eingabewerte, Passwörter,
Aliaswerte, Fingerprintwerte oder Containerbytes.

Der Helper schreibt, falls die GitHub-Dateipfade vorhanden sind:

- `GITHUB_OUTPUT`: `build_permitted`, `status`, `operation`.
- `GITHUB_STEP_SUMMARY`: eine eindeutig als Einrichtungsprüfung bezeichnete
  Übersicht einschließlich fehlender öffentlicher Einstellungsnamen.

Der Buildjob muss **beides** verlangen: erfolgreicher Preflightjob und
`build_permitted == 'true'`. Das ist insbesondere bei einem Schreibfehler der
GitHub-Ausgabedateien notwendig. Der bestehende vollständige Schlüsselimport
im Build darf nicht umgangen werden.

Im Einrichtungsjob darf der eingebettete R13198-Importer erzeugt und importiert
werden; sein bisheriger eigenständiger `--check-config`-Aufruf darf dort nicht
zusätzlich laufen, weil dieser fehlende Einrichtung weiterhin korrekt mit
Exitcode 2 ablehnt.

## Lokale Verifikation

```bash
python3 test_signing_setup_preflight.py --importer /path/to/R13198_IMPORT_SIGNING.py
```

Die 32 Prüfungen reproduzieren zunächst den Originalabbruch aus Lauf
44448376001 mit dem unveränderten Importer. Anschließend prüfen sie beide
Auftragsarten, alle fehlenden Secret-Namen, fehlenden Pin, falsche Formate,
Unicode-/CLI-Fehler, Ausgabe ohne Geheimnisse und echte Schreibfehler.

Die formal gültigen Testeingaben sind **keine privaten Schlüssel**. Genau
dadurch wird auch überprüft, dass das Ergebnis nie eine ausgeführte
PrivateKey-Validierung behauptet. Es entsteht keine APK und es wird kein
Android-Gerät angesprochen.
