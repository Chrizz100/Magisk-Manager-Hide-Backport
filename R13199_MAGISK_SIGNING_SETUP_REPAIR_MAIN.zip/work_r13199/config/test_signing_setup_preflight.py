#!/usr/bin/env python3
"""Focused orchestration tests; no real key, APK, Android or phone is created."""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types


HERE = Path(__file__).resolve().parent
SCRIPT = HERE / "R13199_SIGNING_SETUP_PREFLIGHT.py"
PROJECT = HERE.parents[1]
DEFAULT_IMPORTER = PROJECT / "work_r13198/signing_impl/R13198_IMPORT_SIGNING.py"


def module_at(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--importer", type=Path, default=DEFAULT_IMPORTER)
    parser.add_argument("--report", type=Path, default=HERE / "R13199_PREFLIGHT_TEST_RESULTS.json")
    args = parser.parse_args()
    importer = module_at("importer_tested", args.importer)
    preflight = module_at("preflight_tested", SCRIPT)
    cases = []
    secret_values = {
        "R139_P12_B64": base64.b64encode(b"test-format-only-not-a-private-key" * 8).decode(),
        "R139_STOREPASS": "NEVER-PRINT-STORE-PASSWORD-9431",
        "R139_KEYPASS": "NEVER-PRINT-KEY-PASSWORD-4852",
        "R139_ALIAS": "NEVER-PRINT-ALIAS-2791",
        "R13198_EXPECTED_SIGNER_SHA256": "ab" * 32,
    }
    base_env = dict(os.environ)
    for name in (*importer.SECRET_NAMES, importer.PIN_NAME, "GITHUB_OUTPUT", "GITHUB_STEP_SUMMARY"):
        base_env.pop(name, None)

    def record(name, func):
        func()
        cases.append({"case": name, "status": "PASS"})

    def call(operation, supplied, expected_status, expected_rc, expected_build, extra=None):
        with tempfile.TemporaryDirectory(prefix="r13199-preflight-test-") as directory:
            root = Path(directory)
            output, summary, report = root / "outputs", root / "summary.md", root / "reports/setup.json"
            environment = {**base_env, **supplied, "GITHUB_OUTPUT": str(output), "GITHUB_STEP_SUMMARY": str(summary)}
            command = [sys.executable, str(SCRIPT), "--operation", operation,
                       "--importer", str(args.importer), "--report", str(report)]
            result = subprocess.run(command + (extra or []), env=environment, capture_output=True, text=True, timeout=20)
            assert result.returncode == expected_rc, (result.returncode, result.stdout, result.stderr)
            assert result.stderr == "", result.stderr
            data = json.loads(result.stdout)
            assert data["status"] == expected_status, data
            assert data["build_permitted"] is expected_build, data
            if extra:
                assert not report.exists()
                combined = result.stdout
            else:
                assert json.loads(report.read_text()) == data
                assert data["private_key_validated"] is False
                assert data["new_signing_key_generated"] is False
                assert data["signed_apk_produced"] is False
                assert data["android_runtime"] == "NOT_RUN"
                assert data["release_status"] == "NOT_BUILT"
                assert "PASS" not in data["status"]
                assert data["phone_installation_approval"] == "NOT_ESTABLISHED"
                if operation == "check_signing_setup":
                    assert data["apk_build"] == "NOT_REQUESTED"
                output_values = dict(line.split("=", 1) for line in output.read_text().splitlines())
                assert output_values == {"build_permitted": str(expected_build).lower(), "status": expected_status, "operation": data["operation"]}
                assert "keine APK gebaut" in summary.read_text()
                assert not list(root.rglob(".r13199-public-*"))
                combined = result.stdout + report.read_text() + output.read_text() + summary.read_text()
            for value in supplied.values():
                if len(value) >= 12 and value.strip() and not value.isspace():
                    assert value not in combined, "An input value was disclosed"
            if operation not in preflight.OPERATIONS:
                assert operation not in combined
            assert "Traceback" not in combined
            return data

    def reproduce_original():
        environment = dict(base_env)
        environment.update({name: "" for name in (*importer.SECRET_NAMES, importer.PIN_NAME)})
        result = subprocess.run([sys.executable, str(args.importer), "--check-config"], env=environment,
                                capture_output=True, text=True, timeout=20)
        assert result.returncode == 2
        assert result.stdout.strip() == "R13198_SIGNING_CONFIGURATION_MISSING"
        assert result.stderr == ""
    record("original Run44448376001 missing configuration reproduced with unchanged importer", reproduce_original)
    empty = {name: "" for name in (*importer.SECRET_NAMES, importer.PIN_NAME)}
    record("empty setup diagnostic completes without granting a build", lambda: call("check_signing_setup", empty, "SETUP_REQUIRED", 0, False))
    record("empty release request remains a failure", lambda: call("build_release", empty, "SETUP_REQUIRED", 2, False))
    for name in importer.SECRET_NAMES:
        supplied = dict(secret_values)
        supplied.pop(name)
        record("missing " + name + " is setup required", lambda supplied=supplied: call("check_signing_setup", supplied, "SETUP_REQUIRED", 0, False))
    without_pin = {k: v for k, v in secret_values.items() if k != importer.PIN_NAME}
    record("missing public pin cannot permit a release build", lambda: call("build_release", without_pin, "SETUP_REQUIRED", 2, False))
    record("blank public pin is listed as missing", lambda: call("check_signing_setup", {**secret_values, importer.PIN_NAME: " \t\n"}, "SETUP_REQUIRED", 0, False))
    invalid_cases = [
        ("malformed public pin", importer.PIN_NAME, "NEVER-PRINT-MALFORMED-PIN"),
        ("alias injection", "R139_ALIAS", "NEVER-PRINT-ALIAS\nBUILD_PERMITTED=true"),
        ("invalid Base64", "R139_P12_B64", "NEVER-PRINT-INVALID-BASE64!"),
        ("Unicode Base64 rejected without raw exception", "R139_P12_B64", "Geheim-\u00e4\u00f6\u00fc-NEVER-PRINT"),
        ("non-ASCII store password", "R139_STOREPASS", "NEVER-PRINT-PASSWORT-\u00e4\u00f6\u00fc"),
        ("backslash key password", "R139_KEYPASS", "NEVER-PRINT\\KEY-PASSWORD"),
        ("undersized decoded container", "R139_P12_B64", base64.b64encode(b"no-private-key").decode()),
    ]
    for name, variable, value in invalid_cases:
        for operation, rc in (("check_signing_setup", 0), ("build_release", 2)):
            record(name + " in " + operation,
                   lambda operation=operation, rc=rc, variable=variable, value=value:
                   call(operation, {**secret_values, variable: value}, "CONFIGURATION_INVALID", rc, False))
    record("format-only diagnostic never validates private key or permits build", lambda: call("check_signing_setup", secret_values, "CONFIG_PRESENT_NOT_KEY_VALIDATED", 0, False))
    record("format-only release setup permits subsequent strict key validation only", lambda: call("build_release", secret_values, "CONFIG_PRESENT_NOT_KEY_VALIDATED", 0, True))
    record("normalized uppercase and padded public pin accepted consistently", lambda: call("build_release", {**secret_values, importer.PIN_NAME: " \t" + secret_values[importer.PIN_NAME].upper() + "\n"}, "CONFIG_PRESENT_NOT_KEY_VALIDATED", 0, True))
    record("unknown operation is rejected without reflecting user input", lambda: call("SECRET-MALICIOUS-OPERATION\nvalue=true", secret_values, "REQUEST_INVALID", 2, False))
    record("unknown CLI option never echoes input", lambda: call("check_signing_setup", secret_values, "REQUEST_INVALID", 2, False, ["--NEVER-PRINT-CLI-SECRET"]))

    def input_unicode_failure():
        invalid = dict(secret_values)
        invalid["R139_STOREPASS"] = "surrogate-NEVER-PRINT-\udcff"
        report, rc = preflight.inspect_setup("check_signing_setup", invalid, importer)
        assert rc == 0 and report["status"] == "CONFIGURATION_INVALID"
        assert "surrogate-NEVER-PRINT" not in json.dumps(report)
    record("surrogate environment value produces only fixed public error", input_unicode_failure)

    def unknown_error():
        def rejected(env):
            raise importer.SigningError("NEVER-PRINT-UNKNOWN-SECRET")
        wrapped = types.SimpleNamespace(configuration=rejected, SigningError=importer.SigningError)
        report, rc = preflight.inspect_setup("check_signing_setup", secret_values, wrapped)
        assert rc == 0 and report["error_code"] == "CONFIGURATION_VALIDATION_FAILED"
        assert "NEVER-PRINT-UNKNOWN-SECRET" not in json.dumps(report)
    record("unexpected validator error code is sanitized", unknown_error)

    def io_failure():
        with tempfile.TemporaryDirectory(prefix="r13199-io-test-") as directory:
            result = subprocess.run([sys.executable, str(SCRIPT), "--operation", "check_signing_setup", "--importer", str(args.importer), "--report", directory],
                                    env={**base_env, **secret_values}, capture_output=True, text=True, timeout=20)
            assert result.returncode == 2
            assert json.loads(result.stdout)["status"] == "PREFLIGHT_EXECUTION_FAILED"
            assert result.stderr == ""
            assert directory not in result.stdout
            assert not list(Path(directory).iterdir())
    record("real report write failure stays failure even for setup check", io_failure)

    def bad_importer():
        with tempfile.TemporaryDirectory(prefix="r13199-bad-import-") as directory:
            path = Path(directory) / "importer.py"
            path.write_bytes(b"\xff\xfeNEVER-PRINT-INVALID-UTF8-SECRET")
            result = subprocess.run([sys.executable, str(SCRIPT), "--operation", "check_signing_setup", "--importer", str(path), "--report", str(Path(directory) / "report.json")],
                                    env=base_env, capture_output=True, text=True, timeout=20)
            assert result.returncode == 2
            assert json.loads(result.stdout)["status"] == "PREFLIGHT_EXECUTION_FAILED"
            assert "NEVER-PRINT" not in result.stdout + result.stderr
            assert result.stderr == ""
    record("invalid UTF-8 importer emits fixed execution failure", bad_importer)

    report = {
        "schema": "r13199.signing-setup-preflight-tests-v1",
        "status": "PASS",
        "scope": "CONFIGURATION_AND_WORKFLOW_OUTPUT_LOGIC_ONLY_NO_KEY_APK_OR_ANDROID_TEST",
        "test_count": len(cases), "tests": cases,
        "preflight_sha256": hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
        "unchanged_importer_sha256": hashlib.sha256(args.importer.read_bytes()).hexdigest(),
        "original_run_configuration_failure_reproduced": True,
        "private_keys_generated": False,
        "apk_built": False,
        "android_runtime_executed": False,
        "temporary_fixtures_removed": True,
    }
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": "PASS", "test_count": len(cases), "report": str(args.report)}))


if __name__ == "__main__":
    main()
