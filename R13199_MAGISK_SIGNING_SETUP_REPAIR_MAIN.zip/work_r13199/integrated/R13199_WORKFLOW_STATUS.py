#!/usr/bin/env python3
"""Distinguish a setup-only inspection from a fully completed signed build."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

REQUIRED_JOBS = ("SETUP_JOB", "BUILD_JOB", "GUI_JOB", "ROOT_JOB", "FINAL_GATE_JOB")
SETUP_STATUSES = {"SETUP_REQUIRED", "CONFIGURATION_INVALID", "CONFIG_PRESENT_NOT_KEY_VALIDATED"}


def evaluate(environment: dict[str, str]) -> tuple[dict, int]:
    operation = environment.get("OPERATION", "")
    jobs = {name: environment.get(name, "MISSING") for name in REQUIRED_JOBS}
    permitted = environment.get("BUILD_PERMITTED", "")
    setup_status = environment.get("SETUP_STATUS", "MISSING")
    report = {
        "schema": "r13199.workflow-status-v1", "revision": "R13.19.9",
        "operation": operation if operation in ("check_signing_setup", "build_release") else "INVALID",
        "github_run_id": environment.get("GITHUB_RUN_ID"),
        "status": "FAIL", "jobs": jobs, "setup_status": setup_status if setup_status in SETUP_STATUSES else "UNRECOGNIZED",
        "build_requested": operation == "build_release",
        "apk_built": True if jobs["BUILD_JOB"] == "success" else False if jobs["BUILD_JOB"] == "skipped" else None,
        "android_tests_executed": True if jobs["GUI_JOB"] == jobs["ROOT_JOB"] == "success" else False if jobs["GUI_JOB"] == jobs["ROOT_JOB"] == "skipped" else None,
        "android_tests_passed": jobs["GUI_JOB"] == jobs["ROOT_JOB"] == "success",
        "complete_ci_pass": False, "release_artifact_available": False,
        "physical_device_tested": False, "phone_installation_approval": "NOT_ESTABLISHED",
        "failures": [],
    }
    failures = report["failures"]
    if operation not in ("check_signing_setup", "build_release"):
        failures.append("UNKNOWN_OPERATION")
    elif operation == "check_signing_setup":
        if jobs["SETUP_JOB"] != "success":
            failures.append("SETUP_INSPECTION_JOB_NOT_SUCCESS")
        if setup_status not in SETUP_STATUSES:
            failures.append("SETUP_STATUS_OUTPUT_MISSING_OR_INVALID")
        if permitted != "false":
            failures.append("SETUP_ONLY_MUST_NOT_PERMIT_A_BUILD")
        for name in REQUIRED_JOBS[1:]:
            if jobs[name] != "skipped":
                failures.append("UNEXPECTED_JOB_EXECUTION_IN_SETUP_ONLY_MODE_" + name)
        if not failures:
            report["status"] = "SETUP_CHECK_COMPLETED_NO_APK"
    else:
        if jobs["SETUP_JOB"] != "success":
            failures.append("SIGNING_SETUP_NOT_READY")
            report["status"] = "SIGNED_BUILD_NOT_STARTED_SETUP_REJECTED"
        else:
            if permitted != "true" or setup_status != "CONFIG_PRESENT_NOT_KEY_VALIDATED":
                failures.append("SIGNED_BUILD_REQUEST_WITHOUT_VALID_SETUP_OUTPUTS")
            for name in REQUIRED_JOBS[1:]:
                if jobs[name] != "success":
                    failures.append("REQUIRED_JOB_NOT_SUCCESS_" + name)
            if not failures:
                report.update(status="SIGNED_BUILD_AND_ALL_CI_TESTS_PASSED",
                              complete_ci_pass=True, release_artifact_available=True)
    return report, 2 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path, default=Path("R13199_WORKFLOW_STATUS.json"))
    args = parser.parse_args()
    report, code = evaluate(dict(os.environ))
    args.report.parent.mkdir(parents=True, exist_ok=True)
    temp = args.report.with_suffix(".tmp")
    temp.write_text(json.dumps(report, indent=2) + "\n")
    temp.replace(args.report)
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        title = "Einrichtung geprüft – keine APK gebaut" if report["status"] == "SETUP_CHECK_COMPLETED_NO_APK" else "Ergebnis des angeforderten signierten Builds"
        if report["operation"] == "check_signing_setup":
            details = ("Dieser Lauf prüft ausschließlich die Signierkonfiguration. "
                       "Build, Android-Tests und APK-Veröffentlichung wurden nicht angefordert. "
                       "Ein grüner Vorbereitungsdurchlauf ist keine APK- oder Telefonfreigabe.")
        elif report["complete_ci_pass"]:
            details = ("Der signierte Build, alle 15 GUI-Fälle, der echte Installations-/Updatevertrag "
                       "und Root/Hide/Restore haben ihre verpflichtenden Jobs bestanden. "
                       "Eine Telefoninstallation wurde nicht ausgeführt.")
        else:
            details = ("Der angeforderte signierte Build ist nicht vollständig bestätigt. "
                       "Die fehlende Voraussetzung bzw. der fehlgeschlagene Job ist unten angegeben. "
                       "Es wird keine abgeschlossene APK-Freigabe behauptet.")
        text = "## " + title + "\n\n" + details + "\n\nStatus: `" + report["status"] + "`\n\n"
        text += "| Job | Ergebnis |\n|---|---|\n"
        for name, value in report["jobs"].items():
            safe_value = value if value in ("success", "failure", "cancelled", "skipped") else "MISSING_OR_INVALID"
            text += "| " + name + " | " + safe_value + " |\n"
        if report["failures"]:
            text += "\n" + "\n".join("- `" + item + "`" for item in report["failures"]) + "\n"
        with open(summary, "a", encoding="utf-8") as output:
            output.write(text)
    print(json.dumps({"status": report["status"], "complete_ci_pass": report["complete_ci_pass"], "failures": report["failures"]}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
