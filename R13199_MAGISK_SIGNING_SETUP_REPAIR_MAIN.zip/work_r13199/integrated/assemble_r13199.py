#!/usr/bin/env python3
"""Repair dispatch/setup orchestration; retain every existing product/test gate."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "work_r13199"
BASE = WORK / "evidence/R13198_RUN44448376001.yml"
NAME = "R13199_MAGISK_31100_SIGNING_SETUP_AND_VERIFIED_BUILD.yml"
PIN = "98e62ace4a989ab2311dc5f7186cf433cc63de69cfe0a6fd279e9b94ee5b4571"
CONFIG_JOB = "r13199-signing-setup"
BUILD_JOB = "r139-hardened-pair-build"
GUI_JOB = "r1313-gui-matrix"
ROOT_JOB = "r1314-root-hide-restore-avd"
GATE_JOB = "r1313-api-coverage-gate"


class WorkflowDumper(yaml.SafeDumper):
    pass


WorkflowDumper.add_representer(str, lambda dumper, value: dumper.represent_scalar("tag:yaml.org,2002:str", value, style="|" if "\n" in value else None))


def heredoc(path: Path, name: str, marker: str) -> str:
    source = path.read_text()
    assert source.endswith("\n") and "\n" + marker + "\n" not in source
    return "cat > " + name + " <<'" + marker + "'\n" + source + marker + "\n"


def main():
    assert hashlib.sha256(BASE.read_bytes()).hexdigest() == PIN
    original = yaml.safe_load(BASE.read_text())
    workflow = copy.deepcopy(original)
    workflow["name"] = "Magisk R13.19.9 - Einrichtung prüfen oder signierten APK-Build ausführen"
    workflow["run-name"] = "${{ inputs.operation == 'build_release' && 'R13.19.9 – Signierter APK-Build und vollständige Tests' || 'R13.19.9 – Einrichtung prüfen (keine APK)' }}"
    workflow["on"] = {"workflow_dispatch": {"inputs": {"operation": {
        "description": "check_signing_setup = nur Einrichtung prüfen; build_release = APK bauen und vollständig testen",
        "type": "choice", "required": True, "default": "check_signing_setup",
        "options": ["check_signing_setup", "build_release"],
    }}}}
    config_module = WORK / "config/R13199_SIGNING_SETUP_PREFLIGHT.py"
    importer = ROOT / "work_r13198/signing_impl/R13198_IMPORT_SIGNING.py"
    config_script = "set -euo pipefail\n"
    config_script += heredoc(importer, "R13198_IMPORT_SIGNING.py", "R13199_EXISTING_IMPORTER_PY")
    config_script += heredoc(config_module, "R13199_SIGNING_SETUP_PREFLIGHT.py", "R13199_SETUP_PREFLIGHT_PY")
    config_script += "python3 R13199_SIGNING_SETUP_PREFLIGHT.py --operation \"$R13199_OPERATION\" --importer R13198_IMPORT_SIGNING.py --report reports/R13199_SIGNING_SETUP.json\n"
    config = {
        "name": "R13.19.9 Signiereinrichtung prüfen – erzeugt keine APK",
        "runs-on": "ubuntu-24.04", "timeout-minutes": 5,
        "outputs": {
            "build_permitted": "${{ steps.setup.outputs.build_permitted }}",
            "status": "${{ steps.setup.outputs.status }}",
            "operation": "${{ steps.setup.outputs.operation }}",
        },
        "steps": [
            {"name": "Read signing setup and distinguish preparation from a build request", "id": "setup", "shell": "bash",
             "env": {
                 "R13199_OPERATION": "${{ inputs.operation }}",
                 "R139_P12_B64": "${{ secrets.MAGISK_HIDE_P12_BASE64 }}",
                 "R139_STOREPASS": "${{ secrets.MAGISK_HIDE_P12_PASSWORD }}",
                 "R139_KEYPASS": "${{ secrets.MAGISK_HIDE_P12_KEY_PASSWORD }}",
                 "R139_ALIAS": "${{ secrets.MAGISK_HIDE_P12_ALIAS }}",
                 "R13198_EXPECTED_SIGNER_SHA256": "${{ vars.MAGISK_HIDE_SIGNER_SHA256 }}",
             }, "run": config_script},
            {"name": "Publish public setup result only – no keys and no APK", "if": "always()", "uses": "actions/upload-artifact@v7",
             "with": {"name": "R13199_SIGNING_SETUP_REPORT_NO_APK", "path": "reports/R13199_SIGNING_SETUP.json", "if-no-files-found": "warn", "retention-days": 14}},
        ],
    }
    old_jobs = workflow["jobs"]
    workflow["jobs"] = {CONFIG_JOB: config, **old_jobs}
    build = workflow["jobs"][BUILD_JOB]
    build["needs"] = [CONFIG_JOB]
    build["if"] = "${{ inputs.operation == 'build_release' && needs.r13199-signing-setup.result == 'success' && needs.r13199-signing-setup.outputs.build_permitted == 'true' }}"
    aggregate = workflow["jobs"][GATE_JOB]
    aggregate["if"] = "${{ always() && inputs.operation == 'build_release' && needs.r139-hardened-pair-build.result == 'success' }}"
    # Product, signing, fixture, Android and final release-check scripts stay exact.
    status_module = WORK / "integrated/R13199_WORKFLOW_STATUS.py"
    status_script = "set -euo pipefail\n" + heredoc(status_module, "R13199_WORKFLOW_STATUS.py", "R13199_WORKFLOW_STATUS_PY")
    status_script += "python3 R13199_WORKFLOW_STATUS.py\n"
    workflow["jobs"]["r13199-workflow-result"] = {
        "name": "R13.19.9 Ergebnis – Vorbereitung und vollständigen Build getrennt ausweisen",
        "needs": [CONFIG_JOB, BUILD_JOB, GUI_JOB, ROOT_JOB, GATE_JOB],
        "if": "always()", "runs-on": "ubuntu-24.04", "timeout-minutes": 5,
        "steps": [
            {"name": "Summarize the requested operation without downloading absent build artifacts", "shell": "bash",
             "env": {
                 "OPERATION": "${{ inputs.operation }}",
                 "SETUP_JOB": "${{ needs.r13199-signing-setup.result }}",
                 "SETUP_STATUS": "${{ needs.r13199-signing-setup.outputs.status }}",
                 "BUILD_PERMITTED": "${{ needs.r13199-signing-setup.outputs.build_permitted }}",
                 "BUILD_JOB": "${{ needs.r139-hardened-pair-build.result }}",
                 "GUI_JOB": "${{ needs.r1313-gui-matrix.result }}",
                 "ROOT_JOB": "${{ needs.r1314-root-hide-restore-avd.result }}",
                 "FINAL_GATE_JOB": "${{ needs.r1313-api-coverage-gate.result }}",
             }, "run": status_script},
            {"name": "Publish truthful workflow status", "if": "always()", "uses": "actions/upload-artifact@v7",
             "with": {"name": "R13199_WORKFLOW_STATUS", "path": "R13199_WORKFLOW_STATUS.json", "if-no-files-found": "warn", "retention-days": 14}},
        ],
    }
    for job in original["jobs"]:
        assert workflow["jobs"][job]["steps"] == original["jobs"][job]["steps"], job + " scripts changed"
    output = WORK / "integrated" / NAME
    output.write_text(
        "# R13.19.9 fixes setup/dispatch handling of run44448376001.\n"
        "# Default: explicitly setup inspection only, no APK or Android tests.\n"
        "# build_release still requires the preserved signer and all R13.19.8 gates.\n"
        + yaml.dump(workflow, Dumper=WorkflowDumper, sort_keys=False, allow_unicode=True, width=110)
    )
    assert yaml.safe_load(output.read_text()) == workflow
    proof = {
        "failed_run": "44448376001", "baseline_workflow_sha256": PIN,
        "workflow_sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "all_existing_job_steps_byte_value_unchanged": True,
        "all_existing_signing_native_source_gui_root_and_release_gates_retained": True,
        "persistent_signing_required_for_build": True,
        "new_key_generation_or_research_fallback_added": False,
        "default_operation": "check_signing_setup", "default_operation_builds_apk": False,
        "new_github_run_executed": False, "new_android_run_executed": False,
    }
    (WORK / "integrated/R13199_ASSEMBLY_PROVENANCE.json").write_text(json.dumps(proof, indent=2) + "\n")
    print(json.dumps(proof, indent=2))


if __name__ == "__main__":
    main()
