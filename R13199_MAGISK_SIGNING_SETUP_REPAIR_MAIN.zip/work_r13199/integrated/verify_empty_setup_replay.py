#!/usr/bin/env python3
"""Run the exact new workflow scripts with the empty configuration seen on GitHub.

The public status job inputs below are simulated GitHub job outcomes. No native
build, Android test, APK release, or phone operation is represented as executed.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import yaml

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / "work_r13199"
WORKFLOW = WORK / "integrated/R13199_MAGISK_31100_SIGNING_SETUP_AND_VERIFIED_BUILD.yml"


def main():
    workflow = yaml.safe_load(WORKFLOW.read_text())
    runs = [step["run"] for job in workflow["jobs"].values() for step in job["steps"] if "run" in step]
    for script in runs:
        result = subprocess.run(["bash", "-n"], input=script, text=True, capture_output=True)
        assert result.returncode == 0, result.stderr
    setup_script = workflow["jobs"]["r13199-signing-setup"]["steps"][0]["run"]
    status_script = workflow["jobs"]["r13199-workflow-result"]["steps"][0]["run"]
    modules = {
        "R13199_EXISTING_IMPORTER_PY": ROOT / "work_r13198/signing_impl/R13198_IMPORT_SIGNING.py",
        "R13199_SETUP_PREFLIGHT_PY": WORK / "config/R13199_SIGNING_SETUP_PREFLIGHT.py",
        "R13199_WORKFLOW_STATUS_PY": WORK / "integrated/R13199_WORKFLOW_STATUS.py",
    }
    for marker, path in modules.items():
        script = status_script if marker == "R13199_WORKFLOW_STATUS_PY" else setup_script
        embedded = script.split("<<'" + marker + "'\n", 1)[1].split("\n" + marker + "\n", 1)[0] + "\n"
        assert embedded == path.read_text(), marker
        ast.parse(embedded)
    cases = []
    for operation, expected_code in [("check_signing_setup", 0), ("build_release", 2)]:
        with tempfile.TemporaryDirectory(prefix="r13199-empty-setup-") as temp:
            workspace = Path(temp)
            env = os.environ.copy()
            for name in ("R139_P12_B64", "R139_STOREPASS", "R139_KEYPASS", "R139_ALIAS", "R13198_EXPECTED_SIGNER_SHA256"):
                env[name] = ""
            env.update(R13199_OPERATION=operation, GITHUB_OUTPUT=str(workspace / "github_output"),
                       GITHUB_STEP_SUMMARY=str(workspace / "summary.md"), GITHUB_RUN_ID="local-orchestration-test")
            result = subprocess.run(["bash", "-c", setup_script], cwd=workspace, env=env, text=True, capture_output=True)
            assert result.returncode == expected_code, result.stdout + result.stderr
            setup = json.loads((workspace / "reports/R13199_SIGNING_SETUP.json").read_text())
            assert setup["status"] == "SETUP_REQUIRED" and setup["build_permitted"] is False
            assert setup["private_key_validated"] is False and setup["signed_apk_produced"] is False
            assert len(setup["missing_settings"]) == 5
            assert not any(workspace.rglob("*.apk")) and not any(workspace.rglob("*.p12"))
            outputs = dict(line.split("=", 1) for line in (workspace / "github_output").read_text().splitlines())
            assert outputs == {"build_permitted": "false", "status": "SETUP_REQUIRED", "operation": operation}
            env.update(OPERATION=operation, SETUP_JOB="success" if expected_code == 0 else "failure",
                       SETUP_STATUS=outputs["status"], BUILD_PERMITTED=outputs["build_permitted"],
                       BUILD_JOB="skipped", GUI_JOB="skipped", ROOT_JOB="skipped", FINAL_GATE_JOB="skipped")
            status = subprocess.run(["bash", "-c", status_script], cwd=workspace, env=env, text=True, capture_output=True)
            assert status.returncode == expected_code, status.stdout + status.stderr
            final = json.loads((workspace / "R13199_WORKFLOW_STATUS.json").read_text())
            expected_status = "SETUP_CHECK_COMPLETED_NO_APK" if expected_code == 0 else "SIGNED_BUILD_NOT_STARTED_SETUP_REJECTED"
            assert final["status"] == expected_status
            assert final["complete_ci_pass"] is False and final["release_artifact_available"] is False
            assert final["apk_built"] is False and final["android_tests_executed"] is False
            cases.append({"operation": operation, "setup_exit_code": result.returncode, "status_exit_code": status.returncode,
                          "setup": setup, "end_status": final, "no_apk_or_private_key_created": True,
                          "github_job_outcomes_simulated": True})
    report = {
        "scope": "EXACT_WORKFLOW_SCRIPTS_LOCALLY_EXECUTED_WITH_OBSERVED_EMPTY_ENVIRONMENT",
        "workflow_sha256": hashlib.sha256(WORKFLOW.read_bytes()).hexdigest(),
        "bash_scripts_parsed": len(runs), "new_embedded_modules_exact": True,
        "cases": cases, "all_checks_passed": True,
        "new_github_run_executed": False, "android_executed": False, "physical_device_tested": False,
    }
    out = WORK / "evidence/R13199_EMPTY_SETUP_REPLAY.json"
    out.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"all_checks_passed": True, "bash_scripts_parsed": len(runs), "workflow_sha256": report["workflow_sha256"],
                      "cases": [{"operation": x["operation"], "setup_exit_code": x["setup_exit_code"], "end_status": x["end_status"]["status"]} for x in cases]}, indent=2))


if __name__ == "__main__":
    main()
