#!/usr/bin/env python3
"""Independent status proof using synthetic job results, never Android results."""
from __future__ import annotations

import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

OUTPUT = Path(__file__).parent
JOBS = ("SETUP_JOB", "BUILD_JOB", "GUI_JOB", "ROOT_JOB", "FINAL_GATE_JOB")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("module", type=Path)
    args = parser.parse_args()
    spec = importlib.util.spec_from_file_location("reviewed_workflow_status", args.module)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    results = []
    release = {key: "success" for key in JOBS}
    release.update(OPERATION="build_release", BUILD_PERMITTED="true", SETUP_STATUS="CONFIG_PRESENT_NOT_KEY_VALIDATED", GITHUB_RUN_ID="synthetic-test-only")
    setup = {key: "skipped" for key in JOBS}
    setup.update(OPERATION="check_signing_setup", SETUP_JOB="success", BUILD_PERMITTED="false", SETUP_STATUS="SETUP_REQUIRED", GITHUB_RUN_ID="synthetic-test-only")

    def check(name, env, expected_success, expected_complete_ci=False):
        report, code = module.evaluate(env)
        assert (code == 0) is expected_success, (name, code, report)
        assert report["complete_ci_pass"] is expected_complete_ci, (name, report)
        assert report["release_artifact_available"] is expected_complete_ci, (name, report)
        assert report["physical_device_tested"] is False
        assert report["phone_installation_approval"] == "NOT_ESTABLISHED"
        if expected_complete_ci:
            assert env["OPERATION"] == "build_release"
            assert all(env.get(job) == "success" for job in JOBS)
            assert env["BUILD_PERMITTED"] == "true"
            assert env["SETUP_STATUS"] == "CONFIG_PRESENT_NOT_KEY_VALIDATED"
        if expected_success and env["OPERATION"] == "check_signing_setup":
            assert report["status"] == "SETUP_CHECK_COMPLETED_NO_APK"
            assert report["apk_built"] is False
            assert report["android_tests_executed"] is False
            assert report["android_tests_passed"] is False
        results.append({"case": name, "passed": True, "expected_process_success": expected_success, "expected_complete_ci_pass": expected_complete_ci})

    check("all release requirements succeeded", release, True, True)
    check("missing signing setup inspected without release claim", setup, True)
    for status in ("CONFIGURATION_INVALID", "CONFIG_PRESENT_NOT_KEY_VALIDATED"):
        check("setup-only status " + status, {**setup, "SETUP_STATUS": status}, True)
    # Every missing, cancelled or failed prerequisite independently denies release.
    for job in JOBS:
        for state in ("failure", "cancelled", "skipped", None, ""):
            check("release " + job + "=" + str(state), {**release, job: state}, False)
        missing = copy.deepcopy(release)
        missing.pop(job)
        check("release lacks " + job, missing, False)
    # An unexpected actual job execution must not be hidden by setup-mode labeling.
    for job in JOBS[1:]:
        for state in ("success", "failure", "cancelled", None):
            check("setup-only unexpected " + job + "=" + str(state), {**setup, job: state}, False)
    for seed_name, seed in (("release", release), ("setup", setup)):
        for key in ("OPERATION", "BUILD_PERMITTED", "SETUP_STATUS", "SETUP_JOB"):
            missing = copy.deepcopy(seed)
            missing.pop(key)
            check(seed_name + " missing output " + key, missing, False)
            check(seed_name + " null output " + key, {**seed, key: None}, False)
    for permitted in ("false", True, "TRUE", "yes"):
        check("release invalid permission output " + str(permitted), {**release, "BUILD_PERMITTED": permitted}, False)
    for permitted in ("true", False, "FALSE", "no"):
        check("setup invalid permission output " + str(permitted), {**setup, "BUILD_PERMITTED": permitted}, False)
    for status in ("SETUP_REQUIRED", "CONFIGURATION_INVALID", "PASS", "UNKNOWN"):
        check("release rejects incomplete/unrecognized setup " + status, {**release, "SETUP_STATUS": status}, False)
    for operation in ("auto", "release", "", "unknown\ncomplete_ci_pass=true"):
        check("unknown operation rejected " + repr(operation), {**release, "OPERATION": operation}, False)
    # The exact incident is one root cause; no artifact retrieval is needed here.
    incident = {**setup, "OPERATION": "build_release", "SETUP_JOB": "failure"}
    check("run44448376001 missing setup refuses release", incident, False)
    report, _ = module.evaluate(incident)
    assert report["status"] == "SIGNED_BUILD_NOT_STARTED_SETUP_REJECTED"
    assert report["failures"] == ["SIGNING_SETUP_NOT_READY"]
    output = {
        "revision": "R13.19.9", "scope": "SYNTHETIC_FINAL_STATUS_FAULT_CASES_NOT_ANDROID_EXECUTION",
        "module_sha256": hashlib.sha256(args.module.read_bytes()).hexdigest(),
        "test_count": len(results), "all_tests_passed": True,
        "cases": results, "physical_device_tested": False, "new_github_run_executed": False,
    }
    (OUTPUT / "FINAL_STATUS_FAILURE_REVIEW.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({key: value for key, value in output.items() if key != "cases"}, indent=2))


if __name__ == "__main__":
    main()
