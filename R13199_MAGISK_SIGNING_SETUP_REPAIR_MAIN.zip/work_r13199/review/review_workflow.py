#!/usr/bin/env python3
"""Independently check job control and preservation; never simulate Android PASS."""
from __future__ import annotations

import argparse
import ast
import hashlib
import itertools
import json
from pathlib import Path
import re
import subprocess
import yaml

ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / "work_r13198/integrated/R13198_MAGISK_31100_PERSISTENT_SIGNING_INSTALL_UPDATE.yml"
OUTPUT = Path(__file__).parent
PRE = "r13199-signing-setup"
BUILD = "r139-hardened-pair-build"
GUI = "r1313-gui-matrix"
ROOTED = "r1314-root-hide-restore-avd"
AGG = "r1313-api-coverage-gate"
FINAL = "r13199-workflow-result"
STATES = ("success", "failure", "cancelled", "skipped")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def condition(expression, operation, needs, implicit_success):
    """Evaluate only the simple supported Boolean condition subset, without eval."""
    expression = expression.strip()
    if expression.startswith("${{") and expression.endswith("}}"):
        expression = expression[3:-2].strip()
    explicit_status = bool(re.search(r"\b(always|cancelled|success|failure)\s*\(", expression))
    source = re.sub(r"\binputs\.operation\b", lambda _: json.dumps(operation), expression)
    def replace_need(match):
        item = needs.get(match[1], {})
        if match[2].startswith("outputs."):
            value = item.get("outputs", {}).get(match[2][8:], "")
        else:
            value = item.get("result", "")
        return json.dumps(value)
    source = re.sub(r"\bneeds\.([A-Za-z_][A-Za-z0-9_-]*)\.(outputs\.[A-Za-z_][A-Za-z0-9_-]*|result)\b", replace_need, source)
    source = source.replace("always()", "True").replace("success()", str(implicit_success))
    source = source.replace("cancelled()", "False").replace("failure()", str(not implicit_success))
    source = source.replace("&&", " and ").replace("||", " or ")
    source = re.sub(r"!(?!=)", " not ", source)
    tree = ast.parse(source.strip(), mode="eval")
    def walk(node):
        if isinstance(node, ast.Expression):
            return walk(node.body)
        if isinstance(node, ast.Constant) and type(node.value) in (str, bool):
            return node.value
        if isinstance(node, ast.BoolOp) and isinstance(node.op, (ast.And, ast.Or)):
            values = [bool(walk(value)) for value in node.values]
            return all(values) if isinstance(node.op, ast.And) else any(values)
        if isinstance(node, ast.Compare) and len(node.ops) == 1 and isinstance(node.ops[0], (ast.Eq, ast.NotEq)):
            left, right = walk(node.left), walk(node.comparators[0])
            return left == right if isinstance(node.ops[0], ast.Eq) else left != right
        if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.Not):
            return not walk(node.operand)
        raise AssertionError("Unsupported expression construct: " + ast.dump(node))
    return bool(walk(tree)) and (explicit_status or implicit_success)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workflow", type=Path)
    args = parser.parse_args()
    workflow = yaml.safe_load(args.workflow.read_text())
    baseline = yaml.safe_load(BASE.read_text())
    jobs, old = workflow["jobs"], baseline["jobs"]
    assert set(jobs) == set(old) | {PRE, FINAL}, set(jobs)
    dispatch = workflow["on"]["workflow_dispatch"]["inputs"]["operation"]
    assert dispatch["type"] == "choice"
    assert dispatch["default"] == "check_signing_setup"
    assert set(dispatch["options"]) == {"check_signing_setup", "build_release"}
    assert dispatch["required"] is True
    assert "run-name" in workflow and "inputs.operation" in workflow["run-name"]
    assert "keine APK" in workflow["run-name"] or "no APK" in workflow["run-name"]
    assert workflow["permissions"] == baseline["permissions"]
    # Root may change version/name labels; executable content and every action
    # configuration remain exactly as in the independently reviewed R13.19.8.
    preservation = {}
    for job_id in old:
        before = old[job_id]["steps"]
        after = jobs[job_id]["steps"]
        assert len(before) == len(after), (job_id, len(before), len(after))
        for i, (left, right) in enumerate(zip(before, after)):
            functional_left = {k: v for k, v in left.items() if k != "name"}
            functional_right = {k: v for k, v in right.items() if k != "name"}
            assert functional_left == functional_right, (job_id, i, "functional step changed")
        preservation[job_id] = {"original_step_count": len(before), "functional_steps_unchanged": True}
    assert jobs[GUI] == old[GUI], "GUI job must remain fully unchanged"
    assert jobs[ROOTED] == old[ROOTED], "Root job must remain fully unchanged"
    before_source = old[BUILD]["steps"][2:30]
    after_source = jobs[BUILD]["steps"][2:30]
    assert before_source == after_source and len(before_source) == 28
    needs_build = jobs[BUILD]["needs"]
    assert needs_build == PRE or needs_build == [PRE]
    assert set(jobs[AGG]["needs"]) == set(old[AGG]["needs"])
    assert set(jobs[FINAL]["needs"]) == {PRE, BUILD, GUI, ROOTED, AGG}
    assert jobs[FINAL]["if"].strip().removeprefix("${{").removesuffix("}}").strip() == "always()"
    assert all(not step.get("uses", "").startswith("actions/download-artifact") for step in jobs[FINAL]["steps"])
    scripts = 0
    for job_id, job in jobs.items():
        assert job.get("continue-on-error") is not True, job_id
        for i, step in enumerate(job["steps"]):
            assert step.get("continue-on-error") is not True, (job_id, i)
            if "run" in step:
                result = subprocess.run(["bash", "-n"], input=step["run"], text=True, capture_output=True)
                assert result.returncode == 0, (job_id, i, result.stderr)
                scripts += 1
    conditions = {job: jobs[job]["if"] for job in (BUILD, AGG, FINAL)}
    build_cases = 0
    for operation, pre_result, permitted in itertools.product(("check_signing_setup", "build_release", "INVALID"), STATES, ("true", "false", "")):
        needs = {PRE: {"result": pre_result, "outputs": {"build_permitted": permitted}}}
        actual = condition(conditions[BUILD], operation, needs, pre_result == "success")
        expected = operation == "build_release" and pre_result == "success" and permitted == "true"
        assert actual == expected, ("build", operation, pre_result, permitted, actual, expected)
        build_cases += 1
    aggregate_cases = 0
    for operation, build_result, gui_result, root_result in itertools.product(("check_signing_setup", "build_release", "INVALID"), STATES, STATES, STATES):
        needs = {BUILD: {"result": build_result}, GUI: {"result": gui_result}, ROOTED: {"result": root_result}}
        actual = condition(conditions[AGG], operation, needs, all(item["result"] == "success" for item in needs.values()))
        expected = operation == "build_release" and build_result == "success"
        assert actual == expected, ("aggregate", operation, build_result, gui_result, root_result, actual, expected)
        aggregate_cases += 1
    report = {
        "revision": "R13.19.9", "scope": "STATIC_WORKFLOW_AND_BOOLEAN_CONTROL_REVIEW_NOT_ANDROID_EXECUTION",
        "workflow_sha256": sha(args.workflow), "baseline_sha256": sha(BASE),
        "functional_step_preservation": preservation,
        "all_28_product_source_steps_unchanged": True,
        "entire_15_case_gui_job_unchanged": True,
        "entire_root_install_update_hide_restore_job_unchanged": True,
        "preparation_explicit_default_and_run_name": True,
        "build_condition_cases": build_cases, "aggregate_condition_cases": aggregate_cases,
        "aggregate_still_runs_for_failed_cancelled_or_skipped_tests_after_successful_build": True,
        "separate_unconditional_final_status_job_present": True,
        "final_status_job_has_no_artifact_downloads": True,
        "bash_scripts_parsed": scripts,
        "new_github_run_executed": False, "physical_phone_tested": False,
    }
    (OUTPUT / "WORKFLOW_CONTROL_REVIEW.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
