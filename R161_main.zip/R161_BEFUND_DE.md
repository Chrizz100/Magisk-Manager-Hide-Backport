# R16.1 – Ergebnis des nächsten Arbeitsschritts

**Gerät:** Redmi Note 10 Pro (`sweet`) · Android 13 · MIUI 14 · Linux `4.14.190-perf-g7da93debc0ee`.

**Neu programmiert:** Vollständiges minimales Android-Gradle-App-Projekt, das das separat gebaute Android/ARM64-Programm aus `nativeLibraryDir` per `ProcessBuilder` startet. Dazu kamen die aus dem tatsächlichen Betriebssystem abgefragte `uid/euid`, eine SHA-256-Prüfung des Binaries vor dem Start und ein strenger Auswerteparser. Die App fordert keine besonderen Berechtigungen an, flasht nichts und ruft keine SU-Befehle auf. Der APK-Build wird in der neuen GitHub-Action ausgeführt; die Android-Ausführung ist bisher **nicht auf dem Redmi getestet**.

**Zusätzliche Verbesserung gegenüber R16.0:** Das Android-Gradle-Paket lässt die `.so`-benannte PIE-Datei bei der Installation in `nativeLibraryDir` extrahieren und verhindert nachträgliches Stripping des geprüften Programms (`keepDebugSymbols`). Dadurch bleibt der beim Build gesetzte Binärhash im APK erhalten.

**Lokale Prüfung:** 71 bestehende R16.0-Regressionsprüfungen, 11 neue Java-Parser-Prüfungen und 5 neue negative Paketprüfungen = **87/87 bestanden**. Workflow-YAML und alle Shell-Blöcke syntaktisch geprüft. Der neue Code wurde auf Host/Linux getestet, nicht als vollständige APK gebaut. Ein künstliches Paket mit dem offiziellen R16.0-ARM64-ELF durchlief die statische ELF/ZIP-Verifikation; das ist ausdrücklich **keine installierbare APK**.

**Technischer Stand:** Nur Diagnose/Verifikation. **Kein GhostLock-Exploit**, kein temporärer SU-Zugang, kein MagiskSU, kein KernelSU, kein Bootloader- oder Recovery-Eingriff. Auch eine passende Kernelkennung beweist nicht, dass die gesicherte Bootdatei bytegleich mit der aktuellen Partition ist.

**Nächster Prüfpunkt:** R16.1 in GitHub Actions starten, gebaute APK prüfen und erst dann den nativen Prozessstart auf einem echten Redmi verifizieren, bevor an eine Magisk-Übernahme gedacht wird.

**Referenzen:**
- https://developer.android.com/privacy-and-security/security-best-practices
- https://developer.android.com/reference/tools/gradle-api/8.11/com/android/build/api/dsl/JniLibsPackaging
- https://github.com/YuKongA/ghostlock-app/blob/main/build.gradle.kts
- https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/43067177922
