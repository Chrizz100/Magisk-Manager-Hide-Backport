# R16.1 – Android-Prozessstart des bestehenden ARM64-Nativprogramms

## Was technisch neu ist

R16.0 lieferte ein gültiges Android/ARM64-PIE als eigenständige .so-benannte EXE,
aber **noch keine App, die das Programm unter Android starten kann**.
R16.1 legt eine vollständige, isolierte Android-App mit `ProcessBuilder` an.
Die App nutzt den Installationspfad `applicationInfo.nativeLibraryDir` (nicht den
beschreibbaren App-Datenordner), validiert den SHA-256-Hash des Programms und
ruft `--preflight` auf. Der native Prozess liest selbst `uname` und Android-Properties
und gibt zusätzlich echte Prozess-UID und effektive UID aus. Parser und UI
warten mit Timeout, erkennen falsche Ausgaben und leiten **keinen Root-Erfolg** ab.

### Grenzen / keine Behauptungen
- **Kein GhostLock-Kernel-Exploit implementiert.**
- Keine Root-Rechte, kein SU-Dienst, kein Magisk-Start, kein Boot-Flash.
- `IDENTITY_OK_BACKEND_MISSING` ist NUR eine Geräte-KENNUNG, keine bytegleiche boot.img.
- Die Android-ARM64-Ausführung auf dem echten Redmi steht bis zum Gerätetest aus.
- Diese separate Test-App ist nicht Magisk R13.4 und überschreibt Magisk nicht.
- Kein Shizuku, kein Termux, kein PC und keine besonderen Android-Berechtigungen für den App-Test.

### Installation / Freigabe
Nur die von GitHub Actions erzeugte `R161-SWEET-android-process-test.apk` ist eine
installierbare App. `main.zip` ist Quellcode und `*.yml` der GitHub-Workflow.
Die App selbst besteht aus einem Button für eine native read-only-Kompatibilitätsprüfung.
Es ist ausdrücklich KEINE One-Click-Root-APK.

### GitHub Actions
Die YAML nach `.github/workflows/r161-android-process-test.yml` kopieren,
`main.zip` unter dem Namen `main.zip` ins Hauptverzeichnis des Repos legen
und die Action starten. Bestehende Magisk-Dateien nicht ersetzen.

### Warum nativeLibraryDir?
Android 10+ verbietet die Ausführung aus einem beschreibbaren App-Privatordner
für reguläre Apps. APK-Library-Extraktion geschieht durch
`packaging { jniLibs { useLegacyPackaging = true } }` und lib*.so im passenden ABI.

Offizielle Android-Dokumentation:
https://developer.android.com/privacy-and-security/security-best-practices
https://developer.android.com/reference/tools/gradle-api/8.2/com/android/build/api/variant/JniLibsApkPackaging
