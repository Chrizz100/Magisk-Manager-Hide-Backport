package dev.sweet414

import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * R15.9: Executes ONLY the non-privileged sweet414 archive audit tool.
 * Mirrors the upstream app/native PROCESS boundary, not the upstream exploit.
 * No root request, no writable boot partition, no kernel-memory interface.
 */
class NativeArchiveAuditRunner(
    private val libraryDir: File,
    private val outputDir: File,
    private val expectedSha256: String
) {
    data class ArchivedAssessment(
        val verdict: String,
        val legacySymbolsFound: Boolean,
        val archivedPathFound: Boolean,
        val archiveSha256: String,
        val liveBootMatchConfirmed: Boolean = false,
        val rootAvailable: Boolean = false,
        val rootConfirmed: Boolean = false
    )

    class AuditFailure(message: String) : IllegalStateException(message)

    fun audit(timeoutSeconds: Long = 6): ArchivedAssessment {
        val exe = File(libraryDir, "libsweet414_preflight.so")
        if (!exe.isFile || !exe.canExecute()) throw AuditFailure("AUDIT_EXECUTABLE_MISSING")
        if (!Regex("[a-fA-F0-9]{64}").matches(expectedSha256)) throw AuditFailure("INVALID_EXPECTED_SHA")
        val actualHash = sha256(exe)
        if (!actualHash.equals(expectedSha256, ignoreCase = true)) throw AuditFailure("AUDIT_EXECUTABLE_HASH_MISMATCH")
        outputDir.mkdirs()
        val output = File.createTempFile("sweet414-audit-", ".txt", outputDir)
        try {
            // No generic shell, no arguments supplied by the user. Only the fixed read-only verb.
            val p = ProcessBuilder(exe.absolutePath, "--archive-audit")
                .redirectErrorStream(true)
                .redirectOutput(output)
                .start()
            if (!p.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                p.waitFor(2, TimeUnit.SECONDS)
                throw AuditFailure("AUDIT_PROCESS_TIMEOUT")
            }
            if (p.exitValue() != 0) throw AuditFailure("AUDIT_PROCESS_NONZERO_EXIT")
            if (output.length() > 4096) throw AuditFailure("AUDIT_OUTPUT_TOO_LARGE")
            val lines = output.readLines(Charsets.UTF_8)
            val fields = mutableMapOf<String, String>()
            for (line in lines) {
                val split = line.indexOf('=')
                if (split <= 0) throw AuditFailure("AUDIT_OUTPUT_BAD_FORMAT")
                val k = line.substring(0, split)
                val v = line.substring(split + 1)
                if (k !in expectedFields || k in fields) throw AuditFailure("AUDIT_OUTPUT_BAD_KEYS")
                fields[k] = v
            }
            if (fields.keys != expectedFields) throw AuditFailure("AUDIT_OUTPUT_INCOMPLETE")
            if (fields["archive_4_14_route"] != "ARCHIVED_4_14_PATH_FOUND_LIVE_KERNEL_UNCHECKED")
                throw AuditFailure("AUDIT_NOT_SUPPORTED_ARCHIVED_VERDICT")
            fun strictBool(key: String): Boolean = when (fields[key]) {
                "true" -> true
                "false" -> false
                else -> throw AuditFailure("AUDIT_OUTPUT_INVALID_BOOL")
            }
            val symbols = strictBool("legacy_symbol_names_identified")
            val path = strictBool("archived_futex_path_observed")
            if (!symbols || !path) throw AuditFailure("AUDIT_ARCHIVED_EVIDENCE_INCOMPLETE")
            if (fields["archive_source"] != "SHA256_PINNED_STOCK_BOOT_SNAPSHOT")
                throw AuditFailure("AUDIT_BAD_EVIDENCE_SOURCE")
            if (!fields["archive_boot_sha256"].equals(PINNED_STOCK_BOOT_SHA256, ignoreCase = true))
                throw AuditFailure("AUDIT_ARCHIVE_SHA_MISMATCH")
            if (strictBool("live_boot_match_confirmed"))
                throw AuditFailure("ARCHIVE_AUDIT_CANNOT_CLAIM_LIVE_BOOT")
            // An archive report cannot prove any live root. Abort if it tries to claim otherwise.
            if (strictBool("root_backend_available") || strictBool("root_confirmed"))
                throw AuditFailure("ARCHIVE_AUDIT_CANNOT_CLAIM_ROOT")
            return ArchivedAssessment(fields.getValue("archive_4_14_route"), symbols, path, PINNED_STOCK_BOOT_SHA256)
        } finally {
            output.delete()
        }
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { stream ->
            val buffer = ByteArray(64 * 1024)
            while (true) {
                val n = stream.read(buffer)
                if (n < 0) break
                digest.update(buffer, 0, n)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        private const val PINNED_STOCK_BOOT_SHA256 = "4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015"
        private val expectedFields = setOf(
            "archive_4_14_route", "legacy_symbol_names_identified",
            "archived_futex_path_observed", "archive_source", "archive_boot_sha256",
            "live_boot_match_confirmed", "root_backend_available", "root_confirmed"
        )
    }
}
