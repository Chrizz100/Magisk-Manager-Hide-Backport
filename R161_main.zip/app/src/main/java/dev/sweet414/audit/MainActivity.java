package dev.sweet414.audit;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Single-button Android process smoke-test. NO button to root a device. */
public final class MainActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView result;
    private Button run;
    private Button share;
    private String lastText = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = Math.round(20 * getResources().getDisplayMetrics().density);
        layout.setPadding(pad,pad,pad,pad);
        TextView title = new TextView(this);
        title.setText("GhostLock / SWEET – R16.1");
        title.setTextSize(21);
        title.setTypeface(null, Typeface.BOLD);
        layout.addView(title);
        TextView intro = new TextView(this);
        intro.setText("Prüft ausschließlich den Start des nativen ARM64-Programms und die Gerätekennung. " +
            "Erzeugt keine Root-Rechte und verändert Android nicht.");
        intro.setPadding(0,pad/2,0,pad/2);
        layout.addView(intro);
        run = new Button(this); run.setText("Native-Laufzeit prüfen"); layout.addView(run);
        share = new Button(this); share.setText("Ergebnis teilen"); share.setEnabled(false); layout.addView(share);
        result = new TextView(this);
        result.setTextIsSelectable(true);
        result.setPadding(0,pad/2,0,0);
        layout.addView(result);
        ScrollView scroll = new ScrollView(this); scroll.addView(layout); setContentView(scroll);
        run.setOnClickListener(v -> runDiagnostic());
        share.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain"); i.putExtra(Intent.EXTRA_TEXT,lastText);
            startActivity(Intent.createChooser(i,"Prüfergebnis teilen"));
        });
    }
    private void runDiagnostic() {
        run.setEnabled(false); share.setEnabled(false);
        result.setText("ARM64-Prozess wird geprüft …");
        worker.execute(() -> {
            String message;
            try {
                NativeOutputParser.Result x = NativeLauncher.launch(this);
                message = "Android-Prozess gestartet: JA\n" +
                    "Prüfurteil: " + x.verdict + "\n" +
                    "Gerät: " + x.device + "\n" +
                    "Kernel: " + x.kernel + "\n" +
                    "Android: " + x.android + "\n" +
                    "MIUI: " + x.miui + "\n" +
                    "Prozess-UID/EUID: " + x.uid + "/" + x.euid + "\n" +
                    "Kennung zur Archiv-Sicherung passend: " + (x.identityMatched ? "JA" : "NEIN") + "\n" +
                    "Live-boot.img bytegleich mit Archiv: NICHT GEPRÜFT\n" +
                    "Temporärer Root: NEIN\n" +
                    "Magisk 31100 gestartet: NEIN";
            } catch (Exception e) {
                message = "Android-Prozessprüfung fehlgeschlagen: " + e.getClass().getSimpleName() +
                    " – " + e.getMessage() + "\nKeine Root-Rechte erzeugt.";
            }
            String completed = message;
            runOnUiThread(() -> { result.setText(completed); lastText = completed; run.setEnabled(true); share.setEnabled(true); });
        });
    }
    @Override protected void onDestroy() { worker.shutdownNow(); super.onDestroy(); }
}
