package dev.sweet414.audit;

import android.content.Context;
import java.io.File;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.MessageDigest;
import java.util.concurrent.TimeUnit;

/** Only reads the running Android device identity. No root, kernel writes or shell. */
public final class NativeLauncher {
    private NativeLauncher() { }

    public static NativeOutputParser.Result launch(Context context) throws Exception {
        File lib = new File(context.getApplicationInfo().nativeLibraryDir, "libsweet414_preflight.so");
        if (!lib.isFile() || !lib.canExecute()) throw new IllegalStateException("LIBRARY_NOT_EXTRACTED_OR_EXECUTABLE");
        String actual = sha256(lib);
        if (!actual.equalsIgnoreCase(BuildConfig.NATIVE_SHA256)) throw new IllegalStateException("BINARY_SHA256_MISMATCH");

        File out = File.createTempFile("sweet414-process-", ".txt", context.getCacheDir());
        try {
            Process p = new ProcessBuilder(lib.getAbsolutePath(), "--preflight")
                    .redirectErrorStream(true)
                    .redirectOutput(out)
                    .start();
            if (!p.waitFor(8, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                p.waitFor(2,TimeUnit.SECONDS);
                throw new IllegalStateException("NATIVE_PROCESS_TIMEOUT");
            }
            if (out.length() > 8192) throw new IllegalStateException("NATIVE_OUTPUT_TOO_LARGE");
            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
            try (InputStream stream = new FileInputStream(out)) {
                byte[] block = new byte[4096];
                int n;
                while ((n = stream.read(block)) >= 0) {
                    if (n > 0) bytes.write(block,0,n);
                    if (bytes.size() > 8192) throw new IllegalStateException("NATIVE_OUTPUT_TOO_LARGE");
                }
            }
            String data = new String(bytes.toByteArray(), StandardCharsets.UTF_8);
            return NativeOutputParser.parse(data,p.exitValue());
        } finally {
            out.delete();
        }
    }

    private static String sha256(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream stream = Files.newInputStream(file.toPath())) {
            byte[] buffer = new byte[64 * 1024];
            for (int n; (n = stream.read(buffer)) >= 0; ) if (n > 0) digest.update(buffer,0,n);
        }
        StringBuilder result = new StringBuilder(64);
        for (byte b : digest.digest()) result.append(String.format(java.util.Locale.ROOT,"%02x",b & 0xff));
        return result.toString();
    }
}
