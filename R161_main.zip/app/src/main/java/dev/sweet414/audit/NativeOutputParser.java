package dev.sweet414.audit;

import java.util.HashMap;
import java.util.Collections;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Validates the --preflight response from the read-only R16.1 ARM64 executable. */
public final class NativeOutputParser {
    private NativeOutputParser() { }
    public static final class Result {
        public final String verdict;
        public final String kernel;
        public final String device;
        public final String android;
        public final String miui;
        public final int uid;
        public final int euid;
        public final boolean identityMatched;
        Result(String verdict, Map<String,String> fields, int uid, int euid) {
            this.verdict = verdict;
            this.kernel = fields.get("kernel");
            this.device = fields.get("device");
            this.android = fields.get("android");
            this.miui = fields.get("miui");
            this.uid = uid;
            this.euid = euid;
            this.identityMatched = "IDENTITY_OK_BACKEND_MISSING".equals(verdict);
        }
    }
    private static final Set<String> REQUIRED = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "kernel", "device", "android", "miui", "verdict",
        "root_backend_available", "root_confirmed", "process_uid", "process_euid"
    )));
    private static final Map<String,Integer> EXIT_CODES = new HashMap<>();
    static {
        EXIT_CODES.put("DEVICE_MISMATCH", 20);
        EXIT_CODES.put("FIRMWARE_MISMATCH", 21);
        EXIT_CODES.put("KERNEL_MISMATCH", 22);
        EXIT_CODES.put("ARCH_MISMATCH", 23);
        EXIT_CODES.put("IDENTITY_OK_BACKEND_MISSING", 24);
    }

    public static Result parse(String output, int exitCode) {
        if (output == null || output.length() > 8192) throw new IllegalArgumentException("OUTPUT_TOO_LARGE");
        Map<String,String> fields = new HashMap<>();
        for (String line : output.split("\r?\n")) {
            if (line.isEmpty()) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) throw new IllegalArgumentException("BAD_OUTPUT_LINE");
            String key = line.substring(0,eq), value = line.substring(eq+1);
            if (!REQUIRED.contains(key) && !"reason".equals(key)) throw new IllegalArgumentException("UNKNOWN_OUTPUT_KEY");
            if (value.length() > 512) throw new IllegalArgumentException("OUTPUT_VALUE_TOO_LARGE");
            if ("reason".equals(key)) continue; // repeated informational messages are allowed
            if (fields.putIfAbsent(key,value) != null) throw new IllegalArgumentException("DUPLICATE_FIELD");
        }
        if (!fields.keySet().containsAll(REQUIRED)) throw new IllegalArgumentException("MISSING_FIELDS");
        String verdict = fields.get("verdict");
        Integer expectedExit = EXIT_CODES.get(verdict);
        if (expectedExit == null || expectedExit != exitCode) throw new IllegalArgumentException("EXIT_VERDICT_MISMATCH");
        if (!"false".equals(fields.get("root_backend_available")) ||
            !"false".equals(fields.get("root_confirmed"))) {
            throw new IllegalArgumentException("ROOT_MUST_NOT_BE_CLAIMED");
        }
        int uid = parseUid(fields.get("process_uid"));
        int euid = parseUid(fields.get("process_euid"));
        // This is deliberately a non-root, non-exploit diagnostic. Report any unexpected
        // privileged identity as an error rather than a successful root transition.
        if (uid == 0 || euid == 0) throw new IllegalArgumentException("UNEXPECTED_PRIVILEGED_DIAGNOSTIC");
        return new Result(verdict, fields, uid, euid);
    }
    private static int parseUid(String text) {
        if (!text.matches("[0-9]{1,9}")) throw new IllegalArgumentException("INVALID_UID");
        try { return Integer.parseInt(text); }
        catch (NumberFormatException e) { throw new IllegalArgumentException("INVALID_UID",e); }
    }
}
