#!/usr/bin/env python3
"""R14.1: Reproducible, READ-ONLY AArch64 kernel-CVE pattern audit.

This is NOT an exploit, profile generator, rooting tool, or device test.
It is deliberately pinned to one archived Xiaomi sweet stock boot image.
The audit proves a source-like instruction pattern in that offline image;
it does not prove that the *currently installed* image is the same, nor
that any privilege escalation can be carried out.

Usage:
    python3 R141_GHOSTLOCK_BINARY_AUDIT.py SWEET_STOCK_REFERENZEN_20261107.zip --output report.json
"""
from __future__ import annotations
import argparse
import gzip
import hashlib
import json
import struct
import zipfile
from pathlib import Path

# Validated image-specific anchors; never reuse for another kernel image.
EXPECTED_BOOT_SHA256 = '4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015'
EXPECTED_KERNEL_SHA256 = '1af5b8958e95f82fefc0b9357ddbdfcebba406a3b50f4edb5e5fd21e4b8041fb'
EXPECTED_COUNT = 129028
POS = {
    'kallsyms_offsets': 0x1b80600,
    'kallsyms_num_syms': 0x1bfe800,
    'kallsyms_names': 0x1bfe900,
    'kallsyms_markers': 0x1daca00,
    'kallsyms_token_table': 0x1dada00,
    'kallsyms_token_index': 0x1dade00,
}
TARGET_SYMBOLS = {
    'remove_waiter', 'rt_mutex_start_proxy_lock',
    '__rt_mutex_start_proxy_lock', 'rt_mutex_adjust_prio_chain',
}


def sha256(blob: bytes) -> str:
    return hashlib.sha256(blob).hexdigest()


def load_boot(path: Path) -> bytes:
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            matches = [n for n in archive.namelist() if Path(n).name in ('boot.img', 'boot(4).img')]
            if len(matches) != 1:
                raise ValueError('Expected one boot image in archive')
            return archive.read(matches[0])
    return path.read_bytes()


def decompress_boot(boot: bytes) -> bytes:
    if sha256(boot) != EXPECTED_BOOT_SHA256:
        raise ValueError('Image hash differs from the pinned original sweet archive. Refusing comparison.')
    if len(boot) < 4096 or boot[:8] != b'ANDROID!':
        raise ValueError('Bad Android boot header')
    size, = struct.unpack_from('<I', boot, 8)
    page, = struct.unpack_from('<I', boot, 8 + 7 * 4)
    if page != 4096 or size != 18168248:
        raise ValueError('Unexpected boot layout')
    kernel = gzip.decompress(boot[page:page + size])
    if sha256(kernel) != EXPECTED_KERNEL_SHA256:
        raise ValueError('Unexpected decompressed kernel hash')
    return kernel


def read_kallsyms(kernel: bytes) -> tuple[list[tuple[str, int]], dict]:
    if len(kernel) != 44435472:
        raise ValueError('Unexpected raw kernel length')
    count, = struct.unpack_from('<I', kernel, POS['kallsyms_num_syms'])
    if count != EXPECTED_COUNT:
        raise ValueError('Unexpected kallsyms count')
    offsets = struct.unpack_from(f'<{count}I', kernel, POS['kallsyms_offsets'])
    if any(a > b for a, b in zip(offsets, offsets[1:])):
        raise ValueError('kallsyms offsets out of order')
    idx = struct.unpack_from('<256H', kernel, POS['kallsyms_token_index'])
    if idx[0] != 0 or any(a >= b for a, b in zip(idx, idx[1:])):
        raise ValueError('Invalid kallsyms token index')
    tokens = []
    table_pos = POS['kallsyms_token_table']
    for i, v in enumerate(idx):
        stop = kernel.find(b'\0', table_pos + v, table_pos + v + 200)
        if stop < 0 or (i < 255 and stop != table_pos + idx[i + 1] - 1):
            raise ValueError('Invalid compressed token')
        word = kernel[table_pos + v:stop].decode('ascii')
        if not word or any(not ch.isprintable() for ch in word):
            raise ValueError('Nonprintable kallsyms token')
        tokens.append(word)
    marker_count = (count + 255) // 256
    markers = struct.unpack_from(f'<{marker_count}Q', kernel, POS['kallsyms_markers'])
    symbols = []
    cur = POS['kallsyms_names']
    base = cur
    for i in range(count):
        if i % 256 == 0 and cur - base != markers[i // 256]:
            raise ValueError(f'kallsyms marker mismatch at symbol {i}')
        length = kernel[cur]
        cur += 1
        if not length or length > 240 or cur + length > POS['kallsyms_markers']:
            raise ValueError('Invalid kallsyms name length')
        name = ''.join(tokens[v] for v in kernel[cur:cur + length])
        cur += length
        if not name or name[0] not in 'aAbBcCdDgGiInNpPrRsStTuUvVwW?':
            # Not all Linux symbol types are limited to the canonical set;
            # successful marker checks and selected names form the key validity checks.
            pass
        if name[1:] in TARGET_SYMBOLS:
            symbols.append((name, offsets[i]))
    if cur > POS['kallsyms_markers'] or (POS['kallsyms_markers'] - cur) >= 256:
        raise ValueError('Unexpected names table ending')
    if len(symbols) != len(TARGET_SYMBOLS):
        raise ValueError('Missing/duplicated requested kernel symbols')
    return symbols, {'recovered_symbols_total': count,
                     'verified_kallsyms_markers': marker_count,
                     'compressed_name_table_decoded': True,
                     'name_table_padding_bytes': POS['kallsyms_markers'] - cur}


def aarch64_bl_target(inst: int, pc: int) -> int | None:
    if (inst & 0xfc000000) != 0x94000000:
        return None
    immediate = inst & 0x03ffffff
    if immediate & (1 << 25):
        immediate -= 1 << 26
    return pc + immediate * 4


def inspect_code(kernel: bytes, symbols: dict[str, int]) -> dict:
    start = symbols['remove_waiter']
    proxy = symbols['rt_mutex_start_proxy_lock']
    chain = symbols['rt_mutex_adjust_prio_chain']
    # The next symbol in this particular verified image is 'rt_mutex_next_owner'.
    # Limit to a bounded window, and verify instruction encodings rather than text matches.
    region = kernel[start:start + 0x228]
    words = struct.unpack('<' + 'I' * (len(region) // 4), region)
    mrs_sp_el0 = [(i, w & 0x1f) for i, w in enumerate(words)
                  if (w & 0xffffffe0) == 0xd5384100]
    current_reg = mrs_sp_el0[0][1] if mrs_sp_el0 else None
    # Detect a store of zero into a field of the current task pointer.
    # STR XZR, [Xn, #imm] unsigned immediate addressing.
    current_zero_stores = [(i, ((w >> 10) & 0xfff) * 8) for i, w in enumerate(words)
                           if (w & 0xffc00000) == 0xf9000000 and (w & 0x1f) == 31
                           and current_reg is not None and ((w >> 5) & 0x1f) == current_reg]
    # This is an exact source-to-machine-code comparison for this specific archived image.
    # Source: MiCode/sweet-r-oss kernel/locking/rtmutex.c and arch/arm64/include/asm/current.h.
    expected_mrs_and_clear = (current_reg == 20 and
                              0xd5384114 in words and 0xf904769f in words)
    call_from_proxy = False
    for p in range(proxy, start, 4):
        insn, = struct.unpack_from('<I', kernel, p)
        if aarch64_bl_target(insn, p) == start:
            call_from_proxy = True
            break
    call_to_chain = any(aarch64_bl_target(inst, start + 4 * i) == chain
                        for i, inst in enumerate(words))
    return {
        'named_function_found_in_binary': True,
        'source_like_current_task_register_access': bool(mrs_sp_el0),
        'source_like_current_task_state_clear': bool(current_zero_stores) and expected_mrs_and_clear,
        'proxy_lock_calls_remove_waiter': call_from_proxy,
        'remove_waiter_calls_priority_chain': call_to_chain,
        'binary_matches_legacy_current_task_pattern': bool(expected_mrs_and_clear and call_from_proxy and call_to_chain),
        'remove_waiter_code_sha256': sha256(region),
    }


def audit(path: Path) -> dict:
    boot = load_boot(path)
    kernel = decompress_boot(boot)
    syms, symmeta = read_kallsyms(kernel)
    symbol_map = {k[1:]: v for k, v in syms}
    code = inspect_code(kernel, symbol_map)
    return {
        'revision': 'R14.1',
        'scope': 'OFFLINE ARCHIVED STOCK IMAGE ONLY',
        'device_codename': 'sweet',
        'archived_kernel_version': '4.14.190-perf-g7da93debc0ee',
        'boot_image_sha256': sha256(boot),
        'kernel_sha256': sha256(kernel),
        **symmeta,
        'target_symbols_recovered': sorted(symbol_map),
        'binary_pattern_checks': code,
        'classification': ('LEGACY_CURRENT_TASK_PATTERN_CONFIRMED_IN_ARCHIVED_IMAGE'
                           if code['binary_matches_legacy_current_task_pattern'] else
                           'INDETERMINATE_CODE_PATTERN'),
        'running_device_same_boot_bytes': 'NOT_TESTED',
        'reliable_root_ability': 'NOT_PROVEN',
        'root_execution': False,
        'partition_write': False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('boot_image_or_archive', type=Path)
    parser.add_argument('--output', type=Path, default=Path('R141_BINARY_RESULT.json'))
    args = parser.parse_args()
    report = audit(args.boot_image_or_archive)
    args.output.write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    print('R141_OFFLINE_ANALYSIS=' + report['classification'])
    print('SYMBOLS=' + str(report['recovered_symbols_total']))
    print('OUTPUT=' + str(args.output))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, struct.error, EOFError, gzip.BadGzipFile) as exc:
        raise SystemExit('R141_AUDIT_FAIL: ' + str(exc))
