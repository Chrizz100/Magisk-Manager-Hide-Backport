#!/usr/bin/env python3
"""R14.9: Read-only, hash-pinned symbol/feature inventory for Xiaomi sweet stock boot.

This is *not* a GhostLock exploit, a runnable GhostLock profile, or an Android
installer. It extracts only presence/counts of carefully selected symbol names
from a compressed kallsyms table in one independently verified archive.
No kernel addresses, struct offsets, module CRCs, or write methods are emitted.
"""
from __future__ import annotations
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import struct
import zipfile

BOOT_SHA256 = '4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015'
KERNEL_SHA256 = '1af5b8958e95f82fefc0b9357ddbdfcebba406a3b50f4edb5e5fd21e4b8041fb'
RELEASE = '4.14.190-perf-g7da93debc0ee'
SYMBOL_COUNT = 129028
POSITIONS = {
    'num_syms': 0x1bfe800, 'names': 0x1bfe900, 'markers': 0x1daca00,
    'token_table': 0x1dada00, 'token_index': 0x1dade00,
}
# Names taken from GhostLock src/extract_rs/src/symbols.rs (current upstream).
UPSTREAM_KERNEL_SYMBOLS = {
    'off_init_task':'init_task',
    'off_init_cred':'init_cred',
    'off_root_task_group':'root_task_group',
    'off_selinux_enforcing':'selinux_state',
    'off_selinux_blob_sizes':'selinux_blob_sizes',
    'off_security_hook_heads':'security_hook_heads',
    'off_slide_nfulnl_logger':'nfulnl_logger',
    'off_slide_boot_id':'sysctl_bootid',
}
# Read-only anchors mentioned in upstream no-BTF plan. Their mere presence
# is NOT enough to derive safe field offsets (vendor kernels modify structs).
NO_BTF_ANCHORS = (
    'commit_creds','copy_process','task_blocks_on_rt_mutex',
    'rt_mutex_setprio','rt_mutex_adjust_prio_chain','__secure_computing',
    '__set_task_comm','sched_move_task','remove_waiter',
    'rt_mutex_start_proxy_lock',
)
# These are alternative symbol spellings, not proof of equivalent semantics.
LEGACY_SYSCALL_SPELLINGS = {
    '__arm64_sys_getpid': ['sys_getpid'],
    '__arm64_sys_gettid': ['sys_gettid'],
    '__arm64_sys_pselect6': ['SyS_pselect6','sys_pselect6'],
}
FEATURE_FLAGS = (
    'CONFIG_MODULES','CONFIG_MODULE_UNLOAD','CONFIG_MODVERSIONS',
    'CONFIG_MODULE_SIG','CONFIG_DEBUG_INFO','CONFIG_DEBUG_INFO_BTF',
    'CONFIG_KALLSYMS_ALL','CONFIG_FUTEX_PI','CONFIG_RT_MUTEXES',
    'CONFIG_RANDOMIZE_BASE','CONFIG_RELOCATABLE','CONFIG_KPROBES',
)

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def unpack_stock(path: Path) -> tuple[bytes,str]:
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if Path(n).name == 'boot(4).img']
        if len(names) != 1:
            raise ValueError('Original ZIP muss genau eine boot(4).img enthalten')
        image = z.read(names[0])
    if sha256(image) != BOOT_SHA256:
        raise ValueError('Archivierte boot.img passt nicht zu unabhängig gesicherter SHA256')
    if image[:8] != b'ANDROID!':
        raise ValueError('Kein Android boot.img Header')
    size = struct.unpack_from('<I', image, 8)[0]
    page_size = struct.unpack_from('<I', image, 36)[0]
    hdr_ver = struct.unpack_from('<I', image, 40)[0]
    if (size,page_size,hdr_ver) != (18168248,4096,2):
        raise ValueError('Unbekanntes boot.img Format')
    kernel = gzip.decompress(image[page_size:page_size+size])
    if sha256(kernel) != KERNEL_SHA256 or RELEASE.encode() not in kernel:
        raise ValueError('Dekomprimierter Kernel ist nicht die verifizierte sweet-Basis')
    a=kernel.find(b'IKCFG_ST'); b=kernel.find(b'IKCFG_ED',a+8)
    if a<0 or b<a:
        raise ValueError('Eingebettete Kernelkonfiguration fehlt')
    config=gzip.decompress(kernel[a+8:b]).decode('utf-8')
    return kernel, config

def parse_flags(config: str) -> dict[str,str]:
    cfg={}
    for line in config.splitlines():
        if line.startswith('CONFIG_') and '=' in line:
            a,b=line.split('=',1); cfg[a]=b
        elif line.startswith('# CONFIG_') and line.endswith(' is not set'):
            a=line.removeprefix('# ').removesuffix(' is not set');cfg[a]='n'
    return {name:cfg.get(name,'not_listed') for name in FEATURE_FLAGS}

def iter_names(kernel: bytes):
    """Decode all compressed names with marker and token-table validation.

    Image-specific table positions are pinned via kernel_sha256; they are NOT
    reusable against other kernel builds. Output is only symbol names.
    """
    p=POSITIONS
    count=struct.unpack_from('<I',kernel,p['num_syms'])[0]
    if count != SYMBOL_COUNT:
        raise ValueError('Kallsyms Zähler ist nicht der erwartete Originalwert')
    index=struct.unpack_from('<256H',kernel,p['token_index'])
    if index[0]!=0 or any(a>=b for a,b in zip(index,index[1:])):
        raise ValueError('Kallsyms Tokenindex defekt')
    tokens=[]
    for i,off in enumerate(index):
        start=p['token_table']+off
        end=kernel.find(b'\0',start,start+200)
        if end<0 or (i<255 and end != p['token_table']+index[i+1]-1):
            raise ValueError('Kallsyms Tokentabelle defekt')
        token=kernel[start:end].decode('ascii')
        if not token or not token.isprintable():
            raise ValueError('Ungültiges kallsyms Token')
        tokens.append(token)
    marker_count=(count+255)//256
    markers=struct.unpack_from(f'<{marker_count}Q',kernel,p['markers'])
    pos=p['names']; base=pos
    for i in range(count):
        if i%256==0 and markers[i//256]!=pos-base:
            raise ValueError(f'kallsyms Marker {i//256} defekt')
        size=kernel[pos];pos+=1
        if size==0 or size>240 or pos+size>p['markers']:
            raise ValueError('Kallsyms-Name ist ungültig')
        label=''.join(tokens[x] for x in kernel[pos:pos+size]);pos+=size
        if len(label)<2:
            raise ValueError('Ungültiger kallsyms Eintrag')
        yield label[1:]
    if pos>p['markers'] or p['markers']-pos>=256:
        raise ValueError('Ungültiges Ende der Kallsyms-Namen')

def inventory(names: Counter[str], flags:dict[str,str], _raw_kernel:bytes) -> dict:
    exact={field:{'symbol':name,'count':names[name],'found':names[name]>0}
           for field,name in UPSTREAM_KERNEL_SYMBOLS.items()}
    no_btf={name:{'count':names[name],'found':names[name]>0} for name in NO_BTF_ANCHORS}
    spellings={old:{'modern_name_count':names[old],
                    'legacy_candidates':{c:names[c] for c in variants},
                    'equivalence_proven':False}
               for old,variants in LEGACY_SYSCALL_SPELLINGS.items()}
    return {
        'revision':'R14.9','mode':'OFFLINE_SYMBOL_INVENTORY_ONLY',
        'device':'Redmi Note 10 Pro (sweet)',
        'release':RELEASE,'boot_sha256':BOOT_SHA256,'kernel_sha256':KERNEL_SHA256,
        'decoded_symbol_records':sum(names.values()),'distinct_symbol_names':len(names),
        'upstream_symbol_names':exact,
        'no_btf_anchor_names':no_btf,
        'possible_legacy_spellings_not_semantically_verified':spellings,
        'kernel_config':flags,
        'module_abi': {
            'kernel_modules_compiled':flags['CONFIG_MODULES']=='y',
            'kernel_module_symbol_version_check':flags['CONFIG_MODVERSIONS']=='y',
            'kernel_module_signature_feature':flags['CONFIG_MODULE_SIG'],
            'generic_GKI_module_unmodified': 'NOT_VERIFIED_AND_NOT_ASSUMED',
            'matching_Module_symvers_available_in_archive':False,
            'module_was_built_or_loaded':False,
        },
        'embedded_BTF_signature_detected': bytes.fromhex('9feb0100') in _raw_kernel,
        'embedded_BTF_config_listed': flags['CONFIG_DEBUG_INFO_BTF'],
        'structure_offsets_derived':False,
        'executable_4_14_GhostLock_profile_created':False,
        'live_boot_identity_confirmed':False,
        'actual_root_uid0_observed':False,
        'magisk_handoff_verified':False,
        'decision':'BTFLESS_SYMBOLS_PARTIAL_ABI_UNVERIFIED_NO_DEVICE_EXECUTION',
        'sources':{
            'ghostlock_names':'https://github.com/YuKongA/ghostlock-app/blob/main/tools/extract_rs/src/symbols.rs',
            'no_btf_plan':'https://github.com/YuKongA/ghostlock-app/blob/main/docs/analysis/extractor-no-btf-struct-derivation-plan.md',
            'kernel_abi':'https://www.kernel.org/doc/html/latest/kbuild/modules.html',
        }
    }

def run(path:Path) -> dict:
    raw,config=unpack_stock(path)
    names=Counter(iter_names(raw))
    if sum(names.values()) != SYMBOL_COUNT:
        raise ValueError('Unvollständige Kallsyms-Dekodierung')
    return inventory(names,parse_flags(config),raw)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('stock_zip',type=Path)
    p.add_argument('--output',type=Path,default=Path('R149_RESULT.json'))
    opts=p.parse_args()
    result=run(opts.stock_zip)
    opts.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('R14.9=OFFLINE_SYMBOLCHECK_PASS')
    print('SYMBOLS=',result['decoded_symbol_records'])
    print('UPSTREAM_SYMBOLS_MISSING=',[k for k,v in result['upstream_symbol_names'].items() if not v['found']])
    print('OUTPUT=',opts.output)

if __name__ == '__main__':
    try: main()
    except (OSError,ValueError,EOFError,struct.error,gzip.BadGzipFile,zipfile.BadZipFile) as exc:
        raise SystemExit(f'R14.9=FAIL_CLOSED: {exc}')
