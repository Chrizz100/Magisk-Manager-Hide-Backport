#!/usr/bin/env python3
"""R15.1: hash-verified, read-only Xiaomi sweet 4.14 kernel layout evidence.

This script analyzes a pinned, archived boot image. It does not implement
privilege escalation, execute on Android, or emit a runnable GhostLock profile.
It distinguishes machine-code observations from source-only candidates.
"""
from pathlib import Path
import argparse, hashlib, json, struct
import R141_GHOSTLOCK_BINARY_AUDIT as binary
import r149_symbolcheck as sym

RELEASE = sym.RELEASE
EXPECTED_OPCODES = {
    'mrs_current': 0xd5384114,       # MRS x20, sp_el0
    'pi_lock_base': 0x91231295,      # ADD x21, x20, #0x8c4
    'pi_blocked_on_clear': 0xf904769f,  # STR xzr, [x20, #0x8e8]
    'pi_waiters_base': 0x912342a1,   # ADD x1, x21, #0x8d0, after x21 reloaded
    'pi_top_task_load': 0xf9446ea8,  # LDR x8, [x21, #0x8d8]
}

def immediate_add64(word: int) -> int:
    if (word & 0xff000000) != 0x91000000:
        raise ValueError('Not AArch64 ADD (immediate) 64-bit instruction')
    imm = (word >> 10) & 0xfff
    if (word >> 22) & 1: imm <<= 12
    return imm

def immediate_scaled_ldr_str64(word: int) -> int:
    if (word & 0xffc00000) not in (0xf9400000, 0xf9000000):
        raise ValueError('Not 64-bit immediate LDR/STR')
    return ((word >> 10) & 0xfff) * 8

EXTRA_FUNCTION_ANCHORS = {
    'commit_creds': {
        'mrs_current': 0xd5384114,
        'real_cred_load': 0xf943fe93,
        'cred_load': 0xf9440288,
    },
    '__secure_computing': {
        'mrs_current': 0xd5384108,
        'seccomp_mode_load': 0xb948a109,
    },
    'rt_mutex_setprio': {
        'normal_prio_load': 0xb940b01b,
        'pi_task_move': 0xaa0103f6,
        'prio_load': 0xb940aac8,
    },
}

def u32_load_imm(word:int)->int:
    if (word & 0xffc00000)!=0xb9400000:
        raise ValueError('Not AArch64 32-bit LDR immediate')
    return ((word>>10)&0xfff)*4

def capture_other_struct_fields(kernel:bytes, symbols:dict[str,int])->dict[str,int]:
    for name,codewords in EXTRA_FUNCTION_ANCHORS.items():
        start=symbols[name]
        chunk=kernel[start:start+(0x280 if name=='commit_creds' else 0x120)]
        words=struct.unpack('<'+'I'*(len(chunk)//4),chunk)
        found={key:[i for i,w in enumerate(words) if w==word] for key,word in codewords.items()}
        if any(not matches for matches in found.values()):
            raise ValueError(f'Missing ARM64 source-like fields in {name}: {found}')
        if name=='commit_creds' and not (found['mrs_current'][0]<found['real_cred_load'][0]<found['cred_load'][0]):
            raise ValueError('Unexpected task credential sequence')
        if name=='__secure_computing' and not (found['mrs_current'][0]<found['seccomp_mode_load'][0]):
            raise ValueError('Unexpected task seccomp sequence')
        if name=='rt_mutex_setprio' and not (found['normal_prio_load'][0]<found['pi_task_move'][0]<found['prio_load'][0]):
            raise ValueError('Unexpected task priority sequence')
    return {
        'task_struct.real_cred':immediate_scaled_ldr_str64(EXTRA_FUNCTION_ANCHORS['commit_creds']['real_cred_load']),
        'task_struct.cred':immediate_scaled_ldr_str64(EXTRA_FUNCTION_ANCHORS['commit_creds']['cred_load']),
        'task_struct.seccomp':u32_load_imm(EXTRA_FUNCTION_ANCHORS['__secure_computing']['seccomp_mode_load']),
        'task_struct.prio':u32_load_imm(EXTRA_FUNCTION_ANCHORS['rt_mutex_setprio']['prio_load']),
        'task_struct.normal_prio':u32_load_imm(EXTRA_FUNCTION_ANCHORS['rt_mutex_setprio']['normal_prio_load']),
    }

def evidence(kernel: bytes, config: str, kernel_symbols: dict[str,int]) -> dict:
    start = kernel_symbols['remove_waiter']
    # Bounded to source-like remove_waiter, never search arbitrary kernel data.
    chunk = kernel[start:start+0x228]
    words = struct.unpack('<'+'I'*(len(chunk)//4), chunk)
    matches={name:[i for i,w in enumerate(words) if w==opcode] for name,opcode in EXPECTED_OPCODES.items()}
    expected_counts={'mrs_current':1,'pi_lock_base':1,'pi_blocked_on_clear':1,'pi_waiters_base':2,'pi_top_task_load':1}
    if any(len(matches[k])!=n for k,n in expected_counts.items()):
        raise ValueError('Source-like 4.14 instruction counts do not match the pinned binary')
    # Confirm order of current -> pi_lock and actual block clear and secondary task reads.
    if not (matches['mrs_current'][0] < matches['pi_lock_base'][0] < matches['pi_blocked_on_clear'][0] < matches['pi_waiters_base'][0] < matches['pi_top_task_load'][0]):
        raise ValueError('Instruction sequence does not match the pinned 4.14 binary')
    flags = sym.parse_flags(config)
    # Use actual config, never imply the 4.14.180 source tree matches 4.14.190.
    enabled={key:val for key,val in (line.split('=',1) for line in config.splitlines() if line.startswith('CONFIG_') and '=' in line)}
    assert enabled['CONFIG_ARM64_VA_BITS']=='39'
    assert enabled['CONFIG_MODVERSIONS']=='y'
    if '# CONFIG_GCC_PLUGINS is not set' not in config or '# CONFIG_DEBUG_CREDENTIALS is not set' not in config:
        raise ValueError('Compiler/cred feature configuration differs from archived build')
    verified = {
        'task_struct.pi_lock': immediate_add64(EXPECTED_OPCODES['pi_lock_base']),
        'task_struct.pi_blocked_on': immediate_scaled_ldr_str64(EXPECTED_OPCODES['pi_blocked_on_clear']),
        'task_struct.pi_waiters': immediate_add64(EXPECTED_OPCODES['pi_waiters_base']),
        'task_struct.pi_top_task': immediate_scaled_ldr_str64(EXPECTED_OPCODES['pi_top_task_load']),
    }
    verified.update(capture_other_struct_fields(kernel,kernel_symbols))
    # Verify exact register usage for anchored offsets (in addition to unique opcodes).
    assert (EXPECTED_OPCODES['pi_lock_base'] & 31, (EXPECTED_OPCODES['pi_lock_base'] >> 5) & 31) == (21, 20)
    assert (EXPECTED_OPCODES['pi_blocked_on_clear'] & 31, (EXPECTED_OPCODES['pi_blocked_on_clear'] >> 5) & 31) == (31, 20)
    assert (EXPECTED_OPCODES['pi_waiters_base'] & 31, (EXPECTED_OPCODES['pi_waiters_base'] >> 5) & 31) == (1, 21)
    assert (EXPECTED_OPCODES['pi_top_task_load'] & 31, (EXPECTED_OPCODES['pi_top_task_load'] >> 5) & 31) == (8, 21)
    return {
        'revision':'R15.1', 'mode':'OFFLINE_BINARY_LAYOUT_EVIDENCE',
        'device':'Redmi Note 10 Pro (sweet)', 'kernel_release':RELEASE,
        'archived_boot_hash':sym.BOOT_SHA256,
        'original_kernel_hash':sym.KERNEL_SHA256,
        'source_like_mrs_current_and_pi_sequence':True,
        'machine_code_evidence_hex':{key:f'0x{val:08x}' for key,val in EXPECTED_OPCODES.items()},
        'task_struct_offsets_confirmed_in_archived_binary':{k:hex(v) for k,v in verified.items()},
        'kernel_config':{
            'CONFIG_GCC_PLUGINS':'n',
            'CONFIG_DEBUG_CREDENTIALS':'n',
            'CONFIG_SECURITY':enabled.get('CONFIG_SECURITY','unset'),
            'CONFIG_KEYS':enabled.get('CONFIG_KEYS','unset'),
            'CONFIG_ARM64_VA_BITS':enabled['CONFIG_ARM64_VA_BITS'],
            'CONFIG_RANDOMIZE_BASE':enabled.get('CONFIG_RANDOMIZE_BASE','unset'),
            'CONFIG_MODULES':enabled.get('CONFIG_MODULES','unset'),
            'CONFIG_MODVERSIONS':enabled['CONFIG_MODVERSIONS'],
        },
        'ghostlock_required_task_fields_verified_in_archived_binary':all(name in verified for name in ('task_struct.prio','task_struct.pi_lock','task_struct.pi_waiters','task_struct.pi_blocked_on','task_struct.cred','task_struct.seccomp')),
        'cred_layout_binary_verified':False,
        'seccomp_mode_offset_binary_verified':True,
        'verified_running_phone_boot_identity':False,
        'ghostlock_414_engine_compatible':False,
        'root_uid0_obtained':False,
        'method':'ARM64 instruction checks with SHA256-pinned stock boot, no writes',
        'notes':['KASLR randomizes addresses at runtime, not automatically struct field layouts.',
                 '4.14.180 Xiaomi source is not an exact binary match for 4.14.190.',
                 'No 4.14 profile is enabled or built; this is not a root procedure.']
    }

def audit(stock_zip: Path) -> dict:
    kernel,config=sym.unpack_stock(stock_zip)
    boot = binary.load_boot(stock_zip)
    original = binary.decompress_boot(boot)
    if kernel != original: raise ValueError('Two independent boot readers disagree')
    found,meta = binary.read_kallsyms(kernel)
    symbols={s[1:]:off for s,off in found}
    raw=binary.inspect_code(kernel,symbols)
    if not raw['binary_matches_legacy_current_task_pattern']:
        raise ValueError('Existing independent R14.1 vulnerability signature did not pass')
    counts=sym.SYMBOL_COUNT
    offsets=struct.unpack_from(f'<{counts}I',kernel,binary.POS['kallsyms_offsets'])
    for name,off in zip(sym.iter_names(kernel),offsets):
        if name in EXTRA_FUNCTION_ANCHORS:
            if name in symbols:raise ValueError(f'Duplicate target symbol: {name}')
            symbols[name]=off
    if not all(key in symbols for key in EXTRA_FUNCTION_ANCHORS):
        raise ValueError('Not all extra anchor functions were found')
    return evidence(kernel, config, symbols)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stock_zip',type=Path)
    parser.add_argument('--output',type=Path,default=Path('R151_RESULT.json'))
    opts=parser.parse_args()
    result=audit(opts.stock_zip)
    opts.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('OFFLINE_LAYOUT_EVIDENCE=PASS')
    print('FIELDS_CONFIRMED=',len(result['task_struct_offsets_confirmed_in_archived_binary']))
    print('ROOT_OBTAINED=',result['root_uid0_obtained'])

if __name__=='__main__': main()
