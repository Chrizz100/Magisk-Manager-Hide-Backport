#!/usr/bin/env python3
"""Read-only AArch64 BL call-graph audit for the exact archived Xiaomi sweet kernel.

No kernel memory writes, exploitation, profiling of live devices, or flash actions.
Evidence is function connectivity only, NOT reachability of an exploitable state.
"""
from __future__ import annotations
import argparse
import bisect
import json
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'prior'))
import r149_symbolcheck as stock
import R141_GHOSTLOCK_BINARY_AUDIT as r141

# Chains to establish in static compiled code. These are generic function names,
# not attack settings, data offsets or a device exploitation profile.
CHAINS = {
    'futex_requeue_to_rtmutex': ['SyS_futex', 'do_futex', 'futex_requeue',
                                 'rt_mutex_start_proxy_lock', 'remove_waiter'],
    'pselect_to_core_select': ['SyS_pselect6', 'core_sys_select', 'do_select'],
}
ABSENT_IN_ARCHIVE = ('futex_wait_requeue_pi', 'do_pselect',
                     '__arm64_sys_futex', '__arm64_sys_pselect6')


def read_names_and_types(kernel: bytes) -> tuple[list[tuple[str, str, int]], int]:
    """Parse the pinned KALLSYMS format, validating name/offset/marker data."""
    pos = r141.POS
    count = struct.unpack_from('<I', kernel, pos['kallsyms_num_syms'])[0]
    if count != stock.SYMBOL_COUNT:
        raise ValueError('symbol count mismatch')
    offsets = struct.unpack_from(f'<{count}I', kernel, pos['kallsyms_offsets'])
    if any(a > b for a, b in zip(offsets, offsets[1:])):
        raise ValueError('nonmonotonic symbol positions')
    indices = struct.unpack_from('<256H', kernel, pos['kallsyms_token_index'])
    if indices[0] != 0 or any(a >= b for a, b in zip(indices, indices[1:])):
        raise ValueError('bad token index')
    table = pos['kallsyms_token_table']
    tokens = []
    for i, val in enumerate(indices):
        end = kernel.find(b'\0', table + val, table + val + 200)
        if end < 0 or (i < 255 and end != table + indices[i + 1] - 1):
            raise ValueError('invalid token')
        tokens.append(kernel[table + val:end].decode('ascii'))
    marker_count = (count + 255) // 256
    markers = struct.unpack_from(f'<{marker_count}Q', kernel, pos['kallsyms_markers'])
    cur = start = pos['kallsyms_names']
    result = []
    for index in range(count):
        if index % 256 == 0 and cur-start != markers[index//256]:
            raise ValueError('invalid marker')
        size = kernel[cur]
        cur += 1
        if not 1 <= size <= 240 or cur+size >= pos['kallsyms_markers']:
            raise ValueError('bad compressed name')
        name = ''.join(tokens[k] for k in kernel[cur:cur+size])
        cur += size
        if len(name) < 2:
            raise ValueError('empty name')
        result.append((name[1:], name[0], offsets[index]))
    if cur > pos['kallsyms_markers'] or pos['kallsyms_markers']-cur >= 256:
        raise ValueError('unexpected name padding')
    return result, marker_count


def branch_target(instruction: int, offset: int) -> int | None:
    """Decode an AArch64 26-bit signed BL immediate; no execution."""
    if instruction & 0xfc000000 != 0x94000000:
        return None
    displacement = instruction & 0x03ffffff
    if displacement & (1 << 25):
        displacement -= 1 << 26
    return offset + displacement * 4


def code_functions(symbols: list[tuple[str,str,int]], kernel_length: int):
    # Group text symbol aliases at the same address; find the next DIFFERENT
    # start so an alias doesn't produce a zero-length function.
    text = [(n, addr) for n, t, addr in symbols
            if t in ('t','T') and addr < kernel_length and addr % 4 == 0]
    positions = sorted(set(a for _,a in text))
    index = {name: address for name,address in text}
    return index, positions


def function_span(name: str, index: dict, positions: list, length: int):
    start = index[name]
    j = bisect.bisect_right(positions, start)
    end = positions[j] if j < len(positions) else length
    if end-start <= 0 or end-start > 0x20000:
        raise ValueError(f'unsafe function bounds: {name}')
    return start, end


def exact_direct_call(kernel: bytes, src: str, dst: str, index: dict, positions: list) -> bool:
    start, end = function_span(src,index,positions,len(kernel))
    target = index[dst]
    return any(branch_target(struct.unpack_from('<I',kernel,pc)[0],pc)==target
               for pc in range(start,end,4))


def analyze(kernel: bytes, cfg: str, symbols: list[tuple[str,str,int]], markers: int) -> dict:
    flags=stock.parse_flags(cfg)
    if flags['CONFIG_FUTEX_PI']!='y' or flags['CONFIG_RT_MUTEXES']!='y':
        raise ValueError('PI futex or RT mutex absent')
    index, positions=code_functions(symbols,len(kernel))
    names=set(name for name,_,_ in symbols)
    connected={}
    for label, chain in CHAINS.items():
        if any(x not in index for x in chain):
            raise ValueError(f'missing chain function: {label}')
        connected[label]=[
            {'from':a,'to':b,'direct_bl_verified':exact_direct_call(kernel,a,b,index,positions)}
            for a,b in zip(chain,chain[1:])
        ]
    return {
        'revision':'R15.6', 'mode':'READ_ONLY_BINARY_CONTROL_FLOW',
        'source':'sha-pinned ARCHIVED Xiaomi sweet boot(4).img',
        'boot_image_sha256':stock.BOOT_SHA256,
        'kernel_sha256':stock.KERNEL_SHA256,
        'archive_kernel_version':stock.RELEASE,
        'symbols_decoded':len(symbols), 'markers_verified':markers,
        'config':{'CONFIG_FUTEX_PI':flags['CONFIG_FUTEX_PI'],
                  'CONFIG_RT_MUTEXES':flags['CONFIG_RT_MUTEXES']},
        'direct_calls':connected,
        'all_required_direct_calls_present':all(x['direct_bl_verified'] for row in connected.values() for x in row),
        'missing_independent_symbol_names':sorted(name for name in ABSENT_IN_ARCHIVE if name not in names),
        'interpretation':'missing original symbol may have been inlined/merged; not proven',
        'limits':{
            'no_proof_of_an_exploitable_race':True,
            'live_boot_partition_matched':False,
            'root_uid0_observed':False,
            'magisk_active':False,
            'root_exploit_implemented':False,
        },
    }


def run(archive: Path):
    kernel,cfg=stock.unpack_stock(archive)
    symbols,markers=read_names_and_types(kernel)
    return analyze(kernel,cfg,symbols,markers)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('original_stock_zip',type=Path)
    ap.add_argument('--out',type=Path)
    args=ap.parse_args()
    result=run(args.original_stock_zip)
    out=json.dumps(result,indent=2,ensure_ascii=False)+'\n'
    if args.out:args.out.write_text(out,encoding='utf-8')
    print(out)
    if not result['all_required_direct_calls_present']:
        raise SystemExit('R15.6 FAIL: direct call chain incomplete')

if __name__=='__main__':main()
