#!/usr/bin/env python3
"""Pinned, read-only 4.14.190 Xiaomi cred-layout corroboration.

NEVER generates an exploit, write address, runnable GhostLock profile or root
capability. Static machine-code bytes are checked in the archived boot image;
semantics are cross-checked against the older Xiaomi source but may differ on
the actual device. The original boot partition remains unverified.
"""
import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'prior'))
import R141_GHOSTLOCK_BINARY_AUDIT as b
import r149_symbolcheck as s

BOOT = '4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015'
KERNEL = '1af5b8958e95f82fefc0b9357ddbdfcebba406a3b50f4edb5e5fd21e4b8041fb'
# Exact instruction encodings, read from the *pinned image*, at relative
# positions inside named kernel functions. Offsets here are *file-local*,
# not KASLR/runtime addresses, and are never used for exploitation.
ANCHORS = {
    'prepare_creds': {
        0x38: (0xf94402f6, 'task_struct.cred read'),
        0x3c: (0x52801502, 'copy length 0xa8 bytes'),
        0x54: (0xb8098e9f, 'cred non_rcu field at 0x98 reset'),
        0x58: (0xb9000268, 'new credential usage initialised'),
        0x74: (0xf9404268, 'cred user pointer at 0x80'),
        0x8c: (0xf9402e68, 'cred session_keyring pointer at 0x58'),
        0x108: (0xf9003e7f, 'cred security pointer at 0x78 cleared'),
    },
    'copy_creds': {
        0x28: (0xb900991f, 'cred non_rcu field at 0x98 reset'),
        0x44: (0xf903fe88, 'task_struct.real_cred write'),
        0x68: (0xf9404108, 'cred user pointer at 0x80'),
    },
    '__cap_capable': {
        0x54: (0xb9403908, 'effective capability word read at 0x38'),
    },
}

def pinned_kernel(stock_zip: Path) -> tuple[bytes, str]:
    raw, config = s.unpack_stock(stock_zip)
    if hashlib.sha256(raw).hexdigest() != KERNEL:
        raise ValueError('Kernel digest mismatch')
    if '# CONFIG_DEBUG_CREDENTIALS is not set' not in config:
        raise ValueError('Unexpected DEBUG_CREDENTIALS configuration')
    if '# CONFIG_GCC_PLUGINS is not set' not in config:
        raise ValueError('Unexpected RANDSTRUCT/compiler configuration')
    if 'CONFIG_KEYS=y' not in config or 'CONFIG_SECURITY=y' not in config:
        raise ValueError('Unexpected keyrings or security configuration')
    return raw, config

def symbols_of(kernel: bytes, names: set[str]) -> dict[str, int]:
    count = s.SYMBOL_COUNT
    offsets = struct.unpack_from(f'<{count}I', kernel, b.POS['kallsyms_offsets'])
    symbols = {}
    for name, offset in zip(s.iter_names(kernel), offsets):
        if name in names:
            if name in symbols:
                raise ValueError('Ambiguous kernel symbol: ' + name)
            symbols[name] = offset
    if set(symbols) != names:
        raise ValueError('Missing kernel symbols: ' + repr(names - set(symbols)))
    return symbols

def validate_anchors(kernel: bytes, mapping: dict[str,int]) -> list[dict]:
    out=[]
    for name, patterns in ANCHORS.items():
        start = mapping[name]
        for pc, (expected, meaning) in patterns.items():
            actual, = struct.unpack_from('<I', kernel, start + pc)
            if actual != expected:
                raise ValueError(f'{name}+0x{pc:x}: expected 0x{expected:08x}, found 0x{actual:08x}')
            out.append({'function': name, 'relative_instruction_byte': pc,
                        'word': f'{actual:08x}', 'meaning': meaning})
    return out

def validate_init_cred(kernel: bytes, offset: int) -> dict:
    raw=kernel[offset:offset+0xa8]
    if len(raw)!=0xa8: raise ValueError('Short init_cred object')
    usage,uid,gid,suid,sgid,euid,egid,fsuid,fsgid,securebits=struct.unpack_from('<10I',raw,0)
    # In static Image, pointers awaiting relocation may remain zero and must
    # NOT be misrepresented as the running device's memory contents.
    if usage!=4 or any((uid,gid,suid,sgid,euid,egid,fsuid,fsgid,securebits)):
        raise ValueError('Archived init_cred basic fields differ')
    cap_inh,cap_perm,cap_eff,cap_bset,cap_amb=struct.unpack_from('<5Q',raw,0x28)
    if cap_inh!=0 or cap_perm!=cap_eff or cap_perm!=cap_bset or cap_amb!=0:
        raise ValueError('Archived init_cred capability template differs')
    if cap_eff!=0x0000003fffffffff:
        raise ValueError('Archived init_cred capability mask differs')
    return {'usage':usage,'uid_gid_eight_fields_zero':True,'capability_template_self_consistent':True,
            'cap_effective_mask_hex':f'0x{cap_eff:016x}','image_only_not_live':True}

def audit(path: Path) -> dict:
    kernel,_=pinned_kernel(path)
    mapping=symbols_of(kernel, set(ANCHORS)|{'init_cred','commit_creds'})
    matched=validate_anchors(kernel, mapping)
    init=validate_init_cred(kernel,mapping['init_cred'])
    return {
        'revision':'R15.3', 'status':'ARCHIVED_KERNEL_CRED_ABI_PARTIALLY_CORROBORATED',
        'target':'sweet / 4.14.190-perf-g7da93debc0ee',
        'boot_sha256':BOOT,'decompressed_kernel_sha256':KERNEL,
        'machine_code_checks_count':len(matched), 'machine_code_checks':matched,
        'observed':{
            'struct_cred_size_bytes':168,
            'cred_cap_effective_byte_offset':56,
            'cred_security_byte_offset':120,
            'cred_user_byte_offset':128,
            'cred_group_info_byte_offset':144,
            'cred_non_rcu_byte_offset':152,
            'init_cred':init,
        },
        'not_binary_verified':[
            'Every member of struct cred; some offsets come from older Xiaomi headers only',
            'Identity of the running boot partition with the archived image',
            'Kernel runtime address resolution / KASLR / exploitability',
            'Root privileges / working su daemon / Magisk 31100',
        ],
        'kernel_write_performed':False,
        'root_obtained':False,
        'source_references':{
            'older_source_cred':'https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/sweet-r-oss/include/linux/cred.h',
            'ghostlock':'https://github.com/YuKongA/ghostlock-app',
        }
    }

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('stock_zip',type=Path)
    ap.add_argument('--output',type=Path,default=ROOT/'reports'/'cred_binary_report.json')
    a=ap.parse_args()
    obj=audit(a.stock_zip)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(f'RESULT=PASS CRED_MACHINE_ANCHORS={len(obj["machine_code_checks"])} ROOT={obj["root_obtained"]}')

if __name__=='__main__':
    try:main()
    except (ValueError, OSError, struct.error) as exc:raise SystemExit('R15.3 FAIL CLOSED: '+str(exc))
