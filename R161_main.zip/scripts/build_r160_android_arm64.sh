#!/usr/bin/env bash
# Build only the non-root SWEET 4.14 preflight executable for Android/arm64.
# A native executable named .so is NOT automatically packaged by Gradle.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NDK="${ANDROID_NDK_HOME:-${ANDROID_NDK_LATEST_HOME:-${NDK_PATH:-}}}"
if [[ -z "$NDK" || ! -f "$NDK/build/cmake/android.toolchain.cmake" ]]; then
  echo 'Android NDK missing; set ANDROID_NDK_HOME or ANDROID_NDK_LATEST_HOME' >&2
  exit 69
fi
for name in cmake python3; do command -v "$name" >/dev/null || { echo "Missing $name" >&2; exit 69; }; done
BUILD="$ROOT/.build-android-arm64"
cmake -S "$ROOT" -B "$BUILD" \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 \
    -DANDROID_STL=c++_static -DCMAKE_BUILD_TYPE=Release
cmake --build "$BUILD" --target sweet414-port --parallel 2
BINARY="$BUILD/libsweet414_preflight.so"
test -s "$BINARY"
python3 "$ROOT/scripts/r160_check_android_elf.py" --binary "$BINARY" --stage "$ROOT/android-stage"
# CMake may accidentally link a shared libc++; reject it because it is not staged.
if command -v readelf >/dev/null && readelf -d "$BINARY" | grep -Fq 'libc++_shared.so'; then
  echo 'Unexpected dynamic libc++ dependency; c++_static build did not take effect' >&2
  exit 70
fi
printf '%s\n' 'R16.0 Android/arm64 PIE staged; native root backend = absent; not an APK.'
