#!/usr/bin/env python3
"""Read-only cross-audit of real Xiaomi archived kernel vs 4.14 SELinux model.

Never generates a runnable kernel profile or touches any kernel memory.
The Xiaomi source tree is 4.14.180; the actual archived kernel is 4.14.190.
"""
import argparse
import hashlib
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / 'prior'), str(ROOT / 'scripts')]
import r149_symbolcheck as symbol
import r151_abi_audit as task
import audit_cred as cred

EXPECTED_TASK = {
    'task_struct.prio': 0xa8,
    'task_struct.normal_prio': 0xb0,
    'task_struct.real_cred': 0x7f8,
    'task_struct.cred': 0x800,
    'task_struct.seccomp': 0x8a0,
    'task_struct.pi_lock': 0x8c4,
    'task_struct.pi_waiters': 0x8d0,
    'task_struct.pi_top_task': 0x8d8,
    'task_struct.pi_blocked_on': 0x8e8,
}
EXPECTED_CRED = {
    'struct_cred_size_bytes': 168,
    'cred_cap_effective_byte_offset': 0x38,
    'cred_security_byte_offset': 0x78,
    'cred_user_byte_offset': 0x80,
    'cred_group_info_byte_offset': 0x90,
    'cred_non_rcu_byte_offset': 0x98,
}
REQUIRED_CONFIG = {
    'CONFIG_SECURITY=y',
    'CONFIG_SECURITY_SELINUX=y',
    'CONFIG_RANDOMIZE_BASE=y',
    '# CONFIG_GCC_PLUGINS is not set',
    '# CONFIG_DEBUG_CREDENTIALS is not set',
}

def validate_contract(task_report: dict, cred_report: dict, kernel_config: str, symbols: set[str]) -> dict:
    if not task_report.get('ghostlock_required_task_fields_verified_in_archived_binary'):
        raise ValueError('task_struct check failed')
    got_task = task_report.get('task_struct_offsets_confirmed_in_archived_binary', {})
    for key, expected in EXPECTED_TASK.items():
        if int(got_task.get(key, '-1'), 16) != expected:
            raise ValueError(f'task field inconsistent: {key}')
    got_cred = cred_report.get('observed', {})
    for key, expected in EXPECTED_CRED.items():
        if got_cred.get(key) != expected:
            raise ValueError(f'cred field inconsistent: {key}')
    if task_report.get('archived_boot_hash') != cred_report.get('boot_sha256'):
        raise ValueError('Different boot images used for task and cred ABI checks')
    if task_report.get('original_kernel_hash') != cred_report.get('decompressed_kernel_sha256'):
        raise ValueError('Different kernel images used for task and cred ABI checks')
    lines = set(kernel_config.splitlines())
    for entry in REQUIRED_CONFIG:
        if entry not in lines:
            raise ValueError(f'Unexpected kernel config: {entry}')
    if 'selinux_state' not in symbols or 'security_hook_heads' not in symbols:
        raise ValueError('Required legacy SELinux symbol is missing')
    if 'selinux_blob_sizes' in symbols:
        raise ValueError('Wrong kernel-generation SELinux ABI: blob_sizes symbol present')
    # Deliberately reports ONLY an archived snapshot, regardless of field completeness.
    return {
        'revision': 'R15.4',
        'archive_boot_sha256': task_report['archived_boot_hash'],
        'archive_kernel_sha256': task_report['original_kernel_hash'],
        'task_fields_consistent': len(EXPECTED_TASK),
        'cred_fields_consistent': len(EXPECTED_CRED),
        'cred_fields_direct_machine_anchors': 4,
        'cred_fields_source_inferred': ['group_info'],
        'selinux_legacy_4_14_model': {
            'config_security_selinux': True,
            'symbol_selinux_state': True,
            'symbol_security_hook_heads': True,
            'symbol_selinux_blob_sizes': False,
            'older_xiaomi_source_uses_cred_security_pointer': True,
            'source_version': '4.14.180',
            'archive_version': '4.14.190',
        },
        'image_evidence_validated': True,
        'running_boot_partition_verified': False,
        'kernel_writes_performed': False,
        'ghostlock_root_backend_implemented': False,
        'root_uid_zero_verified': False,
        'magisk_31100_active_verified': False,
        'verdict': 'ARCHIVED_ABI_CROSSCHECK_OK__NO_LIVE_ROOT',
    }

def analyze(stock_zip: Path) -> dict:
    kernel, config = symbol.unpack_stock(stock_zip)
    task_report = task.audit(stock_zip)
    cred_report = cred.audit(stock_zip)
    all_symbols = set(symbol.iter_names(kernel))
    return validate_contract(task_report, cred_report, config, all_symbols)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stock_zip', type=Path)
    parser.add_argument('--out', type=Path, default=ROOT/'reports'/'r154_crosscheck.json')
    args = parser.parse_args()
    try:
        result=analyze(args.stock_zip)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    except (ValueError, OSError) as exc:
        raise SystemExit('R15.4 FAIL CLOSED: '+str(exc))
    print('ARCHIVED_ABI=PASS ROOT=NO MAGISK=NO')
