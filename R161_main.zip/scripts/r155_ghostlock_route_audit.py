#!/usr/bin/env python3
"""Read-only, SHA-pinned symbol compatibility check for sweet 4.14.190.

Checks GhostLock's current symbol expectations against the *archived* Xiaomi
image. This does not measure stack overlap, validate an attack route, write
kernel memory, or produce an executable exploitation profile.
"""
import argparse, json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'prior'))
import r149_symbolcheck as stock

# Code expectation from YuKongA/ghostlock-app tools/extract_rs/src/derive.rs,
# as inspected on 2026-11-11. Do not silently use aliases as verified code.
EXPECT = {
 'pselect_wrapper': ('__arm64_sys_pselect6', ('SyS_pselect6','sys_pselect6')),
 'pselect_core': ('core_sys_select', ()),
 'futex_wrapper': ('__arm64_sys_futex', ('SyS_futex','sys_futex')),
 'futex_dispatch': ('do_futex', ()),
 'futex_wait': ('futex_wait_requeue_pi', ()),
 'proxy_lock': ('rt_mutex_start_proxy_lock', ()),
 'waiter_remove': ('remove_waiter', ()),
}

def summarize(names, cfg):
    flags=stock.parse_flags(cfg)
    found={}
    for label,(original,aliases) in EXPECT.items():
        found[label]={
            'upstream_expected_symbol':original,
            'exact_in_archive':original in names,
            'legacy_alternates_found':[s for s in aliases if s in names],
            'upstream_exact_name_usable':original in names,
        }
    if flags.get('CONFIG_FUTEX_PI')!='y' or flags.get('CONFIG_RT_MUTEXES')!='y':
        raise ValueError('Required futex-PI/rtmutex features not enabled in archive')
    return {
       'revision':'R15.5',
       'image':'SHA-256-pinned archived sweet boot(4).img; NOT live partition',
       'kernel':'4.14.190-perf-g7da93debc0ee',
       'symbols_total':stock.SYMBOL_COUNT,
       'config':{'CONFIG_FUTEX_PI':flags['CONFIG_FUTEX_PI'], 'CONFIG_RT_MUTEXES':flags['CONFIG_RT_MUTEXES']},
       'entries':found,
       'direct_upstream_symbol_contract_passed':all(e['exact_in_archive'] for e in found.values()),
       'root_obtained':False,
       'phone_boot_hash_verified':False,
       'next_required':'Locate actual compiled 4.14 futex wait / pselect control-flow and prove route feasibility; no exploit attempted.',
    }

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('archive',type=Path)
    p.add_argument('--out',type=Path)
    a=p.parse_args()
    kernel,cfg=stock.unpack_stock(a.archive)
    all_names=set(stock.iter_names(kernel))
    result=summarize(all_names,cfg)
    text=json.dumps(result,ensure_ascii=False,indent=2)+'\n'
    if a.out:a.out.write_text(text,encoding='utf-8')
    print(text)

if __name__=='__main__':main()
