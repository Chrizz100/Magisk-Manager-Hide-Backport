#!/usr/bin/env python3
"""R15.7: Read-only, SHA-bound audit for inlined historical futex code.
No exploit, memory-offset profile, flash, device access, or privilege change.
"""
from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'prior'))
import r156_readonly_callgraph as prev

HELPERS = (
    'rt_mutex_init_waiter',
    'futex_wait_setup',
    'futex_wait_queue_me',
    'rt_mutex_wait_proxy_lock',
    'rt_mutex_cleanup_proxy_lock',
)
TARGET_KERNEL = '4.14.190-perf-g7da93debc0ee'
CONFIG_KEYS = (
    'CONFIG_FUTEX_PI', 'CONFIG_RT_MUTEXES', 'CONFIG_RANDOMIZE_BASE',
    'CONFIG_VMAP_STACK', 'CONFIG_ARM64_VA_BITS_39',
    'CONFIG_ARM64_PAN', 'CONFIG_SLAB_FREELIST_RANDOM',
    'CONFIG_SLAB_FREELIST_HARDENED', 'CONFIG_SECCOMP',
    'CONFIG_SECCOMP_FILTER', 'CONFIG_DEBUG_RT_MUTEXES',
    'CONFIG_MODULES', 'CONFIG_MODVERSIONS', 'CONFIG_KPROBES',
)

def config_value(cfg: str, key: str) -> str:
    for line in cfg.splitlines():
        if line.startswith(key+'='):
            return line.split('=',1)[1]
        if line == '# '+key+' is not set':
            return 'n'
    return 'NOT_FOUND'

def run(archive: Path):
    kernel, cfg = prev.stock.unpack_stock(archive)  # exact boot/kernel SHA-256 required
    symbols, markers = prev.read_names_and_types(kernel)
    idx, pos = prev.code_functions(symbols, len(kernel))
    helpers_present = {name: name in idx for name in HELPERS}
    calls = {name: prev.exact_direct_call(kernel,'do_futex',name,idx,pos)
             if helpers_present[name] else False for name in HELPERS}
    standalone = any(name=='futex_wait_requeue_pi' for name,_,_ in symbols)
    conf = {key:config_value(cfg,key) for key in CONFIG_KEYS}
    if not all(calls.values()):
        verdict = 'HELPER_CHAIN_INCOMPLETE'
    elif standalone:
        verdict = 'STANDALONE_SYMBOL_PRESENT_NOT_INLINE_CANDIDATE'
    else:
        verdict = 'STRONG_INLINE_CANDIDATE_ONLY'
    return {
        'revision': 'R15.7', 'method': 'SHA_PINNED_READONLY_ARCHIVED_KERNEL',
        'kernel':TARGET_KERNEL, 'boot_sha256':prev.stock.BOOT_SHA256,
        'symbols_decoded':len(symbols),'kallsyms_markers':markers,
        'symbol_futex_wait_requeue_pi_is_independent':standalone,
        'do_futex_to_wait_requeue_helpers':calls,
        'all_five_direct_calls_present':all(calls.values()),
        'kernel_config':conf,
        'assessment':verdict,
        'interpretation':'5 BL calls consistent with historical function inlined into do_futex; not a proof of block-level semantic equivalence',
        'provenance':{
          'archived_boot_only':True,
          'xiaomi_public_source_kernel_version':'4.14.180, not archived 4.14.190',
          'source_ref':'https://github.com/MiCode/Xiaomi_Kernel_OpenSource/blob/sweet-r-oss/kernel/futex.c',
          'source_function':'futex_wait_requeue_pi in public kernel/futex.c lines 3327-3441',
          'verified_running_boot':False, 'actual_root_uid0':False,
          'ghostlock_exploit_ported':False,
        }
    }

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('stock_archive',type=Path)
    ap.add_argument('--out',type=Path)
    args = ap.parse_args()
    result=run(args.stock_archive)
    report=json.dumps(result,indent=2,ensure_ascii=False)+'\n'
    if args.out:
        args.out.parent.mkdir(parents=True,exist_ok=True)
        args.out.write_text(report,encoding='utf-8')
    print(report)
    if not result['all_five_direct_calls_present']:
        raise SystemExit(1)
if __name__ == '__main__':
    main()
