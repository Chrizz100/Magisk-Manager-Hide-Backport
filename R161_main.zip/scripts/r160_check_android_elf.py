#!/usr/bin/env python3
"""R16.0: verify Android/arm64 PIE executability and stage a read-only native program.

This only examines ELF headers and stages a native preflight executable.
No exploit, root, boot image writes, or device access.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import shutil
import struct
import zipfile
from pathlib import Path

NAME = "libsweet414_preflight.so"
ENTRY = f"lib/arm64-v8a/{NAME}"

class ElfError(ValueError):
    pass

def validate(data: bytes) -> dict:
    if len(data) < 64 or data[:4] != b"\x7fELF":
        raise ElfError("NOT_ELF")
    if data[4] != 2 or data[5] != 1 or data[6] != 1:
        raise ElfError("NOT_ELF64_LITTLE_ENDIAN")
    typ, machine = struct.unpack_from('<HH', data, 16)
    if machine != 183:
        raise ElfError("NOT_AARCH64")
    if typ != 3:
        raise ElfError("NOT_PIE_ET_DYN")
    phoff = struct.unpack_from('<Q', data, 32)[0]
    ehsize, phentsize, phnum = struct.unpack_from('<HHH', data, 52)
    if ehsize != 64 or phentsize != 56 or phnum <= 0 or phnum > 200:
        raise ElfError("BAD_ELF_PROGRAM_HEADERS")
    if phoff < 64 or phoff + phentsize * phnum > len(data):
        raise ElfError("TRUNCATED_ELF_PROGRAM_HEADERS")
    interpreter = None
    has_executable_segment = False
    for i in range(phnum):
        ph = struct.unpack_from('<IIQQQQQQ', data, phoff + i * phentsize)
        p_type, p_flags, p_offset, _, _, p_filesz, _, _ = ph
        if p_type == 3:  # PT_INTERP, present on a PIE executable but not on usual shared libs
            if p_offset + p_filesz > len(data) or p_filesz < 2 or p_filesz > 256:
                raise ElfError("INVALID_INTERPRETER_SEGMENT")
            raw = data[p_offset:p_offset+p_filesz]
            if not raw.endswith(b'\0'):
                raise ElfError("INVALID_INTERPRETER_SEGMENT")
            try:
                interpreter = raw[:-1].decode('ascii')
            except UnicodeDecodeError as ex:
                raise ElfError("INVALID_INTERPRETER_SEGMENT") from ex
        if p_type == 1 and p_flags & 1:
            has_executable_segment = True
            if p_flags & 2:
                raise ElfError("WRITABLE_EXECUTABLE_SEGMENT")
        if p_type == 0x6474e551 and p_flags & 1:  # PT_GNU_STACK must not be executable
            raise ElfError("EXECUTABLE_STACK")
    if not has_executable_segment:
        raise ElfError("MISSING_EXEC_SEGMENT")
    if interpreter != '/system/bin/linker64':
        raise ElfError(f"NOT_ANDROID_DYNAMIC_LINKER:{interpreter}")
    return {
        'elf': 'ELF64 PIE AArch64',
        'interpreter': interpreter,
        'purpose': 'non-root archive compatibility preflight only',
        'root_proof': False,
        'size_bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
    }

def stage(binary: Path, out: Path) -> dict:
    b = binary.read_bytes()
    info = validate(b)
    target = out/'lib'/'arm64-v8a'/NAME
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(binary, target)
    target.chmod(target.stat().st_mode | 0o111)
    meta = out/'R160_ANDROID_ARM64_NATIVE_MANIFEST.json'
    meta.write_text(json.dumps({**info, 'apk_path': ENTRY}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return info

def apk_check(apk: Path) -> dict:
    with zipfile.ZipFile(apk) as z:
        found = [v for v in z.namelist() if v == ENTRY]
        if len(found) != 1:
            raise ElfError('APK_MISSING_OR_DUPLICATE_NATIVE_EXECUTABLE')
        return validate(z.read(ENTRY))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument('--binary',type=Path)
    g.add_argument('--apk',type=Path)
    p.add_argument('--stage',type=Path)
    args = p.parse_args()
    if args.apk:
        info=apk_check(args.apk)
    elif args.stage:
        info=stage(args.binary,args.stage)
    else:
        info=validate(args.binary.read_bytes())
    print(json.dumps(info, sort_keys=True))
if __name__=='__main__':
    main()
