#!/usr/bin/env python3
"""Fail-closed static APK packaging audit; NOT a device runtime test."""
import argparse,hashlib,json,re,struct,zipfile
from pathlib import Path
from r160_check_android_elf import validate, ENTRY

def check(path, expected):
    assert re.fullmatch('[0-9a-f]{64}',expected)
    with zipfile.ZipFile(path) as z:
        assert z.testzip() is None, 'APK_ZIP_CORRUPT'
        entries=z.namelist()
        assert entries.count(ENTRY)==1, 'APK_NATIVE_BINARY_NOT_EXACTLY_ONCE'
        assert 'AndroidManifest.xml' in entries, 'APK_NO_MANIFEST'
        assert 'classes.dex' in entries, 'APK_NO_CLASSES'
        p=z.getinfo(ENTRY)
        assert p.compress_type==zipfile.ZIP_DEFLATED,'LIB_NOT_LEGACY_COMPRESSED'
        b=z.read(ENTRY)
        info=validate(b)
        assert info['sha256']==expected, 'APK_STAGED_NATIVE_SHA_MISMATCH'
        # The packaged binary is executable native code, not a normal shared library.
        assert info['interpreter']=='/system/bin/linker64'
        return {'result':'APK_NATIVE_PACKAGING_STATIC_PASS','apk_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                'embedded_native_sha256':info['sha256'],'legacy_compressed_native_packaging': True,
                'native_library_extraction_on_real_device': 'NOT_TESTED',
                'live_device_test':'NOT_RUN','root':'NOT_PRESENT','apk_bytes':path.stat().st_size}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--apk',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path);args=p.parse_args()
 result=check(args.apk,args.sha256)
 if args.output:args.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(result,sort_keys=True))
