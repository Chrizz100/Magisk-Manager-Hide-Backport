#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STOCK_ZIP="${1:-}"
if [[ -z "$STOCK_ZIP" || ! -f "$STOCK_ZIP" ]]; then
  echo "Missing stock archive. Usage: bash scripts/run_offline_tests.sh /path/to/SWEET_STOCK_REFERENZEN_20261107.zip" >&2
  exit 64
fi
cmake -S "$ROOT" -B "$ROOT/build-host" -DCMAKE_BUILD_TYPE=Release
cmake --build "$ROOT/build-host" -j2
ctest --test-dir "$ROOT/build-host" --output-on-failure
python3 "$ROOT/scripts/audit_cred.py" "$STOCK_ZIP"
STOCK_ZIP="$STOCK_ZIP" python3 -m unittest discover -s "$ROOT/tests" -p 'test_cred.py' -v

python3 "$ROOT/scripts/r154_selinux_audit.py" "$STOCK_ZIP" --out "$ROOT/reports/r154_crosscheck.json"
STOCK_ZIP="$STOCK_ZIP" python3 -m unittest discover -s "$ROOT/tests" -p 'test_r154_contract.py' -v

python3 "$ROOT/scripts/r155_ghostlock_route_audit.py" "$STOCK_ZIP" --out "$ROOT/reports/r155_route_audit.json" >/dev/null
python3 -m unittest discover -s "$ROOT/tests" -p 'test_r155_route_audit.py' -v
