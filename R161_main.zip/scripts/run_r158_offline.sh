#!/usr/bin/env bash
# Read-only R15.8 regression. Never connects to a device, modifies images or requests SU.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STOCK="${1:-}"
if [[ -z "$STOCK" || ! -f "$STOCK" ]]; then
  echo "Usage: bash scripts/run_r158_offline.sh /path/SWEET_STOCK_REFERENZEN_20261107.zip" >&2
  exit 64
fi
mkdir -p "$ROOT/reports"
python3 "$ROOT/scripts/r158_build_evidence.py" "$STOCK" \
  --out-json "$ROOT/reports/r158_evidence.json" \
  --out-header "$ROOT/src/r158_archive_snapshot.hpp" \
  > "$ROOT/reports/r158_generate.log" 2>&1
for compiler in g++ clang++; do
  if ! command -v "$compiler" >/dev/null 2>&1; then
    echo "C++ compiler not found: $compiler" >&2
    exit 69
  fi
  tag="${compiler//+/p}"
  cmake -S "$ROOT" -B "$ROOT/.build-${tag}" -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_COMPILER="$(command -v "$compiler")" \
    > "$ROOT/reports/r158_configure_${tag}.log" 2>&1
  cmake --build "$ROOT/.build-${tag}" --parallel 2 \
    > "$ROOT/reports/r158_build_${tag}.log" 2>&1
  ctest --test-dir "$ROOT/.build-${tag}" --output-on-failure \
    > "$ROOT/reports/r158_ctest_${tag}.log" 2>&1
done
# Retain the existing R15.5 tests and the real R15.6/R15.7 binary regression.
STOCK_ZIP="$STOCK" python3 -m unittest discover -s "$ROOT/tests" -p 'test_cred.py' -v \
  > "$ROOT/reports/r158_py_cred.log" 2>&1
STOCK_ZIP="$STOCK" python3 -m unittest discover -s "$ROOT/tests" -p 'test_r154_contract.py' -v \
  > "$ROOT/reports/r158_py_r154.log" 2>&1
python3 -m unittest discover -s "$ROOT/tests" -p 'test_r155_route_audit.py' -v \
  > "$ROOT/reports/r158_py_r155.log" 2>&1
python3 "$ROOT/tests/test_r156_readonly_callgraph.py" "$STOCK" \
  > "$ROOT/reports/r158_py_r156.log" 2>&1
python3 "$ROOT/tests/test_r157.py" "$STOCK" \
  > "$ROOT/reports/r158_py_r157.log" 2>&1
STOCK_ZIP="$STOCK" python3 -m unittest discover -s "$ROOT/tests" -p 'test_r158.py' -v \
  > "$ROOT/reports/r158_py_r158.log" 2>&1
printf '%s\n' 'R15.8: native host tests GCC/Clang PASS; R15.5-R15.8 Python regression PASS.'
printf '%s\n' 'No Android/device test; no actual uid=0; no boot/recovery write.'
