#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STOCK="${1:-}"
[[ -f "$STOCK" ]] || { echo "Usage: bash scripts/run_r159_offline.sh STOCK_REFERENZEN.zip" >&2; exit 64; }
command -v kotlinc >/dev/null || { echo 'Kotlin compiler missing'; exit 69; }
command -v java >/dev/null || { echo 'Java missing'; exit 69; }
bash "$ROOT/scripts/run_r158_offline.sh" "$STOCK"
kotlinc "$ROOT/android/src/main/java/dev/sweet414/NativeArchiveAuditRunner.kt" \
    "$ROOT/tests/ProcessBridgeIntegration.kt" \
    -include-runtime -d "$ROOT/.build-gpp/r159_process_tests.jar" \
    > "$ROOT/reports/r159_kotlin_compile.log" 2>&1
java -jar "$ROOT/.build-gpp/r159_process_tests.jar" "$ROOT/.build-gpp/sweet414-port" \
    > "$ROOT/reports/r159_kotlin_process_test.log" 2>&1
printf '%s\n' 'R15.9: 41 Python, 5 GCC C++, 5 Clang C++ and 7 JVM/native IPC tests PASS.'
printf '%s\n' 'Only archived boot assessed; real device root not proven; no exploit, no flash.'
