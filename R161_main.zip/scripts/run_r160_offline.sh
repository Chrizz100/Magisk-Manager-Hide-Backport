#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STOCK="${1:-}"
[[ -f "$STOCK" ]] || { echo 'Usage: bash scripts/run_r160_offline.sh STOCK_REFERENZEN.zip' >&2; exit 64; }
mkdir -p "$ROOT/reports"
bash "$ROOT/scripts/run_r158_offline.sh" "$STOCK" >"$ROOT/reports/r160_regression.log" 2>&1
kotlinc "$ROOT/android/src/main/java/dev/sweet414/NativeArchiveAuditRunner.kt" \
  "$ROOT/tests/ProcessBridgeIntegration.kt" -include-runtime \
  -d "$ROOT/.build-gpp/r160_process_tests.jar" \
  >"$ROOT/reports/r160_kotlin_compile.log" 2>&1
java -jar "$ROOT/.build-gpp/r160_process_tests.jar" "$ROOT/.build-gpp/sweet414-port" \
  >"$ROOT/reports/r160_kotlin_native_integration.log" 2>&1
python3 "$ROOT/tests/test_r160_android_elf.py" >"$ROOT/reports/r160_elf_tests.log" 2>&1
printf '%s\n' 'R16.0: 41 existing Python + 5 GCC C++ + 5 Clang C++ + 10 JVM/native + 10 new ELF gate tests PASS.'
printf '%s\n' 'Android NDK actual compile / APK / device test remain open; no root, no flash.'
