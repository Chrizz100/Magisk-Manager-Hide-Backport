#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
# Existing read-only archive regressions need the separately kept STOCK zip.
# Host native and Java parser tests do not.
if [[ $# -ge 1 ]]; then
  bash scripts/run_r160_offline.sh "$1"
else
  cmake -S . -B .build-r161-host -DCMAKE_BUILD_TYPE=Release >/dev/null
  cmake --build .build-r161-host --parallel 2 >/dev/null
  ctest --test-dir .build-r161-host --output-on-failure
fi
python3 -m unittest discover -s tests -p test_r161_packaging.py -v
mkdir -p .build-r161-java
javac -encoding UTF-8 -d .build-r161-java \
  app/src/main/java/dev/sweet414/audit/NativeOutputParser.java \
  tests/android/NativeOutputParserTest.java
java -cp .build-r161-java dev.sweet414.audit.NativeOutputParserTest
