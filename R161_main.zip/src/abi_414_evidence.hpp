#pragma once

#include <array>
#include <cstddef>
#include <cstdint>
#include <string_view>

// Static, read-only evidence from a single SHA-256-pinned archived boot image.
// NEVER use these image-derived values as live kernel addresses or as an
// executable exploit profile. The active phone's boot image is NOT attested.
namespace sweet414::abi {

inline constexpr std::string_view kArchivedBootSha256 =
    "4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015";
inline constexpr std::string_view kArchivedKernelSha256 =
    "1af5b8958e95f82fefc0b9357ddbdfcebba406a3b50f4edb5e5fd21e4b8041fb";

enum class FieldBasis { BinaryAnchor, SourceInferred };
struct ObservedField {
    std::string_view name;
    std::uint32_t byte_offset;
    FieldBasis basis;
};

// Observed in ARM64 machine instructions of the archived 4.14.190 image.
inline constexpr std::array<ObservedField, 9> kTaskStruct = {{
    {"prio", 0xa8, FieldBasis::BinaryAnchor},
    {"normal_prio", 0xb0, FieldBasis::BinaryAnchor},
    {"real_cred", 0x7f8, FieldBasis::BinaryAnchor},
    {"cred", 0x800, FieldBasis::BinaryAnchor},
    {"seccomp", 0x8a0, FieldBasis::BinaryAnchor},
    {"pi_lock", 0x8c4, FieldBasis::BinaryAnchor},
    {"pi_waiters", 0x8d0, FieldBasis::BinaryAnchor},
    {"pi_top_task", 0x8d8, FieldBasis::BinaryAnchor},
    {"pi_blocked_on", 0x8e8, FieldBasis::BinaryAnchor},
}};

// Some cred offsets are supported by binary anchors; group_info is
// only source-corroborated and must NOT be called machine-code-verified.
inline constexpr std::array<ObservedField, 5> kCredStruct = {{
    {"cap_effective", 0x38, FieldBasis::BinaryAnchor},
    {"security", 0x78, FieldBasis::BinaryAnchor},
    {"user", 0x80, FieldBasis::BinaryAnchor},
    {"group_info", 0x90, FieldBasis::SourceInferred},
    {"non_rcu", 0x98, FieldBasis::BinaryAnchor},
}};
inline constexpr std::uint32_t kCredSize = 0xa8;

// Xiaomi sweet-r-oss is 4.14.180; this model is SOURCE-CORROBORATED, not
// an independently proven structure of the running 4.14.190 partition.
enum class SelinuxAbiModel { LegacyCredSecurityPointer, UnsupportedBlobOffsets };
inline constexpr SelinuxAbiModel kArchivedSelinuxModel =
    SelinuxAbiModel::LegacyCredSecurityPointer;

struct OfflineEvidence {
    std::string_view boot_sha256;
    std::string_view kernel_sha256;
    bool archived_symbols_checked = false;
    bool archived_machine_anchors_checked = false;
    bool selinux_config_enabled = false;
    bool selinux_state_symbol_present = false;
    bool selinux_blob_sizes_symbol_present = false;
    bool gcc_plugins_disabled = false;
    bool live_boot_partition_hash_verified = false;
};

enum class EvidenceGate {
    UntrustedArchive,
    UnsupportedSelinuxModel,
    ArchivedSnapshotOnly,
};

// Read-only interpretation of supplied results, not a root-execution guard.
// Even ArchivedSnapshotOnly MUST NEVER enable kernel memory writes.
inline EvidenceGate evaluate_offline(const OfflineEvidence& e) noexcept {
    if (e.boot_sha256 != kArchivedBootSha256 ||
        e.kernel_sha256 != kArchivedKernelSha256 ||
        !e.archived_symbols_checked ||
        !e.archived_machine_anchors_checked || !e.gcc_plugins_disabled) {
        return EvidenceGate::UntrustedArchive;
    }
    if (!e.selinux_config_enabled || !e.selinux_state_symbol_present ||
        e.selinux_blob_sizes_symbol_present) {
        return EvidenceGate::UnsupportedSelinuxModel;
    }
    // Even a matching runtime hash would not prove a functioning exploit.
    return EvidenceGate::ArchivedSnapshotOnly;
}

inline const char* gate_string(EvidenceGate gate) noexcept {
    switch (gate) {
        case EvidenceGate::UntrustedArchive: return "ARCHIVE_EVIDENCE_UNVERIFIED";
        case EvidenceGate::UnsupportedSelinuxModel: return "SELINUX_MODEL_MISMATCH";
        case EvidenceGate::ArchivedSnapshotOnly: return "ARCHIVED_ABI_ONLY_NO_ROOT_BACKEND";
    }
    return "INVALID_GATE";
}

} // namespace sweet414::abi
