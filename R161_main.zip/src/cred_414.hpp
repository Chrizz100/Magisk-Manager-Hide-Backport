#pragma once
#include <cstddef>
#include <cstdint>
#include <type_traits>

// READ-ONLY ABI documentation for a SHA-256-pinned, archived sweet stock kernel.
// Never cast a live kernel pointer to this layout or use it for kernel writes.
// Values cross-checked by scripts/audit_cred.py. Unmeasured members are
// sourced from the older Xiaomi sweet-r-oss header and are not proof of the
// running kernel's actual credential layout.
namespace sweet414 {
struct Cred414LayoutEvidence final {
    std::uint32_t usage;
    std::uint32_t uid;
    std::uint32_t gid;
    std::uint32_t suid;
    std::uint32_t sgid;
    std::uint32_t euid;
    std::uint32_t egid;
    std::uint32_t fsuid;
    std::uint32_t fsgid;
    std::uint32_t securebits;
    std::uint64_t cap_inheritable;
    std::uint64_t cap_permitted;
    std::uint64_t cap_effective;
    std::uint64_t cap_bset;
    std::uint64_t cap_ambient;
    std::uint8_t jit_keyring;
    std::uint8_t _pad_after_jit[7];
    std::uint64_t session_keyring;
    std::uint64_t process_keyring;
    std::uint64_t thread_keyring;
    std::uint64_t request_key_auth;
    std::uint64_t security;
    std::uint64_t user;
    std::uint64_t user_ns;
    std::uint64_t group_info;
    std::uint64_t rcu_next_or_non_rcu;
    std::uint64_t rcu_func;
};
static_assert(std::is_standard_layout<Cred414LayoutEvidence>::value, "ABI evidence must be a plain layout");
static_assert(sizeof(Cred414LayoutEvidence) == 0xa8, "Size observed in prepare_creds differs");
static_assert(offsetof(Cred414LayoutEvidence, cap_effective) == 0x38, "Capability offset drift");
static_assert(offsetof(Cred414LayoutEvidence, security) == 0x78, "Security offset drift");
static_assert(offsetof(Cred414LayoutEvidence, user) == 0x80, "User offset drift");
static_assert(offsetof(Cred414LayoutEvidence, group_info) == 0x90, "Group offset drift");
static_assert(offsetof(Cred414LayoutEvidence, rcu_next_or_non_rcu) == 0x98, "RCU offset drift");

inline constexpr std::size_t kCredSizeFromVerifiedBinary = 0xa8;
inline constexpr std::size_t kCredCapEffectiveOffsetFromVerifiedBinary = 0x38;
inline constexpr std::size_t kCredSecurityOffsetFromVerifiedBinary = 0x78;
inline constexpr std::size_t kCredUserOffsetFromVerifiedBinary = 0x80;
inline constexpr std::size_t kCredGroupOffsetFromVerifiedBinary = 0x90;
inline constexpr std::size_t kCredNonRcuOffsetFromVerifiedBinary = 0x98;
} // namespace sweet414
