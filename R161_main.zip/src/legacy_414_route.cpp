#include "legacy_414_route.hpp"

namespace sweet414 {
LegacyRouteAssessment assess_legacy_route(const LegacyRouteEvidence& e) {
    // Invariant: an archived call graph and matching uname NEVER authorize
    // a root attempt or imply kernel runtime compatibility.
    LegacyRouteAssessment r{};
    if (e.release != "4.14.190-perf-g7da93debc0ee") {
        r.verdict = LegacyRouteVerdict::WrongRelease;
        return r;
    }
    if (!e.archive_sha_verified) {
        r.verdict = LegacyRouteVerdict::UntrustedArchive;
        return r;
    }
    if (!(e.legacy_futex_symbol && e.legacy_pselect_symbol &&
          e.futex_dispatch_symbol && e.pselect_core_symbol)) {
        r.verdict = LegacyRouteVerdict::MissingLegacySymbols;
        return r;
    }
    r.legacy_symbol_aliases_resolved = true;
    if (!e.required_six_calls) {
        r.verdict = LegacyRouteVerdict::CallGraphUnconfirmed;
        return r;
    }
    if (!e.standalone_wait_symbol && !e.all_five_wait_helpers) {
        r.verdict = LegacyRouteVerdict::WaitPathUnconfirmed;
        return r;
    }
    r.archived_futex_path_observed = true;
    // A plausible inlined function remains an unverified candidate.
    if (!e.running_boot_byte_identical) {
        r.verdict = LegacyRouteVerdict::ArchivedCandidateOnly;
        return r;
    }
    // Even with a live-byte match, other exploit/runtime invariants remain open.
    r.verdict = LegacyRouteVerdict::BackendUnverified;
    return r;
}
const char* legacy_route_verdict(LegacyRouteVerdict v) {
    switch (v) {
        case LegacyRouteVerdict::WrongRelease: return "RELEASE_MISMATCH";
        case LegacyRouteVerdict::UntrustedArchive: return "ARCHIVE_INTEGRITY_NOT_VERIFIED";
        case LegacyRouteVerdict::MissingLegacySymbols: return "LEGACY_SYMBOLS_INCOMPLETE";
        case LegacyRouteVerdict::CallGraphUnconfirmed: return "REQUIRED_DIRECT_CALLS_UNVERIFIED";
        case LegacyRouteVerdict::WaitPathUnconfirmed: return "WAIT_PATH_UNVERIFIED";
        case LegacyRouteVerdict::ArchivedCandidateOnly: return "ARCHIVED_4_14_PATH_FOUND_LIVE_KERNEL_UNCHECKED";
        case LegacyRouteVerdict::BackendUnverified: return "GHOSTLOCK_4_14_BACKEND_UNVERIFIED";
    }
    return "UNKNOWN";
}
} // namespace sweet414
