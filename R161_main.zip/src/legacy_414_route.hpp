#pragma once
#include <string>

namespace sweet414 {

// These observations describe the archived, hash-pinned stock image only.
// Deliberately no kernel addresses, memory writes or exploit primitives.
struct LegacyRouteEvidence {
    std::string release;
    bool archive_sha_verified = false;
    bool legacy_futex_symbol = false;
    bool legacy_pselect_symbol = false;
    bool futex_dispatch_symbol = false;
    bool pselect_core_symbol = false;
    bool required_six_calls = false;
    bool all_five_wait_helpers = false;
    bool standalone_wait_symbol = false;
    bool running_boot_byte_identical = false;
    bool native_414_root_backend_verified = false;
};

enum class LegacyRouteVerdict {
    WrongRelease,
    UntrustedArchive,
    MissingLegacySymbols,
    CallGraphUnconfirmed,
    WaitPathUnconfirmed,
    ArchivedCandidateOnly,
    BackendUnverified,
};
struct LegacyRouteAssessment {
    LegacyRouteVerdict verdict;
    bool legacy_symbol_aliases_resolved = false;
    bool archived_futex_path_observed = false;
    bool may_start_root = false;
};
LegacyRouteAssessment assess_legacy_route(const LegacyRouteEvidence& evidence);
const char* legacy_route_verdict(LegacyRouteVerdict verdict);
} // namespace sweet414
