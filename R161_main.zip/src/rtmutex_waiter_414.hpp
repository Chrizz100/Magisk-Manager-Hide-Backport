#pragma once
#include <cstddef>
#include <cstdint>
#include <type_traits>

// READ-ONLY representation of the upstream Xiaomi sweet-r-oss 4.14.180
// rt_mutex_waiter layout when CONFIG_DEBUG_RT_MUTEXES=n.
// Pointers are represented as uint64_t; the layout is NOT verified in the
// active phone's kernel or independently measured in the archived 4.14.190
// binary. NEVER cast a live kernel pointer or generate a writable payload.
namespace sweet414::source_abi {

struct RbNode414 {
    std::uint64_t parent_color;
    std::uint64_t right;
    std::uint64_t left;
};
struct RtMutexWaiter414 {
    RbNode414 tree_entry;
    RbNode414 pi_tree_entry;
    std::uint64_t task;
    std::uint64_t lock;
    std::int32_t prio;
    std::uint32_t padding_before_deadline;
    std::uint64_t deadline;
};

static_assert(sizeof(void*) == 8, "This source ABI is only valid for 64-bit hosts");
static_assert(sizeof(RbNode414) == 24, "Unexpected rb_node representation");
static_assert(offsetof(RtMutexWaiter414, tree_entry) == 0);
static_assert(offsetof(RtMutexWaiter414, pi_tree_entry) == 24);
static_assert(offsetof(RtMutexWaiter414, task) == 48);
static_assert(offsetof(RtMutexWaiter414, lock) == 56);
static_assert(offsetof(RtMutexWaiter414, prio) == 64);
static_assert(offsetof(RtMutexWaiter414, deadline) == 72);
static_assert(sizeof(RtMutexWaiter414) == 80);
static_assert(std::is_standard_layout<RtMutexWaiter414>::value);

// Documented source geometry only; not a run-ready GhostLock profile.
inline constexpr bool kBinaryOffsetsValidated = false;
inline constexpr bool kRunningKernelMatched = false;
inline constexpr bool kRootBackendAvailable = false;
}
