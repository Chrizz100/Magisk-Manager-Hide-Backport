#include "sweet414_port.hpp"
#include "cred_414.hpp"
#include <sys/utsname.h>

#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif

namespace sweet414 {

namespace {
constexpr const char* kCodename = "sweet";
constexpr const char* kKernel = "4.14.190-perf-g7da93debc0ee";
constexpr const char* kAndroid = "13";
constexpr const char* kMiui = "V14.0.9.0.TKFEUXM";

std::string prop(const char* name) {
#ifdef __ANDROID__
    char value[PROP_VALUE_MAX] = {};
    if (__system_property_get(name, value) > 0) return value;
#else
    (void)name;
#endif
    return {};
}
}

DeviceFacts read_local_facts() {
    struct utsname system_info {};
    DeviceFacts facts;
    if (uname(&system_info) == 0) {
        facts.kernel_release = system_info.release;
        facts.machine = system_info.machine;
    }
    facts.codename = prop("ro.product.device");
    facts.android_release = prop("ro.build.version.release");
    facts.miui_incremental = prop("ro.build.version.incremental");
    return facts;
}

Preflight evaluate(const DeviceFacts& device) {
    Preflight r;
    // Fail closed. The following gates check identity only; they never imply a
    // working exploit, a privileged shell, or Magisk installation.
    if (device.codename != kCodename) {
        r.verdict = Verdict::DeviceMismatch;
        r.reasons.push_back("Device codename is not sweet (or is unavailable)");
        return r;
    }
    if (device.machine != "aarch64") {
        r.verdict = Verdict::UnsupportedArchitecture;
        r.reasons.push_back("Kernel architecture is not aarch64");
        return r;
    }
    if (device.kernel_release != kKernel) {
        r.verdict = Verdict::KernelMismatch;
        r.reasons.push_back("Kernel release differs from archived Xiaomi boot image");
        return r;
    }
    if (device.android_release != kAndroid || device.miui_incremental != kMiui) {
        r.verdict = Verdict::FirmwareMismatch;
        r.reasons.push_back("Android/MIUI build differs from documented research snapshot");
        return r;
    }
    r.exact_identity_match = true;
    r.executable_root_backend_available = false;
    r.root_confirmed = false;
    r.verdict = Verdict::SupportedForStaticReviewOnly;
    r.reasons.push_back("Exact device identity matched; native 4.14 GhostLock exploit backend has not been verified or implemented");
    return r;
}

const char* verdict_string(Verdict v) {
    switch (v) {
        case Verdict::DeviceMismatch: return "DEVICE_MISMATCH";
        case Verdict::FirmwareMismatch: return "FIRMWARE_MISMATCH";
        case Verdict::KernelMismatch: return "KERNEL_MISMATCH";
        case Verdict::UnsupportedArchitecture: return "ARCH_MISMATCH";
        case Verdict::SupportedForStaticReviewOnly: return "IDENTITY_OK_BACKEND_MISSING";
    }
    return "UNRECOGNIZED";
}

} // namespace sweet414
