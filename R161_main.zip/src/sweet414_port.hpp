#pragma once

#include <string>
#include <vector>

namespace sweet414 {

struct DeviceFacts {
    std::string codename;
    std::string kernel_release;
    std::string machine;
    std::string android_release;
    std::string miui_incremental;
};

enum class Verdict {
    DeviceMismatch = 20,
    FirmwareMismatch = 21,
    KernelMismatch = 22,
    UnsupportedArchitecture = 23,
    SupportedForStaticReviewOnly = 24,
};

struct Preflight {
    Verdict verdict;
    std::vector<std::string> reasons;
    bool exact_identity_match = false;
    bool executable_root_backend_available = false;
    bool root_confirmed = false;
};

// No arbitrary offsets, no kernel writes, and no exploitation happens here.
// Recognizes precisely the firmware snapshot that was analyzed offline.
Preflight evaluate(const DeviceFacts& device);
DeviceFacts read_local_facts();
const char* verdict_string(Verdict verdict);

} // namespace sweet414
