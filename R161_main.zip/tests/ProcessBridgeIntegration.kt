package dev.sweet414

import java.io.File
import java.nio.file.Files
import java.security.MessageDigest

/** JVM integration test launches the ACTUAL compiled C++ host executable via ProcessBuilder. */
fun main(args: Array<String>) {
    require(args.size == 1) { "Usage: <compiled native binary>" }
    val root = Files.createTempDirectory("r159-process").toFile()
    val out = File(root,"cache").apply { mkdirs() }
    var passed = 0
    fun checkIt(label: String, block: () -> Unit) { block(); passed++; println("PASS $label") }
    fun sha(f: File): String = MessageDigest.getInstance("SHA-256")
        .digest(f.readBytes()).joinToString("") { "%02x".format(it) }
    fun install(f: File): File = File(root,"libsweet414_preflight.so").also {
        f.copyTo(it, overwrite = true); it.setExecutable(true)
    }
    fun invalid(expected: String, body: () -> Unit) {
        try { body(); error("Expected failure: $expected") }
        catch(e: NativeArchiveAuditRunner.AuditFailure) {
            check(e.message == expected) { "Expected $expected, got ${e.message}" }
        }
    }
    fun validSnapshot(replacement: String): String {
        val entries = linkedMapOf(
            "archive_4_14_route" to "ARCHIVED_4_14_PATH_FOUND_LIVE_KERNEL_UNCHECKED",
            "legacy_symbol_names_identified" to "true",
            "archived_futex_path_observed" to "true",
            "archive_source" to "SHA256_PINNED_STOCK_BOOT_SNAPSHOT",
            "archive_boot_sha256" to "4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015",
            "live_boot_match_confirmed" to "false",
            "root_backend_available" to "false",
            "root_confirmed" to "false"
        )
        val key = replacement.substringBefore('=')
        require(key in entries)
        entries[key] = replacement.substringAfter('=')
        return entries.map { (k,v) -> "$k=$v" }.joinToString("\n", postfix="\n")
    }
    fun maliciousOutput(body: String): File {
        val program = File(root,"fixture.sh")
        program.writeText("#!/bin/sh\n" + body + "\n")
        program.setExecutable(true)
        return install(program)
    }
    try {
        val good = install(File(args[0]))
        checkIt("compiled native executable launched and parsed") {
            val result = NativeArchiveAuditRunner(root, out, sha(good)).audit()
            check(result.legacySymbolsFound && result.archivedPathFound)
            check(result.archiveSha256 == "4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015")
            check(!result.liveBootMatchConfirmed)
            check(!result.rootAvailable && !result.rootConfirmed)
        }
        checkIt("wrong executable hash rejected before launch") {
            invalid("AUDIT_EXECUTABLE_HASH_MISMATCH") {
                NativeArchiveAuditRunner(root,out,"0".repeat(64)).audit()
            }
        }
        checkIt("missing executable rejected") {
            good.delete()
            invalid("AUDIT_EXECUTABLE_MISSING") {
                NativeArchiveAuditRunner(root,out,"0".repeat(64)).audit()
            }
        }
        checkIt("root success cannot be forged by archive output") {
            val goodText = "archive_4_14_route=ARCHIVED_4_14_PATH_FOUND_LIVE_KERNEL_UNCHECKED\n" +
                "legacy_symbol_names_identified=true\narchived_futex_path_observed=true\n" +
                "archive_source=SHA256_PINNED_STOCK_BOOT_SNAPSHOT\n" +
                "archive_boot_sha256=4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015\n" +
                "live_boot_match_confirmed=false\n" +
                "root_backend_available=true\nroot_confirmed=true\n"
            val p = maliciousOutput("printf '%s' '${goodText.replace("'", "'\"'\"'")}'")
            invalid("ARCHIVE_AUDIT_CANNOT_CLAIM_ROOT") {
                NativeArchiveAuditRunner(root,out,sha(p)).audit()
            }
        }
        checkIt("forged live boot match rejected") {
            val body = validSnapshot("live_boot_match_confirmed=true")
            val p = maliciousOutput("printf '%s' '${body}'")
            invalid("ARCHIVE_AUDIT_CANNOT_CLAIM_LIVE_BOOT") {
                NativeArchiveAuditRunner(root,out,sha(p)).audit()
            }
        }
        checkIt("wrong archive boot SHA rejected") {
            val body = validSnapshot("archive_boot_sha256=${"0".repeat(64)}")
            val p = maliciousOutput("printf '%s' '${body}'")
            invalid("AUDIT_ARCHIVE_SHA_MISMATCH") {
                NativeArchiveAuditRunner(root,out,sha(p)).audit()
            }
        }
        checkIt("untrusted archive source rejected") {
            val body = validSnapshot("archive_source=UNVERIFIED")
            val p = maliciousOutput("printf '%s' '${body}'")
            invalid("AUDIT_BAD_EVIDENCE_SOURCE") {
                NativeArchiveAuditRunner(root,out,sha(p)).audit()
            }
        }
        checkIt("abnormal process exit rejected") {
            val p=maliciousOutput("exit 17")
            invalid("AUDIT_PROCESS_NONZERO_EXIT") { NativeArchiveAuditRunner(root,out,sha(p)).audit() }
        }
        checkIt("duplicate keys rejected") {
            val goodText = "archive_4_14_route=ARCHIVED_4_14_PATH_FOUND_LIVE_KERNEL_UNCHECKED\n" +
                "archive_4_14_route=ARCHIVED_4_14_PATH_FOUND_LIVE_KERNEL_UNCHECKED\n"
            val p = maliciousOutput("printf '%s' '${goodText}'")
            invalid("AUDIT_OUTPUT_BAD_KEYS") { NativeArchiveAuditRunner(root,out,sha(p)).audit() }
        }
        checkIt("oversized output rejected") {
            val p = maliciousOutput("yes X | head -c 5000")
            invalid("AUDIT_OUTPUT_TOO_LARGE") { NativeArchiveAuditRunner(root,out,sha(p)).audit() }
        }
    } finally { root.deleteRecursively() }
    println("R15.9 JVM/native ProcessBuilder integration: $passed/$passed tests PASS")
}
