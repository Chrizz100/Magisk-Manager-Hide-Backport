package dev.sweet414.audit;

public final class NativeOutputParserTest {
    private static int passes = 0;
    private static String output(String verdict,String root,String uid) {
        return "kernel=4.14.190-perf-g7da93debc0ee\n"+
            "device=sweet\nandroid=13\nmiui=V14.0.9.0.TKFEUXM\n"+
            "verdict="+verdict+"\nprocess_uid="+uid+"\nprocess_euid="+uid+"\n"+
            "root_backend_available="+root+"\nroot_confirmed=false\n"+
            "reason=backend missing\n";
    }
    private static void ok(boolean b) { if (!b) throw new AssertionError("TEST_FAILED"); passes++; }
    private static void bad(String s,int code) {
        boolean failed = false;
        try { NativeOutputParser.parse(s,code); }
        catch (IllegalArgumentException e) { failed = true; }
        ok(failed);
    }
    public static void main(String[] args) {
        var x=NativeOutputParser.parse(output("IDENTITY_OK_BACKEND_MISSING","false","10234"),24);
        ok(x.identityMatched && x.uid==10234 && !x.verdict.isEmpty());
        var y=NativeOutputParser.parse(output("KERNEL_MISMATCH","false","10234"),22);
        ok(!y.identityMatched);
        bad(output("IDENTITY_OK_BACKEND_MISSING","true","10234"),24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","0"),24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","10234"),0);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","10234")+"root_confirmed=false\n",24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","10234").replace("process_euid=10234\n",""),24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","abc"),24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","10234")+"INJECTED_KEY=yes\n",24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","10234").replace("root_confirmed=false","root_confirmed=true"),24);
        bad(output("IDENTITY_OK_BACKEND_MISSING","false","10234").replace("process_euid=10234","process_euid=-1"),24);
        System.out.println("R16.1 NativeOutputParserTests="+passes+" PASS");
    }
}
