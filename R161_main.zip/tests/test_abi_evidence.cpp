#include "abi_414_evidence.hpp"
#include <iostream>
#include <stdexcept>
#include <string>

using namespace sweet414::abi;

int main() {
    int checks = 0;
    auto check = [&](bool ok) {
        if (!ok) throw std::runtime_error("R15.4 evidence gate failed");
        ++checks;
    };
    check(kTaskStruct.size() == 9);
    check(kCredStruct.size() == 5);
    check(kCredStruct[3].basis == FieldBasis::SourceInferred);
    check(kCredStruct[0].basis == FieldBasis::BinaryAnchor);
    check(kCredSize == 0xa8);
    check(kArchivedSelinuxModel == SelinuxAbiModel::LegacyCredSecurityPointer);
    OfflineEvidence v{kArchivedBootSha256, kArchivedKernelSha256, true, true, true, true, false, true, false};
    check(evaluate_offline(v) == EvidenceGate::ArchivedSnapshotOnly);
    v.live_boot_partition_hash_verified = true;
    check(evaluate_offline(v) == EvidenceGate::ArchivedSnapshotOnly);
    v.boot_sha256 = "samsung-a71";
    check(evaluate_offline(v) == EvidenceGate::UntrustedArchive);
    v.boot_sha256 = kArchivedBootSha256;
    v.kernel_sha256 = "unverified";
    check(evaluate_offline(v) == EvidenceGate::UntrustedArchive);
    v.kernel_sha256 = kArchivedKernelSha256;
    v.archived_symbols_checked = false;
    check(evaluate_offline(v) == EvidenceGate::UntrustedArchive);
    v.archived_symbols_checked = true;
    v.archived_machine_anchors_checked = false;
    check(evaluate_offline(v) == EvidenceGate::UntrustedArchive);
    v.archived_machine_anchors_checked = true;
    v.gcc_plugins_disabled = false;
    check(evaluate_offline(v) == EvidenceGate::UntrustedArchive);
    v.gcc_plugins_disabled = true;
    v.selinux_config_enabled = false;
    check(evaluate_offline(v) == EvidenceGate::UnsupportedSelinuxModel);
    v.selinux_config_enabled = true;
    v.selinux_state_symbol_present = false;
    check(evaluate_offline(v) == EvidenceGate::UnsupportedSelinuxModel);
    v.selinux_state_symbol_present = true;
    v.selinux_blob_sizes_symbol_present = true;
    check(evaluate_offline(v) == EvidenceGate::UnsupportedSelinuxModel);
    check(std::string(gate_string(EvidenceGate::ArchivedSnapshotOnly)) == "ARCHIVED_ABI_ONLY_NO_ROOT_BACKEND");
    std::cout << "PASS " << checks << "/" << checks << " 4.14 static ABI/evidence gates\n";
}
