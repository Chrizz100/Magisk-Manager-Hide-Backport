import sys
import unittest
import struct
import os
from pathlib import Path
BASE=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(BASE/'scripts'))
sys.path.insert(0,str(BASE/'prior'))
import audit_cred as a

class TestCredAudit(unittest.TestCase):
    def setUp(self):
        self.kernel,self.config=a.pinned_kernel(Path(os.environ.get('STOCK_ZIP', '/mnt/data/files/SWEET_STOCK_REFERENZEN_20261107.zip')))
        self.mapping=a.symbols_of(self.kernel,set(a.ANCHORS)|{'init_cred','commit_creds'})

    def test_real_kernel(self):
        r=a.audit(Path(os.environ.get('STOCK_ZIP', '/mnt/data/files/SWEET_STOCK_REFERENZEN_20261107.zip')))
        self.assertEqual(r['machine_code_checks_count'],11)
        self.assertFalse(r['root_obtained'])
    def test_size(self):self.assertEqual(a.validate_init_cred(self.kernel,self.mapping['init_cred'])['usage'],4)
    def test_tampered_machine_instruction_rejected(self):
        k=bytearray(self.kernel);off=self.mapping['prepare_creds']+0x3c
        k[off]^=1
        with self.assertRaises(ValueError):a.validate_anchors(k,self.mapping)
    def test_tampered_cred_data_rejected(self):
        k=bytearray(self.kernel);k[self.mapping['init_cred']+4]^=1
        with self.assertRaises(ValueError):a.validate_init_cred(k,self.mapping['init_cred'])
    def test_wrong_symbol_offset_rejected(self):
        d=dict(self.mapping);d['__cap_capable']+=4
        with self.assertRaises(ValueError):a.validate_anchors(self.kernel,d)

if __name__=='__main__':unittest.main()
