#include "cred_414.hpp"
#include "sweet414_port.hpp"
#include <stdexcept>
#include <cstddef>
#include <iostream>

int main() {
    using sweet414::Cred414LayoutEvidence;
    std::size_t checks=0;
    auto verify=[&](bool yes){if(!yes)throw std::runtime_error("Check failed");++checks;};
    verify(sizeof(Cred414LayoutEvidence)==0xa8);
    verify(offsetof(Cred414LayoutEvidence,uid)==4);
    verify(offsetof(Cred414LayoutEvidence,securebits)==0x24);
    verify(offsetof(Cred414LayoutEvidence,cap_permitted)==0x30);
    verify(offsetof(Cred414LayoutEvidence,cap_effective)==0x38);
    verify(offsetof(Cred414LayoutEvidence,security)==0x78);
    verify(offsetof(Cred414LayoutEvidence,user)==0x80);
    verify(offsetof(Cred414LayoutEvidence,group_info)==0x90);
    verify(offsetof(Cred414LayoutEvidence,rcu_next_or_non_rcu)==0x98);
    sweet414::DeviceFacts device{"sweet","4.14.190-perf-g7da93debc0ee","aarch64","13","V14.0.9.0.TKFEUXM"};
    const auto pre=sweet414::evaluate(device);
    verify(pre.verdict==sweet414::Verdict::SupportedForStaticReviewOnly);
    verify(!pre.executable_root_backend_available && !pre.root_confirmed);
    std::cout<<"PASS "<<checks<<"/"<<checks<<" cred ABI layout and no-root gates\n";
}
