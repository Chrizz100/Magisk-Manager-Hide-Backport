#include "sweet414_port.hpp"
#include <stdexcept>
#include <iostream>

using namespace sweet414;
static DeviceFacts correct() {
    return {"sweet", "4.14.190-perf-g7da93debc0ee", "aarch64", "13", "V14.0.9.0.TKFEUXM"};
}
int main() {
    unsigned checks = 0;
    auto verify = [&](bool condition) { if(!condition)throw std::runtime_error("Check failed"); ++checks; };
    DeviceFacts s = correct();
    auto result = evaluate(s);
    verify(result.verdict == Verdict::SupportedForStaticReviewOnly);
    verify(result.exact_identity_match);
    verify(!result.executable_root_backend_available);
    verify(!result.root_confirmed);
    s.codename = "veux"; verify(evaluate(s).verdict == Verdict::DeviceMismatch);
    s = correct(); s.codename.clear(); verify(evaluate(s).verdict == Verdict::DeviceMismatch);
    s = correct(); s.machine = "armv7l"; verify(evaluate(s).verdict == Verdict::UnsupportedArchitecture);
    s = correct(); s.kernel_release = "4.14.190-perf-g000000000000"; verify(evaluate(s).verdict == Verdict::KernelMismatch);
    s = correct(); s.kernel_release = "4.14.190-27200287-abA715FXXSBDXB1"; verify(evaluate(s).verdict == Verdict::KernelMismatch);
    s = correct(); s.android_release = "14"; verify(evaluate(s).verdict == Verdict::FirmwareMismatch);
    s = correct(); s.miui_incremental = "V14.0.8.0.TKFEUXM"; verify(evaluate(s).verdict == Verdict::FirmwareMismatch);
    s = correct(); s.miui_incremental.clear(); verify(evaluate(s).verdict == Verdict::FirmwareMismatch);
    std::cout << "PASS " << checks << "/" << checks << " identity/negative/root-gate tests\n";
}
