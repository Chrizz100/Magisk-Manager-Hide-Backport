#include "legacy_414_route.hpp"
#include "r158_archive_snapshot.hpp"
#include <stdexcept>
#include <iostream>

using namespace sweet414;
int main() {
    unsigned tests=0;
    auto check=[&](bool x){ ++tests; if (!x) throw std::runtime_error("R15.8 gate test failed"); };
    auto a = archive_snapshot::legacy_route_evidence();
    const auto good = assess_legacy_route(a);
    check(good.verdict == LegacyRouteVerdict::ArchivedCandidateOnly);
    check(good.legacy_symbol_aliases_resolved);
    check(good.archived_futex_path_observed);
    check(!good.may_start_root);
    a.release = "4.14.190-27200287-abA715FXXSBDXB1";
    check(assess_legacy_route(a).verdict==LegacyRouteVerdict::WrongRelease);
    a=archive_snapshot::legacy_route_evidence(); a.archive_sha_verified=false;
    check(assess_legacy_route(a).verdict==LegacyRouteVerdict::UntrustedArchive);
    a=archive_snapshot::legacy_route_evidence(); a.legacy_futex_symbol=false;
    check(assess_legacy_route(a).verdict==LegacyRouteVerdict::MissingLegacySymbols);
    a=archive_snapshot::legacy_route_evidence(); a.required_six_calls=false;
    check(assess_legacy_route(a).verdict==LegacyRouteVerdict::CallGraphUnconfirmed);
    a=archive_snapshot::legacy_route_evidence(); a.all_five_wait_helpers=false;
    check(assess_legacy_route(a).verdict==LegacyRouteVerdict::WaitPathUnconfirmed);
    a=archive_snapshot::legacy_route_evidence(); a.running_boot_byte_identical=true;
    check(assess_legacy_route(a).verdict==LegacyRouteVerdict::BackendUnverified);
    a=archive_snapshot::legacy_route_evidence(); a.native_414_root_backend_verified=true;
    check(!assess_legacy_route(a).may_start_root); // untrusted user claim is not authorization
    std::cout << tests << "/" << tests << " R15.8 safety/compatibility gates passed\n";
}
