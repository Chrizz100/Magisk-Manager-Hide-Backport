import copy
import os
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'scripts'))
sys.path.insert(0,str(ROOT/'prior'))
import r154_selinux_audit as a
import r149_symbolcheck as s

class TestOfflineContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        path=Path(os.environ.get('STOCK_ZIP','/mnt/data/files/SWEET_STOCK_REFERENZEN_20261107.zip'))
        kernel,cls.config=s.unpack_stock(path)
        cls.symbols=set(s.iter_names(kernel))
        cls.task=a.task.audit(path)
        cls.cred=a.cred.audit(path)

    def checked(self, t=None,c=None,config=None,symbols=None):
        return a.validate_contract(t if t is not None else self.task,
                                   c if c is not None else self.cred,
                                   config if config is not None else self.config,
                                   symbols if symbols is not None else self.symbols)

    def test_real_archive_abi(self):
        out=self.checked()
        self.assertTrue(out['image_evidence_validated'])
        self.assertFalse(out['root_uid_zero_verified'])
        self.assertFalse(out['ghostlock_root_backend_implemented'])

    def test_wrong_cred_offset_rejected(self):
        data=copy.deepcopy(self.cred)
        data['observed']['cred_security_byte_offset']+=8
        with self.assertRaises(ValueError): self.checked(c=data)

    def test_wrong_task_offset_rejected(self):
        data=copy.deepcopy(self.task)
        data['task_struct_offsets_confirmed_in_archived_binary']['task_struct.cred']='0x808'
        with self.assertRaises(ValueError): self.checked(t=data)

    def test_wrong_archive_rejected(self):
        data=copy.deepcopy(self.task);data['archived_boot_hash']='invalid'
        with self.assertRaises(ValueError):self.checked(t=data)

    def test_missing_selinux_rejected(self):
        with self.assertRaises(ValueError):self.checked(config=self.config.replace('CONFIG_SECURITY_SELINUX=y','CONFIG_SECURITY_SELINUX=n'))

    def test_wrong_kernel_abi_rejected(self):
        with self.assertRaises(ValueError):self.checked(symbols=self.symbols | {'selinux_blob_sizes'})

    def test_missing_kernel_symbol_rejected(self):
        with self.assertRaises(ValueError):self.checked(symbols=self.symbols - {'selinux_state'})

    def test_config_randstruct_rejected(self):
        with self.assertRaises(ValueError):self.checked(config=self.config.replace('# CONFIG_GCC_PLUGINS is not set','CONFIG_GCC_PLUGINS=y'))

if __name__=='__main__':unittest.main()
