import importlib.util, os, sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import r155_ghostlock_route_audit as a

class TestSymbolContract(unittest.TestCase):
    def setUp(self):
        self.names={'SyS_pselect6','sys_pselect6','core_sys_select','SyS_futex','sys_futex',
                    'do_futex','rt_mutex_start_proxy_lock','remove_waiter'}
        self.config='CONFIG_FUTEX_PI=y\nCONFIG_RT_MUTEXES=y\n'
    def test_legacy_names_detected(self):
        r=a.summarize(self.names,self.config)
        self.assertEqual(r['entries']['pselect_wrapper']['legacy_alternates_found'],['SyS_pselect6','sys_pselect6'])
    def test_no_futex_wait_symbol_is_not_success(self):
        r=a.summarize(self.names,self.config)
        self.assertFalse(r['entries']['futex_wait']['exact_in_archive'])
    def test_no_false_pass(self):
        self.assertFalse(a.summarize(self.names,self.config)['direct_upstream_symbol_contract_passed'])
    def test_full_symbol_set_would_pass(self):
        names=self.names|{v[0] for v in a.EXPECT.values()}
        self.assertTrue(a.summarize(names,self.config)['direct_upstream_symbol_contract_passed'])
    def test_missing_rtmutex_config_rejected(self):
        with self.assertRaises(ValueError):a.summarize(self.names,'CONFIG_FUTEX_PI=y\n')
    def test_no_live_root_claim(self):
        r=a.summarize(self.names,self.config)
        self.assertIs(r['root_obtained'],False)
        self.assertIs(r['phone_boot_hash_verified'],False)

if __name__=='__main__':unittest.main()
