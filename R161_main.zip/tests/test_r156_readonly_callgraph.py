#!/usr/bin/env python3
"""Negative-controlled tests; inspect copied archived bytes only."""
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'prior'))
import r156_readonly_callgraph as audit
sys.path.insert(0,str(ROOT/'prior'))
import r149_symbolcheck as stock
ARCHIVE_PATH=Path(sys.argv[1]) if len(sys.argv)>1 else None

class AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.kernel,cls.cfg=stock.unpack_stock(ARCHIVE_PATH)
        cls.names,cls.markers=audit.read_names_and_types(cls.kernel)
        cls.index,cls.positions=audit.code_functions(cls.names,len(cls.kernel))
        cls.report=audit.analyze(cls.kernel,cls.cfg,cls.names,cls.markers)

    def test_exact_original_hash(self):
        self.assertEqual(stock.sha256(self.kernel),stock.KERNEL_SHA256)
    def test_symbol_total(self):
        self.assertEqual(len(self.names),129028)
    def test_markers(self):
        self.assertEqual(self.markers,505)
    def test_futex_chain(self):
        self.assertEqual(len(self.report['direct_calls']['futex_requeue_to_rtmutex']),4)
        self.assertTrue(all(x['direct_bl_verified'] for x in self.report['direct_calls']['futex_requeue_to_rtmutex']))
    def test_pselect_chain(self):
        self.assertEqual(len(self.report['direct_calls']['pselect_to_core_select']),2)
        self.assertTrue(all(x['direct_bl_verified'] for x in self.report['direct_calls']['pselect_to_core_select']))
    def test_missing_old_names_are_just_names(self):
        self.assertIn('futex_wait_requeue_pi',self.report['missing_independent_symbol_names'])
        self.assertIn('do_pselect',self.report['missing_independent_symbol_names'])
        self.assertFalse(self.report['limits']['root_uid0_observed'])
    def test_decode_arm64_bl(self):
        self.assertIsNone(audit.branch_target(0xd503201f,0))
        self.assertEqual(audit.branch_target(0x94000001,0x100),0x104)
        self.assertEqual(audit.branch_target(0x97ffffff,0x100),0xfc)
    def test_mutated_direct_call_is_rejected(self):
        src,dst='futex_requeue','rt_mutex_start_proxy_lock'
        lo,hi=audit.function_span(src,self.index,self.positions,len(self.kernel))
        patched=bytearray(self.kernel)
        mutated=False
        for pc in range(lo,hi,4):
            word=int.from_bytes(patched[pc:pc+4],'little')
            if audit.branch_target(word,pc)==self.index[dst]:
                patched[pc:pc+4]=(0xd503201f).to_bytes(4,'little')  # architectural NOP
                mutated=True
                break
        self.assertTrue(mutated)
        self.assertFalse(audit.exact_direct_call(patched,src,dst,self.index,self.positions))
    def test_missing_feature_fails_closed(self):
        changed=self.cfg.replace('CONFIG_FUTEX_PI=y','# CONFIG_FUTEX_PI is not set')
        with self.assertRaisesRegex(ValueError,'PI futex'):
            audit.analyze(self.kernel,changed,self.names,self.markers)
    def test_assert_no_live_proof(self):
        self.assertFalse(self.report['limits']['live_boot_partition_matched'])
        self.assertFalse(self.report['limits']['root_exploit_implemented'])
        self.assertFalse(self.report['limits']['magisk_active'])

if __name__ == '__main__':
    if ARCHIVE_PATH is None: raise SystemExit("specify original archive")
    sys.argv=[sys.argv[0]]
    unittest.main(verbosity=2)
