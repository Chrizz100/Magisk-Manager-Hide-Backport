#!/usr/bin/env python3
"""Offline regression tests for exact archived Xiaomi boot and branch evidence."""
import argparse,sys,struct,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'scripts'),str(ROOT/'prior')]
import r157_inlined_path_audit as new
import r156_readonly_callgraph as prev

class AuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.archive=Path(ARGS.archive)
        cls.kernel, cls.cfg=prev.stock.unpack_stock(cls.archive)
        cls.symbols,_=prev.read_names_and_types(cls.kernel)
        cls.idx,cls.pos=prev.code_functions(cls.symbols,len(cls.kernel))
        cls.result=new.run(cls.archive)

    def test_helper_calls_from_do_futex_are_real_binary_bl(self):
        self.assertEqual(set(self.result['do_futex_to_wait_requeue_helpers']),set(new.HELPERS))
        self.assertTrue(all(self.result['do_futex_to_wait_requeue_helpers'].values()))

    def test_missing_standalone_symbol(self):
        self.assertFalse(self.result['symbol_futex_wait_requeue_pi_is_independent'])
        self.assertEqual(self.result['assessment'],'STRONG_INLINE_CANDIDATE_ONLY')

    def test_stated_kernel_security_config(self):
        c=self.result['kernel_config']
        for key in ['CONFIG_VMAP_STACK','CONFIG_RANDOMIZE_BASE','CONFIG_ARM64_VA_BITS_39',
                    'CONFIG_SLAB_FREELIST_RANDOM','CONFIG_SLAB_FREELIST_HARDENED',
                    'CONFIG_SECCOMP','CONFIG_SECCOMP_FILTER','CONFIG_ARM64_PAN']:
            self.assertEqual(c[key],'y',key)
        self.assertEqual(c['CONFIG_KPROBES'],'n')

    def test_mutation_on_copy_breaks_individual_direct_call(self):
        # The test only modifies a temporary userspace bytearray, not kernel or files.
        destination='rt_mutex_wait_proxy_lock'
        orig=prev.exact_direct_call(self.kernel,'do_futex',destination,self.idx,self.pos)
        self.assertTrue(orig)
        st,en=prev.function_span('do_futex',self.idx,self.pos,len(self.kernel))
        target=self.idx[destination]
        blob=bytearray(self.kernel)
        edits=0
        for off in range(st,en,4):
            ins=struct.unpack_from('<I',blob,off)[0]
            if prev.branch_target(ins,off)==target:
                struct.pack_into('<I',blob,off,0xD503201F) # NOP in local copy
                edits+=1
        self.assertGreater(edits,0)
        self.assertFalse(prev.exact_direct_call(blob,'do_futex',destination,self.idx,self.pos))

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('archive')
    ARGS=ap.parse_args()
    unittest.main(argv=[sys.argv[0]],verbosity=2)
