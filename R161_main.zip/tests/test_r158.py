#!/usr/bin/env python3
"""R15.8: R15.6/7 source reports merged with strictly limited claims."""
from __future__ import annotations
import os
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import r158_build_evidence as new

class TestR158(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = new.snapshot_from_archive(Path(os.environ['STOCK_ZIP']))

    def test_hash_bound(self):
        self.assertEqual(self.report['archive_boot_sha256'],new.flow.stock.BOOT_SHA256)
    def test_only_legacy_names(self):
        self.assertTrue(all(self.report['legacy_symbols'].values()))
        self.assertFalse(any(self.report['modern_symbols'].values()))
    def test_all_six_calls(self):
        self.assertTrue(self.report['direct_call_chain'])
    def test_five_helpers_present(self):
        self.assertEqual(len(self.report['five_wait_helpers']),5)
        self.assertTrue(all(self.report['five_wait_helpers'].values()))
    def test_no_standalone_waiter(self):
        self.assertFalse(self.report['standalone_futex_wait_requeue_pi'])
    def test_no_root_or_flash_assumptions(self):
        self.assertFalse(self.report['device_boot_part_byte_match_proven'])
        self.assertFalse(self.report['real_root_uid0_proven'])
        self.assertFalse(self.report['verified_ghostlock_native_414_backend'])
    def test_cpp_snapshot_never_enables_backend(self):
        h=new.render_cpp(self.report)
        self.assertIn('running_boot_byte_identical = false;',h)
        self.assertIn('native_414_root_backend_verified = false;',h)
        self.assertNotIn('native_414_root_backend_verified = true;',h)
    def test_failure_to_match_hash(self):
        from tempfile import NamedTemporaryFile
        from zipfile import ZipFile, ZIP_DEFLATED
        orig=Path(os.environ['STOCK_ZIP'])
        with ZipFile(orig) as source:
            original=source.read('ORIGINALE/boot(4).img')
        modified=bytearray(original)
        modified[-12] ^= 1 # only mutate in a temporary file
        with NamedTemporaryFile(suffix='.zip') as tmp:
            with ZipFile(tmp.name,'w',compression=ZIP_DEFLATED) as dest:
                dest.writestr('ORIGINALE/boot(4).img',modified)
            with self.assertRaisesRegex(ValueError,'SHA256'):
                new.snapshot_from_archive(Path(tmp.name))

if __name__ == '__main__':
    unittest.main(verbosity=2)
