#!/usr/bin/env python3
"""R16: negative and positive ELF packaging checks using synthetic, non-executable fixtures."""
import importlib.util
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
import zipfile

script = Path(__file__).parents[1]/'scripts'/'r160_check_android_elf.py'
spec=importlib.util.spec_from_file_location('r160_elf',script)
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def fixture(machine=183,typ=3,interpreter=b'/system/bin/linker64\0', eflags=5, stackflags=6):
    data=bytearray(512)
    data[:16]=b'\x7fELF'+bytes([2,1,1])+b'\0'*9
    struct.pack_into('<HHIQQQIHHHHHH',data,16,typ,machine,1,0,64,0,0,64,56,3,0,0,0)
    struct.pack_into('<IIQQQQQQ',data,64,3,4,256,0,0,len(interpreter),len(interpreter),1)
    struct.pack_into('<IIQQQQQQ',data,120,1,eflags,0,0,0,len(data),len(data),4096)
    struct.pack_into('<IIQQQQQQ',data,176,0x6474e551,stackflags,0,0,0,0,0,16)
    data[256:256+len(interpreter)]=interpreter
    return bytes(data)

class AndroidElfStageTest(unittest.TestCase):
    def test_positive_android_arm64_pie(self):
        self.assertEqual(m.validate(fixture())['interpreter'],'/system/bin/linker64')
    def test_fails_x86(self):
        with self.assertRaisesRegex(m.ElfError,'NOT_AARCH64'):m.validate(fixture(machine=62))
    def test_fails_shared_library_without_interpreter(self):
        with self.assertRaisesRegex(m.ElfError,'NOT_ANDROID_DYNAMIC_LINKER'):m.validate(fixture(interpreter=b'/usr/bin/ld.so\0'))
    def test_fails_wrong_type(self):
        with self.assertRaisesRegex(m.ElfError,'NOT_PIE_ET_DYN'):m.validate(fixture(typ=2))
    def test_fails_writable_executable_segment(self):
        with self.assertRaisesRegex(m.ElfError,'WRITABLE_EXECUTABLE_SEGMENT'):m.validate(fixture(eflags=7))
    def test_fails_executable_stack(self):
        with self.assertRaisesRegex(m.ElfError,'EXECUTABLE_STACK'):m.validate(fixture(stackflags=7))
    def test_fails_truncated(self):
        with self.assertRaisesRegex(m.ElfError,'TRUNCATED_ELF_PROGRAM_HEADERS'):m.validate(fixture()[:100])
    def test_staging_and_hash(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td); source=p/'input';source.write_bytes(fixture())
            out=p/'staged';info=m.stage(source,out)
            self.assertEqual(info['sha256'],m.validate((out/m.ENTRY).read_bytes())['sha256'])
            self.assertEqual(json.loads((out/'R160_ANDROID_ARM64_NATIVE_MANIFEST.json').read_text())['apk_path'],m.ENTRY)
    def test_apk_contains_expected_elf(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'test.apk'
            with zipfile.ZipFile(p,'w') as z: z.writestr(m.ENTRY,fixture())
            self.assertEqual(m.apk_check(p)['elf'],'ELF64 PIE AArch64')
    def test_apk_rejects_missing_native_executable(self):
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'test.apk'
            with zipfile.ZipFile(p,'w') as z: z.writestr('README.txt','not an APK')
            with self.assertRaisesRegex(m.ElfError,'APK_MISSING'):m.apk_check(p)

if __name__=='__main__': unittest.main(verbosity=2)
