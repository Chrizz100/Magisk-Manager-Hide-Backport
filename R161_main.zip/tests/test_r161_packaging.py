#!/usr/bin/env python3
import hashlib,io,sys,tempfile,unittest,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from r161_validate_apk import check
from r160_check_android_elf import ElfError, ENTRY

class PackageTests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
  # a real minimal AArch64 Android ELF with proper header is required here:
  # source/CI will supply the actual ELF using R16.0 builds. Tests focus on
  # controlled archive rejection, rather than fabricating a valid ELF.
  self.apk=Path(self.tmp.name)/'dummy.apk'
 def create(self, native=b'not-elf',dup=False,compressed=True):
  with zipfile.ZipFile(self.apk,'w') as z:
   method=zipfile.ZIP_DEFLATED if compressed else zipfile.ZIP_STORED
   z.writestr('AndroidManifest.xml',b'fake')
   z.writestr('classes.dex',b'fake')
   z.writestr(ENTRY,native,compress_type=method)
   if dup:z.writestr(ENTRY,native,compress_type=method)
 def test_missing_native_rejected(self):
  with zipfile.ZipFile(self.apk,'w') as z:z.writestr('classes.dex','fake')
  with self.assertRaises(AssertionError):check(self.apk,'0'*64)
 def test_duplicate_native_rejected(self):
  self.create(dup=True)
  with self.assertRaises(AssertionError):check(self.apk,'0'*64)
 def test_invalid_native_rejected(self):
  self.create()
  with self.assertRaises((ElfError,AssertionError)):check(self.apk,'0'*64)
 def test_uncompressed_native_rejected(self):
  self.create(compressed=False)
  with self.assertRaises(AssertionError):check(self.apk,'0'*64)
 def test_wrong_input_sha_rejected(self):
  self.create()
  with self.assertRaises(AssertionError):check(self.apk,'123')

if __name__=='__main__':unittest.main()
