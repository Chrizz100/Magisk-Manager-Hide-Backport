#include "rtmutex_waiter_414.hpp"
#include <cstddef>
#include <iostream>
#include <stdexcept>

int main() {
    using namespace sweet414::source_abi;
    auto test = [](bool ok) { if (!ok) throw std::runtime_error("rtmutex waiter source ABI mismatch"); };
    test(sizeof(RbNode414)==24);
    test(sizeof(RtMutexWaiter414)==80);
    test(offsetof(RtMutexWaiter414, pi_tree_entry)==0x18);
    test(offsetof(RtMutexWaiter414, task)==0x30);
    test(offsetof(RtMutexWaiter414, lock)==0x38);
    test(offsetof(RtMutexWaiter414, prio)==0x40);
    test(offsetof(RtMutexWaiter414, deadline)==0x48);
    test(!kBinaryOffsetsValidated && !kRunningKernelMatched && !kRootBackendAvailable);
    std::cout << "8/8 source ABI checks; no root backend enabled\n";
}
