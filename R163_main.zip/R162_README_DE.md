# R16.2 – Magisk 31100 / GhostLock-Prozessübergabe: geprüfte Voraussetzungen

R16.1 hatte auf echtem `sweet` bereits `IDENTITY_OK_BACKEND_MISSING` und UID/EUID 10291/10291 gezeigt.
Das neue Java-Modul `Magisk31100Gate.java` ist **keine Root-Engine**, sondern eine Entscheidungsgrenze für die spätere Übergabe. Es kann weder UID 0 erzeugen noch Magisk-Dienste starten.

- Zielgerät/Firmware exakt abgleichen.
- Vorhandenen Magisk Manager 31100 nicht mit aktiviertem Magisk verwechseln.
- Einen privilegierten Kanal nur akzeptieren, wenn die Gegenstelle **über Android-Kernel-Peer-Credentials** als UID 0 bestätigt wurde (in R16.2 selbst nur eine Schnittstellenannahme; eine echte Root-Gegenstelle gibt es nicht).
- Selbst bei vorab bestätigtem UID-0-Kanal nur `ROOT_CHANNEL_PRESENT_MAGISK_UNCONFIRMED` melden. `magiskd` 31100 muss in einem späteren gesonderten Schritt nachgewiesen werden.
- Kein Flash, keine SEPolicy-Änderung, keine Exploit-Ausführung. Die ursprüngliche R16.1-Oberfläche und Magisk R13.4 bleiben unverändert.

## Lokale Regressionen

`bash scripts/test_r161_host.sh` – bestehende R16.1-Tests plus neue Java-Gate- und Python-Logtests. Das Benutzerlog wird **nicht** in GitHub-Quellarchiven abgelegt.

## Gerätelog
Die vollständige Benutzer-Logdatei ist ABSICHTLICH NICHT in diesem ZIP enthalten; nur die lokale Auswertung wird als separates Dokument bereitgestellt.
