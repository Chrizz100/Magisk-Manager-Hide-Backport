# R16.3 – Magisk-Übergabe mit echter Android-Berechtigungsprüfung

**Status 11.11.2026.** Das bisherige R16.1 wurde auf dem Redmi Note 10 Pro (`sweet`) gestartet. **UID/EUID 10291/10291**, `IDENTITY_OK_BACKEND_MISSING`: Ein Android-ARM64-Prozessstart, **kein Root**. Dein separates Magisk-Log bestätigt die Magisk-31100-Manager-Anwendung und Kernelversion, jedoch keinen laufenden privilegierten Daemon.

## Was R16.3 im Quellcode tatsächlich repariert

- In R16.2 vertraute `Magisk31100Gate.decide(...)` einem vom Aufrufer übergebenen Integer `kernelVerifiedPeerUid` und einer frei übergebenen Bestätigungs-Boolean. Diese API kann keinen OS-beglaubigten Root-Nachweis gewährleisten.
- Die neue Klasse `AndroidRootPeerProbe` stellt selbst eine Verbindung zu einem festen lokalen Android-Socket (`sweet414-root-peer-v1`) her und liest bei erfolgreichem Verbindungsaufbau die wirkliche UID der Gegenstelle über `android.net.LocalSocket.getPeerCredentials()`. **Der passende Socket-Server ist noch nicht vorhanden**; ohne ihn ergibt die Prüfung `NO_ROOT_PROVIDER`.
- `MagiskManagerInspector` fragt das installierte Paket `com.topjohnwu.magisk` über den Android-PackageManager ab, statt die Manager-Versionsnummer aus einem Log oder einem Aufruferparameter als bewiesen anzunehmen. Ab Android 11 wird die Paketabfrage durch `<queries>` in der Manifestdatei ermöglicht. Bei fehlendem Paket/Abfragefehler wird die Übergabe nicht freigegeben.
- Das bestehende Diagnosefenster aus R16.1 ruft diese Prüfung nach erfolgreichem nativen Prozessstart auf. Es zeigt **keinen** Root-Erfolg an; R16.3 fügt keinen Root-Knopf hinzu.
- Ein bestätigter UID-0-Peer **wäre noch kein bestätigter Magisk-Dienst**. Diese Grenze bleibt ausdrücklich als `ROOT_CHANNEL_PRESENT_MAGISK_UNCONFIRMED` erhalten. Es wird weder `magiskd` gestartet noch ein Exploit ausgeführt.

## Tests und technische Grenzen

Insgesamt **46 lokale Prüfungen bestanden**: 5 C++-Hosttests, 5 Python-Pakettests, 11 Parser-Tests, 16 simulierte Android-Berechtigungs-/Manager-Verbindungsfälle und 9 Logtests (einschließlich separat eingebundenem Original-Log). Die simulierten Fälle verwenden **nur im Tests-Ordner** liegende Java-Klassen und sind **kein** echter UID-0-Nachweis.

**Der aktuelle Android-APK-Build für R16.3 und der reale Gerätetest stehen noch aus.** Die frühere R16.1-APK bleibt die letzte erfolgreich auf dem Gerät ausgeführte Version. Für die neue Version wurde eine auf dem erfolgreichen GitHub-R16.1-Workflow aufbauende YAML erstellt; dieser neue Workflow wurde bislang nicht gestartet.

Das Paket enthält **keine Original-Magisk-Logdatei** und **keine** veränderten Boot-/Recovery-Dateien. Magisk R13.4 bleibt unverändert. Kein Flash, kein KernelSU, kein Bootloader-Wechsel und keine Rootfreigabe.

## Noch fehlende Kernkomponente

Die native GhostLock-4.14-Rechteerhöhung für diesen Xiaomi-Kernel existiert weiterhin nicht. Auch ein dauerhaft gesicherter Magisk-Start wurde nicht implementiert. Ein lokaler Socket-Nachweis ist nur eine notwendige Sicherung für einen **späteren** privilegierten Provider; er stellt selbst keine privilegierten Rechte bereit.

Upstream-Nachweis zur Android-API: https://developer.android.com/reference/android/net/LocalSocket#getPeerCredentials()

Zusammenfassung: **R16.3_SOURCE_TEST_PASS / R16.3_ANDROID_BUILD_NOT_RUN / LIVE_ROOT_NOT_ACHIEVED / MAGISKD_NOT_VERIFIED**.
