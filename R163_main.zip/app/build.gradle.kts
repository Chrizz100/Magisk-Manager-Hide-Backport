plugins { id("com.android.application") }

val nativeSha = providers.gradleProperty("nativeSha256").orNull ?: ""
require(Regex("^[0-9a-f]{64}$").matches(nativeSha)) {
    "Pass -PnativeSha256=<sha256 of verified Android native executable>"
}

android {
    namespace = "dev.sweet414.audit"
    compileSdk = 35
    defaultConfig {
        applicationId = "dev.sweet414.audit"
        minSdk = 26
        targetSdk = 35
        versionCode = 163
        versionName = "16.3"
        buildConfigField("String", "NATIVE_SHA256", "\"${nativeSha}\"")
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildFeatures { buildConfig = true }
    // Android 10+ blocks exec() from writable app storage (W^X).
    // Legacy JNI packaging installs libsweet414_preflight.so in nativeLibraryDir.
    packaging {
        jniLibs {
            useLegacyPackaging = true
            // Do not strip/change the binary after its SHA-256 was injected into BuildConfig.
            keepDebugSymbols += "**/libsweet414_preflight.so"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
