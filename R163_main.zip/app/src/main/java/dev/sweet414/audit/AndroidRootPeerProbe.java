package dev.sweet414.audit;

import android.net.Credentials;
import android.net.LocalSocket;
import android.net.LocalSocketAddress;
import java.io.IOException;

/**
 * R16.3: OS-backed peer credential check for an *already running* provider.
 * The socket currently has NO corresponding provider in this project.
 * It does not start Magisk, run an exploit, or grant privileges.
 */
public final class AndroidRootPeerProbe {
    private AndroidRootPeerProbe() {}

    /** Fixed abstract socket name; not an arbitrary caller-provided endpoint. */
    private static final String SOCKET_NAME = "sweet414-root-peer-v1";

    public enum State { ABSENT, UNVERIFIED, VERIFIED }

    /** Proof objects cannot be constructed by ordinary callers from a raw UID. */
    public static final class Proof {
        private final State state;
        private final int peerUid;
        private Proof(State state, int peerUid) {
            this.state = state;
            this.peerUid = peerUid;
        }
        public State state() { return state; }
        public boolean isKernelVerifiedRootPeer() {
            return state == State.VERIFIED && peerUid == 0;
        }
        public boolean isKernelVerifiedNonRootPeer() {
            return state == State.VERIFIED && peerUid != 0;
        }
    }

    private static Proof absent() { return new Proof(State.ABSENT, -1); }
    private static Proof unverified() { return new Proof(State.UNVERIFIED, -1); }

    /**
     * The kernel supplies getPeerCredentials(). A text message or uid=0 string
     * in a diagnostic log MUST NOT be treated as root proof.
     */
    public static Proof probe() {
        try (LocalSocket socket = new LocalSocket()) {
            socket.connect(new LocalSocketAddress(SOCKET_NAME, LocalSocketAddress.Namespace.ABSTRACT));
            if (!socket.isConnected()) return unverified();
            Credentials creds = socket.getPeerCredentials();
            if (creds == null || creds.getUid() < 0) return unverified();
            return new Proof(State.VERIFIED, creds.getUid());
        } catch (IOException e) {
            // No endpoint / failed socket I/O is NEVER a root success.
            return absent();
        } catch (SecurityException e) {
            return unverified();
        }
    }
}
