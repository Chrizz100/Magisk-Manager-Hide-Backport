package dev.sweet414.audit;

import android.content.Context;

/**
 * R16.3: fail-closed boundary for possible future Magisk 31100 handoff.
 * Never treats a caller-supplied integer UID or boolean as kernel attestation.
 * Even a verified UID-0 socket peer is NOT evidence that magiskd is running.
 */
public final class Magisk31100Gate {
    private Magisk31100Gate() {}
    public enum Decision {
        TARGET_MISMATCH,
        MANAGER_VERSION_MISMATCH,
        NO_ROOT_PROVIDER,
        PRIVILEGED_PEER_UNVERIFIED,
        PRIVILEGED_PEER_NOT_ROOT,
        ROOT_CHANNEL_PRESENT_MAGISK_UNCONFIRMED
    }

    public static Decision decide(
            NativeOutputParser.Result live,
            Context context) {
        if (live == null || !live.identityMatched ||
                !"sweet".equals(live.device) ||
                !"4.14.190-perf-g7da93debc0ee".equals(live.kernel) ||
                !"13".equals(live.android) ||
                !"V14.0.9.0.TKFEUXM".equals(live.miui))
            return Decision.TARGET_MISMATCH;
        if (MagiskManagerInspector.installedManagerVersion(context) != 31100)
            return Decision.MANAGER_VERSION_MISMATCH;
        // This gate obtains its own OS credentials; callers cannot supply a proof.
        final AndroidRootPeerProbe.Proof peerEvidence = AndroidRootPeerProbe.probe();
        if (peerEvidence.state() == AndroidRootPeerProbe.State.ABSENT)
            return Decision.NO_ROOT_PROVIDER;
        if (peerEvidence.state() != AndroidRootPeerProbe.State.VERIFIED)
            return Decision.PRIVILEGED_PEER_UNVERIFIED;
        if (!peerEvidence.isKernelVerifiedRootPeer())
            return Decision.PRIVILEGED_PEER_NOT_ROOT;
        return Decision.ROOT_CHANNEL_PRESENT_MAGISK_UNCONFIRMED;
    }
}
