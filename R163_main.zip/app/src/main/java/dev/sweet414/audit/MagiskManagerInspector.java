package dev.sweet414.audit;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

/** Queries the actual installed Magisk manager package; the log alone is not authority. */
public final class MagiskManagerInspector {
    private MagiskManagerInspector() {}
    public static int installedManagerVersion(Context context) {
        if (context == null) return -1;
        try {
            PackageInfo info = context.getPackageManager().getPackageInfo("com.topjohnwu.magisk", 0);
            long version = Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode;
            return version >= 0 && version <= Integer.MAX_VALUE ? (int) version : -1;
        } catch (PackageManager.NameNotFoundException | SecurityException e) {
            return -1;
        }
    }
}
