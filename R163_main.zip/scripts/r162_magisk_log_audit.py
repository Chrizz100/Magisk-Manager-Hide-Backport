#!/usr/bin/env python3
"""R16.2: offline, read-only Magisk log evidence audit; no root or flash operations.
Only a small allowlist of fields is ever exported. Do not include raw device logs in release archives.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import re
from pathlib import Path

PROPS = (
    'ro.product.device', 'ro.product.model', 'ro.product.cpu.abi',
    'ro.build.version.release', 'ro.build.version.incremental',
    'ro.boot.flash.locked', 'ro.boot.vbmeta.device_state',
    'ro.boot.verifiedbootstate', 'init.svc.mqsasd', 'init.svc.magiskd',
)
PROPERTY_PATTERN = re.compile(r'^\[([^\]]+)\]: \[(.*)\]$')
MANAGER_PATTERN = re.compile(r'^([0-9a-f]{8}) \((\d{4,6})\)$')
EXPECTED = {'device': 'sweet', 'kernel': '4.14.190-perf-g7da93debc0ee',
            'android': '13', 'miui': 'V14.0.9.0.TKFEUXM'}

def audit_text(data: str) -> dict:
    if len(data) > 2_000_000:
        raise ValueError('LOG_TOO_LARGE')
    lines = data.splitlines()
    props = {}
    header = {}
    section = None
    magisk_lines = []
    manager_version = None
    manager_commit = None
    avc_enforcing_events = 0
    for raw in lines:
        line = raw.strip()
        if line in ('---Detected Device Info---','---System Properties---',
                    '---Magisk Logs---','---Manager Logs---'):
            section = line[3:-3]
            continue
        if section == 'Detected Device Info':
            if '=' in line and line.split('=',1)[0] in ('isAB','isSAR','ramdisk','kernel'):
                k,v = line.split('=',1)
                header[k] = v
        elif section == 'System Properties':
            m = PROPERTY_PATTERN.match(line)
            if m and m.group(1) in PROPS:
                props[m.group(1)] = m.group(2)
        elif section == 'Magisk Logs':
            if line:
                magisk_lines.append(line)
        elif section == 'Manager Logs':
            m = MANAGER_PATTERN.match(line)
            if m:
                manager_commit, manager_version = m.group(1), int(m.group(2))
            if 'avc: denied' in line and 'permissive=0' in line:
                avc_enforcing_events += 1
    kernel_header = header.get('kernel', '')
    kernel_release = kernel_header.split(' ', 3)[2] if kernel_header.startswith('Linux aarch64 ') else ''
    device = props.get('ro.product.device')
    android = props.get('ro.build.version.release')
    miui = props.get('ro.build.version.incremental')
    live_identity_matches = (device == EXPECTED['device'] and kernel_release == EXPECTED['kernel']
                             and android == EXPECTED['android'] and miui == EXPECTED['miui'])
    unlocked_props = (props.get('ro.boot.flash.locked') == '0'
                      and props.get('ro.boot.vbmeta.device_state') == 'unlocked'
                      and props.get('ro.boot.verifiedbootstate') == 'orange')
    # Nothing in a Magisk manager log proves that an elevated root process exists.
    daemon_explicit = props.get('init.svc.magiskd') == 'running'
    log_is_empty = magisk_lines == ['(-1)'] or not magisk_lines
    result = {
        'schema': 'R16.2/offline-evidence/v1',
        'target': {'device': device, 'kernel': kernel_release, 'android': android,
                   'firmware': miui, 'abi': props.get('ro.product.cpu.abi')},
        'magisk_manager': {'version': manager_version, 'commit': manager_commit,
                           'manager_version_matched': manager_version == 31100,
                           'daemon_running_from_logs': 'NOT_PROVEN' if not daemon_explicit else 'INIT_PROPERTY_RUNNING_UNVERIFIED'},
        'boot': {'isAB': header.get('isAB') == 'true' if header.get('isAB') in ('true','false') else None,
                 'isSAR': header.get('isSAR') == 'true' if header.get('isSAR') in ('true','false') else None,
                 'ramdisk': header.get('ramdisk') == 'true' if header.get('ramdisk') in ('true','false') else None,
                 'unlocked_by_three_property_cross_check': unlocked_props,
                 'verifiedbootstate': props.get('ro.boot.verifiedbootstate')},
        'observed': {'archived_kernel_version_matches_running_kernel': live_identity_matches,
                     'current_boot_partition_byte_match': 'NOT_TESTED',
                     'magisk_log_section': 'EMPTY_OR_UNAVAILABLE' if log_is_empty else 'HAS_CONTENT_NOT_A_ROOT_PROOF',
                     'selinux_denial_events_enforcing': avc_enforcing_events,
                     'mqsasd_running': props.get('init.svc.mqsasd') == 'running',
                     'root_credential_proof': 'NOT_PRESENT',
                     'magisk_31100_active': 'NOT_PROVEN'},
        'decision': 'MANAGER_PRESENT_ROOT_BACKEND_MISSING' if live_identity_matches and manager_version == 31100 else 'TARGET_OR_MANAGER_NOT_CONFIRMED',
        'safe_for_root_flash': False,
        'safe_to_claim_temporary_root': False,
    }
    return result

def audit_file(path: Path) -> dict:
    raw = path.read_bytes()
    text = raw.decode('utf-8-sig', 'replace')
    r = audit_text(text)
    r['log_sha256'] = hashlib.sha256(raw).hexdigest()
    r['log_size_bytes'] = len(raw)
    return r

if __name__ == '__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('log', type=Path)
    ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args()
    report=audit_file(args.log)
    args.out.parent.mkdir(parents=True,exist_ok=True)
    args.out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('R162_LOG_REVIEW='+report['decision'])
