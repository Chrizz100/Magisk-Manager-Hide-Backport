package dev.sweet414.audit;
import android.net.LocalSocket;
import android.content.Context;
import android.content.pm.PackageManager;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/** All socket outcomes here are SIMULATED; no real privileged process is used. */
public final class Magisk31100GateTest {
    private static int passed=0;
    private static final Context CONTEXT=new Context();
    static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);passed++;}
    static NativeOutputParser.Result result(String verdict,int exit,String uid){
        return NativeOutputParser.parse("kernel=4.14.190-perf-g7da93debc0ee\n"+
            "device=sweet\nandroid=13\nmiui=V14.0.9.0.TKFEUXM\n"+
            "verdict="+verdict+"\nprocess_uid="+uid+"\nprocess_euid="+uid+"\n"+
            "root_backend_available=false\nroot_confirmed=false\n",exit);
    }
    static void expect(LocalSocket.Mode mode, Magisk31100Gate.Decision decision) {
        LocalSocket.next=mode;
        check(Magisk31100Gate.decide(result("IDENTITY_OK_BACKEND_MISSING",24,"10291"),CONTEXT)==decision,"state="+mode);
    }
    public static void main(String[] args) throws Exception {
        expect(LocalSocket.Mode.ABSENT, Magisk31100Gate.Decision.NO_ROOT_PROVIDER);
        expect(LocalSocket.Mode.DISCONNECTED, Magisk31100Gate.Decision.PRIVILEGED_PEER_UNVERIFIED);
        expect(LocalSocket.Mode.NULL_CREDS, Magisk31100Gate.Decision.PRIVILEGED_PEER_UNVERIFIED);
        expect(LocalSocket.Mode.NEGATIVE_UID, Magisk31100Gate.Decision.PRIVILEGED_PEER_UNVERIFIED);
        expect(LocalSocket.Mode.NONROOT, Magisk31100Gate.Decision.PRIVILEGED_PEER_NOT_ROOT);
        expect(LocalSocket.Mode.ROOT, Magisk31100Gate.Decision.ROOT_CHANNEL_PRESENT_MAGISK_UNCONFIRMED);
        expect(LocalSocket.Mode.DENIED, Magisk31100Gate.Decision.PRIVILEGED_PEER_UNVERIFIED);
        LocalSocket.next=LocalSocket.Mode.ROOT;
        check("sweet414-root-peer-v1".equals(LocalSocket.requestedName),"must use fixed endpoint");
        PackageManager.installed=30000;
        check(Magisk31100Gate.decide(result("IDENTITY_OK_BACKEND_MISSING",24,"10291"),CONTEXT)==Magisk31100Gate.Decision.MANAGER_VERSION_MISMATCH,"manager mismatch");
        PackageManager.installed=31100;
        check(Magisk31100Gate.decide(result("KERNEL_MISMATCH",22,"10291"),CONTEXT)==Magisk31100Gate.Decision.TARGET_MISMATCH,"kernel mismatch");
        check(Magisk31100Gate.decide(null,CONTEXT)==Magisk31100Gate.Decision.TARGET_MISMATCH,"null result");
        LocalSocket.next=LocalSocket.Mode.ABSENT;
        check(Magisk31100Gate.decide(result("IDENTITY_OK_BACKEND_MISSING",24,"10291"),CONTEXT)==Magisk31100Gate.Decision.NO_ROOT_PROVIDER,"absent provider");
        PackageManager.installed=-1;
        check(Magisk31100Gate.decide(result("IDENTITY_OK_BACKEND_MISSING",24,"10291"),CONTEXT)==Magisk31100Gate.Decision.MANAGER_VERSION_MISMATCH,"uninstalled manager");
        PackageManager.installed=31100;
        check(AndroidRootPeerProbe.Proof.class.getConstructors().length==0,"no public proof ctor");
        boolean oldMethod=false;
        for(Method m:Magisk31100Gate.class.getMethods())
            if(m.getName().equals("decide") && m.getParameterCount()>2) oldMethod=true;
        check(!oldMethod,"old caller-supplied uid,bool API must not be public");
        check(!Modifier.isPublic(AndroidRootPeerProbe.Proof.class.getDeclaredConstructors()[0].getModifiers()),"proof ctor private");
        System.out.println("R16.3 VERIFIED-PEER-AND-MANAGER-TESTS="+passed+" PASS (ALL SIMULATED)");
    }
}
