package android.content;
import android.content.pm.PackageManager;
/** TEST-ONLY. */
public class Context {
    private final PackageManager packageManager=new PackageManager();
    public PackageManager getPackageManager(){return packageManager;}
}
