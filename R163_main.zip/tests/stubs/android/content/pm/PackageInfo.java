package android.content.pm;
/** TEST-ONLY. */
public class PackageInfo { public int versionCode; public long getLongVersionCode(){return versionCode;} }
