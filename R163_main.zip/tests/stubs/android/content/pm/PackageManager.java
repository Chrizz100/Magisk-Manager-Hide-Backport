package android.content.pm;
/** TEST-ONLY: no Android runtime linked. */
public final class PackageManager {
    public static class NameNotFoundException extends Exception {}
    public static int installed = 31100;
    public PackageInfo getPackageInfo(String name,int flags) throws NameNotFoundException {
        if (!"com.topjohnwu.magisk".equals(name) || installed < 0)
           throw new NameNotFoundException();
        PackageInfo i=new PackageInfo(); i.versionCode=installed; return i;
    }
}
