package android.net;
/** TEST-ONLY stand-in. This class is never packaged into the real Android APK. */
public final class Credentials {
    private final int uid;
    public Credentials(int uid) { this.uid = uid; }
    public int getUid() { return uid; }
}
