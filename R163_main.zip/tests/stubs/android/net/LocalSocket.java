package android.net;
import java.io.IOException;
/** Deterministic TEST-ONLY stub, not a real kernel credential check. */
public final class LocalSocket implements AutoCloseable {
    public enum Mode { ABSENT, DISCONNECTED, NULL_CREDS, NEGATIVE_UID, NONROOT, ROOT, DENIED }
    public static Mode next = Mode.ABSENT;
    public static String requestedName = "";
    private boolean connected = false;
    public void connect(LocalSocketAddress address) throws IOException {
        requestedName=address.name;
        if(next==Mode.ABSENT) throw new IOException("No provider");
        if(next==Mode.DENIED) throw new SecurityException("Denied");
        connected=next!=Mode.DISCONNECTED;
    }
    public boolean isConnected(){return connected;}
    public Credentials getPeerCredentials() throws IOException {
        if(!connected) throw new IOException("Not connected");
        switch(next){
          case NULL_CREDS: return null;
          case NEGATIVE_UID: return new Credentials(-1);
          case NONROOT: return new Credentials(10291);
          case ROOT: return new Credentials(0);
          default: throw new IOException("No creds");
        }
    }
    @Override public void close() { connected=false; }
}
