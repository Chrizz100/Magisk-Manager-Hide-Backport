package android.net;
/** TEST-ONLY stand-in; the Android platform provides the production type. */
public final class LocalSocketAddress {
    public enum Namespace { ABSTRACT }
    public final String name;
    public final Namespace namespace;
    public LocalSocketAddress(String name, Namespace namespace) {
        this.name=name; this.namespace=namespace;
    }
}
