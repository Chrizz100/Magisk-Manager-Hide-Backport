package android.os;
/** TEST-ONLY. */
public class Build { public static class VERSION { public static int SDK_INT=33; } }
