import os
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent.parent / 'scripts'))
from r162_magisk_log_audit import audit_file, audit_text

HEAD="""---Detected Device Info---
isAB=false
isSAR=true
ramdisk=true
kernel=Linux aarch64 4.14.190-perf-g7da93debc0ee #1 SMP PREEMPT
---System Properties---
[ro.product.device]: [sweet]
[ro.product.cpu.abi]: [arm64-v8a]
[ro.build.version.release]: [13]
[ro.build.version.incremental]: [V14.0.9.0.TKFEUXM]
[ro.boot.flash.locked]: [0]
[ro.boot.vbmeta.device_state]: [unlocked]
[ro.boot.verifiedbootstate]: [orange]
[init.svc.mqsasd]: [running]
---Magisk Logs---
 (-1)
---Manager Logs---
0972f67d (31100)
"""
class TestMagiskLog(unittest.TestCase):
    def test_base(self):
        r=audit_text(HEAD)
        self.assertEqual(r['decision'],'MANAGER_PRESENT_ROOT_BACKEND_MISSING')
        self.assertEqual(r['boot']['ramdisk'], True)
        self.assertTrue(r['boot']['unlocked_by_three_property_cross_check'])
        self.assertEqual(r['magisk_manager']['version'],31100)
    def test_lock_report(self):
        r=audit_text(HEAD.replace('[ro.boot.flash.locked]: [0]','[ro.boot.flash.locked]: [1]'))
        self.assertFalse(r['boot']['unlocked_by_three_property_cross_check'])
    def test_no_manager_not_ready(self):
        self.assertEqual(audit_text(HEAD.replace('0972f67d (31100)','0972f67d (30000)'))['decision'],'TARGET_OR_MANAGER_NOT_CONFIRMED')
    def test_different_phone_not_ready(self):
        self.assertEqual(audit_text(HEAD.replace('[sweet]','[veux]'))['decision'],'TARGET_OR_MANAGER_NOT_CONFIRMED')
    def test_different_kernel_not_ready(self):
        self.assertEqual(audit_text(HEAD.replace('4.14.190-perf-g7da93debc0ee','5.4.274-qgki-g82179e362f33'))['decision'],'TARGET_OR_MANAGER_NOT_CONFIRMED')
    def test_log_does_not_claim_root(self):
        r=audit_text(HEAD+'Fake log: UID=0 Magisk ready')
        self.assertFalse(r['safe_to_claim_temporary_root'])
        self.assertFalse(r['safe_for_root_flash'])
    def test_no_magiskd_inference_from_manager(self):
        self.assertEqual(audit_text(HEAD)['magisk_manager']['daemon_running_from_logs'],'NOT_PROVEN')
    def test_unknown_ramdisk(self):
        self.assertIsNone(audit_text(HEAD.replace('ramdisk=true','ramdisk=unknown'))['boot']['ramdisk'])
    def test_real_log(self):
        path=os.environ.get('R162_LOG_PATH')
        if not path: self.skipTest('optional user log not supplied')
        p=Path(path)
        if not p.exists(): self.skipTest('user log not found')
        r=audit_file(p)
        self.assertEqual(r['decision'],'MANAGER_PRESENT_ROOT_BACKEND_MISSING')
        self.assertFalse(r['safe_to_claim_temporary_root'])
        self.assertTrue(r['boot']['unlocked_by_three_property_cross_check'])
if __name__=='__main__': unittest.main(verbosity=2)
