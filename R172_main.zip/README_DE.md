# R17.2 – Echter Gegenprozess für die bestehende R16.3-Root-Peer-Prüfung

**Was konkret neu programmiert wurde:** Der bislang nur auf App-Seite vorhandene Android-Localsocket-Kanal (`sweet414-root-peer-v1`) erhält erstmals ein **vollständiges natives Server-Gegenstück** in C++17. Es wird als ARM64-Prozess übersetzt und kann von einem künftigen, **bereits unabhängig privilegierten** GhostLock-Root-Child aufgerufen werden. Die bestehende R16.3-App muss dafür nicht geändert werden. Dieses Paket ist ausschließlich ein Integrationsbaustein: **R17.2 kann weder Root erzeugen noch Magisk installieren oder starten.**

## Was der Server macht

1. Start verweigern, wenn reale und effektive UID nicht **beide 0** sind (kein Umschalten auf Root).
2. Exakte Gerätedaten verlangen: `sweet`, Kernel `4.14.190-perf-g7da93debc0ee`, Android 13, MIUI `V14.0.9.0.TKFEUXM`. Host- und andere Geräte verweigern die Ausführung.
3. Höchstens eine lokale AF_UNIX-Verbindung im **abstrakten** Socket-Namensraum annehmen; nach 12 Sekunden ohne Client schließen.
4. Auf dem Server die Client-UID über `SO_PEERCRED` prüfen und ausschließlich die beim Start erwartete App-UID zulassen.
5. Ausschließlich eine feste read-only Kennung (`MAGISKD=NOT_VERIFIED`) schreiben, nie Befehle entgegennehmen oder ausführen.
6. R16.3 vertraut ohnehin nur `LocalSocket.getPeerCredentials()` – **nicht** dem vom Server gesendeten Text.

## Integration in die bisherige Architektur

`GhostLock W1/W2` (noch nicht auf sweet implementiert) → **bereits privilegierter Root-Child** → `sweet414-root-peer --serve-once --app-uid <richtige App-UID>` → bereits implementierte `AndroidRootPeerProbe.probe()` in **R16.3**. Ohne privilegierten Child startet der Server nicht, und R16.3 bleibt bei `NO_ROOT_PROVIDER`. Ein erfolgreicher Peer-Kanal bedeutet weiterhin **nicht** `magiskd`, MagiskSU oder Zygisk.

Dieses Artefakt lässt den fehlenden Root-Exploit absichtlich unverändert. Es ist **kein** Root-Tool und sollte nicht auf dem Telefon installiert oder ausgeführt werden, solange kein verifizierter Root-Child existiert.

## Prüfungen

- CMake-GNU-Hostbuild mit `-Wall -Wextra -Werror` und CTest.
- `tests/peer_policy_test.cpp`: 16 positive/negative Policy-Tests (statische Modellfälle, nicht Gerätetest).
- `tests/test_r172_guards.py`: 11 Tests auf Fail-Closed-Eigenschaften und Übereinstimmung des Socket-Namens.
- GitHub Actions baut einen ARM64-Android-ELF mit NDK 27.2 (ohne APK), prüft Dateityp, `AArch64`, `PIE`, `linker64` und archiviert ihn.

Die vorhandene R16.3-APK, Magisk R13.4 und die originale Bootpartition werden **nicht geändert**.
