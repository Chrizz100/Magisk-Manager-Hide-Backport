#pragma once
#include <cstdint>
#include <string_view>

namespace sweet414 {
struct DeviceIdentity {
    std::string_view codename;
    std::string_view architecture;
    std::string_view kernel;
    std::string_view android_release;
    std::string_view miui_incremental;
};

// The target constants are intentionally exact and should never be relaxed
// simply to turn an unknown kernel into a PASS.
inline constexpr std::string_view kCodename = "sweet";
inline constexpr std::string_view kArchitecture = "aarch64";
inline constexpr std::string_view kKernel = "4.14.190-perf-g7da93debc0ee";
inline constexpr std::string_view kAndroid = "13";
inline constexpr std::string_view kMiui = "V14.0.9.0.TKFEUXM";
inline constexpr std::string_view kSocketName = "sweet414-root-peer-v1";

inline bool target_matches(const DeviceIdentity& x) noexcept {
    return x.codename == kCodename && x.architecture == kArchitecture && x.kernel == kKernel &&
        x.android_release == kAndroid && x.miui_incremental == kMiui;
}

inline bool really_privileged(uint32_t uid, uint32_t euid) noexcept {
    return uid == 0 && euid == 0;
}

inline bool expected_client_uid(uint32_t uid) noexcept {
    // Android app UID in the regular per-user range; no shell / system / root.
    // R16.3 observed 10291; installation can assign another app UID.
    return uid >= 10000 && uid <= 19999;
}

inline bool client_allowed(uint32_t actual_uid, uint32_t expected_uid) noexcept {
    return expected_client_uid(expected_uid) && actual_uid == expected_uid;
}
} // namespace sweet414
