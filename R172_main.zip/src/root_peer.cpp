/**
 * R17.2: Root-child attestation responder for the existing R16.3 Android
 * LocalSocket.getPeerCredentials() client.
 *
 * Does NOT exploit a kernel, grant privileges, spawn a root shell, start
 * Magisk, change SELinux policy, flash partitions, or accept commands.
 * Running from an unprivileged Android app fails BEFORE opening the socket.
 *
 * A future, separate GhostLock provider MAY invoke --serve-once from an
 * independently verified UID-0 child, once one exists for the exact device.
 */
#include "peer_policy.hpp"
#include <cerrno>
#include <cstddef>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <limits>
#include <string>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/utsname.h>
#include <poll.h>
#include <unistd.h>
#ifdef __ANDROID__
#include <sys/system_properties.h>
#endif

namespace {
constexpr int kListenTimeoutMs = 12000;
constexpr int kWriteTimeoutSeconds = 2;

#ifdef __ANDROID__
std::string prop(const char* key) {
    char buf[PROP_VALUE_MAX] = {};
    const int len = __system_property_get(key, buf);
    return len > 0 ? std::string(buf, static_cast<size_t>(len)) : std::string{};
}

sweet414::DeviceIdentity live_identity(
        const std::string& codename, const std::string& architecture, const std::string& kernel,
        const std::string& android_release, const std::string& miui) {
    return {codename, architecture, kernel, android_release, miui};
}
#endif

bool is_exact_android_target() {
#ifndef __ANDROID__
    return false; // Host builds MUST NEVER listen as a fake Android root peer.
#else
    struct utsname u{};
    if (uname(&u) != 0) return false;
    const std::string kernel(u.release);
    const std::string codename = prop("ro.product.device");
    const std::string android_release = prop("ro.build.version.release");
    const std::string miui = prop("ro.build.version.incremental");
    return sweet414::target_matches(live_identity(codename, u.machine, kernel, android_release, miui));
#endif
}

bool parse_app_uid(const char* value, uid_t& out) {
    if (!value || value[0] == '\0') return false;
    errno = 0;
    char* end = nullptr;
    const unsigned long parsed = std::strtoul(value, &end, 10);
    if (errno || end == value || *end != '\0' ||
        parsed > static_cast<unsigned long>(std::numeric_limits<uid_t>::max()) ||
        !sweet414::expected_client_uid(static_cast<uint32_t>(parsed))) return false;
    out = static_cast<uid_t>(parsed);
    return true;
}

int serve_once(uid_t expected_app_uid) {
    if (!sweet414::really_privileged(static_cast<uint32_t>(getuid()),
                                     static_cast<uint32_t>(geteuid()))) {
        std::cerr << "ROOT_PEER_NOT_ROOT: refusal before socket create\n";
        return 77;
    }
    if (!is_exact_android_target()) {
        std::cerr << "ROOT_PEER_TARGET_MISMATCH: exact SWEET firmware required\n";
        return 78;
    }

    const int server = socket(AF_UNIX, SOCK_STREAM | SOCK_CLOEXEC, 0);
    if (server < 0) { std::perror("socket"); return 71; }
    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    // Android LocalSocketAddress.Namespace.ABSTRACT uses a leading NUL byte.
    const std::string name(sweet414::kSocketName);
    if (name.size() + 1 >= sizeof(addr.sun_path)) {
        close(server);
        return 70;
    }
    addr.sun_path[0] = '\0';
    std::memcpy(addr.sun_path + 1, name.data(), name.size());
    const socklen_t len = static_cast<socklen_t>(offsetof(sockaddr_un, sun_path) + 1 + name.size());
    if (bind(server, reinterpret_cast<sockaddr*>(&addr), len) != 0) {
        std::perror("root peer bind");
        close(server);
        return 73;
    }
    if (listen(server, 1) != 0) {
        std::perror("root peer listen");
        close(server);
        return 73;
    }
    // One connection, bounded lifetime: never a persistent root backdoor.
    pollfd wait_one{server, POLLIN, 0};
    const int pr = poll(&wait_one, 1, kListenTimeoutMs);
    if (pr <= 0 || !(wait_one.revents & POLLIN)) {
        std::cerr << "ROOT_PEER_NO_CLIENT_OR_TIMEOUT\n";
        close(server);
        return 74;
    }
    const int client = accept4(server, nullptr, nullptr, SOCK_CLOEXEC);
    close(server);
    if (client < 0) { std::perror("root peer accept"); return 74; }
    struct ucred creds{};
    socklen_t creds_len = sizeof(creds);
    if (getsockopt(client, SOL_SOCKET, SO_PEERCRED, &creds, &creds_len) != 0 ||
        creds_len != sizeof(creds) ||
        !sweet414::client_allowed(static_cast<uint32_t>(creds.uid),
                                 static_cast<uint32_t>(expected_app_uid))) {
        std::cerr << "ROOT_PEER_CLIENT_UID_REJECTED\n";
        close(client);
        return 77;
    }
    // R16.3 only checks the KERNEL peer credentials via getPeerCredentials().
    // This intentionally sends no secrets, no commands and no fake magiskd status.
    const char reply[] = "SWEET414_ROOT_PEER_V1\nMAGISKD=NOT_VERIFIED\n";
    (void)send(client, reply, sizeof(reply) - 1, MSG_NOSIGNAL);
    close(client);
    std::cout << "ROOT_PEER_ONE_SHOT_COMPLETE;MAGISKD_NOT_VERIFIED\n";
    return 0;
}
}

int main(int argc, char** argv) {
    if (argc == 2 && std::strcmp(argv[1], "--about") == 0) {
        std::cout << "sweet414-root-peer R17.2; read-only UID-0 proof; no exploit; no Magisk\n";
        return 0;
    }
    if (argc != 4 || std::strcmp(argv[1], "--serve-once") != 0 ||
        std::strcmp(argv[2], "--app-uid") != 0) {
        std::cerr << "Usage: sweet414-root-peer --about | --serve-once --app-uid N\n";
        return 64;
    }
    uid_t app_uid = 0;
    if (!parse_app_uid(argv[3], app_uid)) {
        std::cerr << "ROOT_PEER_BAD_APP_UID\n";
        return 64;
    }
    return serve_once(app_uid);
}
