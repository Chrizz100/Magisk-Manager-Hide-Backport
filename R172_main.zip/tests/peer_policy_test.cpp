#include "peer_policy.hpp"
#include <stdexcept>
#define REQUIRE(cond) do { if(!(cond)) throw std::runtime_error("failed: " #cond); } while(0)
#include <iostream>

int main(){
    using namespace sweet414;
    int n=0;
    const DeviceIdentity exact{kCodename,kArchitecture,kKernel,kAndroid,kMiui};
    REQUIRE(target_matches(exact)); ++n;
    REQUIRE(!target_matches({"veux", kArchitecture, kKernel, kAndroid, kMiui})); ++n;
    REQUIRE(!target_matches({kCodename,"armv7l",kKernel,kAndroid,kMiui})); ++n;
    REQUIRE(!target_matches({kCodename, kArchitecture, "4.14.190-incorrect", kAndroid, kMiui})); ++n;
    REQUIRE(!target_matches({kCodename, kArchitecture, kKernel, "12", kMiui})); ++n;
    REQUIRE(!target_matches({kCodename, kArchitecture, kKernel, kAndroid,"V14.0.8.0.TKFEUXM"})); ++n;
    REQUIRE(really_privileged(0,0)); ++n;
    REQUIRE(!really_privileged(0,10291)); ++n;
    REQUIRE(!really_privileged(10291,0)); ++n;
    REQUIRE(expected_client_uid(10291)); ++n;
    REQUIRE(!expected_client_uid(2000)); ++n;
    REQUIRE(!expected_client_uid(0)); ++n;
    REQUIRE(!expected_client_uid(20000)); ++n;
    REQUIRE(client_allowed(10291,10291)); ++n;
    REQUIRE(!client_allowed(10290,10291)); ++n;
    REQUIRE(!client_allowed(0,0)); ++n;
    std::cout << "R172_PEER_POLICY=" << n << "/" << n << " PASS (host-only policy tests)\n";
}
