import pathlib
import re
import subprocess
import sys
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SERVER = ROOT / 'src' / 'root_peer.cpp'
POLICY = ROOT / 'src' / 'peer_policy.hpp'

class GuardTests(unittest.TestCase):
    def test_exact_expected_target(self):
        p = POLICY.read_text()
        for s in ('sweet', 'aarch64', '4.14.190-perf-g7da93debc0ee', '13', 'V14.0.9.0.TKFEUXM'):
            self.assertIn(s, p)

    def test_matches_existing_r163_android_probe_socket(self):
        old = ROOT / 'reference' / 'AndroidRootPeerProbe.java'
        match = re.search(r'kSocketName = "([^"]+)"', POLICY.read_text())
        self.assertIsNotNone(match)
        self.assertEqual(match.group(1), 'sweet414-root-peer-v1')
        self.assertTrue(old.is_file())
        self.assertIn(match.group(1), old.read_text())

    def test_root_before_socket(self):
        s=SERVER.read_text()
        self.assertLess(s.index('really_privileged('), s.index('socket(AF_UNIX'))

    def test_root_and_real_uid(self):
        s=SERVER.read_text()
        self.assertIn('getuid()', s)
        self.assertIn('geteuid()', s)

    def test_target_before_socket(self):
        s=SERVER.read_text()
        self.assertLess(s.index('is_exact_android_target()) {\n        std::cerr'), s.index('socket(AF_UNIX'))

    def test_peer_from_kernel(self):
        self.assertIn('SO_PEERCRED', SERVER.read_text())

    def test_server_no_shell_or_system(self):
        s=SERVER.read_text()
        for forbidden in ('system(', 'execve(', 'popen(', 'setuid(', 'setresuid(', 'finit_module(', 'ptrace(', 'ioctl('):
            self.assertNotIn(forbidden, s)

    def test_no_root_string_without_proof(self):
        s=SERVER.read_text()
        self.assertNotIn('MAGISKD=RUNNING',s)
        self.assertIn('MAGISKD=NOT_VERIFIED',s)

    def test_bounds_and_once(self):
        s=SERVER.read_text()
        self.assertIn('kListenTimeoutMs = 12000',s)
        self.assertIn('accept4(',s)
        self.assertEqual(s.count('accept4('),1)

    def test_unprivileged_or_host_execution_never_succeeds(self):
        binary = ROOT / '.build-host' / 'sweet414-root-peer'
        if not binary.exists(): self.skipTest('host build not available')
        completed = subprocess.run([str(binary), '--serve-once', '--app-uid', '10291'], capture_output=True, text=True, timeout=2)
        self.assertIn(completed.returncode, (77, 78))

    def test_no_fake_android_host_property(self):
        s=SERVER.read_text()
        self.assertIn('return false; // Host builds MUST NEVER listen',s)

if __name__=='__main__': unittest.main()
