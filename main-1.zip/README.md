# Magisk Manager-Hide R1 — audit-only reference kit

This repository provides a **read-only source audit** and an **opt-in historical
build** of the last known Magisk source revision retaining app manager repackaging.

**It is NOT an installable Magisk module, NOT a Magisk Alpha 31100 backport,
and NOT approved for device installation or flashing.**

The pre-removal baseline is pinned at `ea16c8141eb64dc28b56a0e7fb536689ef465429`
(versionCode 31000). The final public Magisk 31.1 is
`0972f67d97f9b6302b67c5171283330c74114b4a`.

Workflow default: source audit only. The optional build compiles historical
source and is offered solely for reproducibility. Read `README_DE.md`.

Scripts: GPL-3.0-or-later; original Magisk code: GPL-3.0-or-later.
