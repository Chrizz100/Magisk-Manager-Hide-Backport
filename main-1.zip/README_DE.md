# Magisk Manager-Hide — Backport R1 (Quellcode-Audit & Referenz-Build)

**Status 08.11.2026: R1, SOURCE / NICHT FLASHEN / NICHT INSTALLIEREN.**

Dieses Projekt ist absichtlich getrennt von `Chrizz100/ZygiskEnv-Alpha-Bridge` und
vom VEUX-Kernelprojekt. **Es enthält noch keinen fertigen Magisk-Modul-Fix**,
sondern die nachprüfbare Grundlage für das Wiederherstellen der alten
**Magisk-Manager-Umbenennung**.

## Der technische Befund

- **MagiskHide** (Rootverstecken) wurde schon in **Magisk 24.0** entfernt.
- **Magisk-App verstecken / App-Repackaging** existierte noch in **Magisk 30.0
  und 31.0**: Zufalls-Paketname, neu signierte Stub-App, gespeicherter
  Manager-Paketname, Zertifikatsprüfung und Wiederherstellungsfunktion.
- **Magisk 31.1 (31100)** entfernte diese Funktion in mehreren Schritten.
- Der native Magisk-31.1-Dienst verwendet nicht mehr die frühere Verwaltung
  eines repackagten Managers; ein altes APK-Modul allein reicht **nicht**.
- Die Funktion entfernt **keine** systemweiten SELinux-Spuren von Magisk.
  Bank-App-Unterstützung wird **nicht** garantiert.

### Historische Referenzen (offizieller Magisk-Quellcode)

| Version | Commit | Manager-Hide |
|---|---|---|
| Magisk 30.0 | `e81de7ec36ee3b0826782a095fa0458dede6b6c2` | vorhanden |
| Magisk 31.0 | `96221b69fae9910b1c0c75c2f92a4ebb2c2dc698` | vorhanden |
| Letzter Stand vor Entfernung (22.10.2026) | `ea16c8141eb64dc28b56a0e7fb536689ef465429` | vorhanden |
| Magisk 31.1 (25.10.2026) | `0972f67d97f9b6302b67c5171283330c74114b4a` | entfernt |

**Wichtig:** Der letzte historische Stand besitzt **`versionCode=31000`**,
auch wenn er bereits viele spätere Änderungen enthält. **Er ist kein Magisk
Alpha 31100** und lässt sich nicht als vollwertiger 31.1-Fix bezeichnen.
Der veröffentlichte Alpha-31100-Tag zeigt öffentlich denselben Basiscommit
wie das offizielle 31.1; die zusätzlichen Alpha-spezifischen Änderungen
sind über die angegebene Alpha-Quellcode-Referenz nicht vollständig abrufbar.

## Was R1 liefert

1. Einen **reproduzierbaren, SHA-gepinnten Abgleich** des letzten
   Hide-fähigen Standes mit Magisk 31.1 (`tools/audit.py`).
2. Automatische Tests für die Bestandteile: APK-Umpacker, Stub-Lader,
   Signierer, Manager-Datenbank und native Manager-Erkennung.
3. Eine **GitHub-Actions-YAML** für den sicheren Read-only-Audit (Standard).
4. Einen **optional zuschaltbaren reinen Referenz-Build** des alten
   Quellcode-Stands für Redmi `sweet` (ARM32/ARM64), ausdrücklich
   **ohne Flash oder Installation**. Ein grüner Build beweist keine Boot-
   oder Banking-Kompatibilität.

## Verwendung ohne PC – nur ZWEI Dateien auf GitHub

Im Repository `Magisk-Manager-Hide-Backport` auf Branch `main` werden
**nur zwei Dateien direkt hochgeladen**:

- `/main.zip` (dieses unverändert hochgeladene Archiv, nicht entpacken)
- `/.github/workflows/build.yml` (die separat bereitgestellte YAML)

Die Action entpackt `main.zip` nach `kit/`, verifiziert Checksummen und die
Übereinstimmung zwischen der eingebetteten und der separat hochgeladenen YAML
und startet dann den sicheren Source-Audit. **`main.zip` ist NICHT selbst ein
Magisk-Modul und wird NICHT auf dem Smartphone installiert.**

1. GitHub: neues, leeres Repository mit `main` anlegen.
2. `main.zip` über **Add file → Upload files** ins Hauptverzeichnis hochladen.
3. Über **Add file → Create new file** den Pfad
   `.github/workflows/build.yml` eingeben und den Inhalt der separat
   bereitgestellten `build.yml` einfügen. Alternativ die YAML in genau diesem
   Unterordner hochladen.
4. GitHub: **Actions → Magisk Manager-Hide R1 - Source Audit → Run workflow**.
5. `compile_historical_snapshot` auf **false** lassen.
6. Die Ergebnisse der Action und ggf. das Audit-Artefakt
   `MAGISK_MANAGER_HIDE_R1_SOURCE_AUDIT` prüfen.

Der optionale alte Build liefert nur einen **ungetesteten Referenzstand
(31000)**, keinen funktionierenden Alpha-31100-Fix.

## Was für einen wirklich funktionierenden Alpha-31100-Backport noch fehlt

- Die native Manager-Erkennung und Zertifikatsbindung von Magisk 31.0
  **bewusst an die neue 31.1-SU-Verwaltung portieren** (inkl. Android 13 UID,
  Multi-User-/HSUM-Sonderfällen und Signaturprüfung).
- Die App-seitige Stub-App, dynamische Ladefunktionen, APK-Signierung,
  Aktualisierung und Rückkehrfunktion an den 31.1-Compose-Manager anpassen.
- Keine anderen Magisk-Module oder Zygisk-Implementierungen automatisch
  installieren; unsere Alpha Bridge bleibt unberührt.
- Statische Checks, APK-Signierung, AVD mit Android 13, Manager-Upgrade-
  und Wiederherstellungsprüfungen vor einem physischen Gerätetest.
- Alpha-spezifische Änderungen zur Root-Diensterkennung verifizieren.
  Ohne diese Prüfung wäre die Bezeichnung „Magisk Alpha 31100 kompatibel“
  unbelegt.

**Hauptproblem:** Der neue Dienst in `native/src/core/package.rs` erkennt
keinen aus 31.0 bekannten fremden Paketnamen mehr. Ein simples Skript,
das `io.github.vvb2060.magisk` umbenennt, würde deshalb die
Root-Verwaltung gefährden und ist **keine vertretbare Lösung**.

## Quelldokumentation

- [Magisk 31.0 AppMigration](https://github.com/topjohnwu/Magisk/blob/v31.0/app/core/src/main/java/com/topjohnwu/magisk/core/tasks/AppMigration.kt)
- [Magisk 31.0 native Manager-Erkennung](https://github.com/topjohnwu/Magisk/blob/v31.0/native/src/core/package.rs)
- [Magisk 31.1 native Manager-Erkennung](https://github.com/topjohnwu/Magisk/blob/v31.1/native/src/core/package.rs)
- [Originalentfernung UI](https://github.com/topjohnwu/Magisk/commit/58477458401a298c02604b99caf5afcdb9ed9e3f)
- [Originalentfernung Signierung & Repackaging](https://github.com/topjohnwu/Magisk/commit/1240c2e35ca3f232d7a125238a33e634e9ab3231)
- [Originalentfernung nativer Manager-Erkennung](https://github.com/topjohnwu/Magisk/commit/5f2faee61879859004acb34811051f45d51a5191)

## Sicherheit / Lizenz

Der Audit selbst ist lesend. Ein späterer echter Magisk-Fork benötigt
besonders sorgfältige Signatur- und Update-Tests sowie einen dokumentierten
Rettungsweg. **R1 ist nicht für die Installation auf dem Redmi freigegeben.**
Die Scripts in diesem Projekt stehen unter GPL-3.0-or-later; Magisk-Quellen
werden zur Buildzeit aus der originalen GitHub-Quelle geholt, nicht in der ZIP
mitgeliefert. Magisk steht unter der GNU GPLv3 oder neuer; die Lizenzangaben
von Magisk und dessen Unterprojekten bleiben einzuhalten.
