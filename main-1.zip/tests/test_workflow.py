import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from validate_workflow import validate


class TestWorkflow(unittest.TestCase):
    def test_original_workflow(self):
        data = (Path(__file__).parents[1] / '.github/workflows/build.yml').read_text(encoding='utf-8')
        self.assertEqual([], validate(data))

    def test_detect_unwanted_flash(self):
        data = (Path(__file__).parents[1] / '.github/workflows/build.yml').read_text(encoding='utf-8')
        self.assertTrue(any('installation/flashing' in s for s in validate(data + '\nfastboot flash boot boot.img\n')))

    def test_two_file_mode(self):
        data = (Path(__file__).parents[1] / '.github/workflows/build.yml').read_text(encoding='utf-8')
        self.assertIn("- 'main.zip'", data)
        self.assertIn('unzip -oq main.zip -d kit', data)
        self.assertIn('sha256sum -c MANIFEST.sha256', data)

    def test_sha_pin_mandatory(self):
        data = (Path(__file__).parents[1] / '.github/workflows/build.yml').read_text(encoding='utf-8')
        self.assertTrue(validate(data.replace('ea16c8141eb64dc28b56a0e7fb536689ef465429', 'main')))


if __name__ == '__main__':
    unittest.main()
