#!/usr/bin/env python3
"""Local workflow preflight (requires PyYAML; actionlint is the preferred CI linter)."""
from pathlib import Path
import argparse
import re
import sys


def validate(text: str) -> list[str]:
    findings = []
    required = [
        'source-audit:', 'historical-build:', 'persist-credentials: false',
        'ea16c8141eb64dc28b56a0e7fb536689ef465429',
        '0972f67d97f9b6302b67c5171283330c74114b4a',
        'python3 kit/tools/audit.py', 'python3 -m unittest',
        'compile_historical_snapshot', 'main.zip', 'unzip -oq main.zip -d kit',
        'sha256sum -c MANIFEST.sha256', 'NOT_FLASH',
    ]
    # Treat words as advisory only: not every warning label must have same spelling.
    for token in required[:12]:
        if token not in text:
            findings.append(f'Missing required workflow token: {token}')
    if 'compile_historical_snapshot == true' not in text:
        findings.append('Optional compilation must have explicit true guard')
    if re.search(r'\b(?:fastboot\s+flash|adb\s+shell\s+su|magisk\s+--install-module)\b', text):
        findings.append('Workflow contains installation/flashing commands')
    try:
        import yaml
        tree = yaml.safe_load(text)
        if not isinstance(tree, dict) or not isinstance(tree.get('jobs'), dict):
            findings.append('Invalid workflow jobs shape')
        elif set(tree['jobs']) != {'source-audit', 'historical-build'}:
            findings.append('Unexpected jobs present')
    except Exception as exc:
        findings.append(f'Invalid YAML or PyYAML missing: {exc}')
    return findings


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('file', type=Path)
    args = p.parse_args()
    errors = validate(args.file.read_text(encoding='utf-8'))
    for issue in errors:
        print('FAIL', issue)
    print('Workflow static preflight:', 'PASS' if not errors else 'FAIL')
    return 0 if not errors else 1


if __name__ == '__main__':
    sys.exit(main())
