# R15.8 – Kurzbefund zum GhostLock-Port

**Neu entstanden:** Eine tatsächlich kompilierbare C++17-Kompatibilitätskomponente für den archivierten Xiaomi-Kernel 4.14.190, ein reproduzierbarer Abgleich mit der originalen `boot(4).img` und eine Native/JNI-Statusanbindung.

**Nachgewiesen:** Die älteren Kernel-Symbolnamen sind vorhanden. Die R15.6/R15.7-Prüfungen bestätigen sechs direkte Funktionsverbindungen und fünf Hilfsaufrufe. Ein fehlender eigenständiger Name für `futex_wait_requeue_pi` muss daher nicht bedeuten, dass die Funktionalität entfernt wurde. Das beweist jedoch **nicht**, dass GhostLock zur Laufzeit funktioniert.

**Prüfergebnis:** 41/41 Python-Tests, 5/5 C++-Tests mit GCC, 5/5 mit Clang. Es handelt sich um Host-/Offline-Tests. Nicht um `UID=0`-Tests auf dem Smartphone.

**Blocker:** Die originale GhostLock-Engine unterstützt die Kernelarchitektur 4.14 noch nicht nachweislich. Das veröffentlichte Profilschema beschränkt sich auf Kernelmajor 5 oder 6. Ein zur laufenden Firmware passender echter Root-Zugang ist nicht nachgewiesen. Magisk 31100 und dein Smartphone bleiben unverändert.

**Nächster sinnvoller Schwerpunkt:** Nur die verbleibenden, tatsächlich notwendigen Kernel-4.14-Laufzeitunterschiede zur originalen GhostLock-Engine prüfen. Keine weitere Test-APK, die Root bloß simuliert, und kein Wechsel zu KernelSU. Vor Geräteversuchen: identische Bootbasis und unabhängiger Wiederherstellungsweg.

**Wichtig:** Das Paket ist Quellcode und kein installierbares Root-Programm. Ein installierbarer, funktionsfähiger SU-Start ist noch nicht erreicht.
