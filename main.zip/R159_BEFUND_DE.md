# R15.9 – GhostLock-Prozessarchitektur: tatsächliche Integration getestet

**Datum:** 11.11.2026 · **Redmi Note 10 Pro (`sweet`)** · Android 13 / MIUI `V14.0.9.0.TKFEUXM` · archivierter Stockkernel `4.14.190-perf-g7da93debc0ee`.

## Neue, unabhängige Beobachtung

Im aktuellen Originalprojekt `YuKongA/ghostlock-app` wird das native GhostLock-Programm **als eigener Android-Prozess** mittels Kotlin `ProcessBuilder` gestartet (`AGENTS.md`, ab Zeile 15). Das ausführbare ELF wird als `libghostlock.so` ausgeliefert; der Eingang verarbeitet `--ghostlock-app-call` mit GLK1-Profil. Unsere R15.8-Kompatibilitätsprüfung verwendete dagegen eine direkte JNI-Statusabfrage. Dieser Unterschied verhindert keine statische Analyse, ist aber eine **falsche Vorlage für die spätere native GhostLock-Einbindung**.

Das echte GhostLock verwendet intern einen kurzlebigen privilegierten Root-Child-Ablauf; nach `W1/W2` wird KernelSU spät geladen. In `src/core/session/root_child_frontend.cpp` sind die Übergabe und `ever_rooted` dokumentiert. Der Wert `ever_rooted` allein beweist nicht, dass Android anschließend einen nutzbaren MagiskSU-Dienst besitzt. Ein eigenständiger Magisk-31100-Übergabeweg ist weiterhin **nicht vorhanden**.

## Jetzt tatsächlich geändert

- Die R15.8-Kotlin/JNI-Verbindung ist **aus dem aktiven Buildpfad entfernt** und nur als DEPRECATED-Datei unter `prior/` archiviert.
- Das Android-Buildziel für unser **nicht privilegiertes** C++-Archivprüfprogramm trägt den Bibliotheksnamen `libsweet414_preflight.so` (bei NDK-Kompilation). Dies ist **nicht** `libghostlock.so` und **kein** GhostLock-Exploit.
- Neu: `NativeArchiveAuditRunner.kt`. Es startet nur die feste Option `--archive-audit` über einen eigenständigen Prozess, verlangt einen explizit vorgegebenen SHA-256 der ausführbaren Datei, liest ein stark begrenztes Ergebnisformat und weist root=true, Mehrfacheinträge, Fehlercodes, manipulierte Dateien und zu lange Ausgaben zurück. Keine Kommandozeile aus Benutzereingaben.
- Neu: `tests/ProcessBridgeIntegration.kt`: Tatsächlich gestartetes, unter GCC kompiliertes C++-Programm wird von Kotlin/JVM aus aufgerufen. Es folgen bewusst manipulierte Negativtests. Das ist **kein** Android-Gerätetest.
- Neu: `scripts/run_r159_offline.sh`: Führt die vorhandenen R15.8-Regressionen und den Kotlin/Prozess-Test reproduzierbar aus.

## Ergebnisse, lokal reproduziert

| Kontrollpunkt | Befund |
|---|---|
| Archivierte `boot(4).img` | SHA-256 erneut geprüft; original unverändert |
| Alte Futex-/pselect-Verbindungen | 6 direkt nachgewiesen, 5 weitere Helfer; wie R15.7 |
| Alte Regressionen | 41 / 41 Python-Tests PASS |
| Native Linux GCC Release | 5 / 5 C++-Tests PASS |
| Native Linux Clang Release | 5 / 5 C++-Tests PASS |
| **Neue Kotlin/JVM-Prozessintegration** | **7 / 7 Tests PASS** |
| Android NDK / installierbare APK | NICHT gebaut / NICHT geprüft |
| Native GhostLock-Engine für 4.14 | NICHT implementiert |
| Reale temporäre SU-Rechte / Magisk 31100 | NICHT erreicht |

**Wichtig:** Der erfolgreiche `ProcessBuilder`-Lauf beweist nur die funktionierende Host-Prozessgrenze mit unserem lesenden Diagnoseprogramm. Er ist **kein GhostLock-Lauf und kein Root-Nachweis**.

## Reproduzierbarkeit

Das unveränderte `SWEET_STOCK_REFERENZEN_20261107.zip` liegt separat in deiner Bibliothek; es wird nicht in dieses ZIP kopiert. Auf einer Linux-Entwicklungsumgebung mit Python 3, GCC, Clang, CMake, Java und Kotlin:

```sh
bash scripts/run_r159_offline.sh /pfad/SWEET_STOCK_REFERENZEN_20261107.zip
```

## Verbleibender Blocker – klar benannt

Der neue Android-Transport ist eine Voraussetzung der originalen App-Architektur. Für temporären Root fehlt **der kompatible, validierte GhostLock-4.14-Laufzeitcode** (inklusive gerätespezifischer Speicher- und Kernelbedingungen). Danach fehlt noch die *persistente Übergabe* der privilegierten Root-Child-Sitzung in einen für Magisk 31100 nutzbaren SU-Dienst. Weder die JNI-Entfernung noch die Prozessintegration lösen diese beiden Probleme allein.

**Nicht verifiziert:** Bootimage bytegleich mit laufender Partition; Android-Prozessstart auf tatsächlichem Gerät; Android NDK; Root `uid=0`; Magisk-Initialisierung; Recovery-/Bootflash. **Gerät wurde nicht verändert.** Kein KernelSU, keine weiteren Apps, kein PC, kein Termux-Test erforderlich.

## Originalquellen

- Originalarchitektur: https://github.com/YuKongA/ghostlock-app/blob/main/AGENTS.md (Blob-SHA `feff742343e8cf1893c4280bec27f6ee0f781c28`)
- Root Child: https://github.com/YuKongA/ghostlock-app/blob/main/src/core/session/root_child_frontend.cpp (Blob-SHA `4762122d847a8a85755e18b9be8df5f2d9462264`)
- Native-Komponenten: https://github.com/YuKongA/ghostlock-app/blob/main/src/core/README.md (Blob-SHA `c4a94d9bc75b0583f11be0db392606a15e67a0c5`)
- Profilstandard, der Major 4 weiterhin ausschließt: https://github.com/YuKongA/ghostlock-app/blob/main/docs/kernel_profiles/PROFILE_SCHEMA.md
