# Magisk Manager-Hide Backport R2 (experimental)

This source-only research kit reverts eight Magisk manager-app hiding deletion commits on the precise **official Magisk 31.1** source checkout, verifies restored code markers, and optionally compiles an untested APK on GitHub Actions.

**Not a Magisk module, not Magisk Alpha 31100, and NOT safe to install/flash.** Upstream merge conflicts are treated as failures requiring manual review, never auto-resolved. Passing an APK structure check cannot establish bank-app compatibility, signature/manager authorization, or Android 13 runtime stability.

See `README_DE.md` for the phone-based upload steps. `docs/RESTORE_COMMITS.json` pins the relevant upstream commits.
