# Magisk Manager-Hide Backport R2.2 – Native-Integration

**Status: Forschungsstand. Kein installierbares Magisk-Modul. Nicht flashen.**

## Ursache von R2.1

Im GitHub-Lauf `42476412723` wurde der Manifest-Konflikt aus R2 erfolgreich aufgelöst. Danach scheiterte das Rückgängigmachen des Upstream-Commits `c86a8776cee88689dd684ec1dd7d584d77540110` an zwei Rust-Dateien:

- `native/src/core/package.rs` – alte Stub-Manager-Verwaltung vs. Magisk-31.1-Manager-ID-API
- `native/src/core/su/daemon.rs` – alte Manager-API vs. neuere Root-Berechtigungs- und Benachrichtigungsregeln

## Änderung in R2.2

Die Wiederherstellung behandelt **ausschließlich diese bekannten Konfliktdateien** bei genau diesem gepinnten Commit und der exakten Magisk-31.1-Basis. Für `package.rs` wird die alte Stub-Funktionalität aus der historischen Konfliktseite übernommen; die neue `get_app_id`-Funktion wird ausdrücklich aus dem neueren Quellcode übernommen. Die `su/daemon.rs` bleibt in der neueren 31.1-Variante mit Schutz vor Benachrichtigungen ohne Manager. Die Vorgehensweise ist ein **Forschungskompromiss**, keine bewiesene vollständige Android-/Rust-Kompatibilität. Weitere Konflikte sind möglich und führen zum Abbruch.

Die vorherige R2.1-Korrektur des Manifests bleibt erhalten. Zusätzliche Strukturprüfungen untersuchen Stub-Verwaltung, Signaturerkennung, Android-HSUM, die neue Manager-ID-Funktion und SU-Berechtigungen. Bei einem unbekannten Konflikt werden sämtliche Git-Stages der Konfliktdateien in `conflict_sources/` für die Nachprüfung gespeichert. Es gibt keine automatische pauschale `-X ours`-/`-X theirs`-Strategie.

## In GitHub hochladen (Smartphone)

1. Im Repository `Chrizz100/Magisk-Manager-Hide-Backport` die bisherige `main.zip` im Hauptordner durch die neue Datei `main.zip` ersetzen (**nicht** entpacken).
2. Die Datei `.github/workflows/build.yml` mit dem Inhalt der separaten neuen `build.yml` ersetzen.
3. Den Workflow `Magisk Manager-Hide R2.2 - Native Stub Conflict Review` in Actions prüfen; er wird bei Push normalerweise automatisch gestartet.
4. Bei einem roten Lauf die erzeugte Fehlerdiagnose verwenden; erst wenn alle Reverts und Quellcodeprüfungen bestanden sind, versucht der Workflow eine Kompilierung.

**Wichtig:** Der Code ist auf OFFIZIELLEM Magisk 31.1 aufgebaut. Es ist kein verifizierter Backport in die proprietär modifizierte Magisk Alpha 31100 und kein nachgewiesener Fix für Axis Mobile.

Die Ausgabe `R2_2_RECONSTRUCTION_AND_BUILD_REPORT` wird auch bei Konflikten erstellt. Die optional erzeugte APK ist als `DO_NOT_INSTALL_OR_FLASH` markiert. Ein Gerätetest oder zuverlässiger Rückweg ist nicht belegt.
