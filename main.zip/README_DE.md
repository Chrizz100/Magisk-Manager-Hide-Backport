## R2.1 – Prüfung nach dem fehlgeschlagenen GitHub-Lauf

Der erste R2-Integrationsversuch scheiterte am Zusammenführen der Android-Manifestdatei. R2.1 korrigiert **ausschließlich diesen nachgewiesenen Konflikt** unter strengen Prüfungen und bricht bei weiteren Konflikten ab. Es ist **kein installierbares Modul**. Weitere Details: `docs/R2_1_MANIFEST_REPAIR.md`.

# Magisk Manager-Hide Backport R2 – Anleitung (8. November 2026)

**Quellcode-Kandidat und Kompilierungsversuch, kein fertiges Magisk-Modul. NICHT FLASHEN.**

## Ziel

Magisk 31.1 (Basis `0972f67d97f9b6302b67c5171283330c74114b4a`) erhält versuchsweise die in Magisk 31.0 noch vorhandene App-Umbenennung zurück. Dazu werden acht aufeinanderfolgende, gut dokumentierte Entfernungsschritte in umgekehrter Reihenfolge rückgängig gemacht. Die R2.1-Prüfungen sind **fail-closed**: Nur der bereits geprüfte Manifest-Konflikt wird anhand des exakten Upstream-Quellcodes automatisch aufgelöst; bei weiteren Konflikten wird abgebrochen und ein genaues Protokoll erstellt; niemals Dateien unbemerkt überschreiben oder dennoch eine APK freigeben.

Das ist **kein** MagiskHide (altes systemweites Root-Hiding wurde 2022 in Magisk 24.0 entfernt). Es geht nur um die in Magisk 31.1 entfernte **Magisk-Manager-App-Umbenennung**.

## Upload mit Smartphone

1. GitHub-Repo öffnen: https://github.com/Chrizz100/Magisk-Manager-Hide-Backport
2. Auf `main` die **bereits vorhandene** `main.zip` durch die neue R2-`main.zip` ersetzen (Dateiname gleich lassen; den ZIP-Inhalt **nicht** manuell entpacken).
3. `.github/workflows/build.yml` mit der neuen R2-`build.yml` ersetzen. **Beide Dateien müssen vom selben R2-Paket stammen.**
4. GitHub **Actions → Magisk Manager-Hide R2 - Real Source Integration → Run workflow** starten. Beim Hochladen auf `main` startet der Workflow auch automatisch.
5. Es gibt zwei Jobs. `source-audit` prüft die Quellen und Tests. `reconstruct-and-build` versucht die echte Quellcodeintegration und startet **nur bei vollständiger Integration** den Build.
6. Bei Konflikten erscheint möglicherweise ein rotes ❌ im zweiten Job – das ist bewusst so, denn eine unvollständige Wiederherstellung darf nicht als erfolgreich gelten. Das Artefakt `R2_1_RECONSTRUCTION_AND_BUILD_REPORT` enthält die konkreten Konfliktdateien; Run-Link für die nächste Diagnose teilen.

## Was entsteht?

- Immer nach dem Audit: `R2_PINNED_SOURCE_AUDIT` (historische Quellen und Vergleich).
- Im Kandidatenjob, auch bei Git-Konflikt: `R2_1_RECONSTRUCTION_AND_BUILD_REPORT` (`reconstruction.json`, `reconstruction.md`, `failure.txt` falls nötig).
- **Nur wenn alle 8 Reverts UND der Quellcode-Check UND der Android-Build erfolgreich sind:** `R2_EXPERIMENTAL_MAGISK_CANDIDATE_DO_NOT_FLASH` (APK/Buildausgaben, nicht zur Installation freigegeben).

## Wichtige Grenzen

- Die verwendete Basis ist **offizielles Magisk 31.1**, nicht der proprietär angepasste **Magisk Alpha 31100**-Binärstand. Die Release-Tags teilen einen upstream-Commit, aber die ausgelieferten APKs sind nicht identisch.
- Selbst ein vollständig kompiliertes APK kann an der Root-Daemon-Signaturprüfung, Package-Manager-Migration, SELinux- oder Android-13-Laufzeit scheitern. Ein grüner Compiler ist noch keine Flashfreigabe.
- Die alte Funktion versteckt nur einen Paketnamen. Sie entfernt keine globalen Magisk-SELinux-Regeln, Magisk-Root-Binaries und garantiert keinen Erfolg bei einer Banking-App.
- Ein echter Test muss auf einem Android-13-Emulator erfolgen: vorab Root-Rechte setzen, Originalmanager erhalten, unbenannten Manager erkennen, Root-Richtlinien lesen/schreiben, App-Upgrade und **Rollback** prüfen. Ein Emulator-Test ist in R2 noch nicht vorhanden.
- Auf dem Redmi Note 10 Pro (`sweet`), Kernel `4.14.190-perf-g7da93debc0ee`, **keine Dateien installieren oder Boot/Recovery flashen**.

## Quellhistorie

- Alte Funktion im letzten Stand: https://github.com/topjohnwu/Magisk/commit/ea16c8141eb64dc28b56a0e7fb536689ef465429
- Offizieller Stand 31.1: https://github.com/topjohnwu/Magisk/commit/0972f67d97f9b6302b67c5171283330c74114b4a
- Vollständige Rückbau-Liste: `docs/RESTORE_COMMITS.json`
- R1-Ergebnis: https://github.com/Chrizz100/Magisk-Manager-Hide-Backport/actions/runs/42472586629

*Weder die bestehende ZygiskEnv Alpha Bridge noch die VEUX-Kernel-Repo werden geändert.*
