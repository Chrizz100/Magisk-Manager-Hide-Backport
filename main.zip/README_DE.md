# R16.0 – korrigierter Android-ARM64-Paketweg

**Zielgerät:** Redmi Note 10 Pro (`sweet`), Android 13, MIUI 14, Kernelkennung `4.14.190-perf-g7da93debc0ee`.

## Was verbessert wurde

1. **Korrigierte Paketierung.** `add_executable(... OUTPUT_NAME libsweet414_preflight.so)` aus R15.9 reicht nicht aus, damit Android Gradle den Binary in eine APK aufnimmt. Der offizielle Gradle-Ablauf verpackt standardmäßig Shared Libraries; das native ausführbare ELF muss explizit in `jniLibs/arm64-v8a` kopiert werden. R16.0 liefert die dafür nötigen Staging- und ELF-Prüfskripte plus Beispiel-Workflow. Kein unverifiziertes Umbenennen einer Linux-Binärdatei in eine Android-`.so` mehr.
2. **Provenienz im Prozessprotokoll.** Der eigenständige C++-Prozess gibt künftig `archive_source`, `archive_boot_sha256` und `live_boot_match_confirmed=false` aus. Kotlin weist falschen Archiv-Hash, gefälschten Live-Boot-Abgleich und falschen Quellentyp zurück. Das ist ein Schutz gegen falsch-positive Fortschrittsmeldungen, keine Root-Funktion.
3. **Tests der Paketarchitektur.** Eine neue ELF64/AArch64/PIE-Prüfung akzeptiert nur einen ARM64-Android-Interpreter `/system/bin/linker64`. Falsche Rechnerarchitektur, Linux-Ladeprogramme, ausführbare Stacks, schreibbare ausführbare Segmente und fehlerhafte APK-ZIP-Pfade werden abgewiesen.

## Nachgewiesene und weiterhin offene Arbeit

- R15.8: 41 Python-Regressionen, 5 GCC/C++-Tests, 5 Clang/C++-Tests.
- R16.0: 10 echte Kotlin/JVM-Prozesstests mit dem Linux-C++-Programm, davon 3 neue Protokoll-Negativtests.
- R16.0: 10 neue ELF-Staging-Tests, jeweils auf synthetischen, **nicht ausführbaren** ARM64-Headern.
- Keine lokalen Android-NDK-Buildwerkzeuge verfügbar: **AArch64-Kompilation noch nicht geprüft.** Workflow als isolierter GitHub-Actions-Build vorbereitet, nicht gestartet.
- Keine Android-APK gebaut und keine Android-Geräteausführung nachgewiesen.
- Keine GhostLock-Rechteerhöhung und kein MagiskSU; `UID=0` **nicht erreicht**.
- Es wurde ausschließlich die archivierte `boot(4).img` geprüft – **keine bytegenaue Prüfung der laufenden Bootpartition**.

## Konkreter nächster Blocker

Nach einem echten Android-ARM64-Build wäre die **Android-Lauffähigkeit des nichtprivilegierten Prozesses** erst einmal nachzuweisen. Das ist weiterhin getrennt von der noch fehlenden GhostLock-4.14-Engine und ihrer Magisk-31100-Übergabe zu sehen. Keine Änderungen an Magisk R13.4, an Boot/Recovery oder an KernelSU.

**Achtung:** Kein Root-Installer, keine zur Installation freigegebene Root-APK, kein Flash-Paket. Die GitHub-YAML ist ausschließlich für eine eigenständige Entwicklungsumgebung gedacht und darf nicht als Ersatz für den bestehenden R13.4-Hide-Workflow übernommen werden.

## Schnelltest auf Linux

```bash
bash scripts/run_r160_offline.sh /pfad/SWEET_STOCK_REFERENZEN_20261107.zip
```

Für Android NDK getrennt: `bash scripts/build_r160_android_arm64.sh`.
