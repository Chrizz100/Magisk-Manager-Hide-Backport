# Porting matrix — Magisk 31.0 hidden Manager -> 31.1 (research only)

This matrix describes required migration points. It is NOT a validated patch.

| Functional block | Pre-removal code (up to `ea16c814`) | Magisk 31.1 status | Requirement to port |
|---|---|---|---|
| App repackager | `app/core/.../tasks/AppMigration.kt` | deleted | Rebuild with modern Compose API and support Android 13 package install and rollback |
| APK binary XML patcher | `app/core/.../utils/AXML.kt` | deleted | Replace/port with bounded XML transforms; maintain manifest/component correctness |
| APK signing | `app/core/.../signing/*`, `Keygen.kt` | deleted | Restore a verifiable signing pipeline; test package certificate identity |
| Stub dynamic loader | `app/stub/*`, `app/shared/.../StubApk.java` | removed/merged | Reconstruct Gradle module linkage and target-compatible class/resource loading |
| Manager preference | `Config.suManager`, `DbEntryKey::SuManager` | removed | Persist/retrieve selected manager without breaking 31.1 grant policy/HSUM |
| Native manager identification | `native/src/core/package.rs` with `repackaged_pkg` | replaced | Verify a trusted certificate and per-user UID, prevent unknown packages claiming Root manager identity |
| UI | old Hide/Restore buttons on Home | removed | Explicit user-controlled transaction with rollback; never silently uninstall main manager |
| Native stub embedding | scripts/installer, `applet_stub` and embedded APK | removed | Build and package matching stub; prove updates and restore path |
| Magisk baseline SELinux rules | `native/src/sepolicy/rules.rs` | present | **Out of scope**; manager repackaging does not fix these traces |

## Dependency graph

`Signed stub apk` -> `Native daemon validates manager identity` -> `Root grants and updates are possible` -> `Full manager UI starts` -> `Restore original package tested`.

A separate APK with a random package name is **not** sufficient, because the Magisk 31.1 native daemon uses its own manager identification and signing expectations.

## Stage gate (mandatory before a device attempt)

1. Static audit passes for both upstream revisions with SHA pinning.
2. Experimental old-code build compiles without Gradle/Rust errors (this is not proof of a successful port).
3. 31.1-based patch compiles for ARM32 and ARM64 with v31.1 dependencies.
4. Android 13 emulator confirms: manager launch, superuser policy read/write, installation, restart and switching to the original manager.
5. Signatures and package IDs verified after upgrade; no reused untrusted certs or world-writable manager state.
6. No boot image is changed by the install/restore feature itself.
7. Actual Magisk **Alpha** compatibility confirmed separately; upstream official binary equivalence must not be assumed.
8. Documented rollback from a second working root shell and recovery mechanism before any physical test.

## Relevant source commits

- UI deletion: https://github.com/topjohnwu/Magisk/commit/58477458401a298c02604b99caf5afcdb9ed9e3f
- Repack/signing deletion: https://github.com/topjohnwu/Magisk/commit/1240c2e35ca3f232d7a125238a33e634e9ab3231
- Stub loader deletion: https://github.com/topjohnwu/Magisk/commit/7d9b0dfb3e58ab0959021533e0d19ba362b766a7
- Manager native validation deletion: https://github.com/topjohnwu/Magisk/commit/5f2faee61879859004acb34811051f45d51a5191
- Native stub embedding deletion: https://github.com/topjohnwu/Magisk/commit/c86a8776cee88689dd684ec1dd7d584d77540110
- Stub Gradle removal: https://github.com/topjohnwu/Magisk/commit/d22fea290654dcf7bad9128f79834535ee3f47c3
- Shared-module removal: https://github.com/topjohnwu/Magisk/commit/e31ef291d401faa21c20fb791c38f1e60bedfa2e
