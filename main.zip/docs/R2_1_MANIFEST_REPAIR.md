# R2.1: reviewed shared-manifest conflict fix

## Evidence from R2 run 42475432778

- First reverse-revert, `e31ef291d401faa21c20fb791c38f1e60bedfa2e`, failed.
- Sole conflict: `app/core/src/main/AndroidManifest.xml`.
- The reverted upstream change had merged `:shared` manifest entries into `:core`.
- Between that change and official v31.1, this file only changed one
  `android:enableOnBackInvokedCallback` value from `false` to `true`.

## Explicit conflict resolution

`tools/reconstruct.py` checks the complete manifest content at three pinned
Git revisions and checks that the restored `:shared` manifest is byte-for-byte
identical to the original before applying a change. When and only when the
observed conflict is the single `:core` manifest, it reverts the merged core
manifest to its original `:core` version and carries the current
`enableOnBackInvokedCallback=true` flag into the restored `:shared` manifest.

It calls `git revert --continue` to complete the commit. Any deviation from
those constraints fails closed with an evidence report; no use of
`git checkout --ours`, `-X theirs`, or conflict-marker deletion.

## Scope

This fixes one known merge conflict but does not establish that all subsequent
historical reverts will apply, let alone that Magisk 31.1 builds or that a
repackaged manager can administer the installed Magisk Alpha 31100 daemon.

The build remains strictly gated behind clean restoration; emulator and device
integration testing have not been performed. **Do not install or flash.**
