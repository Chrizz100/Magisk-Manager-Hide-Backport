# R2.2 Native integration review

## Evidence

Magisk-Manager-Hide-Backport run `42476412723`, failed Job `128718696777`, generated `R2_1_RECONSTRUCTION_AND_BUILD_REPORT`.

- `e31ef291d401` reverse-reverted after the reviewed Android manifest fix.
- `d22fea290654` reverse-reverted cleanly.
- `c86a8776cee8` failed with conflicts in `native/src/core/package.rs` and `native/src/core/su/daemon.rs`.

Original removal diff: `https://github.com/topjohnwu/Magisk/commit/c86a8776cee88689dd684ec1dd7d584d77540110`

## Controlled resolution

On **exact** official base `0972f67d97f9b6302b67c5171283330c74114b4a` and **exact** removal commit `c86a8776...`, require the unmerged paths to match the two observed native Rust files. Require the historic stub methods and `get_manager_uid`, plus the newer `get_app_id`/HSUM implementation. Verify `su/daemon.rs` is byte-identical to official Magisk 31.1 before the conflict and has `settings.log = false;` and `settings.notify = false;` for missing manager.

Restore historical `package.rs` Git stage-3 content and retain the distinct, newer `get_app_id(&self,pkg)` method from the stage-2 source; retain stage-2 `su/daemon.rs` authorization implementation. The subsequent revert of `5f2faee6` must restore the package-aware `get_package_uid(user,pkg)` interface for this combination to compile. Source-level probes then require all old manager components and the new HSUM/app-ID and SU guards. If any condition fails, stop; do not downgrade the test or silently take one side of another conflict.

## Limitations and prerequisites

This is a controlled research merge, **not a validated patch**. Git text merges and isolated unit tests do not prove Rust API compatibility, correct APKSig trust chain, running root policies, or safe manager upgrades. The GitHub workflow must produce clean source checks, compile ARM32+ARM64, and test on an Android 13 emulator before installing on a phone. Do not install research APKs or flash images. This operation does not change Magisk's SELinux footprint and may not solve any banking-app detection.
