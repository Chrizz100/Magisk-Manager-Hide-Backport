# R2 implementation: what this actually tests

## Mechanism

The official Magisk 31.1 commit (`0972f67d…`) follows multiple upstream removals of app repackaging and its native trust chain. R2 does not attempt to paste a v30 APK into a v31.1 installation. `tools/reconstruct.py` uses Git **revert** in the opposite chronological order from the removal commits. This changes the actual 31.1 source checkout and produces an auditable patch when Git succeeds.

| Priority | Source component | Required outcome |
|---|---|---|
| 1 | Kotlin AppMigration | Patches binary manifest, changes package ID, signs a stub APK |
| 2 | Stub app + shared module | Can start the full manager under new package ID |
| 3 | Magisk native `get_manager_uid` | Recognizes a valid signed repackaged manager and tracks its UID |
| 4 | Gradle config | Re-adds shared/stub projects and dependencies |
| 5 | UI + state | Provides user-controlled Hide/Restore and preserves rollback |
| 6 | Compiler | ARM64/ARM32 Android components build without incompatibilities |

## Stage gate

- `CANDIDATE_RESTORED` means **only source revert and textual checks passed**. No APK implication.
- `FAILED_CONFLICT` means a genuine source-level merge conflict; report lists exact filenames. No fallback to `-X theirs`, force-pushing or automatic deletion.
- `FAILED_PROBES` means the expected components still cannot be identified after reverts.
- A successful Gradle/Rust compilation is **not** a safe deployment decision. R2 has no Android 13 emulator test. The portable alpha fork remains unverified.

## Expected next work after run

Review `R2_RECONSTRUCTION_AND_BUILD_REPORT` and manually reconcile any conflicts against the actual v31.1 interfaces. Resolve 31.1/Alpha signature handling, app multiuser support, special UID policy path, upgrade handling. Set up an Android 13 emulator with test users for hide/restore, su policy, module discovery and reboot. Do not modify Magisk's SELinux behavior merely to silence heuristics without proving necessity.
