# Android-Paketierung: bewusst keine Root-APK

Der native R15.9-Prototyp verwendete in `CMakeLists.txt` `add_executable()` und benannte die Ausgabedatei wie eine `.so`-Datei. **Ein CMake-Executable wird von Android Gradle nicht automatisch als JNI-Library in eine APK aufgenommen.** Damit wäre unter Android `ProcessBuilder()` mit `applicationInfo.nativeLibraryDir/libsweet414_preflight.so` häufig ins Leere gelaufen.

R16.0 schließt die Paketlücke durch einen *separaten* NDK-Build und explizites Staging. Der Android-ARM64-Build wird zuerst als native PIE-Datei kompiliert, gegen den Android-Linker `/system/bin/linker64` und die Architektur AArch64 geprüft und dann unter `lib/arm64-v8a/libsweet414_preflight.so` bereitgestellt. Ein Android-Projekt muss dieses Verzeichnis ausdrücklich als JNI-Library-Input deklarieren und `jniLibs.useLegacyPackaging = true` setzen, damit die native Datei extrahiert wird und ein tatsächlicher Dateipfad für `ProcessBuilder` existiert.

**Wichtig:** Diese Datei ist ein nicht privilegierter Archivprüfer und kein GhostLock-Binary, keine Magisk-Erstinstallation und kein Root-Einstieg. R13.4 nicht überschreiben. Nur als separate Entwicklungskomponente verwenden.

## Optionale Integration in einen späteren Android-App-Build

Die in `stage-android-native.gradle.kts.txt` dokumentierte Kopieraufgabe ist ein *Entwurf für ein separates Test-/Entwicklungsprojekt* – keine Änderung an deinem bestehenden Magisk-Repository. Die Gradle-Aufgabe muss vor `mergeDebugJniLibFolders` bzw. `mergeReleaseJniLibFolders` abgeschlossen sein. Unabhängig davon sollte das fertig erzeugte APK mit `python3 scripts/r160_check_android_elf.py --apk <pfad>` kontrolliert werden.

Die SHA-256 des **unveränderten archivierten** `boot(4).img` ist `4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015`. Das laufende `boot` wurde weiterhin nicht bytegleich nachgewiesen.

## Nachweise und Grenzen

- Quelle der Paketregeln: https://developer.android.com/studio/projects/gradle-external-native-builds
- Quelle zum Lib-Verzeichnis: https://developer.android.com/ndk/guides/abis
- Quelle zur Original-GhostLock-Paketierung: https://github.com/YuKongA/ghostlock-app/blob/main/build.gradle.kts (`prepareGhostlockJniLibs`)

R16.0 wurde hostseitig auf Linux/JVM geprüft. **Ohne das Android NDK kann lokal keine valide AArch64-Android-Datei gebaut werden.** Das mitgelieferte GitHub-Workflow-Beispiel ermöglicht einen NDK-Build in einem *separaten* Entwicklungsrepository ohne PC, aber es wurde hier noch nicht über GitHub Actions gestartet. Keine Root-Versuche/Flashbefehle enthalten.
