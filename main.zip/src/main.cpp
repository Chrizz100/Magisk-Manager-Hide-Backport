#include "sweet414_port.hpp"
#include "legacy_414_route.hpp"
#include "r158_archive_snapshot.hpp"
#include <iostream>
#include <string>

int main(int argc, char** argv) {
    if (argc != 2) {
        std::cerr << "Use: sweet414-port --preflight | --archive-audit\n";
        return 64;
    }
    if (std::string(argv[1]) == "--archive-audit") {
        const auto report = sweet414::assess_legacy_route(
            sweet414::archive_snapshot::legacy_route_evidence());
        std::cout << "archive_4_14_route=" << sweet414::legacy_route_verdict(report.verdict) << "\n"
                  << "legacy_symbol_names_identified=" << (report.legacy_symbol_aliases_resolved ? "true" : "false") << "\n"
                  << "archived_futex_path_observed=" << (report.archived_futex_path_observed ? "true" : "false") << "\n"
                  "archive_source=SHA256_PINNED_STOCK_BOOT_SNAPSHOT\n"
                  "archive_boot_sha256=4123ddc071662ed266c871ef45a93f637b3f1ae1c9775cfcabf13793b5040015\n"
                  "live_boot_match_confirmed=false\n"
                  << "root_backend_available=false\nroot_confirmed=false\n";
        return 0;
    }
    if (std::string(argv[1]) != "--preflight") {
        std::cerr << "Unknown argument\n";
        return 64;
    }
    const auto facts = sweet414::read_local_facts();
    const auto result = sweet414::evaluate(facts);
    std::cout << "kernel=" << facts.kernel_release << "\n"
              << "device=" << facts.codename << "\n"
              << "android=" << facts.android_release << "\n"
              << "miui=" << facts.miui_incremental << "\n"
              << "verdict=" << sweet414::verdict_string(result.verdict) << "\n"
              << "root_backend_available=false\nroot_confirmed=false\n";
    for (auto& reason: result.reasons) std::cout << "reason=" << reason << '\n';
    return static_cast<int>(result.verdict);
}
