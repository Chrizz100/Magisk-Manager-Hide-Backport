import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from audit import FEATURE_PROBES, run_audit, render_markdown
from verify_build import verify


class TestSourceAudit(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        base = Path(self.tmp.name)
        self.pre, self.final = base / 'pre', base / 'final'
        for name, (rel, needles) in FEATURE_PROBES.items():
            dest = self.pre / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text('\n'.join(needles), encoding='utf-8')
        newpkg = self.final / 'native/src/core/package.rs'
        newpkg.parent.mkdir(parents=True, exist_ok=True)
        newpkg.write_text('pub fn get_manager_uid(&self, user: i32) -> i32 { 0 }', encoding='utf-8')

    def test_expected_split(self):
        results = run_audit(self.pre, self.final, verify_sha=False)
        self.assertTrue(results['all_passed'], results['passes'])
        self.assertIn('PASS', render_markdown(results))

    def test_missing_old_signer_fails(self):
        (self.pre / FEATURE_PROBES['signer'][0]).unlink()
        result = run_audit(self.pre, self.final, verify_sha=False)
        self.assertFalse(result['all_passed'])
        self.assertFalse(result['passes']['pre_removal_feature_complete'])

    def test_remaining_repackager_in_new_fails(self):
        dest = self.final / FEATURE_PROBES['app_repackager'][0]
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text('class Experimental', encoding='utf-8')
        self.assertFalse(run_audit(self.pre, self.final, False)['passes']['final_no_app_repackager'])

    def test_wrong_base_rejected(self):
        data = run_audit(self.pre, self.final, verify_sha=True)
        self.assertFalse(data['all_passed'])
        self.assertFalse(data['passes']['pre_ref_exact'])

    def test_no_candidate_apk(self):
        self.assertFalse(verify(self.pre / 'missing.apk')['passed'])


if __name__ == '__main__':
    unittest.main()
