"""R2.1 tests for a single deliberately reviewed manifest conflict."""
import importlib.util
import tempfile
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('reconstruct', ROOT / 'tools' / 'reconstruct.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def run(root, *args, check=True):
    p = subprocess.run(['git', '-C', str(root), *args], capture_output=True, text=True)
    if check and p.returncode:
        raise AssertionError(str(args) + p.stderr + p.stdout)
    return p


class ReviewedManifestConflict(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.repo = Path(self.tmp.name)
        run(self.repo, 'init', '-q')
        run(self.repo, 'config', 'user.name', 'Test')
        run(self.repo, 'config', 'user.email', 'test@example.invalid')
        self.core = self.repo / 'app/core/src/main/AndroidManifest.xml'
        self.shared = self.repo / 'app/shared/src/main/AndroidManifest.xml'
        self.core.parent.mkdir(parents=True)
        self.shared.parent.mkdir(parents=True)
        self.before_core = '<manifest><application android:name=".App" />\n</manifest>\n'
        self.before_shared = ('<manifest><application android:enableOnBackInvokedCallback="false" '
                              'android:theme="Theme" /></manifest>\n')
        self.core.write_text(self.before_core)
        self.shared.write_text(self.before_shared)
        run(self.repo, 'add', '.')
        run(self.repo, 'commit', '-qm', 'Before shared merge')
        self.core.write_text('<manifest><application android:name=".App" android:enableOnBackInvokedCallback="false" />\n</manifest>\n')
        self.shared.unlink()
        run(self.repo, 'add', '-A')
        run(self.repo, 'commit', '-qm', 'Merge shared into core')
        self.removal = run(self.repo,'rev-parse','HEAD').stdout.strip()
        self.core.write_text(self.core.read_text().replace('Callback="false"','Callback="true"'))
        run(self.repo, 'add', '.')
        run(self.repo, 'commit', '-qm', 'Keep modern callback behaviour')
        self.base = run(self.repo,'rev-parse','HEAD').stdout.strip()

    def test_known_conflict_resolved_and_preserves_new_callback(self):
        proc = run(self.repo, 'revert', '--no-edit', self.removal, check=False)
        self.assertNotEqual(proc.returncode, 0, 'Synthetic manifest conflict failed to occur')
        result = mod.resolve_shared_manifest_conflict(self.repo, self.removal, self.base)
        self.assertTrue(result['fixed'], result)
        self.assertEqual(self.core.read_text(),self.before_core)
        self.assertEqual(self.shared.read_text(),self.before_shared.replace('Callback="false"','Callback="true"'))
        self.assertEqual(run(self.repo,'status','--porcelain').stdout.strip(), '')

    def test_unreviewed_extra_change_rejected(self):
        self.core.write_text(self.core.read_text().replace('android:name=".App"','android:name=".Changed"'))
        run(self.repo, 'add', '.')
        run(self.repo, 'commit', '-qm', 'Other unreviewed manifest edit')
        base = run(self.repo,'rev-parse','HEAD').stdout.strip()
        proc = run(self.repo, 'revert', '--no-edit', self.removal, check=False)
        self.assertNotEqual(proc.returncode, 0)
        result = mod.resolve_shared_manifest_conflict(self.repo, self.removal, base)
        self.assertFalse(result['fixed'])
        self.assertIn('beyond the one reviewed callback flag',result['reason'])
        self.assertFalse(self.shared.exists() is False)


if __name__ == '__main__':
    unittest.main()
