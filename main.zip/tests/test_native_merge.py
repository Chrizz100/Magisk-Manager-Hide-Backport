"""Synthetic-git tests for the exact known R2.1 native merge conflict.

These do NOT prove the real Magisk source can be compiled.
"""
import importlib.util
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

FILE = Path(__file__).resolve().parents[1] / 'tools' / 'reconstruct.py'
spec = importlib.util.spec_from_file_location('reconstruct', FILE)
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


def run(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], text=True, capture_output=True)


PKG_OLD = '''// old native stub module
impl MagiskD {
    stub_apk_fd
    fn install_stub(&mut self) {}
    pub fn preserve_stub_apk(&self) {}
    pub fn ensure_manager(&self) {}
    pub fn get_manager_uid(&self, user: i32) -> i32 { user }
    fn get_users(&self) {
        if self.is_headless && user == 0 {}
    }
}
'''
PKG_NEW = '''// modern core
impl MagiskD {
    pub fn get_manager_uid(&self, user: i32) -> i32 { user }
    fn get_users(&self) { if self.is_headless && user == 0 {} }
}
'''
GET_APP = '''    pub fn get_app_id(&self, pkg: &str) -> i32 {
        for user in self.get_users() {
            let uid = get_package_uid(user, pkg);
            if uid >= 0 {
                return to_app_id(uid);
            }
        }
        0
    }
'''
SU_OLD = '''fn get_su_info(&self) {
    let manager = self.get_manager(0, true);
}
'''
SU_NEW = '''fn get_su_info(&self) {
    let manager = self.get_manager_uid(0);
}
'''
SU_FINAL = '''fn get_su_info(&self) {
    let mgr_uid = self.get_manager_uid(0);
    if mgr_uid < 0 {
        settings.log = false;
        settings.notify = false;
    }
}
'''


class NativeMergeFixture(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.repo = Path(self.tmp.name)
        run(self.repo, 'init', '-q')
        run(self.repo, 'config', 'user.name', 'Test')
        run(self.repo, 'config', 'user.email', 'test@example.invalid')
        self.pkg = self.repo / 'native/src/core/package.rs'
        self.su = self.repo / 'native/src/core/su/daemon.rs'
        self.pkg.parent.mkdir(parents=True)
        self.su.parent.mkdir(parents=True)
        self.pkg.write_text(PKG_OLD)
        self.su.write_text(SU_OLD)
        run(self.repo, 'add', '.')
        run(self.repo, 'commit', '-qm', 'old stub version')
        self.old = run(self.repo, 'rev-parse', 'HEAD').stdout.strip()
        self.pkg.write_text(PKG_NEW)
        self.su.write_text(SU_NEW)
        run(self.repo, 'add', '.')
        run(self.repo, 'commit', '-qm', 'Remove stub support')
        self.removal = run(self.repo, 'rev-parse', 'HEAD').stdout.strip()
        self.pkg.write_text(PKG_NEW.replace('\n}', '\n' + GET_APP + '}'))
        self.su.write_text(SU_FINAL)
        run(self.repo, 'add', '.')
        run(self.repo, 'commit', '-qm', 'modern app id and SU behavior')
        self.base = run(self.repo, 'rev-parse', 'HEAD').stdout.strip()
        self.assertNotEqual(run(self.repo, 'revert', '--no-edit', self.removal).returncode, 0)

    def wrapped_git(self, repo, *args):
        if args[:1] == ('show',) and len(args) == 2:
            requested = args[1]
            if requested.startswith(mod.BASE_SHA + ':'):
                args = ('show', self.base + requested[len(mod.BASE_SHA):])
            elif requested.startswith(mod.COMMIT_MAP[5][0] + '^:'):
                args = ('show', self.old + requested[len(mod.COMMIT_MAP[5][0] + '^'):])
        return self.real_git(repo, *args)

    def test_preserve_modern_su_and_restore_old_stub_and_new_app_id(self):
        self.real_git = mod.git
        with patch.object(mod, 'git', side_effect=self.wrapped_git):
            result = mod.resolve_native_stub_embedding_conflict(self.repo, mod.COMMIT_MAP[5][0], mod.BASE_SHA)
        self.assertTrue(result['fixed'], result)
        self.assertIn('preserve_stub_apk', self.pkg.read_text())
        self.assertIn(GET_APP.strip(), self.pkg.read_text())
        self.assertEqual(self.su.read_text(), SU_FINAL)
        self.assertEqual(run(self.repo,'status','--porcelain').stdout.strip(), '')

    def test_reject_if_unreviewed_su_policy_drift(self):
        self.real_git = mod.git
        # The current SU source must preserve an explicit missing-manager guard.
        saved = self.su.read_text()
        self.su.write_text(saved.replace('settings.notify = false;', 'settings.notify = true;'))
        run(self.repo, 'add', 'native/src/core/su/daemon.rs')
        # Staging a changed conflict does not change the stage-2 source, so the
        # resolver must not accept a different base source injected via git API.
        def bad_git(repo, *args):
            r = self.wrapped_git(repo, *args)
            if args[:1] == ('show',) and len(args) == 2 and args[1].startswith(mod.BASE_SHA + ':native/src/core/su/daemon.rs'):
                return subprocess.CompletedProcess(args, 0, r.stdout.replace('settings.notify = false;', 'settings.notify = true;'), '')
            return r
        with patch.object(mod, 'git', side_effect=bad_git):
            result = mod.resolve_native_stub_embedding_conflict(self.repo, mod.COMMIT_MAP[5][0], mod.BASE_SHA)
        self.assertFalse(result['fixed'])

    def test_reject_unsupported_revision(self):
        result = mod.resolve_native_stub_embedding_conflict(self.repo, '0'*40, mod.BASE_SHA)
        self.assertFalse(result['fixed'])


class BracedMethodTests(unittest.TestCase):
    def test_extract_method(self):
        self.assertEqual(mod.extract_braced_method(PKG_NEW + GET_APP, 'pub fn get_app_id(&self, pkg: &str) -> i32'), GET_APP.rstrip('\n'))

    def test_missing_or_duplicate_rejected(self):
        self.assertIsNone(mod.extract_braced_method(PKG_NEW, 'pub fn get_app_id(&self, pkg: &str) -> i32'))
        self.assertIsNone(mod.extract_braced_method(GET_APP*2, 'pub fn get_app_id(&self, pkg: &str) -> i32'))


if __name__ == '__main__':
    unittest.main()
