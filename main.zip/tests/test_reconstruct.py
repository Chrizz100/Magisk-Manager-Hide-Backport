"""Offline synthetic-Git integration tests for R2 revert gate."""
from __future__ import annotations
import importlib.util
import subprocess
import tempfile
import unittest
from pathlib import Path

FILE = Path(__file__).resolve().parents[1] / 'tools' / 'reconstruct.py'
spec = importlib.util.spec_from_file_location('reconstruct', FILE)
reconstruct = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reconstruct)


def git(repo: Path, *args: str) -> str:
    proc = subprocess.run(['git', '-C', str(repo), *args], capture_output=True, text=True)
    if proc.returncode:
        raise RuntimeError(f"git {args}: {proc.stderr}")
    return proc.stdout.strip()


class RestoreFixture(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / 'repo'
        self.path.mkdir()
        git(self.path, 'init', '-q')
        git(self.path, 'config', 'user.name', 'R2 unit tests')
        git(self.path, 'config', 'user.email', 'test@example.invalid')
        (self.path / 'README.md').write_text('Original\n')
        git(self.path, 'add', '.')
        git(self.path, 'commit', '-qm', 'Initial')
        self.removed_file = self.path / 'AppMigration.kt'
        self.removed_file.write_text('feature=hidden\n')
        git(self.path, 'add', '.')
        git(self.path, 'commit', '-qm', 'Add hiding feature')
        self.removed_file.unlink()
        git(self.path, 'add', '.')
        git(self.path, 'commit', '-qm', 'Remove manager hiding')
        self.removal_sha = git(self.path, 'rev-parse', 'HEAD')
        (self.path / 'NEW.md').write_text('Unrelated newer improvement\n')
        git(self.path, 'add', '.')
        git(self.path, 'commit', '-qm', 'Add newer unrelated behavior')
        self.base_sha = git(self.path, 'rev-parse', 'HEAD')
        self.reports = Path(self.temp.name) / 'reports'

    def test_one_revert_restores_old_file_and_retains_new_feature(self):
        result = reconstruct.perform(self.path, self.reports, base=self.base_sha,
                                     plan=((self.removal_sha, 'unit test removal'),), verify_probes=False)
        self.assertEqual(result['status'], 'CANDIDATE_RESTORED')
        self.assertTrue(self.removed_file.exists())
        self.assertTrue((self.path / 'NEW.md').exists())
        self.assertEqual(len(result['steps']), 1)
        self.assertTrue((self.reports / 'R2_2_REVERT_CANDIDATE.patch').is_file())
        self.assertFalse(result['flash_allowed'])

    def test_wrong_base_rejected_without_mutation(self):
        bad_base = 'a' * 40
        before = git(self.path, 'rev-parse', 'HEAD')
        result = reconstruct.perform(self.path, self.reports, base=bad_base,
                                     plan=((self.removal_sha,'unit'),),verify_probes=False)
        self.assertEqual(result['status'], 'FAILED_PREFLIGHT')
        self.assertEqual(git(self.path, 'rev-parse', 'HEAD'), before)

    def test_dirty_repo_rejected(self):
        (self.path / 'README.md').write_text('uncommitted change')
        result = reconstruct.perform(self.path,self.reports,base=self.base_sha,
                                     plan=((self.removal_sha,'unit'),),verify_probes=False)
        self.assertEqual(result['status'], 'FAILED_PREFLIGHT')
        self.assertFalse(self.removed_file.exists())

    def test_nonexistent_revert_commit_rejected(self):
        result = reconstruct.perform(self.path,self.reports,base=self.base_sha,
                                     plan=(('f'*40,'nonexistent'),),verify_probes=False)
        self.assertEqual(result['status'],'FAILED_PREFLIGHT')

    def test_nongit_directory_rejected(self):
        p=Path(self.temp.name)/'empty'
        p.mkdir()
        result=reconstruct.perform(p,self.reports,base=self.base_sha,plan=(),verify_probes=False)
        self.assertEqual(result['status'],'FAILED_PREFLIGHT')

    def test_missing_markers_fail_closed(self):
        result=reconstruct.perform(self.path,self.reports,base=self.base_sha,
                                   plan=((self.removal_sha,'unit'),),verify_probes=True)
        self.assertEqual(result['status'],'FAILED_PROBES')
        self.assertFalse(all(p['pass'] for p in result['probes'].values()))

    def test_conflicting_readd_detected(self):
        # Simulates new upstream code reintroducing a different file at a former path.
        self.removed_file.write_text('feature=changed-by-upstream\n')
        git(self.path,'add','.')
        git(self.path,'commit','-qm','Reintroduced changed file')
        sha=git(self.path,'rev-parse','HEAD')
        result=reconstruct.perform(self.path,self.reports,base=sha,
                                   plan=((self.removal_sha,'unit'),),verify_probes=False)
        self.assertEqual(result['status'],'FAILED_CONFLICT')
        self.assertTrue(result['conflicts'])
        self.assertTrue((self.reports/'failure.txt').exists())

    def test_fixed_commit_sequence_is_reverse(self):
        a=reconstruct.COMMIT_MAP
        self.assertEqual(len(a),8)
        self.assertEqual(tuple(reversed(a))[0][0], 'e31ef291d401faa21c20fb791c38f1e60bedfa2e')
        self.assertEqual(tuple(reversed(a))[-1][0], '58477458401a298c02604b99caf5afcdb9ed9e3f')
        self.assertEqual(len({x[0] for x in a}), 8)


if __name__ == '__main__':
    unittest.main()
