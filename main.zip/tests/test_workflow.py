"""Offline checks for the R2 CI workflow safety and dependency ordering."""
from pathlib import Path
import importlib.util
import unittest

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('validate_workflow',ROOT/'tools'/'validate_workflow.py')
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
WORKFLOW=(ROOT/'.github/workflows/build.yml').read_text(encoding='utf-8')

class TestWorkflow(unittest.TestCase):
    def test_r2_workflow(self):
        self.assertEqual(module.validate(WORKFLOW),[])
    def test_missing_pins(self):
        change=WORKFLOW.replace('0972f67d97f9b6302b67c5171283330c74114b4a','latest')
        self.assertTrue(module.validate(change))
    def test_flashing_forbidden(self):
        change=WORKFLOW.replace('name: Magisk Manager-Hide R2.1 - Reviewed Manifest Repair',
                    'name: Magisk Manager-Hide R2.1 - Reviewed Manifest Repair\n# fastboot flash boot boot.img')
        self.assertTrue(module.validate(change))
    def test_build_gate_required(self):
        self.assertTrue(module.validate(WORKFLOW.replace('if: always()', 'if: success()')))
    def test_real_compiler_is_in_workflow(self):
        self.assertIn('python3 build.py -vr -c ../kit/config/sweet.prop all',WORKFLOW)
        self.assertIn('python3 kit/tools/reconstruct.py', WORKFLOW)
    def test_one_archive_two_files(self):
        self.assertIn('main.zip', WORKFLOW)
        self.assertIn('cmp .github/workflows/build.yml kit/.github/workflows/build.yml',WORKFLOW)

if __name__=='__main__':
    unittest.main()
