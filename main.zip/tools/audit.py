#!/usr/bin/env python3
"""Read-only, pinned-source feasibility audit for the Magisk manager-hide backport.

This tool does not change system files, APKs, Android policies, or a GitHub repository.
"""
from __future__ import annotations
import argparse
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

PRE_REF = 'ea16c8141eb64dc28b56a0e7fb536689ef465429'
FINAL_REF = '0972f67d97f9b6302b67c5171283330c74114b4a'

# Required affirmative and negative checks: don't infer the feature from just a UI string.
FEATURE_PROBES = {
    'app_repackager': ('app/core/src/main/java/com/topjohnwu/magisk/core/tasks/AppMigration.kt',
                       ('suspend fun patchAndHide(', 'suspend fun restoreApp(', 'SignApk.sign(')),
    'stub_loader': ('app/shared/src/main/java/com/topjohnwu/magisk/StubApk.java',
                    ('class StubApk', 'current.apk')),
    'stub_application': ('app/stub/src/main/java/com/topjohnwu/magisk/StubApplication.java',
                         ('class StubApplication',)),
    'manager_db': ('app/core/src/main/java/com/topjohnwu/magisk/core/Config.kt',
                   ('var suManager',)),
    'native_manager': ('native/src/core/package.rs',
                       ('repackaged_pkg', 'get_manager_uid', 'SuManager')),
    'signer': ('app/core/src/main/java/com/topjohnwu/magisk/core/signing/SignApk.java',
               ('class SignApk',)),
}


def source_probes(root: Path) -> dict[str, dict]:
    found = {}
    for label, (path, needles) in FEATURE_PROBES.items():
        source = root / path
        content = source.read_text(encoding='utf-8') if source.is_file() else ''
        found[label] = {
            'path': path,
            'file_exists': source.is_file(),
            'markers': {needle: (needle in content) for needle in needles},
            'complete': source.is_file() and all(needle in content for needle in needles),
        }
    return found


def get_sha(root: Path) -> str:
    try:
        return subprocess.check_output(
            ['git', '-C', str(root), 'rev-parse', 'HEAD'],
            text=True, stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        return ''


def run_audit(pre: Path, final: Path, verify_sha: bool = True) -> dict:
    before = source_probes(pre)
    after = source_probes(final)
    passes = {
        'pre_removal_feature_complete': all(x['complete'] for x in before.values()),
        'final_no_app_repackager': not after['app_repackager']['file_exists'],
        'final_no_stub_application': not after['stub_application']['file_exists'],
        'final_no_stub_loader': not after['stub_loader']['file_exists'],
        'final_no_separate_signer': not after['signer']['file_exists'],
        'final_native_no_repackaged_pkg': not after['native_manager']['markers']['repackaged_pkg'],
        'final_manager_still_present': (final / 'native/src/core/package.rs').is_file(),
    }
    sha_pre, sha_final = get_sha(pre), get_sha(final)
    if verify_sha:
        passes['pre_ref_exact'] = sha_pre == PRE_REF
        passes['final_ref_exact'] = sha_final == FINAL_REF
    return {
        'expected_refs': {'pre_removal': PRE_REF, 'release_31_1': FINAL_REF},
        'actual_refs': {'pre_removal': sha_pre or 'not a git checkout',
                        'release_31_1': sha_final or 'not a git checkout'},
        'probes': {'pre_removal': before, 'release_31_1': after},
        'passes': passes,
        'all_passed': all(passes.values()),
        'scope': 'Source-level comparison; no compilation or device testing performed.',
        'limitations': [
            'Pre-removal snapshot has versionCode 31000 and is NOT released Magisk Alpha 31100.',
            'The Alpha-specific modified build is not fully reconstructible from its public release tag.',
            'Repackaging a manager does not remove Magisk SELinux policy or guarantee banking-app acceptance.',
            'The 31.1 Magisk daemon rejects legacy repackaged manager identification; full port required.',
        ],
    }


def render_markdown(result: dict) -> str:
    p = result['passes']
    lines = ['# Magisk Manager-Hide Backport — read-only source audit', '',
             f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}", '',
             '| Check | Result |', '|---|---|']
    for name, ok in p.items():
        lines.append(f'| `{name}` | {"PASS" if ok else "FAIL"} |')
    lines += ['', f"**Overall: {'PASS' if result['all_passed'] else 'FAIL'}**", '',
              '## Exact upstream commits',
              f"- Historical pre-removal commit: `{PRE_REF}` (2026-10-22).",
              f"- Official Magisk 31.1: `{FINAL_REF}` (2026-10-25).", '',
              '## Interpretation',
              'Magisk app-hide depended on the app-side repackager, a signing pipeline, a stub '
              'APK and native daemon tracking. Restoring only the Settings button or the APK '
              'package name cannot re-enable the complete mechanism.', '',
              '## Limits / safety']
    lines.extend(f'- {line}' for line in result['limitations'])
    lines += ['', '**Do not install the build outputs on a physical phone until native integration, '
              'signature handling, rollback and Android 13 emulator tests are completed.**', '']
    return '\n'.join(lines)


def main() -> int:
    a = argparse.ArgumentParser(description=__doc__)
    a.add_argument('--pre', type=Path, required=True)
    a.add_argument('--final', type=Path, required=True)
    a.add_argument('--output', type=Path, default=Path('reports/audit.json'))
    a.add_argument('--skip-sha-check', action='store_true',
                   help='For local fixture tests only (never use for release CI).')
    args = a.parse_args()
    result = run_audit(args.pre, args.final, verify_sha=not args.skip_sha_check)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    md = args.output.with_suffix('.md')
    md.write_text(render_markdown(result), encoding='utf-8')
    print(render_markdown(result))
    return 0 if result['all_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
