#!/usr/bin/env python3
"""R2 experimental restoration of old Magisk Manager repackaging on official 31.1.

Operates only on a disposable local Git checkout. Conflicts fail closed; do NOT
make guesses about Android/Gradle/Rust merge resolutions. Never flashes a device.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

BASE_SHA = '0972f67d97f9b6302b67c5171283330c74114b4a'
PRE_SHA = 'ea16c8141eb64dc28b56a0e7fb536689ef465429'
COMMIT_MAP = [
    ('58477458401a298c02604b99caf5afcdb9ed9e3f', 'App hide UI'),
    ('1240c2e35ca3f232d7a125238a33e634e9ab3231', 'App migration and signer'),
    ('7d9b0dfb3e58ab0959021533e0d19ba362b766a7', 'Dynamic stub loader'),
    ('5f2faee61879859004acb34811051f45d51a5191', 'Native manager verification'),
    ('447a8f9965198f32a125b6c2c33644ca9604976e', 'Shared manifest layout'),
    ('c86a8776cee88689dd684ec1dd7d584d77540110', 'Native stub embedding'),
    ('d22fea290654dcf7bad9128f79834535ee3f47c3', 'Gradle stub module'),
    ('e31ef291d401faa21c20fb791c38f1e60bedfa2e', 'Shared-module dependency'),
]

RESTORE_MARKERS = {
    'app_repackager': ('app/core/src/main/java/com/topjohnwu/magisk/core/tasks/AppMigration.kt',
                       ('patchAndHide(', 'restoreApp(', 'SignApk.sign(')),
    'stub_loader': ('app/shared/src/main/java/com/topjohnwu/magisk/StubApk.java', ('class StubApk',)),
    'stub_app': ('app/stub/src/main/java/com/topjohnwu/magisk/StubApplication.java', ('class StubApplication',)),
    'apk_signer': ('app/core/src/main/java/com/topjohnwu/magisk/core/signing/SignApk.java', ('class SignApk',)),
    'native_trust': ('native/src/core/package.rs', ('repackaged_pkg', 'get_manager_uid', 'trusted_cert')),
    'module_config': ('app/settings.gradle.kts', ('":stub"', '":shared"')),
    'native_version': ('app/gradle.properties', ('magisk.versionCode=31100',)),
}


def git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(['git', '-C', str(repo), *args], text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)


def probe_tree(repo: Path) -> dict:
    result = {}
    for label, (file, needles) in RESTORE_MARKERS.items():
        p = repo / file
        raw = p.read_text(encoding='utf-8') if p.is_file() else ''
        result[label] = {'file': file, 'exists': p.is_file(),
                         'markers': {needle: needle in raw for needle in needles},
                         'pass': p.is_file() and all(needle in raw for needle in needles)}
    return result


def report_md(report: dict) -> str:
    status = report['status']
    rows = ['# Magisk Manager Hide Backport R2 — Integration', '',
            f"**Status: {status}**", '',
            f"Base: `{report['expected_base']}`", '',
            '| Reverted removal commit | Result |', '|---|---|']
    for step in report['steps']:
        rows.append(f"| `{step['sha'][:12]}` – {step['description']} | {step['result']} |")
    if report.get('conflicts'):
        rows += ['', '## Git merge conflicts', '']
        rows.extend('- `'+p+'`' for p in report['conflicts'])
    if report.get('probes'):
        rows += ['', '## Source restoration checks', '', '| Component | Status |', '|---|---|']
        rows.extend(f'| {n} | {"PASS" if p["pass"] else "FAIL"} |'
                    for n, p in report['probes'].items())
    rows += ['', '## Important limits', '',
             '- This is a SOURCE RESTORATION EXPERIMENT, not a Magisk Alpha 31100 module.',
             '- Git reverts do not prove Java/Rust API compatibility; only a real compile can.',
             '- Repackaging the manager does not remove SELinux signals or guarantee bank support.',
             '- No physical phone install/flash until Android 13 emulator, signatures and rollback are tested.', '']
    return '\n'.join(rows)


def perform(repo: Path, report_dir: Path, base: str = BASE_SHA,
            plan: tuple[tuple[str, str], ...] | None = None,
            verify_probes: bool = True) -> dict:
    """Apply reverse-chronological Git reverts without force-conflict resolution.

    Custom base and plans are for synthetic unit tests; production CLI pins them.
    """
    if plan is None:
        plan = tuple(reversed(COMMIT_MAP))
    report = {
        'generated_utc': datetime.now(timezone.utc).isoformat(),
        'expected_base': base, 'target': 'official Magisk 31.1 only',
        'status': 'NOT_STARTED', 'steps': [], 'conflicts': [], 'probes': {},
        'device_tested': False, 'flash_allowed': False,
    }
    report_dir.mkdir(parents=True, exist_ok=True)

    def finish(status: str, reason: str = '') -> dict:
        report['status'] = status
        report['reason'] = reason
        report['final_sha'] = git(repo, 'rev-parse', 'HEAD').stdout.strip()
        report['git_status'] = git(repo, 'status', '--porcelain').stdout.strip().splitlines()
        (report_dir / 'reconstruction.json').write_text(
            json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        (report_dir / 'reconstruction.md').write_text(report_md(report), encoding='utf-8')
        return report

    if not repo.is_dir() or not (repo / '.git').exists():
        return finish('FAILED_PREFLIGHT', 'Not an ordinary Git checkout')
    actual = git(repo, 'rev-parse', 'HEAD')
    if actual.returncode != 0 or actual.stdout.strip() != base:
        return finish('FAILED_PREFLIGHT', 'Checkout is not the exact expected source revision')
    if git(repo, 'status', '--porcelain').stdout.strip():
        return finish('FAILED_PREFLIGHT', 'Git tree must be clean before R2 reconstruction')
    for sha, desc in plan:
        if not re.fullmatch(r'[0-9a-f]{40}', sha):
            return finish('FAILED_PREFLIGHT', f'Invalid revision: {sha}')
        if git(repo, 'cat-file', '-t', sha).stdout.strip() != 'commit':
            return finish('FAILED_PREFLIGHT', f'Commit unavailable, fetch full history: {sha}')
        if git(repo, 'merge-base', '--is-ancestor', sha, base).returncode != 0:
            return finish('FAILED_PREFLIGHT', f'Removal commit not ancestral to base: {sha}')

    # This checkout is disposable (GitHub Actions runner), no external repo edits.
    git(repo, 'config', 'user.name', 'Magisk R2 source audit')
    git(repo, 'config', 'user.email', 'magisk-r2-ci@users.noreply.github.com')

    for sha, desc in plan:
        proc = git(repo, 'revert', '--no-edit', sha)
        step = {'sha': sha, 'description': desc,
                'result': 'PASS' if proc.returncode == 0 else 'CONFLICT_OR_ERROR',
                'stdout_tail': proc.stdout[-3000:], 'stderr_tail': proc.stderr[-5000:]}
        report['steps'].append(step)
        if proc.returncode != 0:
            report['conflicts'] = [p for p in git(repo, 'diff', '--name-only', '--diff-filter=U').stdout.strip().splitlines() if p]
            (report_dir / 'failure.txt').write_text(
                f'Unable to revert {sha} ({desc})\n\n{proc.stdout}\n{proc.stderr}\n'
                + '\n'.join(report['conflicts']) + '\n', encoding='utf-8')
            return finish('FAILED_CONFLICT', 'Source conflicts require explicit reviewed port fixes')

    report['probes'] = probe_tree(repo)
    missing = [x for x, p in report['probes'].items() if not p['pass']]
    if verify_probes and missing:
        return finish('FAILED_PROBES', 'Restoration incomplete: ' + ', '.join(missing))
    diff = git(repo, 'diff', '--binary', base, 'HEAD')
    if diff.returncode == 0:
        (report_dir / 'R2_REVERT_CANDIDATE.patch').write_text(diff.stdout, encoding='utf-8')
    return finish('CANDIDATE_RESTORED', 'All chosen source reverts applied; build and device tests still required')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--reports', type=Path, required=True)
    args = parser.parse_args()
    result = perform(args.repo, args.reports)
    print(report_md(result))
    return 0 if result['status'] == 'CANDIDATE_RESTORED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
