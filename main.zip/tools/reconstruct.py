#!/usr/bin/env python3
"""R2.2 experimental restoration of old Magisk Manager repackaging on official 31.1.

Operates only on a disposable local Git checkout. Conflicts fail closed; do NOT
make guesses about Android/Gradle/Rust merge resolutions. Never flashes a device.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path

BASE_SHA = '0972f67d97f9b6302b67c5171283330c74114b4a'
PRE_SHA = 'ea16c8141eb64dc28b56a0e7fb536689ef465429'
COMMIT_MAP = [
    ('58477458401a298c02604b99caf5afcdb9ed9e3f', 'App hide UI'),
    ('1240c2e35ca3f232d7a125238a33e634e9ab3231', 'App migration and signer'),
    ('7d9b0dfb3e58ab0959021533e0d19ba362b766a7', 'Dynamic stub loader'),
    ('5f2faee61879859004acb34811051f45d51a5191', 'Native manager verification'),
    ('447a8f9965198f32a125b6c2c33644ca9604976e', 'Shared manifest layout'),
    ('c86a8776cee88689dd684ec1dd7d584d77540110', 'Native stub embedding'),
    ('d22fea290654dcf7bad9128f79834535ee3f47c3', 'Gradle stub module'),
    ('e31ef291d401faa21c20fb791c38f1e60bedfa2e', 'Shared-module dependency'),
]

RESTORE_MARKERS = {
    'app_repackager': ('app/core/src/main/java/com/topjohnwu/magisk/core/tasks/AppMigration.kt',
                       ('patchAndHide(', 'restoreApp(', 'SignApk.sign(')),
    'stub_loader': ('app/shared/src/main/java/com/topjohnwu/magisk/StubApk.java', ('class StubApk',)),
    'stub_app': ('app/stub/src/main/java/com/topjohnwu/magisk/StubApplication.java', ('class StubApplication',)),
    'apk_signer': ('app/core/src/main/java/com/topjohnwu/magisk/core/signing/SignApk.java', ('class SignApk',)),
    'native_trust': ('native/src/core/package.rs', ('repackaged_pkg', 'get_manager_uid', 'trusted_cert',
                                                     'preserve_stub_apk', 'install_stub', 'get_app_id', 'is_headless')),
    'su_modern': ('native/src/core/su/daemon.rs', ('get_manager_uid(', 'settings.notify = false;')),

    'module_config': ('app/settings.gradle.kts', ('":stub"', '":shared"')),
    'native_version': ('app/gradle.properties', ('magisk.versionCode=31100',)),
}


def git(repo: Path, *args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(['git', '-C', str(repo), *args], text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)


def probe_tree(repo: Path) -> dict:
    result = {}
    for label, (file, needles) in RESTORE_MARKERS.items():
        p = repo / file
        raw = p.read_text(encoding='utf-8') if p.is_file() else ''
        result[label] = {'file': file, 'exists': p.is_file(),
                         'markers': {needle: needle in raw for needle in needles},
                         'pass': p.is_file() and all(needle in raw for needle in needles)}
    return result


def report_md(report: dict) -> str:
    status = report['status']
    rows = ['# Magisk Manager Hide Backport R2.2 — Integration', '',
            f"**Status: {status}**", '',
            f"Base: `{report['expected_base']}`", '',
            '| Reverted removal commit | Result |', '|---|---|']
    for step in report['steps']:
        rows.append(f"| `{step['sha'][:12]}` – {step['description']} | {step['result']} |")
    if report.get('conflicts'):
        rows += ['', '## Git merge conflicts', '']
        rows.extend('- `'+p+'`' for p in report['conflicts'])
    if report.get('probes'):
        rows += ['', '## Source restoration checks', '', '| Component | Status |', '|---|---|']
        rows.extend(f'| {n} | {"PASS" if p["pass"] else "FAIL"} |'
                    for n, p in report['probes'].items())
    rows += ['', '## Important limits', '',
             '- This is a SOURCE RESTORATION EXPERIMENT, not a Magisk Alpha 31100 module.',
             '- Git reverts do not prove Java/Rust API compatibility; only a real compile can.',
             '- Repackaging the manager does not remove SELinux signals or guarantee bank support.',
             '- No physical phone install/flash until Android 13 emulator, signatures and rollback are tested.', '']
    return '\n'.join(rows)




def resolve_shared_manifest_conflict(repo: Path, removal_sha: str, base: str) -> dict:
    """R2.2: review-only resolution of the one observed Magisk 31.1 manifest conflict.

    The original upstream change relocated shared module declarations into core.
    Between that change and v31.1, only enableOnBackInvokedCallback went from
    false to true in the core manifest. On reverse-revert, move that exact change
    back into shared, and restore the original core manifest verbatim. Reject
    any other upstream differences or any other unmerged files.
    """
    core_rel = 'app/core/src/main/AndroidManifest.xml'
    shared_rel = 'app/shared/src/main/AndroidManifest.xml'
    conflicts = [x for x in git(repo, 'diff', '--name-only', '--diff-filter=U').stdout.splitlines() if x]
    if conflicts != [core_rel]:
        return {'fixed': False, 'reason': f'Unexpected conflict files: {conflicts!r}'}

    def old_text(revision: str, path: str) -> str | None:
        proc = git(repo, 'show', f'{revision}:{path}')
        return proc.stdout if proc.returncode == 0 else None

    before = old_text(removal_sha + '^', core_rel)
    after = old_text(removal_sha, core_rel)
    final = old_text(base, core_rel)
    prior_shared = old_text(removal_sha + '^', shared_rel)
    target = repo / shared_rel
    if None in (before, after, final, prior_shared) or not target.is_file():
        return {'fixed': False, 'reason': 'Missing historical manifest or restored shared manifest'}
    if target.read_text(encoding='utf-8') != prior_shared:
        return {'fixed': False, 'reason': 'Restored shared manifest differs from pinned upstream parent'}
    before_flag = 'android:enableOnBackInvokedCallback="false"'
    after_flag = 'android:enableOnBackInvokedCallback="true"'
    if after.count(before_flag) != 1 or final != after.replace(before_flag, after_flag):
        return {'fixed': False, 'reason': 'Magisk 31.1 core manifest differs beyond the one reviewed callback flag'}
    if prior_shared.count(before_flag) != 1:
        return {'fixed': False, 'reason': 'Historical shared manifest lacks one unambiguous callback flag'}
    if '<<<<<<< ' in before or '>>>>>>> ' in before or before == after:
        return {'fixed': False, 'reason': 'Historical core manifest is malformed or not a relocation'}

    # The stock 31.1 callback behavior is preserved in restored :shared.
    (repo / core_rel).write_text(before, encoding='utf-8')
    target.write_text(prior_shared.replace(before_flag, after_flag), encoding='utf-8')
    stage = git(repo, 'add', '--', core_rel, shared_rel)
    if stage.returncode != 0:
        return {'fixed': False, 'reason': 'Git stage failed: ' + stage.stderr[-1500:]}
    cont = git(repo, '-c', 'core.editor=true', 'revert', '--continue')
    if cont.returncode != 0:
        return {'fixed': False, 'reason': 'git revert --continue failed: ' + cont.stderr[-2500:]}
    if (repo / core_rel).read_text(encoding='utf-8') != before:
        return {'fixed': False, 'reason': 'Post-commit core manifest differs from historical parent'}
    if (repo / shared_rel).read_text(encoding='utf-8') != prior_shared.replace(before_flag, after_flag):
        return {'fixed': False, 'reason': 'Post-commit shared callback does not match Magisk 31.1'}
    return {'fixed': True, 'reason': 'Reviewed manifest relocation; Android back callback flag preserved in :shared'}


def extract_braced_method(source: str, signature: str) -> str | None:
    """Extract one uniquely named Rust method by balanced curly braces.

    Used only for the known, pinned public upstream get_app_id method.
    Reject duplicate declarations and missing brace pairs rather than guessing.
    """
    found = list(re.finditer(re.escape(signature) + r"\s*\{", source))
    if len(found) != 1:
        return None
    start = source.rfind('\n', 0, found[0].start()) + 1
    open_brace = source.find('{', found[0].start())
    depth = 0
    for i in range(open_brace, len(source)):
        if source[i] == '{':
            depth += 1
        elif source[i] == '}':
            depth -= 1
            if depth == 0:
                return source[start:i+1]
    return None


def resolve_native_stub_embedding_conflict(repo: Path, removal_sha: str, base: str) -> dict:
    """Reconcile only the exactly observed native conflict from c86a8776c.

    package.rs: prefer the pre-removal stub management implementation, preserving
    the later Magisk 31.1 get_app_id addition and checked HSUM user exclusion.
    su/daemon.rs: retain the newer Magisk 31.1 authorization and notification
    logic (the old tuple-based manager interface is restored in package.rs).

    The result is a RESEARCH candidate, not a verified authorization port.
    Rejected on any extra conflict, changed source structure or missing anchor.
    """
    package = 'native/src/core/package.rs'
    su = 'native/src/core/su/daemon.rs'
    paths = git(repo, 'diff', '--name-only', '--diff-filter=U').stdout.splitlines()
    if sorted(paths) != sorted((package, su)):
        return {'fixed': False, 'reason': f'Unexpected conflicts: {paths!r}'}
    if removal_sha != 'c86a8776cee88689dd684ec1dd7d584d77540110' or base != BASE_SHA:
        return {'fixed': False, 'reason': 'Source revision not approved for the targeted native merge'}

    def stage(stage_index: int, relpath: str) -> str | None:
        res = git(repo, 'show', f':{stage_index}:{relpath}')
        return res.stdout if res.returncode == 0 else None

    pkg_ours, pkg_theirs = stage(2, package), stage(3, package)
    su_ours, su_theirs = stage(2, su), stage(3, su)
    if None in (pkg_ours, pkg_theirs, su_ours, su_theirs):
        return {'fixed': False, 'reason': 'Missing Git stage-2/3 source (unexpected conflict type)'}
    assert pkg_ours is not None and pkg_theirs is not None
    assert su_ours is not None and su_theirs is not None

    # Strong anchors: the old side must actually restore pre-removal stub
    # management; ours must preserve the new user manager authorization checks.
    expected_old = ('stub_apk_fd', 'fn install_stub(', 'pub fn preserve_stub_apk(',
                    'pub fn ensure_manager(', 'pub fn get_manager_uid(', 'self.is_headless')
    expected_pkg_now = ('pub fn get_app_id(', 'pub fn get_manager_uid(', 'self.is_headless')
    expected_su_now = ('get_manager_uid(', 'settings.log = false;', 'settings.notify = false;')
    if not all(x in pkg_theirs for x in expected_old):
        return {'fixed': False, 'reason': 'Theirs is missing approved upstream stub or HSUM anchors'}
    if not all(x in pkg_ours for x in expected_pkg_now):
        return {'fixed': False, 'reason': 'Ours is missing Magisk 31.1 manager API or HSUM anchors'}
    if not all(x in su_ours for x in expected_su_now):
        return {'fixed': False, 'reason': 'Current SU policy checks differ; cannot retain them safely'}
    if 'get_manager_uid(' in su_theirs and 'get_manager_uid(' not in su_ours:
        return {'fixed': False, 'reason': 'Unexpected new source does not support manager UID'}
    # Anchored to both the exact 31.1 base and the historical parent.
    historical_pkg = git(repo, 'show', f'{removal_sha}^:{package}')
    current_pkg = git(repo, 'show', f'{base}:{package}')
    current_su = git(repo, 'show', f'{base}:{su}')
    if any(x.returncode != 0 for x in (historical_pkg, current_pkg, current_su)):
        return {'fixed': False, 'reason': 'Unable to read pinned upstream source'}
    for needle in expected_old:
        if needle not in historical_pkg.stdout:
            return {'fixed': False, 'reason': f'Historical source lacks {needle}'}
    for needle in expected_pkg_now:
        if needle not in current_pkg.stdout:
            return {'fixed': False, 'reason': f'31.1 source lacks {needle}'}
    for needle in expected_su_now:
        if needle not in current_su.stdout:
            return {'fixed': False, 'reason': f'31.1 SU source lacks {needle}'}
    # Ensure that the conflict stage did not change the SU authorization source.
    # Note this file has not been touched by the two preceding reverts.
    if su_ours != current_su.stdout:
        return {'fixed': False, 'reason': 'Unexpected SU file drift before native conflict'}
    if pkg_ours != current_pkg.stdout:
        return {'fixed': False, 'reason': 'Unexpected package.rs drift before native conflict'}

    method = extract_braced_method(pkg_ours, 'pub fn get_app_id(&self, pkg: &str) -> i32')
    if not method or 'get_package_uid(user, pkg)' not in method:
        return {'fixed': False, 'reason': 'Cannot isolate original 31.1 get_app_id implementation'}
    if 'pub fn get_app_id(' in pkg_theirs:
        old_method = extract_braced_method(pkg_theirs, 'pub fn get_app_id(&self, pkg: &str) -> i32')
        if old_method != method:
            return {'fixed': False, 'reason': 'Conflicting get_app_id implementations'}
        revised_pkg = pkg_theirs
    else:
        boundary = pkg_theirs.rfind('\n}')
        if boundary < 0 or pkg_theirs[boundary:].strip() != '}':
            return {'fixed': False, 'reason': 'Unexpected package.rs end-of-impl structure'}
        revised_pkg = pkg_theirs[:boundary] + '\n' + method + '\n' + pkg_theirs[boundary:]

    # c86's historical package.rs uses get_package_uid(user); 5f's later
    # reverse-revert must restore the pkg-aware variant. The final probe and
    # real compiler MUST verify that interface. Never declare compile success.
    (repo / package).write_text(revised_pkg, encoding='utf-8')
    (repo / su).write_text(su_ours, encoding='utf-8')
    st = git(repo, 'add', '--', package, su)
    if st.returncode != 0:
        return {'fixed': False, 'reason': 'Cannot stage reviewed native files: ' + st.stderr[-1500:]}
    done = git(repo, '-c', 'core.editor=true', 'revert', '--continue')
    if done.returncode != 0:
        return {'fixed': False, 'reason': 'Native revert continuation failed: ' + done.stderr[-2200:]}
    if (repo / su).read_text() != su_ours or method not in (repo / package).read_text():
        return {'fixed': False, 'reason': 'Post-commit verification of native merge failed'}
    return {'fixed': True, 'reason':
            'Historical stub source + pinned 31.1 get_app_id; modern su authorization retained; build test required'}


def preserve_conflict_evidence(repo: Path, report_dir: Path, conflicts: list[str], sha: str) -> None:
    """Export up to 10 original Git stages and conflict markers for debugging.

    These are public Magisk source files; no credentials or device data.
    """
    target = report_dir / 'conflict_sources'
    target.mkdir(parents=True, exist_ok=True)
    for path in conflicts[:10]:
        # Avoid writing unexpected paths outside diagnostics.
        if path.startswith('/') or '..' in Path(path).parts:
            continue
        label = path.replace('/', '__')
        for stage_id in (1, 2, 3):
            source = git(repo, 'show', f':{stage_id}:{path}')
            if source.returncode == 0:
                (target / f'{label}.stage{stage_id}.txt').write_text(source.stdout, encoding='utf-8')
        work = repo / path
        if work.is_file():
            (target / f'{label}.conflicted.txt').write_text(work.read_text(encoding='utf-8'), encoding='utf-8')
    (report_dir / 'conflict_commit.txt').write_text(sha + '\n', encoding='utf-8')


def perform(repo: Path, report_dir: Path, base: str = BASE_SHA,
            plan: tuple[tuple[str, str], ...] | None = None,
            verify_probes: bool = True) -> dict:
    """Apply reverse-chronological Git reverts without force-conflict resolution.

    Custom base and plans are for synthetic unit tests; production CLI pins them.
    """
    if plan is None:
        plan = tuple(reversed(COMMIT_MAP))
    report = {
        'generated_utc': datetime.now(timezone.utc).isoformat(),
        'expected_base': base, 'target': 'official Magisk 31.1 only',
        'status': 'NOT_STARTED', 'steps': [], 'conflicts': [], 'probes': {},
        'device_tested': False, 'flash_allowed': False,
    }
    report_dir.mkdir(parents=True, exist_ok=True)

    def finish(status: str, reason: str = '') -> dict:
        report['status'] = status
        report['reason'] = reason
        report['final_sha'] = git(repo, 'rev-parse', 'HEAD').stdout.strip()
        report['git_status'] = git(repo, 'status', '--porcelain').stdout.strip().splitlines()
        (report_dir / 'reconstruction.json').write_text(
            json.dumps(report, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
        (report_dir / 'reconstruction.md').write_text(report_md(report), encoding='utf-8')
        return report

    if not repo.is_dir() or not (repo / '.git').exists():
        return finish('FAILED_PREFLIGHT', 'Not an ordinary Git checkout')
    actual = git(repo, 'rev-parse', 'HEAD')
    if actual.returncode != 0 or actual.stdout.strip() != base:
        return finish('FAILED_PREFLIGHT', 'Checkout is not the exact expected source revision')
    if git(repo, 'status', '--porcelain').stdout.strip():
        return finish('FAILED_PREFLIGHT', 'Git tree must be clean before R2 reconstruction')
    for sha, desc in plan:
        if not re.fullmatch(r'[0-9a-f]{40}', sha):
            return finish('FAILED_PREFLIGHT', f'Invalid revision: {sha}')
        if git(repo, 'cat-file', '-t', sha).stdout.strip() != 'commit':
            return finish('FAILED_PREFLIGHT', f'Commit unavailable, fetch full history: {sha}')
        if git(repo, 'merge-base', '--is-ancestor', sha, base).returncode != 0:
            return finish('FAILED_PREFLIGHT', f'Removal commit not ancestral to base: {sha}')

    # This checkout is disposable (GitHub Actions runner), no external repo edits.
    git(repo, 'config', 'user.name', 'Magisk R2 source audit')
    git(repo, 'config', 'user.email', 'magisk-r2-ci@users.noreply.github.com')

    for sha, desc in plan:
        proc = git(repo, 'revert', '--no-edit', sha)
        step = {'sha': sha, 'description': desc,
                'result': 'PASS' if proc.returncode == 0 else 'CONFLICT_OR_ERROR',
                'stdout_tail': proc.stdout[-3000:], 'stderr_tail': proc.stderr[-5000:]}
        report['steps'].append(step)
        if proc.returncode != 0:
            # Only two specifically observed conflicts have pinned, anchored resolutions.
            if sha == 'e31ef291d401faa21c20fb791c38f1e60bedfa2e':
                resolution = resolve_shared_manifest_conflict(repo, sha, base)
                step['resolution'] = resolution
                if resolution['fixed']:
                    step['result'] = 'REVIEWED_MANIFEST_FIX'
                    continue
            elif sha == 'c86a8776cee88689dd684ec1dd7d584d77540110' and base == BASE_SHA:
                resolution = resolve_native_stub_embedding_conflict(repo, sha, base)
                step['resolution'] = resolution
                if resolution['fixed']:
                    step['result'] = 'REVIEWED_NATIVE_HYBRID'
                    continue
            report['conflicts'] = [p for p in git(repo, 'diff', '--name-only', '--diff-filter=U').stdout.strip().splitlines() if p]
            preserve_conflict_evidence(repo, report_dir, report['conflicts'], sha)
            (report_dir / 'failure.txt').write_text(
                f'Unable to revert {sha} ({desc})\n\n{proc.stdout}\n{proc.stderr}\n'
                + '\n'.join(report['conflicts']) + '\n', encoding='utf-8')
            # Keep any completed revert commits for review even on later conflicts.
            diff = git(repo, 'diff', '--binary', base, 'HEAD')
            if diff.returncode == 0 and diff.stdout.strip():
                (report_dir / 'R2_2_COMPLETED_REVERTS_ONLY.patch').write_text(diff.stdout, encoding='utf-8')
            return finish('FAILED_CONFLICT', 'Unreviewed source conflicts; no blind merge')

    report['probes'] = probe_tree(repo)
    missing = [x for x, p in report['probes'].items() if not p['pass']]
    if verify_probes and missing:
        return finish('FAILED_PROBES', 'Restoration incomplete: ' + ', '.join(missing))
    diff = git(repo, 'diff', '--binary', base, 'HEAD')
    if diff.returncode == 0:
        (report_dir / 'R2_2_REVERT_CANDIDATE.patch').write_text(diff.stdout, encoding='utf-8')
    return finish('CANDIDATE_RESTORED', 'All chosen source reverts applied; build and device tests still required')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--reports', type=Path, required=True)
    args = parser.parse_args()
    result = perform(args.repo, args.reports)
    print(report_md(result))
    return 0 if result['status'] == 'CANDIDATE_RESTORED' else 1


if __name__ == '__main__':
    raise SystemExit(main())
