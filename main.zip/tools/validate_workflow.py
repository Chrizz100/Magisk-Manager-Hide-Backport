#!/usr/bin/env python3
"""Check R2 workflow structure, source pins and physical-device safety gates."""
from __future__ import annotations
import argparse, re, sys
from pathlib import Path


def validate(text: str) -> list[str]:
    errors = []
    must = (
        'source-audit:', 'reconstruct-and-build:', 'persist-credentials: false',
        'ea16c8141eb64dc28b56a0e7fb536689ef465429',
        '0972f67d97f9b6302b67c5171283330c74114b4a',
        'python3 kit/tools/reconstruct.py --repo magisk --reports reports',
        'R2_RECONSTRUCTION_AND_BUILD_REPORT', 'submodules: recursive',
        'fetch-depth: 0', 'DO_NOT_INSTALL_OR_FLASH.txt', 'if: always()',
        'sha256sum -c MANIFEST.sha256', 'cmp .github/workflows/build.yml kit/.github/workflows/build.yml',
    )
    for part in must:
        if part not in text:
            errors.append('Missing required token: ' + part)
    if re.search(r'\b(fastboot\s+(flash|boot)|adb\s+install|adb\s+shell\s+su|magisk\s+--install-module)\b', text, flags=re.I):
        errors.append('Workflow contains forbidden device install/flash command')
    if 'continue-on-error: true' in text:
        errors.append('Fail-closed restoration must not continue after errors')
    try:
        import yaml
        y = yaml.safe_load(text)
        if not isinstance(y, dict) or not isinstance(y.get('jobs'), dict):
            errors.append('Invalid YAML job map')
        elif set(y['jobs']) != {'source-audit', 'reconstruct-and-build'}:
            errors.append('Workflow must contain exactly R2 audit and candidate jobs')
        else:
            steps = y['jobs']['reconstruct-and-build']['steps']
            titles = [s.get('name', '') for s in steps]
            revert = next((i for i,n in enumerate(titles) if 'Revert all 8' in n), -1)
            build = next((i for i,n in enumerate(titles) if 'Compile source candidate' in n), -1)
            if revert < 0 or build < 0 or revert >= build:
                errors.append('Compile must follow a completed restoration gate')
            if y['jobs']['reconstruct-and-build'].get('needs') != 'source-audit':
                errors.append('Candidate build must depend on the source audit')
            uploader = next((s for s in steps if s.get('name') == 'Upload reconstruction evidence and build diagnostics'), {})
            if uploader.get('if') != 'always()':
                errors.append('Diagnostics must be uploaded on failure')
    except Exception as exc:
        errors.append('YAML validation failed: ' + str(exc))
    return errors


def main():
    p = argparse.ArgumentParser()
    p.add_argument('workflow', type=Path)
    a = p.parse_args()
    try:
        issues = validate(a.workflow.read_text(encoding='utf-8'))
    except OSError as exc:
        issues = [str(exc)]
    for i in issues:
        print('ERROR:', i)
    print('R2 workflow preflight:', 'PASS' if not issues else 'FAIL')
    return 0 if not issues else 1

if __name__ == '__main__':
    sys.exit(main())
