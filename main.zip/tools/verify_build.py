#!/usr/bin/env python3
"""Static APK inspection (NOT a device/runtime compatibility test)."""
import argparse
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, BadZipFile


def verify(apk: Path) -> dict:
    result = {'file': str(apk), 'exists': apk.is_file(), 'sha256': None,
              'file_size': 0, 'passed': False, 'has_manifest': False, 'has_classes': False,
              'has_arm64_binary': False, 'archive_valid': False}
    if not apk.is_file():
        return result
    result['file_size'] = apk.stat().st_size
    result['sha256'] = hashlib.sha256(apk.read_bytes()).hexdigest()
    try:
        with ZipFile(apk, 'r') as zf:
            names = zf.namelist()
            result['archive_valid'] = zf.testzip() is None
            result['has_manifest'] = 'AndroidManifest.xml' in names
            result['has_classes'] = 'classes.dex' in names
            result['has_arm64_binary'] = any(n.startswith('lib/arm64-v8a/') and n.endswith('.so') for n in names)
    except (BadZipFile, OSError):
        pass
    result['passed'] = (result['archive_valid'] and result['has_manifest']
                        and result['has_classes'] and result['has_arm64_binary'])
    return result


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--apk', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    result = verify(args.apk)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
