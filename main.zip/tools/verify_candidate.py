#!/usr/bin/env python3
"""Read-only Magisk research APK ABI and archive structure checker."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from zipfile import ZipFile, BadZipFile


def check(apk: Path) -> dict:
    result = {'apk': str(apk), 'ok': False, 'arm64': False, 'arm32': False,
              'manifest': False, 'dex': False, 'sha256': None,
              'limitations': ['Archive structure is not app signature validation.',
                              'Android 13 runtime tests were not performed.',
                              'APK is NOT Magisk Alpha 31100 and must not be installed on phone.']}
    if not apk.is_file():
        return result
    try:
        with ZipFile(apk) as z:
            names = set(z.namelist())
            result['arm64'] = any(n.startswith('lib/arm64-v8a/') and n.endswith('.so') for n in names)
            result['arm32'] = any(n.startswith('lib/armeabi-v7a/') and n.endswith('.so') for n in names)
            result['manifest'] = 'AndroidManifest.xml' in names
            result['dex'] = any(n.startswith('classes') and n.endswith('.dex') for n in names)
            result['ok'] = z.testzip() is None and all(result[x] for x in ['arm64','arm32','manifest','dex'])
        h = hashlib.sha256()
        with apk.open('rb') as f:
            for piece in iter(lambda: f.read(1024 * 1024), b''):
                h.update(piece)
        result['sha256'] = h.hexdigest()
    except (BadZipFile, OSError):
        result['error'] = 'Invalid ZIP/APK archive'
    return result


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--apk', required=True, type=Path)
    p.add_argument('--output', required=True, type=Path)
    a = p.parse_args()
    result = check(a.apk)
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))
    return 0 if result['ok'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
